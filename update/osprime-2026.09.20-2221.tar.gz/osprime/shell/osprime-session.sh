#!/usr/bin/env bash
# OSprime graphical session: labwc compositor + kiosk chat.
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export XDG_SESSION_TYPE=wayland
export XDG_CURRENT_DESKTOP=labwc
export MOZ_ENABLE_WAYLAND=1
export QT_QPA_PLATFORM=wayland

# Cursor. wlroots draws nothing at all if no XCursor theme is named, which
# presents as an invisible pointer that still clicks.
export XCURSOR_THEME="${XCURSOR_THEME:-Adwaita}"
export XCURSOR_SIZE="${XCURSOR_SIZE:-24}"
export XCURSOR_PATH="${XCURSOR_PATH:-/usr/share/icons:$HOME/.local/share/icons}"

# Second, separate cause of an invisible pointer: on virtualised GPUs
# (VMware, VirtualBox, QEMU) wlroots allocates the hardware cursor plane in
# system memory and the guest driver never scans it out. Software cursors
# cost nothing here and always draw.
if [ -z "${WLR_NO_HARDWARE_CURSORS:-}" ] && \
   grep -qiE 'vmware|virtualbox|qemu|kvm|innotek|microsoft corporation' \
        /sys/class/dmi/id/sys_vendor /sys/class/dmi/id/product_name 2>/dev/null; then
    export WLR_NO_HARDWARE_CURSORS=1
fi
# Which graphics card drives the screen.
#
# A laptop with two GPUs has one that is wired to the panel — the built-in
# one — and one that is not. wlroots picks whichever DRM device it finds
# first, and installing an NVIDIA driver changed which that was: the
# compositor tried to start on a card with no display attached and the
# desktop stopped coming up at all. The machine was fine; nothing was
# broken; there was simply no screen on the card it chose.
#
# So choose deliberately: the card with a connected connector. This is a
# no-op on a desktop with one GPU, and it is what makes installing a
# graphics driver a safe thing to do on a laptop.
# Taking the first card with a connected connector was not enough. Once the
# NVIDIA driver is loaded, more than one card can report a connected
# connector, and "first" then depends on probe order — which is exactly the
# thing that changed and broke the desktop.
#
# So the rule is explicit: among the cards that have something connected,
# prefer one that is NOT the discrete NVIDIA card. On a laptop the panel is
# wired to the integrated GPU and that is where a compositor belongs; the
# discrete card is for compute. A machine with only an NVIDIA card still
# gets it, through the fallback.
_pick_display_card() {
    local card conn drv connected best="" fallback=""
    for card in /sys/class/drm/card[0-9]*; do
        [ -e "$card/device" ] || continue
        drv="$(basename "$(readlink -f "$card/device/driver" 2>/dev/null)" 2>/dev/null)"
        connected=no
        for conn in "$card"-*; do
            [ -f "$conn/status" ] || continue
            if grep -q '^connected' "$conn/status" 2>/dev/null; then
                connected=yes
                break
            fi
        done
        echo "  card $(basename "$card"): driver=${drv:-unknown} connected=$connected" >&2
        [ "$connected" = yes ] || continue
        [ -n "$fallback" ] || fallback="$card"
        case "$drv" in
            nvidia*|nouveau) ;;
            *) [ -n "$best" ] || best="$card" ;;
        esac
    done
    [ -n "${best:-$fallback}" ] && basename "${best:-$fallback}"
}

if [ -z "${WLR_DRM_DEVICES:-}" ]; then
    _chosen="$(_pick_display_card 2>/tmp/osprime-drm-scan.log)"
    [ -n "$_chosen" ] && export WLR_DRM_DEVICES="/dev/dri/$_chosen"
fi

mkdir -p "$XDG_RUNTIME_DIR" 2>/dev/null
chmod 700 "$XDG_RUNTIME_DIR" 2>/dev/null

LOG=/tmp/osprime-shell.log
HERE="$(cd "$(dirname "$0")" && pwd)"
{
  echo "=== OSprime session $(date) ==="
  echo "user=$(id -un) uid=$(id -u) tty=$(tty)"
  echo "XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR"
  echo "dri: $(ls /dev/dri 2>&1 | tr '\n' ' ')"
  echo "display card: ${WLR_DRM_DEVICES:-(wlroots chooses)}"
  echo "what the scan saw:"
  cat /tmp/osprime-drm-scan.log 2>/dev/null
  echo "labwc: $(command -v labwc || echo MISSING)"
} > "$LOG" 2>&1

# Wait for the web UI, but do NOT block the desktop on it. Previously the
# session existed only to show the chat, so waiting made sense. Now the
# desktop is the product: it must come up even if the agent is broken.
for _ in $(seq 1 30); do
    (echo > /dev/tcp/127.0.0.1/8080) 2>/dev/null && break
    sleep 0.5
done
echo "web-ui reachable: $?" >> "$LOG"

# Read the compositor config straight from /opt/osprime, not from the home
# directory. Updates replace /opt/osprime but never touch ~/.config, so the
# home copy silently went stale — Super+D kept launching the old menu long
# after the config had changed. One location, and updates reach it.
LABWC_CONF="$HERE/labwc"
[ -d "$LABWC_CONF" ] || LABWC_CONF="$HOME/.config/labwc"

# The user's own keyboard shortcuts are merged in here, into a copy under
# the runtime directory. They cannot live in the shipped config: that is in
# /opt and every update replaces it.
#
# Best-effort by construction. If anything about the merge fails, the
# shipped config is used unchanged — a broken shortcut must never be the
# reason a desktop does not appear.
MERGED="$XDG_RUNTIME_DIR/osprime-labwc"
if python3 - "$LABWC_CONF" "$MERGED" >>"$LOG" 2>&1 <<'PY'
import json, pathlib, shutil, sys
base, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
rc = (base / "rc.xml").read_text(encoding="utf-8")
try:
    user = json.loads(pathlib.Path("/etc/osprime/shortcuts.json")
                      .read_text(encoding="utf-8"))
except Exception:
    user = {}
actions = {
    "screenshot": "bash /opt/osprime/shell/osprime-screenshot.sh area",
    "full screenshot": "bash /opt/osprime/shell/osprime-screenshot.sh full",
    "chat": "bash /opt/osprime/shell/osprime-toggle.sh",
    "terminal": "foot",
    "apps": "bash /opt/osprime/shell/osprime-apps.sh",
    "browser": "bash /opt/osprime/shell/osprime-browser.sh",
    "files": "thunar",
    "settings": "bash /opt/osprime/shell/osprime-settings.sh",
}
extra = [f'    <keybind key="{k}"><action name="Execute"><command>'
         f'{actions[v]}</command></action></keybind>'
         for k, v in sorted(user.items()) if v in actions]
if extra:
    rc = rc.replace("</keyboard>", "\n".join(extra) + "\n  </keyboard>", 1)
out.mkdir(parents=True, exist_ok=True)
for name in ("menu.xml", "autostart", "environment"):
    src = base / name
    if src.is_file():
        shutil.copy2(src, out / name)
(out / "rc.xml").write_text(rc, encoding="utf-8")
print(f"merged {len(extra)} user shortcut(s)")
PY
then
    LABWC_CONF="$MERGED"
else
    echo "shortcut merge failed — using the shipped config" >> "$LOG"
fi
echo "labwc config: $LABWC_CONF" >> "$LOG"
labwc -C "$LABWC_CONF" >>"$LOG" 2>&1
echo "labwc exited with status $?" >> "$LOG"
