#!/usr/bin/env python3
"""OSprime web UI: stdlib-only HTTP server that serves an RTL chat page
and bridges it to the agent daemon's Unix socket.

Run:  python3 ui/web.py   →  open http://localhost:8080
"""

import http.server
import json
import os
import pathlib
import socket
import sys
import threading
import time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "agent"))
import i18n
import control_panel
import system_tools
import updater
import voice


SECRETS_PATH = pathlib.Path(os.environ.get("OSPRIME_SECRETS",
                                           "/etc/osprime/secrets.env"))


def _plain(msg: str) -> str:
    """Strip the ERROR: marker before showing a message to a person.

    The prefix exists so the assistant cannot mistake a failure for a
    success. It means nothing to the user reading a settings window.
    """
    return msg[6:].strip() if msg.startswith("ERROR:") else msg


def _read_settings() -> dict:
    """One read, from the same place the assistant reads."""
    out = json.loads(system_tools.get_settings())
    t = system_tools.get_time()
    try:
        # "automatic_sync", not "auto_sync". There were two get_time()
        # functions in system_tools for months — Python kept the second and
        # silently discarded the first, and this line was reading the dead
        # one's key name. .get(..., False) turned that into a permanent
        # "off": the clock's automatic-sync switch in Settings showed off
        # even with NTP running. No error, no log, just a wrong answer.
        out["auto_time"] = bool(json.loads(t)["automatic_sync"])
    except (json.JSONDecodeError, KeyError):
        out["auto_time"] = False
    net = system_tools.network_status()
    try:
        out["network"] = ", ".join(n["name"] for n in json.loads(net))
    except json.JSONDecodeError:
        # _plain, not the raw string: "ERROR: could not read network
        # status" is a sentence for a log, not for a label in a window.
        out["network"] = _plain(net)
    out["has_api_key"] = "ANTHROPIC_API_KEY" in _read_secrets()
    return out


def _overview() -> dict:
    """Everything the "This machine" page shows, in one request.

    Six separate fetches for one page is six chances for one of them to
    fail quietly and leave a card reading "unknown" with no reason. This
    assembles them here, where a failure can be caught and named.

    Nothing in here touches the agent. This page has to render on a machine
    whose model will not load — that is precisely when someone opens it.
    """
    out = {"version": _version()}
    try:
        out.update(json.loads(system_tools.system_summary()))
    except Exception:
        pass
    try:
        out.update(json.loads(system_tools.model_status()))
    except Exception:
        # model_status returns a plain ERROR string when the hardware
        # profile cannot be read. The page copes with the keys missing.
        pass
    try:
        out["network"] = ", ".join(
            n["name"] for n in json.loads(system_tools.network_status()))
    except Exception:
        out["network"] = ""
    return out


def _memory_db():
    """Read the assistant's memory without going through the assistant.

    Its own connection to the same SQLite file, not a call into the agent.
    The Control Panel has to work when the agent is dead, and "what has this
    thing remembered about me" is a question a person is entitled to an
    answer to whether or not the model will load. SQLite in WAL mode is
    built for exactly this — one writer, other readers.
    """
    import memory as memory_mod
    path = os.environ.get("OSPRIME_MEMORY_DB", "/var/lib/osprime/memory.db")
    return memory_mod.Memory(path)


def _memory_list() -> dict:
    try:
        mem = _memory_db()
        return {"ok": True, "count": mem.count(), "memories": mem.all(200)}
    except Exception as e:
        return {"ok": False, "count": 0, "memories": [], "message": str(e)}


def _storage() -> dict:
    out = {}
    try:
        out["usage"] = json.loads(system_tools.disk_usage())
    except Exception:
        out["usage"] = None
    try:
        out["drives"] = json.loads(system_tools.list_drives())
    except Exception:
        out["drives"] = []
    return out


def _read_secrets() -> dict:
    out = {}
    try:
        for line in SECRETS_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except Exception:
        pass
    return out


def _apply_setting(key: str, value) -> dict:
    """Every branch calls the same function the assistant would call, so the
    two interfaces cannot disagree about what a setting means."""
    try:
        if key == "wallpaper":
            msg = system_tools.set_wallpaper(str(value))
        elif key == "language":
            msg = system_tools.set_language(str(value))
        elif key == "timezone":
            msg = system_tools.set_timezone(str(value))
        elif key == "time":
            msg = system_tools.set_time(str(value))
        elif key == "auto_time":
            msg = system_tools.set_auto_time(bool(value))
        elif key == "volume":
            msg = system_tools.set_volume(value)
        elif key == "scale":
            msg = system_tools.set_display(scale=str(value))
        elif key == "resolution":
            msg = system_tools.set_display(resolution=str(value))
        elif key == "desktop":
            system_tools._write_env("OSPRIME_DESKTOP",
                                    "yes" if value else "no")
            msg = ("desktop on — log out and back in to see it"
                   if value else "desktop off — log out and back in")
        elif key == "confirm_level":
            msg = system_tools.set_confirm_level(str(value))
        elif key == "cloud_mode":
            if str(value) not in ("off", "ask", "auto"):
                return {"ok": False, "message": "unknown cloud mode"}
            system_tools._write_env("OSPRIME_CLOUD_MODE", str(value))
            msg = "cloud mode saved — restart the assistant to apply"
        elif key == "api_key":
            v = str(value or "").strip()
            if not v:
                return {"ok": False, "message": "no key given"}
            SECRETS_PATH.parent.mkdir(parents=True, exist_ok=True)
            lines = [l for l in (SECRETS_PATH.read_text(encoding="utf-8").splitlines()
                                 if SECRETS_PATH.exists() else [])
                     if not l.startswith("ANTHROPIC_API_KEY=")]
            lines.append(f"ANTHROPIC_API_KEY={v}")
            SECRETS_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
            SECRETS_PATH.chmod(0o600)
            msg = "key saved on this machine"
        else:
            return {"ok": False, "message": f"unknown setting: {key}"}
    except Exception as e:
        return {"ok": False, "message": str(e)}

    # system_tools marks every failure with an ERROR: prefix, which replaces
    # the previous guesswork of matching phrases inside the message.
    return {"ok": not msg.startswith("ERROR:"), "message": _plain(msg)}


def _version() -> str:
    for p in (pathlib.Path(__file__).resolve().parent.parent / "VERSION",
              pathlib.Path("/opt/osprime/VERSION")):
        try:
            return p.read_text(encoding="utf-8").strip()
        except Exception:
            continue
    return "dev"

SOCKET_PATH = os.environ.get("OSPRIME_SOCKET", "/run/osprime/agent.sock")
PROFILE_PATH = pathlib.Path(os.environ.get("OSPRIME_PROFILE", "/etc/osprime/profile.json"))
PORT = int(os.environ.get("OSPRIME_WEB_PORT", "8080"))

_sessions = {}
_lock = threading.Lock()

# A conversation nobody has spoken in for this long is over. The number is
# generous on purpose: someone who walks away mid-thought and comes back
# after lunch should find their conversation, not a blank window.
IDLE_TIMEOUT = 30 * 60


def get_session(sid: str):
    """One persistent daemon connection per browser session (keeps history)."""
    with _lock:
        if sid not in _sessions:
            sk = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sk.connect(SOCKET_PATH)
            _sessions[sid] = {"sock": sk, "f": sk.makefile("rwb"),
                              "lock": threading.Lock(), "seen": time.time()}
        _sessions[sid]["seen"] = time.time()
        return _sessions[sid]


def end_session(sid: str) -> bool:
    """Close one conversation.

    Closing the socket is what tells the agent the conversation is over, and
    the agent's own end-of-conversation work — reading the exchange and
    keeping the few durable facts in it — runs at exactly that moment.
    Nothing ever closed these, so that step had effectively never run
    outside a service restart: the assistant was not learning anything from
    talking to anyone.
    """
    with _lock:
        sess = _sessions.pop(sid, None)
    if not sess:
        return False
    for closer in (sess["f"].close, sess["sock"].close):
        try:
            closer()
        except Exception:
            pass
    return True


def _reap_idle_sessions():
    """Close conversations that have gone quiet, forever, in the background.

    The browser says goodbye when it can, but a window that is killed, a
    machine that sleeps, or a tab that crashes says nothing at all. Without
    this the sockets accumulate one per chat window opened, for as long as
    the service runs.
    """
    while True:
        time.sleep(60)
        cutoff = time.time() - IDLE_TIMEOUT
        for sid in [s for s, v in list(_sessions.items())
                    if v.get("seen", 0) < cutoff]:
            if end_session(sid):
                print(f"conversation {sid[:8]} ended after being idle")


def session_send(sess, obj):
    with sess["lock"]:
        sess["f"].write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
        sess["f"].flush()


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # Pictures the assistant refers to are shown in the chat, which means the
    # page has to be able to fetch them. Deliberately narrow: images only,
    # inside the user's own home directory, resolved before it is checked so
    # a path full of ".." cannot walk out of it.
    _IMAGE_TYPES = {".png": "image/png", ".jpg": "image/jpeg",
                    ".jpeg": "image/jpeg", ".gif": "image/gif",
                    ".webp": "image/webp", ".bmp": "image/bmp"}

    def _serve_file(self):
        import urllib.parse
        raw = urllib.parse.parse_qs(self.path.split("?", 1)[1]).get("path", [""])[0]
        try:
            p = pathlib.Path(raw).resolve()
            home = pathlib.Path(os.path.expanduser(
                "~" + (os.environ.get("SUDO_USER") or "osprime"))).resolve()
            ctype = self._IMAGE_TYPES.get(p.suffix.lower())
            if ctype is None or not p.is_file() or home not in p.parents:
                self._json({"error": "not available"}, 404)
                return
            data = p.read_bytes()
        except Exception:
            self._json({"error": "not available"}, 404)
            return
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/":
            # Locale is resolved per request, so changing it in settings takes
            # effect on reload instead of needing a service restart.
            code = i18n.lang()
            # The version is shown in the header on purpose: a stale service
            # left running from an older install is otherwise indistinguishable
            # from a fresh one, and costs an hour of chasing the wrong build.
            data = (PAGE.replace("{{LANG}}", code)
                        .replace("{{DIR}}", "rtl" if i18n.is_rtl(code) else "ltr")
                        .replace("{{VERSION}}", _version())).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif self.path == "/settings":
            code = i18n.lang()
            data = (control_panel.PAGE.replace("{{LANG}}", code)
                    .replace("{{DIR}}", "rtl" if i18n.is_rtl(code) else "ltr")
                    .replace("{{VERSION}}", _version())).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif self.path.startswith("/api/file?"):
            self._serve_file()
        elif self.path == "/api/settings":
            self._json(_read_settings())
        elif self.path == "/api/display":
            raw = system_tools.get_display()
            try:
                self._json({"screens": json.loads(raw)})
            except json.JSONDecodeError:
                self._json({"screens": [], "message": _plain(raw)})
        elif self.path == "/api/wifi/scan":
            raw = system_tools.list_wifi()
            try:
                self._json({"networks": json.loads(raw)})
            except json.JSONDecodeError:
                self._json({"networks": [], "message": _plain(raw)})
        elif self.path == "/api/overview":
            self._json(_overview())
        elif self.path == "/api/memory":
            self._json(_memory_list())
        elif self.path == "/api/storage":
            self._json(_storage())
        elif self.path == "/api/backups":
            self._json({"backups": list(reversed(updater.status()["backups"]))})
        elif self.path == "/api/profile":
            self._json({"exists": PROFILE_PATH.exists()})
        elif self.path == "/api/update/check":
            # Deliberately not routed through the assistant. Asked to install an
            # update the model invented `sudo /path/to/update/install.sh`, and
            # the fix for that behaviour lives inside the update it refuses to
            # install. Keeping a system's own update path behind a 1.5B model's
            # tool choice is a design error; this is the way out of it.
            self._json(updater.check())
        elif self.path == "/api/voice/status":
            self._json(voice.status())
        elif self.path == "/api/notifications":
            try:
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.connect(SOCKET_PATH)
                sf = s.makefile("rwb")
                sf.write(b'{"type": "poll_notifications"}\n'); sf.flush()
                resp = json.loads(sf.readline())
                s.close()
                self._json(resp)
            except Exception as e:
                self._json({"items": [], "error": str(e)})
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length)

        if self.path == "/api/stt":
            suffix = "." + (self.headers.get("X-Audio-Ext") or "webm").lstrip(".")
            lang = self.headers.get("X-Audio-Lang") or "auto"
            try:
                text = voice.transcribe(raw, suffix, lang)
            except Exception as e:
                text = f"ERROR: {e}"
            if text.startswith("ERROR:"):
                self._json({"ok": False, "error": text[6:].strip()})
            else:
                self._json({"ok": True, "text": text})
            return

        if self.path == "/api/tts":
            try:
                payload = json.loads(raw)
                wav = voice.synthesize(payload.get("text", ""))
            except Exception:
                wav = b""
            if not wav:
                self.send_response(503)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(wav)))
            self.end_headers()
            self.wfile.write(wav)
            return

        # Tolerate an empty body. Endpoints that take no arguments were
        # failing here before reaching their handler, because this parsed
        # every remaining POST as JSON unconditionally.
        try:
            body = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            body = {}

        if self.path == "/api/confirm":
            try:
                sess = get_session(body["session"])
                session_send(sess, {"type": "confirm_response",
                                    "id": body["id"], "approved": bool(body["approved"])})
                self._json({"ok": True})
            except Exception as e:
                self._json({"ok": False, "error": str(e)})
            return
        if self.path == "/api/settings":
            self._json(_apply_setting(body.get("key", ""), body.get("value")))
            return

        if self.path == "/api/wifi/connect":
            msg = system_tools.connect_wifi(body.get("ssid", ""),
                                            body.get("password", ""))
            self._json({"ok": not msg.startswith("ERROR:"),
                        "message": _plain(msg)})
            return

        if self.path == "/api/wifi/forget":
            msg = system_tools.forget_wifi(body.get("ssid", ""))
            self._json({"ok": not msg.startswith("ERROR:"),
                        "message": _plain(msg)})
            return

        if self.path == "/api/update/install":
            # restart=False deliberately. Restarting the services is part of an
            # update, but osprime-web is one of them — doing it inline kills
            # this very connection before the reply is written, and the browser
            # reports "Failed to fetch" for an update that actually succeeded.
            try:
                result = updater.update(restart=False)
                ok = updater.succeeded(result)
            except Exception as e:
                result, ok = f"update failed: {e}", False
            self._json({"ok": ok, "message": result,
                        "version": updater.current_version()})
            if ok:
                # Answer first, restart a moment later.
                threading.Timer(1.0, updater.restart_services).start()
            return

        if self.path == "/api/memory/forget":
            try:
                mem = _memory_db()
                if body.get("all"):
                    n = mem.forget_all()
                    self._json({"ok": True,
                                "message": f"forgot {n} things" if n
                                else "there was nothing to forget"})
                else:
                    ok = mem.forget(body.get("id"))
                    self._json({"ok": ok, "message": "forgotten" if ok
                                else "that memory is already gone"})
            except Exception as e:
                self._json({"ok": False, "message": str(e)})
            return

        if self.path == "/api/rollback":
            # Answer first, restart after — the same lesson as /api/update.
            # Rolling back restarts osprime-web, which is the server writing
            # this reply.
            try:
                result = updater.restore(restart=False)
                ok = result.startswith("restored")
            except Exception as e:
                result, ok = f"rollback failed: {e}", False
            self._json({"ok": ok, "message": _plain(result)})
            if ok:
                threading.Timer(1.0, updater.restart_services).start()
            return

        if self.path == "/api/end":
            # The window is closing. Sent with sendBeacon so it still
            # arrives while the page is being torn down.
            self._json({"ok": end_session(str(body.get("session", "")))})
            return

        if self.path == "/api/open":
            # A link clicked in the chat must open a browser WINDOW, not
            # navigate this one. The chat is a kiosk window with no address
            # bar and no back button: letting it follow a link would replace
            # the assistant with a web page and leave no way back.
            url = str(body.get("url", "")).strip()
            if not url.startswith(("http://", "https://")):
                self._json({"ok": False, "message": "not a web address"})
                return
            try:
                import desktop
                self._json({"ok": True, "message": desktop.open_url(url)})
            except Exception as e:
                self._json({"ok": False, "message": str(e)})
            return

        if self.path == "/api/onboard":
            PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
            PROFILE_PATH.write_text(
                json.dumps(body, ensure_ascii=False, indent=2), encoding="utf-8")
            self._json({"ok": True})
        elif self.path == "/api/chat":
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.end_headers()

            def emit(obj):
                self.wfile.write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
                self.wfile.flush()

            try:
                sess = get_session(body["session"])
                f = sess["f"]
                session_send(sess, {"type": "user_message", "text": body["text"]})
                for line in f:
                    msg = json.loads(line)
                    emit(msg)
                    if msg.get("type") in ("assistant", "error"):
                        return
                emit({"type": "error", "text": "Lost connection to the agent"})
            except BrokenPipeError:
                pass
            except Exception as e:
                try:
                    emit({"type": "error", "text": str(e)})
                except Exception:
                    pass
        else:
            self._json({"error": "not found"}, 404)


PAGE = r"""<!DOCTYPE html>
<html lang="{{LANG}}" dir="{{DIR}}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OSprime</title>
<style>
  :root { --bg:#0d1117; --panel:#161b22; --accent:#58a6ff; --text:#e6edf3; --dim:#8b949e; }
  * { box-sizing:border-box; margin:0; }
  body { background:var(--bg); color:var(--text); height:100vh; display:flex; flex-direction:column;
         font-family:"Segoe UI", Vazirmatn, Tahoma, sans-serif; }
  header { padding:14px 22px; background:var(--panel); border-bottom:1px solid #21262d;
           display:flex; align-items:center; gap:10px; }
  header .logo { font-size:20px; font-weight:700; color:var(--accent); }
  header .sub { color:var(--dim); font-size:13px; }
  #chat { flex:1; overflow-y:auto; padding:20px; display:flex; flex-direction:column; gap:10px; }
  .msg { max-width:75%; padding:10px 14px; border-radius:14px; line-height:1.9; white-space:pre-wrap; }
  .user { background:#1f6feb; align-self:flex-start; border-bottom-right-radius:4px; }
  .bot  { background:var(--panel); align-self:flex-end; border-bottom-left-radius:4px; border:1px solid #21262d; }
  /* A file path has no spaces to break at, so a long one ran straight off
     the right edge and took the sentence around it with it: "There are 3
     pictures in /home/os" was all that could be read. */
  .msg, .tool { overflow-wrap:anywhere; word-break:break-word; }
  .link { color:var(--accent); text-decoration:underline; cursor:pointer; }
  .link:hover { text-decoration:none; }
  .img  { padding:8px; }
  .img img { max-width:420px; max-height:340px; width:auto; height:auto;
             display:block; border-radius:8px; cursor:zoom-in; }
  .img .cap { color:var(--dim); font-size:12px; margin-top:6px;
              direction:ltr; text-align:left; }
  .tool { align-self:flex-end; color:var(--dim); font-size:12px; direction:ltr; text-align:left;
          background:#161b2280; border:1px dashed #30363d; border-radius:8px; padding:4px 10px;
          font-family:Consolas, monospace; }
  .badge { font-size:11px; color:var(--dim); margin-top:4px; }
  form { display:flex; gap:10px; padding:14px 20px; background:var(--panel); border-top:1px solid #21262d; }
  input { flex:1; background:var(--bg); color:var(--text); border:1px solid #30363d; border-radius:10px;
          padding:12px 16px; font-size:15px; font-family:inherit; outline:none; }
  input:focus { border-color:var(--accent); }
  button { background:var(--accent); color:#0d1117; border:0; border-radius:10px; padding:0 22px;
           font-size:15px; font-weight:700; cursor:pointer; font-family:inherit; }
  button:disabled { opacity:.5; }
  .typing { color:var(--dim); align-self:flex-end; font-size:13px; }
  .confirm { align-self:flex-end; background:#2d1a1a; border:1px solid #a14; border-radius:12px;
             padding:12px 14px; max-width:75%; }
  .confirm .q { color:#ffb3b3; margin-bottom:6px; }
  .confirm .cmd { direction:ltr; text-align:left; font-family:Consolas,monospace; font-size:13px;
                  background:#0d1117; border-radius:6px; padding:6px 10px; margin-bottom:10px;
                  white-space:pre-wrap; word-break:break-all; }
  .confirm .btns { display:flex; gap:8px; }
  .confirm button { padding:6px 16px; border-radius:8px; border:0; cursor:pointer; font-family:inherit; font-weight:700; }
  .confirm .yes { background:#238636; color:#fff; }
  .confirm .no  { background:#30363d; color:var(--text); }
  .iconbtn { background:var(--bg); color:var(--text); border:1px solid #30363d; border-radius:10px;
             padding:0 14px; font-size:18px; cursor:pointer; }
  .iconbtn.on { background:#a12d2d; border-color:#e05555; animation:pulse 1.2s infinite; }
  .iconbtn.speak-on { background:var(--accent); color:#0d1117; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.55} }
  /* Chat settings. Only what belongs to the conversation lives here —
     everything about the machine is in the Control Panel. A chat window
     that can also repartition your disk is a chat window nobody trusts. */
  .hdrbtn { background:transparent; border:0; color:#8b949e; font-size:13px;
            cursor:pointer; font-family:inherit; padding:4px 8px;
            border-radius:6px; }
  .hdrbtn:hover { background:#21262d; color:var(--text); }
  #chatset { display:none; position:absolute; top:52px; inset-inline-end:16px;
             width:290px; background:#161b22; border:1px solid #30363d;
             border-radius:12px; padding:12px 14px; z-index:20;
             box-shadow:0 10px 30px rgba(0,0,0,.45); }
  #chatset.on { display:block; }
  #chatset h3 { margin:0 0 10px; font-size:13px; color:#8b949e;
                font-weight:600; }
  #chatset .r { display:flex; align-items:center; gap:10px; padding:7px 0;
                border-top:1px solid #21262d; font-size:13px; }
  #chatset .r:first-of-type { border-top:0; }
  #chatset .r span { flex:1; }
  #chatset select { background:#0d1117; color:var(--text);
                    border:1px solid #30363d; border-radius:6px;
                    padding:5px 7px; font-size:12px; font-family:inherit; }
  #chatset .full { display:block; width:100%; text-align:center;
                   margin-top:10px; padding:8px; border-radius:8px;
                   border:1px solid #30363d; color:var(--text);
                   text-decoration:none; font-size:13px; }
  #chatset .full:hover { border-color:#2d6cdf; }
</style>
</head>
<body>
<header><span class="logo">OSprime</span><span class="sub">the operating system that thinks &nbsp;·&nbsp; v{{VERSION}}</span>
<button type="button" class="hdrbtn" id="chatsetbtn" style="margin-left:auto">Chat settings</button>
<span id="upd" style="display:none;margin-left:14px;font-size:13px;align-items:center;gap:10px">
<span id="updtxt"></span>
<button type="button" id="updbtn" style="border:0;border-radius:6px;padding:5px 14px;background:#2d6cdf;color:#fff;cursor:pointer;font-size:13px">Install</button>
</span></header>
<div id="chatset">
  <h3>This conversation</h3>
  <div class="r"><span>Who answers</span>
    <select id="cs_cloud">
      <option value="off">This computer only</option>
      <option value="ask">Cloud when I ask</option>
      <option value="auto">Cloud when needed</option>
    </select></div>
  <div class="r"><span>Check with me before</span>
    <select id="cs_confirm">
      <option value="everything">anything</option>
      <option value="moderate">changing things</option>
      <option value="dangerous">risky things</option>
      <option value="nothing">never ask</option>
    </select></div>
  <div class="r"><span>Language</span>
    <select id="cs_lang">
      <option value="en">English</option>
      <option value="fa">فارسی</option>
    </select></div>
  <div class="r"><span>Start a new conversation</span>
    <button type="button" class="hdrbtn" id="cs_clear"
            style="border:1px solid #30363d">Clear</button></div>
  <a class="full" href="/settings">All settings — Control Panel</a>
</div>
<div id="chat"></div>
<form id="f">
<button type="button" id="mic" class="iconbtn" title="Record voice" style="display:none">🎤</button>
<button type="button" id="spk" class="iconbtn" title="Read answers aloud" style="display:none">🔈</button>
<input id="inp" autocomplete="off" placeholder="Ask your computer anything..." autofocus>
<button id="btn">Send</button></form>
<script>
const chat = document.getElementById("chat"), inp = document.getElementById("inp"),
      btn = document.getElementById("btn"), sid = crypto.randomUUID();
let onboarding = null;
const OB_QUESTIONS = [
  ["name", "What's your name?"],
  ["language", "Preferred language? (en/fa)"],
  ["skill", "Technical level? (beginner/intermediate/expert)"],
  ["usage", "What do you mostly use this computer for?"],
  ["autonomy", "Ask permission before changing the system? (yes/no)"],
];

function add(cls, text) {
  const d = document.createElement("div");
  d.className = "msg " + cls; d.textContent = text;
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight; return d;
}

// Turn web addresses in an answer into something you can click.
//
// Built out of DOM nodes, never innerHTML: the text comes from a language
// model, and a model that can be asked to repeat what a web page said can
// be asked to repeat a <script> tag along with it.
//
// Clicking asks the server to open a browser window instead of following
// the link here, because "here" is a window with no way back.
const URL_RE = /(https?:\/\/[^\s<>"'()\[\]]+)/g;
function linkify(el, text) {
  el.textContent = "";
  let last = 0, m;
  URL_RE.lastIndex = 0;
  while ((m = URL_RE.exec(text)) !== null) {
    if (m.index > last) el.appendChild(document.createTextNode(text.slice(last, m.index)));
    const raw = m[1].replace(/[.,;:)\]]+$/, "");
    const a = document.createElement("a");
    a.href = "#"; a.className = "link"; a.textContent = raw;
    a.title = "Open in a browser window";
    // Says so when it fails. Clicking a link and having nothing at all
    // happen is the single most confusing thing an interface can do, and
    // it is exactly what happened while the browser was being launched
    // without the flags it needs.
    a.onclick = async ev => {
      ev.preventDefault();
      a.textContent = raw + "  (opening…)";
      try {
        const r = await fetch("/api/open", { method: "POST",
          body: JSON.stringify({ url: raw }) }).then(r => r.json());
        a.textContent = raw;
        if (!r.ok) add("bot", "⚠ Could not open it: " + (r.message || "unknown reason"));
      } catch (e) {
        a.textContent = raw;
        add("bot", "⚠ Could not open it: " + e);
      }
    };
    el.appendChild(a);
    last = m.index + raw.length;
  }
  if (last < text.length) el.appendChild(document.createTextNode(text.slice(last)));
}
function addTool(e) {
  const d = document.createElement("div");
  d.className = "tool"; d.textContent = "⚙ " + e.name + ": " + e.detail;
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight;
}
// A picture the assistant found or made. The path came from a file that was
// checked to exist before it was sent, so a broken image here means the
// server refused it, not that the assistant made the path up.
function addImage(path) {
  const d = document.createElement("div");
  d.className = "msg bot img";
  const img = document.createElement("img");
  img.src = "/api/file?path=" + encodeURIComponent(path);
  img.alt = path;
  img.onclick = () => window.open(img.src, "_blank");
  const cap = document.createElement("div");
  cap.className = "cap"; cap.textContent = path.split("/").pop();
  d.appendChild(img); d.appendChild(cap);
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight;
}

// Tell the server the conversation is over when the window goes away, so
// the assistant does its end-of-conversation thinking — reading what was
// said and keeping the handful of durable facts in it. sendBeacon is used
// because a normal fetch is cancelled when the page unloads.
//
// pagehide fires where beforeunload does not, including when a window is
// closed on a phone or put to sleep.
function endSession() {
  try {
    navigator.sendBeacon("/api/end", JSON.stringify({ session: sid }));
  } catch (e) { /* the idle sweep on the server catches this case */ }
}
window.addEventListener("pagehide", endSession);
window.addEventListener("beforeunload", endSession);

// ---- chat settings ----------------------------------------------------
// Only the conversation's own settings. Everything about the machine moved
// to the Control Panel: a chat window that could also repartition a disk
// was a chat window with no honest boundary, and the settings it held were
// unreachable the moment the assistant was the thing that was broken.
const cset = document.getElementById("chatset");

document.getElementById("chatsetbtn").onclick = async ev => {
  ev.stopPropagation();
  const opening = !cset.classList.contains("on");
  cset.classList.toggle("on", opening);
  if (!opening) return;
  // Read on open, not on page load. These can be changed from the Control
  // Panel or by asking, and a value cached at startup would quietly be a
  // lie by the time anyone looked at it.
  try {
    const s = await fetch("/api/settings").then(r => r.json());
    document.getElementById("cs_cloud").value = s.cloud_mode || "off";
    if (s.confirm_level) document.getElementById("cs_confirm").value = s.confirm_level;
    if (s.language) document.getElementById("cs_lang").value = s.language;
  } catch (e) { /* the selects keep their current values */ }
};

document.addEventListener("click", ev => {
  if (!cset.contains(ev.target)) cset.classList.remove("on");
});

async function saveChatSetting(key, value) {
  try {
    const r = await fetch("/api/settings", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ key, value })
    }).then(r => r.json());
    if (!r.ok) add("bot", "⚠ " + (r.message || "Could not save that."));
  } catch (e) { add("bot", "⚠ Could not save that: " + e); }
}

document.getElementById("cs_cloud").onchange   = e => saveChatSetting("cloud_mode", e.target.value);
document.getElementById("cs_confirm").onchange = e => saveChatSetting("confirm_level", e.target.value);
document.getElementById("cs_lang").onchange    = e => saveChatSetting("language", e.target.value);

document.getElementById("cs_clear").onclick = () => {
  // Ends the conversation properly rather than just blanking the screen:
  // the server closes the socket, which is what makes the assistant keep
  // what it learned. Wiping the transcript without that would throw the
  // conversation away instead of finishing it.
  endSession();
  chat.innerHTML = "";
  cset.classList.remove("on");
  location.reload();
};

async function init() {
  const r = await fetch("/api/profile").then(r => r.json());
  if (!r.exists) {
    onboarding = { step: 0, answers: {} };
    add("bot", "Hello! I'm OSprime — your operating system.\nA few quick questions so I know you.");
    add("bot", OB_QUESTIONS[0][1]);
  } else {
    add("bot", "Hi — ask your computer anything.");
  }
}

async function send(text) {
  add("user", text);
  if (onboarding) {
    onboarding.answers[OB_QUESTIONS[onboarding.step][0]] = text;
    onboarding.step++;
    if (onboarding.step < OB_QUESTIONS.length) {
      add("bot", OB_QUESTIONS[onboarding.step][1]);
    } else {
      await fetch("/api/onboard", { method: "POST", body: JSON.stringify(onboarding.answers) });
      add("bot", "Thanks " + (onboarding.answers.name || "") + "! I'm at your service now.");
      onboarding = null;
    }
    return;
  }
  btn.disabled = true;
  let t = add("typing", "Thinking..."), bubble = null;
  const clearT = () => { if (t) { t.remove(); t = null; } };
  try {
    const resp = await fetch("/api/chat", { method: "POST",
      body: JSON.stringify({ session: sid, text }) });
    const reader = resp.body.getReader(), dec = new TextDecoder();
    let buf = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line) continue;
        const m = JSON.parse(line);
        if (m.type === "delta") {
          clearT();
          if (!bubble) bubble = add("bot", "");
          bubble.textContent += m.text;
          chat.scrollTop = chat.scrollHeight;
        } else if (m.type === "tool_use") {
          clearT(); addTool(m); bubble = null;
        } else if (m.type === "image") {
          clearT(); addImage(m.path); bubble = null;
        } else if (m.type === "assistant") {
          clearT();
          if (!bubble) bubble = add("bot", m.text);
          // Streaming appends plain text; the links go in once at the end,
          // when the whole address is known. Half a URL is not a link.
          linkify(bubble, m.text || bubble.textContent);
          const b = document.createElement("div"); b.className = "badge";
          b.textContent = m.backend === "claude" ? "\u2601 Claude" : "\u2302 Local model";
          bubble.appendChild(b);
          speak(m.text);
        } else if (m.type === "confirm") {
          clearT(); bubble = null; renderConfirm(m);
        } else if (m.type === "error") {
          clearT(); add("bot", "⚠ " + m.text);
        }
      }
    }
  } catch (e) { clearT(); add("bot", "\u26a0 Connection error: " + e); }
  btn.disabled = false; inp.focus();
}

document.getElementById("f").addEventListener("submit", ev => {
  ev.preventDefault();
  const text = inp.value.trim();
  if (text) { inp.value = ""; send(text); }
});
// ---- voice ----------------------------------------------------------
const mic = document.getElementById("mic"), spk = document.getElementById("spk");
let recorder = null, chunks = [], speakOn = false;

async function initVoice() {
  let st = {};
  try { st = await fetch("/api/voice/status").then(r => r.json()); } catch (e) { return; }
  if (st.stt && navigator.mediaDevices) mic.style.display = "";
  if (st.tts) spk.style.display = "";
}

spk.onclick = () => {
  speakOn = !speakOn;
  spk.classList.toggle("speak-on", speakOn);
  spk.textContent = speakOn ? "🔊" : "🔈";
};

async function speak(text) {
  if (!speakOn || !text) return;
  try {
    const r = await fetch("/api/tts", { method: "POST", body: JSON.stringify({ text }) });
    if (!r.ok) return;
    const blob = await r.blob();
    new Audio(URL.createObjectURL(blob)).play();
  } catch (e) {}
}

mic.onclick = async () => {
  if (recorder && recorder.state === "recording") { recorder.stop(); return; }
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
  catch (e) { add("bot", "\u26a0 Microphone access denied."); return; }
  chunks = [];
  recorder = new MediaRecorder(stream);
  recorder.ondataavailable = e => chunks.push(e.data);
  recorder.onstop = async () => {
    stream.getTracks().forEach(t => t.stop());
    mic.classList.remove("on"); mic.textContent = "🎤";
    const blob = new Blob(chunks, { type: recorder.mimeType || "audio/webm" });
    const ext = (recorder.mimeType || "audio/webm").includes("ogg") ? "ogg" : "webm";
    const note = add("typing", "Transcribing...");
    try {
      const r = await fetch("/api/stt", { method: "POST",
        headers: { "X-Audio-Ext": ext }, body: blob }).then(r => r.json());
      note.remove();
      if (r.ok && r.text) { inp.value = r.text; send(r.text); inp.value = ""; }
      else add("bot", "⚠ " + (r.error || "No speech detected"));
    } catch (e) { note.remove(); add("bot", "\u26a0 Transcription error: " + e); }
  };
  recorder.start();
  mic.classList.add("on"); mic.textContent = "⏹";
};

function renderConfirm(m) {
  const d = document.createElement("div");
  d.className = "confirm";
  const q = document.createElement("div"); q.className = "q"; q.textContent = "🔒 " + m.text;
  const cmd = document.createElement("div"); cmd.className = "cmd"; cmd.textContent = m.detail || "";
  const btns = document.createElement("div"); btns.className = "btns";
  const yes = document.createElement("button"); yes.className = "yes"; yes.textContent = "Allow";
  const no = document.createElement("button"); no.className = "no"; no.textContent = "Deny";
  const answer = (approved) => {
    yes.disabled = no.disabled = true;
    yes.style.opacity = no.style.opacity = .5;
    fetch("/api/confirm", { method: "POST",
      body: JSON.stringify({ session: sid, id: m.id, approved }) });
    q.textContent = (approved ? "\u2713 Allowed" : "\u2715 Denied") + " — " + m.text;
  };
  yes.onclick = () => answer(true); no.onclick = () => answer(false);
  btns.append(yes, no); d.append(q); if (m.detail) d.append(cmd); d.append(btns);
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight;
}

async function pollNotifications() {
  try {
    const r = await fetch("/api/notifications").then(r => r.json());
    (r.items || []).forEach(n => {
      if (n.kind === "message" || n.text) {
        add("bot", n.text);
      } else {
        const icon = n.status === "done" ? "✅" : "⚠";
        add("bot", `${icon} Background task "${n.label}" ${n.status === "done" ? "finished" : "failed"} (code ${n.code}).`);
      }
    });
  } catch (e) {}
}
setInterval(pollNotifications, 3000);
initVoice();
init();
// --- updates -------------------------------------------------------------
// Independent of the assistant on purpose. This must keep working on the day
// the model is having a bad day, because the fix for that day arrives here.
(async () => {
  const bar = document.getElementById("upd");
  const txt = document.getElementById("updtxt");
  const btn = document.getElementById("updbtn");
  let info = null;
  try { info = await (await fetch("/api/update/check")).json(); } catch (e) { return; }
  if (!info || !info.available) return;
  txt.textContent = "Version " + info.latest + " is available";
  bar.style.display = "flex";
  btn.onclick = async () => {
    btn.disabled = true;
    txt.textContent = "Installing " + info.latest + "…";
    btn.textContent = "…";
    let r = null;
    try { r = await (await fetch("/api/update/install", {method:"POST"})).json(); }
    catch (e) { r = null; }   // the service may have restarted underneath us
    if (r && !r.ok) {
      txt.textContent = r.message || "Update failed";
      btn.textContent = "Retry"; btn.disabled = false;
      return;
    }
    // Either it reported success, or the connection dropped mid-restart.
    // Both look the same from here, so wait for the service to answer again
    // and reload once it does, rather than guessing.
    txt.textContent = "Installed — restarting";
    for (let i = 0; i < 30; i++) {
      await new Promise(s => setTimeout(s, 1000));
      try { await fetch("/api/update/check", {cache: "no-store"});
            location.reload(); return; } catch (e) {}
    }
    txt.textContent = "Installed — reopen this window";
    btn.style.display = "none";
  };
})();
</script>
</body>
</html>"""


def main():
    server = http.server.ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    threading.Thread(target=_reap_idle_sessions, daemon=True).start()
    print(f"OSprime web UI on http://localhost:{PORT}")
    server.serve_forever()


if __name__ == "__main__":
    main()
