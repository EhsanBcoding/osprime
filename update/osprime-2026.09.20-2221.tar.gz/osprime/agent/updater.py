"""OSprime self-update (OTA) with automatic rollback.

Layout:
    /opt/osprime            <- live code
    /var/lib/osprime/backups/<timestamp>  <- previous versions

An update stages the new code, verifies it compiles, swaps it in, and
restores the backup if anything fails.
"""

import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import urllib.request

INSTALL_DIR = pathlib.Path(os.environ.get("OSPRIME_INSTALL", "/opt/osprime"))
BACKUP_DIR = pathlib.Path(os.environ.get("OSPRIME_BACKUPS", "/var/lib/osprime/backups"))

# Where releases are announced. A static file is enough — no server code.
MANIFEST_URL = os.environ.get(
    "OSPRIME_MANIFEST_URL",
    "https://ehsanbcoding.github.io/osprime/update/manifest.json")

# Direct archive URL, used only when a manifest is deliberately bypassed
# (local testing, or an explicitly supplied package).
SOURCE_URL = os.environ.get("OSPRIME_UPDATE_URL", "")

VERSION_FILE = INSTALL_DIR / "VERSION"
# "skills" belongs here: skills are the product, and leaving them out meant
# they were written, packaged, and never actually delivered to a machine.
CODE_DIRS = ("agent", "ui", "onboarding", "tools.d", "shell", "installer",
             "skills")
KEEP_BACKUPS = 3
NET_TIMEOUT = 15


def current_version() -> str:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        return "unknown"


def fetch_manifest(url: str = "") -> dict:
    """Read the release manifest. Returns {} when unreachable — being
    offline is a normal state here, not an error worth surfacing."""
    url = url or MANIFEST_URL
    try:
        with urllib.request.urlopen(url, timeout=NET_TIMEOUT) as r:
            data = json.load(r)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _newer(latest: str, current: str) -> bool:
    """Versions are YYYY.MM.DD-HHMM, so string order is chronological."""
    if not latest:
        return False
    if current in ("", "unknown", "dev"):
        return True
    return latest > current


def check(url: str = "") -> dict:
    """Is there a newer version? Never installs anything."""
    m = fetch_manifest(url)
    if not m:
        return {"available": False, "reason": "could not reach the update server",
                "current": current_version()}
    latest = str(m.get("version", ""))
    return {
        "available": _newer(latest, current_version()),
        "current": current_version(),
        "latest": latest,
        "notes": m.get("notes", ""),
        "url": m.get("url", ""),
        "sha256": m.get("sha256", ""),
        # Dropping this silently meant a release could declare dependencies
        # and none of them were ever installed — the update looked successful
        # and the new code was broken.
        "packages": m.get("packages", []),
    }


def _sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _compiles(root: pathlib.Path) -> bool:
    """Every python file in the staged tree must byte-compile."""
    files = [str(p) for d in CODE_DIRS for p in (root / d).rglob("*.py")]
    if not files:
        return False
    env = dict(os.environ, PYTHONPYCACHEPREFIX=tempfile.mkdtemp())
    r = subprocess.run(["python3", "-m", "py_compile", *files],
                       capture_output=True, text=True, env=env)
    return r.returncode == 0


def _install_packages(pkgs: list) -> str:
    """Install system packages named in the manifest.

    Code-only updates cannot deliver a skill that needs ocrmypdf or
    imagemagick, so an update has to be able to bring its dependencies.

    Note: -Sy followed by -S is the well-known Arch partial-upgrade risk. It
    is accepted for now because the alternative, a full -Syu, would pull the
    whole system on every skill install. The real fix is our own repository
    with pinned versions, which is on the roadmap.
    """
    if not pkgs:
        return ""
    if not shutil.which("pacman"):
        return "package manager not available"
    subprocess.run(["pacman", "-Sy", "--noconfirm"],
                   capture_output=True, text=True, timeout=300)
    r = subprocess.run(["pacman", "-S", "--needed", "--noconfirm", *pkgs],
                       capture_output=True, text=True, timeout=1800)
    if r.returncode != 0:
        tail = (r.stderr or r.stdout or "").strip().splitlines()
        return f"packages failed: {tail[-1] if tail else 'unknown error'}"
    return f"{len(pkgs)} package(s) checked"


def _apply_system_files(root: pathlib.Path) -> str:
    """Copy the package's system/ tree over the real filesystem.

    This is how service units and menu entries reach an installed machine.
    Without it, a new .desktop file only ever appears by rebuilding the ISO —
    which is exactly why Settings was missing from the Apps menu.
    """
    src = root / "system"
    if not src.is_dir():
        return ""
    count, failed = 0, []
    for path in src.rglob("*"):
        if not path.is_file():
            continue
        dest = pathlib.Path("/") / path.relative_to(src)
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
            count += 1
        except Exception as e:
            # Swallowing these made a missing menu entry look like a mystery
            # instead of a permission error.
            failed.append(f"{dest}: {e}")
    if failed:
        return (f"{count} system file(s) updated, "
                f"{len(failed)} failed — {failed[0]}")
    if count:
        if shutil.which("systemctl"):
            subprocess.run(["systemctl", "daemon-reload"], capture_output=True)
        if shutil.which("update-desktop-database"):
            subprocess.run(["update-desktop-database",
                            "/usr/share/applications"], capture_output=True)
    return f"{count} system file(s) updated" if count else ""


def _run_post_install(root: pathlib.Path) -> str:
    """The part of a release that copying files cannot express.

    Ownership, sudo rules, anything that is not code. A failure here used to
    be reported as a note alongside a successful update, which is how half a
    change ships: the new service units are already in place and the
    permissions they depend on are not.

    So it raises. apply_staged catches that and rolls the whole release
    back, which is the only honest outcome — a machine half-moved is worse
    than one that never moved.
    """
    script = root / "post_install.sh"
    if not script.is_file():
        return ""
    r = subprocess.run(["bash", str(script)], capture_output=True,
                       text=True, timeout=900)
    detail = ((r.stdout or "") + (r.stderr or "")).strip()
    if r.returncode != 0:
        raise RuntimeError("post-install failed: " + (detail[-300:] or "no output"))
    return "post-install ran"


def _find_root(extracted: pathlib.Path) -> pathlib.Path:
    """Archives usually contain a single top-level folder."""
    if (extracted / "agent").is_dir():
        return extracted
    subs = [p for p in extracted.iterdir() if p.is_dir()]
    for s in subs:
        if (s / "agent").is_dir():
            return s
    return extracted


def backup() -> pathlib.Path:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = BACKUP_DIR / stamp
    n = 1
    while dest.exists():                 # two updates in the same second
        dest = BACKUP_DIR / f"{stamp}-{n}"
        n += 1
    dest.mkdir()
    for d in CODE_DIRS:
        src = INSTALL_DIR / d
        if src.is_dir():
            shutil.copytree(src, dest / d, dirs_exist_ok=True)
    if VERSION_FILE.exists():
        shutil.copy(VERSION_FILE, dest / "VERSION")
    _prune_backups()
    return dest


def _prune_backups():
    if not BACKUP_DIR.is_dir():
        return
    olds = sorted([p for p in BACKUP_DIR.iterdir() if p.is_dir()])
    for p in olds[:-KEEP_BACKUPS]:
        shutil.rmtree(p, ignore_errors=True)


def list_backups() -> list:
    if not BACKUP_DIR.is_dir():
        return []
    return sorted(p.name for p in BACKUP_DIR.iterdir() if p.is_dir())


def _swap_in(src_root: pathlib.Path):
    for d in CODE_DIRS:
        s = src_root / d
        if not s.is_dir():
            continue
        target = INSTALL_DIR / d
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(s, target)


def _rollback_as_root(restart: bool = True) -> str:
    """Ask root to put the previous version back.

    Same boundary as _as_root, and the same reasoning: the unprivileged
    side may say WHEN to roll back, not WHAT to roll back to. The
    privileged side picks the most recent backup itself, so there is no
    argument for a caller to aim somewhere else.

    restart=False exists for the same reason it does on the update path.
    The root side restarting osprime-web would kill the server that is
    sitting here waiting for this very command to return, and the user
    would see a rollback that "failed" while succeeding.
    """
    if not shutil.which("sudo"):
        return ("ERROR: rolling back needs root and sudo is not available "
                "on this system.")
    cmd = ["sudo", "-n", sys.executable,
           str(pathlib.Path(__file__).resolve()), "--rollback"]
    if not restart:
        cmd.append("--no-restart")
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    out = (r.stdout or "").strip() or (r.stderr or "").strip()
    if r.returncode != 0:
        if "password is required" in out or "no tty" in out.lower():
            return ("ERROR: this system will not let the assistant roll back "
                    "without a password. Run it yourself with: sudo python3 "
                    "/opt/osprime/agent/updater.py --rollback")
        return out or "ERROR: the rollback failed and said nothing."
    return out


def restore(name: str = "", restart: bool = True) -> str:
    """Put a previous version back.

    Writes to /opt/osprime, which is root-owned on purpose — that is what
    stops the unprivileged agent rewriting the code it may ask root to run.
    So an ordinary user hands the whole job to root, exactly as an update
    does. Without this the button existed and failed with a bare permission
    error at the one moment a person most needs it to work.
    """
    if os.geteuid() != 0:
        if name:
            return ("ERROR: only the most recent backup can be restored "
                    "without root. Run it yourself to choose another: "
                    "sudo python3 /opt/osprime/agent/updater.py --rollback")
        return _rollback_as_root(restart)

    backups = list_backups()
    if not backups:
        return "no backup available"
    name = name or backups[-1]
    # Checked against the list, not just for being a directory. `is_dir()`
    # happily accepts "../../etc" — and this function is reachable from a
    # tool a language model calls, behind sudo. A name that is not one of
    # ours is not a name.
    if name not in backups:
        return f"backup {name} not found"
    src = BACKUP_DIR / name
    _swap_in(src)
    v = src / "VERSION"
    if v.exists():
        shutil.copy(v, VERSION_FILE)
    return f"restored backup {name}"


def restart_services() -> str:
    # The desktop shell holds its config in memory. Without these two, a
    # change to the panel or the key bindings only appeared after a logout,
    # which looked like the update had not arrived at all.
    subprocess.run(["pkill", "-USR2", "waybar"], capture_output=True)
    if shutil.which("labwc"):
        subprocess.run(["labwc", "--reconfigure"], capture_output=True)

    if not shutil.which("systemctl"):
        return "systemctl not available (restart manually)"

    # As an ordinary user these need sudo, and the sudoers file names these
    # exact units. Nothing else is reachable through it: the unit files are
    # root-owned, so "restart osprime-agent" cannot be made to mean
    # something other than restarting osprime-agent.
    pre = [] if os.geteuid() == 0 else ["sudo", "-n"]

    # The inference engine is restarted too, and deliberately last. Its
    # launch script carries the performance flags, so leaving it running on
    # the old ones meant an update that reported success while half of it
    # had not taken effect until the next reboot — the same silent partial
    # application that has cost this project more time than any other bug.
    #
    # It costs a slow first answer while the model loads again, which is
    # worth saying out loud rather than leaving the user to wonder.
    r = subprocess.run(pre + ["systemctl", "restart",
                              "osprime-agent", "osprime-web"],
                       capture_output=True, text=True)
    if r.returncode != 0:
        return f"restart failed: {r.stderr.strip()}"
    m = subprocess.run(pre + ["systemctl", "restart", "osprime-model"],
                       capture_output=True, text=True)
    if m.returncode != 0:
        return ("services restarted, but the inference engine did not: "
                + m.stderr.strip())
    return ("services restarted — the engine is reloading the model, so the "
            "first answer will take longer than usual")


def _as_root(restart: bool) -> str:
    """Ask root to install the update the manifest names.

    This is the whole privilege boundary. The agent runs as an ordinary
    user and may say WHEN to update; it may not say WHAT the update is.
    So the privileged side does the fetching, the checksum and the
    installing itself, from a manifest URL baked into this file — which
    lives in /opt/osprime, owned by root, and is therefore not something
    the unprivileged side can rewrite before asking for it to be run.

    A helper that installed whatever the caller had already staged would
    look like a boundary and be a doorway.
    """
    if not shutil.which("sudo"):
        return ("ERROR: updating needs root and sudo is not available on "
                "this system.")
    cmd = ["sudo", "-n", sys.executable, str(pathlib.Path(__file__).resolve()),
           "--install"]
    if not restart:
        cmd.append("--no-restart")
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=2400)
    out = (r.stdout or "").strip() or (r.stderr or "").strip()
    if r.returncode != 0:
        if "password is required" in out or "no tty" in out.lower():
            return ("ERROR: this system will not let the assistant install "
                    "updates without a password. Run it yourself with: "
                    "sudo python3 /opt/osprime/agent/updater.py --install")
        return out or "ERROR: the update failed and said nothing."
    return out


def succeeded(result: str) -> bool:
    """Did that string from update() mean an update was installed?

    One sentence, in one place. Two callers decide what to do next based on
    this — the Settings page and the chat tool — and when they each had
    their own copy of the test, only one of them was right.
    """
    return (result or "").startswith("updated to")


def update(url: str = "", restart: bool = True, expect_sha: str = "",
           version: str = "", packages: list = None) -> str:
    """Install an update. With no url, the manifest decides what to fetch.

    The checksum is not optional on the manifest path. This code downloads an
    archive and then runs it as the system's own brain, so an unverified
    package means whoever controls the URL controls the machine.
    """
    # Installing writes to /opt/osprime and runs pacman, which the agent no
    # longer has the right to do. Hand the whole job to root rather than
    # failing halfway through with a permission error.
    if os.geteuid() != 0 and not url:
        return _as_root(restart)

    if not url:
        info = check()
        if not info.get("latest"):
            return f"no update available ({info.get('reason', 'up to date')})"
        if not info["available"]:
            return f"already on the latest version ({info['current']})"
        url = info["url"]
        expect_sha = expect_sha or info["sha256"]
        version = version or info["latest"]
        packages = info.get("packages") or []
        if not url:
            return "manifest is missing a download url"
        if not expect_sha:
            return "manifest has no sha256 — refusing to install an unverified package"

    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        archive = tmp / "src.tar.gz"
        try:
            if url.startswith(("http://", "https://")):
                urllib.request.urlretrieve(url, archive)
            else:                                  # local file (also used in tests)
                shutil.copy(url, archive)
        except Exception as e:
            return f"download failed: {e}"

        if expect_sha:
            got = _sha256(archive)
            if got.lower() != expect_sha.lower():
                return ("update rejected: checksum mismatch — nothing was changed.\n"
                        f"  expected {expect_sha}\n  got      {got}")

        extract = tmp / "x"
        extract.mkdir()
        try:
            shutil.unpack_archive(str(archive), str(extract))
        except Exception as e:
            return f"extract failed: {e}"

        root = _find_root(extract)
        if not (root / "agent" / "agent.py").is_file():
            return "invalid package: agent/agent.py missing"
        if not _compiles(root):
            return "update rejected: new code does not compile (nothing changed)"

        # Hand the installation to the updater *inside the package*, when it
        # knows how to accept it.
        #
        # Otherwise every change to this file takes effect one release late:
        # the code that installs a release is always the previous release's
        # code. That cost us a missing Settings entry and would cost the same
        # again for every future change here.
        staged = root / "agent" / "updater.py"
        try:
            can_hand_off = "--apply" in staged.read_text(encoding="utf-8")
        except Exception:
            can_hand_off = False

        if can_hand_off:
            r = subprocess.run(
                [sys.executable, str(staged), "--apply", str(root),
                 version or "", *(packages or [])],
                capture_output=True, text=True, timeout=2400)
            out = (r.stdout or "").strip() or (r.stderr or "").strip()
            if r.returncode != 0:
                return out or "update failed while applying"
            msg = out or f"updated to {current_version()}"
            if restart:
                msg += " — " + restart_services()
            return msg

        # Older package: apply it here, the old way.
        extra = []
        pkg_msg = _install_packages(list(packages or []))
        if pkg_msg:
            extra.append(pkg_msg)
            if pkg_msg.startswith("packages failed"):
                return f"update stopped: {pkg_msg} — nothing was changed"

        b = backup()
        try:
            _swap_in(root)
            for msg in (_apply_system_files(root), _run_post_install(root)):
                if msg:
                    extra.append(msg)
            # Record the version the manifest advertised, not the clock. Using
            # local time here left the installed version below the published
            # one, so check() reported an update available forever.
            new_v = version
            if not new_v and (root / "VERSION").is_file():
                new_v = (root / "VERSION").read_text(encoding="utf-8").strip()
            if not new_v:
                new_v = datetime.datetime.now().strftime("%Y.%m.%d-%H%M")
            VERSION_FILE.write_text(new_v + "\n", encoding="utf-8")
        except Exception as e:
            restore(b.name)
            return f"update failed ({e}) — rolled back to {b.name}"

    msg = f"updated to {current_version()} (backup: {b.name})"
    if extra:
        msg += " — " + "; ".join(extra)
    if restart:
        msg += " — " + restart_services()
    return msg


def apply_staged(root: pathlib.Path, version: str = "",
                 packages: list = None) -> str:
    """Install an already downloaded and verified package.

    Called by the *previous* version's updater as a subprocess, so that the
    logic in this file is what runs — not whatever shipped last time.
    """
    extra = []
    pkg_msg = _install_packages(list(packages or []))
    if pkg_msg:
        extra.append(pkg_msg)
        if pkg_msg.startswith("packages failed"):
            raise RuntimeError(f"update stopped: {pkg_msg} — nothing was changed")

    b = backup()
    try:
        _swap_in(root)
        for msg in (_apply_system_files(root), _run_post_install(root)):
            if msg:
                extra.append(msg)
        new_v = version
        if not new_v and (root / "VERSION").is_file():
            new_v = (root / "VERSION").read_text(encoding="utf-8").strip()
        if not new_v:
            new_v = datetime.datetime.now().strftime("%Y.%m.%d-%H%M")
        VERSION_FILE.write_text(new_v + "\n", encoding="utf-8")
    except Exception as e:
        restore(b.name)
        raise RuntimeError(f"update failed ({e}) — rolled back to {b.name}")

    msg = f"updated to {current_version()} (backup: {b.name})"
    if extra:
        msg += " — " + "; ".join(extra)
    return msg


def status() -> dict:
    return {"version": current_version(), "install_dir": str(INSTALL_DIR),
            "backups": list_backups(), "manifest": MANIFEST_URL}


if __name__ == "__main__":
    # Entry point for the hand-off described in update(): the outgoing
    # version downloads and verifies, then runs this file from the new
    # package to do the actual installation.
    #
    #   python3 updater.py --apply <extracted-root> <version> [packages...]
    #
    # And the privileged entry point the unprivileged agent asks for by name
    # through sudo. It takes no description of what to install: the manifest
    # decides, and the manifest URL is in this file, which the caller cannot
    # write to.
    if len(sys.argv) >= 2 and sys.argv[1] == "--rollback":
        # Takes no argument, deliberately: see _rollback_as_root.
        if os.geteuid() != 0:
            print("--rollback must be run as root", file=sys.stderr)
            sys.exit(1)
        try:
            msg = restore()
            print(msg)
            if not msg.startswith("restored"):
                sys.exit(1)
            if "--no-restart" not in sys.argv:
                print(restart_services())
        except Exception as e:
            print(e, file=sys.stderr)
            sys.exit(1)
        sys.exit(0)

    if len(sys.argv) >= 2 and sys.argv[1] == "--install":
        if os.geteuid() != 0:
            print("--install must be run as root", file=sys.stderr)
            sys.exit(1)
        try:
            print(update(restart="--no-restart" not in sys.argv))
        except Exception as e:
            print(e, file=sys.stderr)
            sys.exit(1)
        sys.exit(0)

    if len(sys.argv) >= 3 and sys.argv[1] == "--apply":
        try:
            print(apply_staged(pathlib.Path(sys.argv[2]),
                               sys.argv[3] if len(sys.argv) > 3 else "",
                               sys.argv[4:]))
        except Exception as e:
            print(e, file=sys.stderr)
            sys.exit(1)
    else:
        print(json.dumps(status(), indent=2))
