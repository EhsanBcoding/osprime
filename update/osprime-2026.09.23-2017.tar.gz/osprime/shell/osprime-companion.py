#!/usr/bin/env python3
"""The OSprime companion: a small presence you can put anywhere.

Replaces the "Ask OSprime" pill that used to sit in the middle of the
panel. Click it to open or close the chat; drag it wherever you like.

Read docs/COMPANION.md before changing this. The short version:

  * It is built as a surface that DRAWS WHATEVER IT IS TOLD, not as a
    button with a picture on it. A later version puts a character here —
    a face, an animation, a frame sequence — and must be able to do that
    without touching how this is positioned, dragged or clicked.
  * The three states (idle, working, attention) are a named state machine
    for the same reason: a character animates states, rather than needing
    new plumbing invented for it.
  * ATTENTION IS A DOT. Not a bubble, not a window, not a sound. The
    companion may become visible; it may never become present. That rule is
    the whole difference between this and Clippy.
  * Nothing here may take the session down. If this program dies the user
    loses a button, not their computer.

Dragging is ours to implement. A layer-shell surface is placed by the
compositor from an anchor and a margin — there is no window manager to drag
it with — so we track the pointer and move the margin ourselves.
"""

import json
import math
import os
import pathlib
import subprocess
import sys
import time

import cairo
import gi

gi.require_version("Gtk", "3.0")
gi.require_version("GtkLayerShell", "0.1")
from gi.repository import Gtk, Gdk, GLib, GtkLayerShell  # noqa: E402

HERE = pathlib.Path(__file__).resolve().parent
ENV_FILE = pathlib.Path(os.environ.get("OSPRIME_DESKTOP_ENV",
                                       "/etc/osprime/desktop.env"))
STATE_FILE = pathlib.Path(os.environ.get(
    "OSPRIME_COMPANION_STATE", "/tmp/osprime-companion.state"))
LOG = pathlib.Path(os.environ.get("OSPRIME_COMPANION_LOG",
                                  f"/tmp/osprime-companion-{os.getuid()}.log"))


def log(msg):
    try:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%H:%M:%S')} {msg}\n")
    except Exception:
        pass


def env() -> dict:
    out = {}
    try:
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"')
    except Exception:
        pass
    return out


def save_env(key: str, value: str):
    """Write one key back, keeping the rest of the file.

    The same file Settings and the assistant use, so the companion's
    position is not a fourth place configuration lives.
    """
    try:
        ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
        lines = (ENV_FILE.read_text(encoding="utf-8").splitlines()
                 if ENV_FILE.exists() else [])
        for i, line in enumerate(lines):
            if line.strip().startswith(f"{key}="):
                lines[i] = f"{key}={value}"
                break
        else:
            lines.append(f"{key}={value}")
        ENV_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except Exception as e:
        log(f"could not save {key}: {e}")


class Companion:
    # Corners, and the edges each one anchors to. Position is stored as a
    # corner plus an offset rather than as x,y from the top left: a screen
    # that changes resolution then keeps the companion in the corner it was
    # near, instead of leaving it off the edge of a smaller display.
    CORNERS = {
        "bottom-right": (GtkLayerShell.Edge.BOTTOM, GtkLayerShell.Edge.RIGHT),
        "bottom-left": (GtkLayerShell.Edge.BOTTOM, GtkLayerShell.Edge.LEFT),
        "top-right": (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.RIGHT),
        "top-left": (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.LEFT),
    }

    def __init__(self):
        cfg = env()
        # From configuration, not a constant: a character will want more
        # room than a dot, and that should not be a code change.
        self.size = max(32, min(160, int(cfg.get("OSPRIME_COMPANION_SIZE", 56))))
        self.corner = cfg.get("OSPRIME_COMPANION_CORNER", "bottom-right")
        if self.corner not in self.CORNERS:
            self.corner = "bottom-right"
        try:
            self.mx = int(cfg.get("OSPRIME_COMPANION_X", 28))
            self.my = int(cfg.get("OSPRIME_COMPANION_Y", 76))
        except ValueError:
            self.mx, self.my = 28, 76

        self.state = "idle"
        self.attention = False
        self._phase = 0.0
        self._drag = None
        self._moved = False

        self.win = Gtk.Window()
        self.win.set_name("companion")
        GtkLayerShell.init_for_window(self.win)
        # TOP, not OVERLAY: above ordinary windows, but still below a
        # full-screen video or a lock screen, which should not have a
        # button floating over them.
        GtkLayerShell.set_layer(self.win, GtkLayerShell.Layer.TOP)
        GtkLayerShell.set_namespace(self.win, "osprime-companion")
        # 0, not -1: it must not reserve space or push other windows around.
        GtkLayerShell.set_exclusive_zone(self.win, 0)
        try:
            GtkLayerShell.set_keyboard_mode(
                self.win, GtkLayerShell.KeyboardMode.NONE)
        except Exception:
            pass

        screen = self.win.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.win.set_visual(visual)
        self.win.set_app_paintable(True)

        self.area = Gtk.DrawingArea()
        self.area.set_size_request(self.size, self.size)
        self.area.connect("draw", self.on_draw)
        self.win.add(self.area)

        self.win.add_events(Gdk.EventMask.BUTTON_PRESS_MASK
                            | Gdk.EventMask.BUTTON_RELEASE_MASK
                            | Gdk.EventMask.POINTER_MOTION_MASK
                            | Gdk.EventMask.ENTER_NOTIFY_MASK
                            | Gdk.EventMask.LEAVE_NOTIFY_MASK)
        self.win.connect("button-press-event", self.on_press)
        self.win.connect("button-release-event", self.on_release)
        self.win.connect("motion-notify-event", self.on_motion)
        self.win.set_size_request(self.size, self.size)

        self.apply_position()
        self.win.show_all()

        # Two timers. The animation one only runs while something is
        # animating — a pulse that ticks at 20 Hz forever would keep a
        # laptop's GPU awake to draw a circle that is not moving.
        GLib.timeout_add(700, self.poll_state)
        self._anim_id = None

    # ---- position ------------------------------------------------------
    def apply_position(self):
        for edge in (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.BOTTOM,
                     GtkLayerShell.Edge.LEFT, GtkLayerShell.Edge.RIGHT):
            GtkLayerShell.set_anchor(self.win, edge, False)
        v, h = self.CORNERS[self.corner]
        GtkLayerShell.set_anchor(self.win, v, True)
        GtkLayerShell.set_anchor(self.win, h, True)
        GtkLayerShell.set_margin(self.win, h, max(0, self.mx))
        GtkLayerShell.set_margin(self.win, v, max(0, self.my))

    def save_position(self):
        save_env("OSPRIME_COMPANION_CORNER", self.corner)
        save_env("OSPRIME_COMPANION_X", str(int(self.mx)))
        save_env("OSPRIME_COMPANION_Y", str(int(self.my)))

    # ---- drawing -------------------------------------------------------
    def on_draw(self, _area, cr):
        """Everything drawn, nothing loaded.

        No image asset: sharp at any size, and it adds nothing to an update.
        A later character replaces the body of this method and nothing else.
        """
        s = self.size
        # SOURCE rather than OVER, so this REPLACES the alpha instead of
        # compositing onto it. Painting transparent with OVER changes
        # nothing, and the window keeps whatever GTK last left there —
        # which is how a "transparent" window ends up a grey square.
        # The named constants, not 1 and 2: a magic number here is a
        # rectangle nobody can explain six months from now.
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)

        cx = cy = s / 2
        r = s / 2 - 4

        # The body.
        cr.arc(cx, cy, r, 0, 2 * math.pi)
        cr.set_source_rgba(0.09, 0.12, 0.18, 0.96)
        cr.fill_preserve()
        cr.set_source_rgba(0.18, 0.42, 0.87, 0.9)
        cr.set_line_width(2)
        cr.stroke()

        # The ring, which is what "working" animates. Drawn as an arc that
        # travels, so the state reads as motion rather than as a colour
        # change somebody might not notice.
        if self.state == "working":
            start = self._phase
            cr.arc(cx, cy, r, start, start + math.pi * 0.6)
            cr.set_source_rgba(0.35, 0.62, 1.0, 0.95)
            cr.set_line_width(3)
            cr.stroke()

        # The mark.
        cr.select_font_face("Noto Sans")
        cr.set_font_size(s * 0.42)
        cr.set_source_rgba(0.85, 0.90, 0.98, 0.95)
        ext = cr.text_extents("O")
        cr.move_to(cx - ext.width / 2 - ext.x_bearing,
                   cy - ext.height / 2 - ext.y_bearing)
        cr.show_text("O")

        # Attention: a dot on the edge. This is the entire notification.
        # Anything louder than this and we have built Clippy.
        if self.attention:
            cr.arc(cx + r * 0.72, cy - r * 0.72, max(4, s * 0.11),
                   0, 2 * math.pi)
            cr.set_source_rgba(0.82, 0.60, 0.13, 1.0)
            cr.fill()
        return False

    def tick(self):
        self._phase = (self._phase + 0.18) % (2 * math.pi)
        self.area.queue_draw()
        if self.state != "working":
            self._anim_id = None
            self.area.queue_draw()
            return False
        return True

    # ---- state ---------------------------------------------------------
    def poll_state(self):
        """Read the state another process wrote. Never asks the agent.

        A file rather than a socket: the companion must keep working when
        the agent is not running, and a missing file means idle, which is
        the correct answer for a machine whose assistant is not there.
        """
        state, attention = "idle", False
        try:
            raw = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            state = raw.get("state", "idle")
            attention = bool(raw.get("attention"))
            # A stale file is not a state. If nothing has updated it for a
            # while, the writer died mid-turn and the companion would spin
            # for ever.
            if time.time() - float(raw.get("at", 0)) > 120:
                state = "idle"
        except Exception:
            pass
        if state not in ("idle", "working", "attention"):
            state = "idle"

        changed = (state != self.state) or (attention != self.attention)
        self.state, self.attention = state, attention
        if state == "working" and self._anim_id is None:
            self._anim_id = GLib.timeout_add(60, self.tick)
        if changed:
            self.area.queue_draw()
        return True

    # ---- pointer -------------------------------------------------------
    def on_press(self, _w, ev):
        if ev.button == 3:
            self.menu(ev)
            return True
        if ev.button == 1:
            self._drag = (ev.x_root, ev.y_root, self.mx, self.my)
            self._moved = False
        return True

    def on_motion(self, _w, ev):
        if not self._drag:
            return False
        sx, sy, ox, oy = self._drag
        dx, dy = ev.x_root - sx, ev.y_root - sy
        if abs(dx) > 3 or abs(dy) > 3:
            self._moved = True
        # The margin grows towards the anchored edge, so the sign depends
        # on which corner it is anchored to. Getting this wrong makes the
        # companion run away from the pointer, which is very funny once.
        v, h = self.corner.split("-")
        self.mx = max(0, ox + (-dx if h == "right" else dx))
        self.my = max(0, oy + (-dy if v == "bottom" else dy))
        self.apply_position()
        return True

    def on_release(self, _w, ev):
        if not self._drag:
            return False
        self._drag = None
        if not self._moved:
            self.toggle_chat()
            return True

        # Re-anchor to whichever corner it was left nearest, so a drag
        # across the screen does not leave it anchored to the far edge with
        # a margin the width of the display — which breaks the moment the
        # resolution changes.
        mon = self.win.get_screen().get_monitor_geometry(0)
        v, h = self.corner.split("-")
        x = (mon.width - self.mx - self.size) if h == "right" else self.mx
        y = (mon.height - self.my - self.size) if v == "bottom" else self.my
        new_h = "right" if x + self.size / 2 > mon.width / 2 else "left"
        new_v = "bottom" if y + self.size / 2 > mon.height / 2 else "top"
        self.corner = f"{new_v}-{new_h}"
        self.mx = (mon.width - x - self.size) if new_h == "right" else x
        self.my = (mon.height - y - self.size) if new_v == "bottom" else y
        self.mx, self.my = max(0, int(self.mx)), max(0, int(self.my))
        self.apply_position()
        self.save_position()
        return True

    # ---- actions -------------------------------------------------------
    def toggle_chat(self):
        try:
            subprocess.Popen(["bash", str(HERE / "osprime-toggle.sh")],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        except Exception as e:
            log(f"could not open the chat: {e}")

    def menu(self, ev):
        m = Gtk.Menu()
        for label, fn in (
                ("Open the chat", lambda *_: self.toggle_chat()),
                ("Settings", lambda *_: self.open_settings()),
                ("Hide until next login", lambda *_: Gtk.main_quit()),
                ("Hide for good", lambda *_: self.hide_for_good())):
            item = Gtk.MenuItem(label=label)
            item.connect("activate", fn)
            m.append(item)
        m.show_all()
        m.popup_at_pointer(ev)

    def open_settings(self):
        try:
            subprocess.Popen(["bash", str(HERE / "osprime-settings.sh"),
                              "personal"],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        except Exception as e:
            log(f"could not open settings: {e}")

    def hide_for_good(self):
        # Writes the same switch Settings shows, so the two cannot disagree
        # about whether the companion is meant to be here.
        save_env("OSPRIME_COMPANION", "no")
        Gtk.main_quit()


def main():
    if env().get("OSPRIME_COMPANION", "yes") == "no":
        log("companion is switched off")
        return
    try:
        Companion()
        Gtk.main()
    except Exception as e:
        # A button is not worth a session. Log it and leave; labwc, the
        # panel and the Super key all keep working without us.
        log(f"companion failed: {e}")
        sys.exit(0)


if __name__ == "__main__":
    main()
