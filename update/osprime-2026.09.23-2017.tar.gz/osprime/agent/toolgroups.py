"""Which tools the model is shown on a given turn.

Read docs/TOOL_BUDGET.md first. The short version: OSprime shipped 65 tool
definitions to a 3B model on every turn. That is ~7,200 tokens, which is 88%
of the 8192-token window the vision models use — so the engine truncated,
the tool list fell off, and the assistant politely denied every ability it
had. Raising the context fixed the truncation and did nothing about the
other half of the problem: published work is consistent that a model's
ability to pick the right tool DEGRADES well before the context fills, with
the knee around 20-25 tools. We were showing 65.

So we show a group. The selection happens HERE, in Python, before the model
runs — not by asking the model which tools it wants. That distinction is the
whole design:

    A tool-search step costs a model turn. This project has already
    established on this machine that a small model does one thing per turn —
    it would not chain take_photo into look, and the fix was to remove the
    chain rather than coach it. Asking such a model to "first find the tool
    you need" buys a token saving with the one capability we know is
    weakest. It would answer ABOUT searching.

The model's experience is unchanged: it gets a list of tools and calls one.
The list is just short and relevant.

Two rules govern every choice below:

  * EVERY TOOL IS REACHABLE. Grouping decides what is offered this turn,
    never what exists. `run_shell` is in the core, so the model is never
    actually helpless.
  * UNCERTAINTY SENDS MORE, NEVER LESS. Two groups is still under 3,500
    tokens; a missing tool is a turn that fails completely. The failure
    direction has to be "too many tools", which costs accuracy slowly.
"""

import re

# --------------------------------------------------------------------------
# The core: sent on every turn, whatever the question.
#
# Small on purpose — seven tools is 555 tokens. Each earns its place by
# being the answer to a request that arrives in any context at all:
# run_shell so the model is never without a way to act, list_files and
# open_file because "show me my…" is the most common thing anyone asks this
# machine, remember because a fact can be mentioned in passing during any
# conversation, and the three that describe the machine itself.
# --------------------------------------------------------------------------
CORE = [
    "run_shell",
    "list_files",
    "open_file",
    "remember",
    "get_settings",
    "power",
    "system_info",
]

# --------------------------------------------------------------------------
# The groups.
#
# Every tool belongs to exactly one, and test_groups_cover_every_tool()
# below enforces that — a tool in no group is a tool that can never be
# offered, and a tool in two is a token cost paid twice.
#
# The names are the user's mental model, not the code's. "documents" holds
# the PDF and image tools because a person asking to merge two PDFs is
# thinking about documents, not about ghostscript.
# --------------------------------------------------------------------------
GROUPS = {
    "camera": [
        "take_photo", "look", "list_capture_devices", "set_volume",
    ],
    "files": [
        "search_files", "read_file", "write_file", "delete_files",
        "disk_usage", "list_drives", "mount_drive",
    ],
    "documents": [
        "make_document", "merge_pdfs", "compress_pdf", "ocr_pdf",
        "convert_images", "passport_photo", "remove_background",
        "make_signature",
    ],
    "apps": [
        "list_apps", "search_apps", "app_info", "install_app",
        "uninstall_app", "open_app", "close_app", "list_windows",
    ],
    "network": [
        "list_wifi", "connect_wifi", "forget_wifi", "wifi_radio",
        "network_status", "web_search", "fetch_url", "open_url", "weather",
    ],
    "appearance": [
        "set_wallpaper", "list_backgrounds", "set_display", "get_display",
        "set_language", "take_screenshot",
    ],
    "clock": [
        "get_time", "set_time", "set_timezone", "set_auto_time",
    ],
    "updates": [
        "check_update", "self_update", "update_status", "rollback_update",
        "model_status",
    ],
    "jobs": [
        "run_job", "job_status", "list_jobs", "list_shortcuts",
        "set_shortcut", "schedule_task",
    ],
    "maths": [
        "calc",
    ],
}

# --------------------------------------------------------------------------
# What a request has to say to reach a group.
#
# Keywords a person can read and correct, not an embedding score nobody can
# debug — and not another model to ship, load and keep in RAM on a machine
# that is already tight. When this is wrong, it is wrong in a way somebody
# can see and fix in one line.
#
# Both languages. Ehsan types Persian to it and the OS answers in the user's
# language, so an English-only map would route every Persian request to the
# fallback — which would work, and would quietly undo the whole feature.
#
# A hint matches where a WORD STARTS, not anywhere in the string. Stems
# still work — "photo" catches photos and photograph, "دوربین" catches
# دوربینم — but a hint can no longer hide inside an unrelated word.
#
# This was not theoretical. The first version matched plain substrings and
# "check for updates" was routed to the clock, because "date" is inside
# "up-date-s". It cost the turn six tool definitions and would have been
# very hard to notice: the answer still worked, because `updates` matched
# too. A wrong group that happens to be harmless today is the kind of thing
# that is wrong for months.
# --------------------------------------------------------------------------
HINTS = {
    "camera": [
        "camera", "webcam", "photo", "picture of me", "selfie", "see me",
        "look at", "what am i", "microphone", "mic ", "volume", "sound",
        "loud", "quiet", "mute", "record",
        "دوربین", "عکس", "سلفی", "ببین", "نگاه", "میکروفن", "صدا", "بلند",
        "ضبط", "بی‌صدا", "بیصدا",
    ],
    "files": [
        "file", "folder", "directory", "disk", "drive", "usb", "space",
        "delete", "remove", "trash", "copy", "move", "rename", "save",
        "read", "write", "download", "desktop", "home",
        "فایل", "پوشه", "فولدر", "دیسک", "درایو", "حافظه", "فضا", "پاک",
        "حذف", "کپی", "انتقال", "ذخیره", "بخوان", "بنویس", "دانلود",
    ],
    "documents": [
        "pdf", "document", "scan", "ocr", "merge", "compress", "signature",
        "sign ", "passport", "resize", "convert", "background of",
        "letter", "report", "word", "docx",
        "سند", "مدرک", "اسکن", "ادغام", "فشرده", "امضا", "پاسپورت",
        "تبدیل", "نامه", "گزارش",
    ],
    "apps": [
        "app", "application", "program", "software", "install", "uninstall",
        "open ", "launch", "run ", "close", "quit", "window", "gimp",
        "browser", "chromium", "firefox",
        "برنامه", "نرم‌افزار", "نرم افزار", "نصب", "حذف نصب", "باز کن",
        "اجرا", "ببند", "پنجره", "مرورگر",
    ],
    "network": [
        "wifi", "wi-fi", "internet", "network", "online", "offline",
        "connect", "search", "google", "web", "site", "url", "http",
        "weather", "news", "look up", "find out",
        "وای‌فای", "وایفای", "اینترنت", "شبکه", "آنلاین", "وصل", "جستجو",
        "سرچ", "گوگل", "سایت", "هوا", "اخبار",
    ],
    "appearance": [
        "wallpaper", "background", "theme", "colour", "color", "dark",
        "light", "screen", "display", "resolution", "scale", "font",
        "text size", "bigger", "smaller", "language", "screenshot",
        "پس‌زمینه", "پس زمینه", "والپیپر", "تم", "رنگ", "تیره", "روشن",
        "صفحه", "نمایش", "وضوح", "بزرگ", "کوچک", "زبان", "اسکرین‌شات",
    ],
    "clock": [
        "time", "clock", "date", "timezone", "time zone", "hour", "today",
        "tomorrow", "calendar",
        "ساعت", "زمان", "تاریخ", "منطقه زمانی", "امروز", "فردا", "تقویم",
    ],
    "updates": [
        "update", "upgrade", "version", "roll back", "rollback", "go back",
        "model", "newer", "latest",
        "آپدیت", "به‌روز", "به روز", "نسخه", "برگرد", "مدل", "جدیدتر",
    ],
    "jobs": [
        "schedule", "every day", "every morning", "remind", "later",
        "background", "job", "task", "shortcut", "key", "hotkey",
        "زمان‌بندی", "هر روز", "هر صبح", "یادآور", "بعدا", "بعداً",
        "پس‌زمینه", "کار", "وظیفه", "میانبر", "کلید",
    ],
    "maths": [
        "calculate", "how much is", "plus", "minus", "times", "divided",
        "percent", "sum of", "=",
        "حساب", "جمع", "تفریق", "ضرب", "تقسیم", "درصد", "چقدر می‌شود",
    ],
}

# Never send more than this many groups at once.
#
# Two, not three. Three was measured first and put the worst case at 47% of
# an 8192 window — under the line, but with little room left for the
# conversation and the tool results, which is what got us here. Two puts it
# at 39%. The cost is a request naming three different areas at once, which
# is rare and which the second-pass retry is for.
MAX_GROUPS = 2

# When nothing matches.
#
# Something on this computer, or something out in the world — those are the
# two places an unclassified request is likely to be pointing. `apps` is
# deliberately absent: requests about applications almost always say
# install, open, program or app, so the hints already catch them, and every
# group in here is paid for on every unclassified turn.
#
# Exactly MAX_GROUPS long, and a test enforces that. The fallback used to be
# three groups while MAX_GROUPS was two, so the one path where we know least
# about the request sent the MOST tools — the opposite of what was intended,
# and invisible because it still worked.
FALLBACK = ["files", "network"]


def _normalise(text: str) -> str:
    text = (text or "").lower()
    # Arabic yeh/kaf appear in Persian text from some keyboards and would
    # make a hint match on one machine and not another.
    return text.replace("ي", "ی").replace("ك", "ک")


# A letter in either script. Used to require that a hint begins a word.
_LETTER = r"\w؀-ۿ"
_cache = {}


def _matches(hint: str, text: str) -> bool:
    pat = _cache.get(hint)
    if pat is None:
        pat = _cache[hint] = re.compile(
            f"(?<![{_LETTER}])" + re.escape(_normalise(hint).strip()))
    return bool(pat.search(text))


def pick_groups(request: str) -> list:
    """Which groups this request needs. Never empty."""
    low = _normalise(request)
    scored = []
    for group, hints in HINTS.items():
        hits = sum(1 for h in hints if _matches(h, low))
        if hits:
            scored.append((hits, group))
    if not scored:
        return list(FALLBACK)
    # Most specific first, but keep the near-misses: a request that mentions
    # both a photo and a file wants both groups, and sending both costs
    # about a thousand tokens against a turn that otherwise fails.
    scored.sort(reverse=True)
    chosen = [g for _, g in scored[:MAX_GROUPS]]
    if len(scored) > MAX_GROUPS:
        # Matched everything, which means it matched nothing useful.
        return list(FALLBACK)
    return chosen


def tools_for(request: str, all_tools: list):
    """The tool schemas to send this turn, and why.

    Returns (tools, groups). The second value exists so the caller can log
    it: the only honest way to find out whether this grouping matches how
    people actually ask is to record what was chosen and whether the model
    then called something from it. Guessing at the grouping from an armchair
    is how it drifts.
    """
    groups = pick_groups(request)
    wanted = set(CORE)
    for g in groups:
        wanted.update(GROUPS.get(g, []))
    # A tool in no group at all — a plugin dropped into tools.d, say — is
    # sent every turn rather than never. Unreachable is the one outcome that
    # is not allowed, and a plugin the user installed is a tool they chose.
    known = set(CORE) | {n for v in GROUPS.values() for n in v}
    chosen = [t for t in all_tools
              if t.get("name") in wanted or t.get("name") not in known]
    return chosen, groups


def ungrouped(all_tools: list) -> list:
    """Tools belonging to no group. Used by the tests and the release guard.

    Empty for everything OSprime ships; a plugin may legitimately appear
    here, which is why this reports rather than raises.
    """
    known = set(CORE) | {n for v in GROUPS.values() for n in v}
    return sorted(t.get("name") for t in all_tools
                  if t.get("name") not in known)


def duplicates() -> list:
    """Tools listed in more than one group, or in a group and the core."""
    seen, dupes = set(), set()
    for name in CORE + [n for v in GROUPS.values() for n in v]:
        if name in seen:
            dupes.add(name)
        seen.add(name)
    return sorted(dupes)


def worst_case(all_tools: list) -> tuple:
    """The largest tool payload any single request can produce, in schema
    characters, and the group that produces it. What the release guard has
    to measure — checking the average would pass a build that breaks on the
    one question somebody actually asks."""
    import json
    by_name = {t.get("name"): t for t in all_tools}
    extra = [by_name[n] for n in ungrouped(all_tools) if n in by_name]
    core = [by_name[n] for n in CORE if n in by_name] + extra

    def size(tools):
        return len(json.dumps(tools, ensure_ascii=False))

    # Up to MAX_GROUPS may be sent together, so the worst case is the
    # largest combination, not the largest single group. Measuring one group
    # would be a guard that measures something adjacent — the mistake that
    # caused all of this.
    import itertools
    worst, which = 0, ()
    names = list(GROUPS)
    for n in range(1, MAX_GROUPS + 1):
        for combo in itertools.combinations(names, n):
            tools = core + [by_name[x] for g in combo
                            for x in GROUPS[g] if x in by_name]
            s = size(tools)
            if s > worst:
                worst, which = s, combo
    return worst, which
