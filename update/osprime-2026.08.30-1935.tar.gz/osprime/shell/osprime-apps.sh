#!/usr/bin/env bash
# The Apps menu.
#
# archiso's base image drags in a rescue toolkit — xgps, xgpsspeed, Avahi
# browsers, Software Token, Qt V4L2 test utilities, lftp, Vim. Useful on an
# installer ISO, meaningless to someone who wants to open their photos, and
# together they make the menu unusable for the person this OS is for.
#
# So the menu is a curated list rather than whatever happens to be installed.
# Everything else is still installed and still runnable from a terminal; it
# is simply not offered to someone browsing for an application.
#
# Adding an application to the OS means adding its name here too.

ALLOW=(
  osprime-settings
  thunar
  mousepad
  imv
  mpv
  gimp org.gnome.gimp
  libreoffice-writer libreoffice-calc libreoffice-impress libreoffice-startcenter
  galculator
  chromium
  foot
)

SEARCH=(/usr/share/applications /usr/local/share/applications
        "$HOME/.local/share/applications")

MENU="$(mktemp -d)"
trap 'rm -rf "$MENU"' EXIT
mkdir -p "$MENU/applications"
MISSING=/tmp/osprime-apps-missing.log
: > "$MISSING"

# Package name and desktop-entry name are not the same thing. Xfce and GNOME
# applications ship reverse-DNS files — mousepad installs
# org.xfce.mousepad.desktop — so an exact filename match silently dropped
# them from the menu. Match the exact name first, then any entry whose name
# ends with .<name>, which is precise enough not to catch anything unrelated.
find_desktop() {
    local want="$1" dir f
    for dir in "${SEARCH[@]}"; do
        [ -d "$dir" ] || continue
        [ -f "$dir/$want.desktop" ] && { printf '%s\n' "$dir/$want.desktop"; return 0; }
        for f in "$dir"/*."$want".desktop; do
            [ -f "$f" ] && { printf '%s\n' "$f"; return 0; }
        done
    done
    return 1
}

found=0
for name in "${ALLOW[@]}"; do
    if entry="$(find_desktop "$name")"; then
        cp "$entry" "$MENU/applications/"
        found=$((found + 1))
    else
        echo "$name" >> "$MISSING"
    fi
done

# An empty menu is worse than a cluttered one: fall back rather than show
# the user nothing at all.
if [ "$found" -eq 0 ]; then
    exec fuzzel
fi

# fuzzel reads <dir>/applications/*.desktop for each entry in XDG_DATA_DIRS.
# Pointing both variables at the curated directory hides everything else.
export XDG_DATA_DIRS="$MENU"
export XDG_DATA_HOME="$MENU"
exec fuzzel
