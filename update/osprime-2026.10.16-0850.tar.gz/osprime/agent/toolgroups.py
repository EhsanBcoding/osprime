"""Which tools the model is shown on a given turn.

Read docs/TOOL_BUDGET.md first. The short version: OSprime shipped 65 tool
definitions to a 3B model on every turn. That is ~7,200 tokens, which is 88%
of the 8192-token window the vision models use — so the engine truncated,
the tool list fell off, and the assistant politely denied every ability it
had. Raising the context fixed the truncation and did nothing about the
other half of the problem: published work is consistent that a model's
ability to pick the right tool DEGRADES well before the context fills, with
the knee around 20-25 tools. We were showing 65.

So we show a group. The selection happens HERE, in Python, before the model
runs — not by asking the model which tools it wants. That distinction is the
whole design:

    A tool-search step costs a model turn. This project has already
    established on this machine that a small model does one thing per turn —
    it would not chain take_photo into look, and the fix was to remove the
    chain rather than coach it. Asking such a model to "first find the tool
    you need" buys a token saving with the one capability we know is
    weakest. It would answer ABOUT searching.

The model's experience is unchanged: it gets a list of tools and calls one.
The list is just short and relevant.

Two rules govern every choice below:

  * EVERY TOOL IS REACHABLE. Grouping decides what is offered this turn,
    never what exists. `run_shell` is in the core, so the model is never
    actually helpless.
  * UNCERTAINTY SENDS MORE, NEVER LESS. Two groups is still under 3,500
    tokens; a missing tool is a turn that fails completely. The failure
    direction has to be "too many tools", which costs accuracy slowly.
"""

import re

# --------------------------------------------------------------------------
# The core: sent on every turn, whatever the question.
#
# Small on purpose — seven tools is 555 tokens. Each earns its place by
# being the answer to a request that arrives in any context at all:
# run_shell so the model is never without a way to act, list_files and
# open_file because "show me my…" is the most common thing anyone asks this
# machine, remember because a fact can be mentioned in passing during any
# conversation, and the three that describe the machine itself.
# --------------------------------------------------------------------------
CORE = [
    "run_shell",
    "list_files",
    "open_file",
    "remember",
    "get_settings",
    "power",
    "system_info",
]

# --------------------------------------------------------------------------
# The groups.
#
# Every tool belongs to exactly one, and test_groups_cover_every_tool()
# below enforces that — a tool in no group is a tool that can never be
# offered, and a tool in two is a token cost paid twice.
#
# The names are the user's mental model, not the code's. "documents" holds
# the PDF and image tools because a person asking to merge two PDFs is
# thinking about documents, not about ghostscript.
# --------------------------------------------------------------------------
GROUPS = {
    "camera": [
        "take_photo", "look", "list_capture_devices", "set_volume", "media",
    ],
    "files": [
        "search_files", "read_file", "write_file", "delete_files", "save_chat",
        "disk_usage", "list_drives", "mount_drive",
    ],
    # Moving, copying, renaming and zipping (agent/everyday.py, 16 October).
    # A group of its own: "files" + "jobs" was already the largest turn.
    "filework": [
        "manage_files", "archive",
    ],
    "documents": [
        "make_document", "merge_pdfs", "compress_pdf", "ocr_pdf",
        "convert_images", "passport_photo", "remove_background",
        "make_signature",
    ],
    "apps": [
        "list_apps", "search_apps", "app_info", "install_app",
        "uninstall_app", "open_app", "close_app", "list_windows", "processes",
    ],
    "network": [
        "list_wifi", "connect_wifi", "forget_wifi", "wifi_radio",
        "network_status", "web_search", "fetch_url", "open_url", "weather",
    ],
    "appearance": [
        "set_wallpaper", "list_backgrounds", "set_display", "get_display",
        "set_language", "take_screenshot", "set_keyboard", "brightness",
    ],
    "clock": [
        "get_time", "set_time", "set_timezone", "set_auto_time",
    ],
    "memory": [
        "recall", "forget", "save_skill",
    ],
    "updates": [
        "check_update", "self_update", "update_status", "rollback_update",
        "model_status",
    ],
    "jobs": [
        "run_job", "job_status", "list_jobs", "list_shortcuts",
        "set_shortcut", "schedule_task", "list_schedules", "remove_schedule",
        "guide_me",
    ],
    "maths": [
        "calc", "random_number",
    ],
    # The helpers' own tools (agent/helpers.py, 9 October). A helper always
    # has its tools; the groups let the General assistant reach them too.
    "research": [
        "research_papers",
    ],
    "markets": [
        "market_price", "watchlist",
    ],
    "code": [
        "repos_status", "github_repo",
    ],
    "helpers": [
        "create_helper",
    ],
    # Step 3 (9 October): watchers and the new helpers' sources.
    "watchers": [
        "watch",
    ],
    "health": [
        "health_info",
    ],
    "lookup": [
        "look_up",
    ],
    # Making pictures (agent/images.py, 12 October).
    "images": [
        "make_image",
    ],
    # Making videos (agent/videos.py, 12 October).
    "videos": [
        "make_video",
    ],
    # Deep answers with the big local model (agent/deep.py, 12 October).
    "deep": [
        "deep_answer",
    ],
    # "Do it for me" in an app's window (shell/companion_act.py, 13 October).
    "act": [
        "do_on_screen",
    ],
}

# --------------------------------------------------------------------------
# What a request has to say to reach a group.
#
# Keywords a person can read and correct, not an embedding score nobody can
# debug — and not another model to ship, load and keep in RAM on a machine
# that is already tight. When this is wrong, it is wrong in a way somebody
# can see and fix in one line.
#
# Both languages. Ehsan types Persian to it and the OS answers in the user's
# language, so an English-only map would route every Persian request to the
# fallback — which would work, and would quietly undo the whole feature.
#
# A hint matches where a WORD STARTS, not anywhere in the string. Stems
# still work — "photo" catches photos and photograph, "دوربین" catches
# دوربینم — but a hint can no longer hide inside an unrelated word.
#
# This was not theoretical. The first version matched plain substrings and
# "check for updates" was routed to the clock, because "date" is inside
# "up-date-s". It cost the turn six tool definitions and would have been
# very hard to notice: the answer still worked, because `updates` matched
# too. A wrong group that happens to be harmless today is the kind of thing
# that is wrong for months.
# --------------------------------------------------------------------------
# The hints themselves live in agent/lang/<code>.json since 15 October
# (agent/langpacks.py, docs/LANGUAGES.md): English and Persian as they were
# here, French and German beside them. The reasons once written beside each
# list are kept in en.json under "note".
import langpacks  # noqa: E402
HINTS, _WHOLE = langpacks.routing()

# Never send more than this many groups at once.
#
# Two, not three. Three was measured first and put the worst case at 47% of
# an 8192 window — under the line, but with little room left for the
# conversation and the tool results, which is what got us here. Two puts it
# at 39%. The cost is a request naming three different areas at once, which
# is rare and which the second-pass retry is for.
MAX_GROUPS = 2

# When nothing matches.
#
# Something on this computer, or something out in the world — those are the
# two places an unclassified request is likely to be pointing. `apps` is
# deliberately absent: requests about applications almost always say
# install, open, program or app, so the hints already catch them, and every
# group in here is paid for on every unclassified turn.
#
# Exactly MAX_GROUPS long, and a test enforces that. The fallback used to be
# three groups while MAX_GROUPS was two, so the one path where we know least
# about the request sent the MOST tools — the opposite of what was intended,
# and invisible because it still worked.
FALLBACK = ["files", "network"]


def _normalise(text: str) -> str:
    text = (text or "").lower()
    # Arabic yeh/kaf appear in Persian text from some keyboards and would
    # make a hint match on one machine and not another.
    return text.replace("ي", "ی").replace("ك", "ک")


# A letter in either script. Used to require that a hint begins a word.
_LETTER = r"\w؀-ۿ"
_cache = {}


def _matches(hint: str, text: str) -> bool:
    pat = _cache.get(hint)
    if pat is None:
        # A French or German hint is a whole word unless it ends in * ("lies"
        # is German for "read" and the start of the English "lies"); English
        # and Persian hints match at the start of a word, as they always did.
        word = re.escape(_normalise(hint.rstrip("*")).strip())
        end = f"(?![{_LETTER}])" if hint in _WHOLE else ""
        pat = _cache[hint] = re.compile(f"(?<![{_LETTER}])" + word + end)
    return bool(pat.search(text))


# Evidence a word list cannot express. 28 September, the tool check: "what
# is 17% of 2340" never reached maths ("%" follows a digit, so it never
# starts a word), "Read me the page archlinux.org" went to files and opened
# a file called https:/archlinux.org, and "convert the photo x.avif in my
# Downloads to PNG" lost documents to photo + Downloads on a three-way tie.
# Each pattern adds this many points to its group.
_PATTERNS = [
    ("maths", re.compile(r"\d\s*%|\d\s*[-+*/×÷^]\s*\d"), 3),
    ("network", re.compile(r"https?://|(?<![\w@])[\w-]+(?:\.[\w-]+)*\.(?:com|org|net|io|ir|dev|"
                           r"gov|edu|info|co|app|ai|me|tv|uk|de|fr)\b"), 3),
    # a picture on disk, named: `look` answers questions about it
    ("camera", re.compile(r"\.(?:jpe?g|png|webp|heic|avif|gif|bmp)\b"), 2),
    # The ones in words — "the document about the rent", "learn: when I say X,
    # do Y" (each with its story in git history) — are in the language packs.
] + langpacks.patterns()

# The verbs of the document tools outweigh the nouns around them: in
# "convert the photo … in my Downloads to PNG" the job is converting.
_STRONG = langpacks.strong()


def pick_groups(request: str, previous=()) -> list:
    """Which groups this request needs. Never empty.

    `previous` is what the last request in this conversation was given.
    A follow-up that names nothing — "again", "yes", "do it once more",
    "the other one" — is about the same thing, so it gets the same groups
    instead of the fallback (28 September: "again" after "open the browser"
    went to files + network, without open_app, and the model said the
    browser was open again when nothing had happened)."""
    low = _normalise(request)
    scored = []
    for group, hints in HINTS.items():
        # A hint scores one point per word. "in the background" is three
        # words of evidence that this is a background job; "background" on
        # its own is one word that also means a wallpaper. Counting both as
        # one hit let the vaguer word win on list order.
        hits = sum(len(h.split()) for h in hints if _matches(h, low))
        hits += sum(2 for h in _STRONG.get(group, ()) if _matches(h, low))
        hits += sum(w for g, pat, w in _PATTERNS if g == group and pat.search(low))
        if hits:
            scored.append((hits, group))
    if not scored:
        return list(previous or FALLBACK)
    # Most specific first, but keep the near-misses: a request that mentions
    # both a photo and a file wants both groups, and sending both costs
    # about a thousand tokens against a turn that otherwise fails.
    #
    # When more than MAX_GROUPS match, the best-scoring ones are kept. This
    # used to throw them ALL away and send the fallback instead, on the
    # theory that matching everything means matching nothing. Measured
    # against real phrasings it was wrong: "convert all my videos in the
    # background" matched three groups, lost every one of them, and was sent
    # files and network. Three matches is usually two right answers and one
    # stray word, not noise.
    #
    # Ties go to the order of HINTS, which is roughly most-specific first.
    order = {g: i for i, g in enumerate(HINTS)}
    scored.sort(key=lambda s: (-s[0], order[s[1]]))
    return [g for _, g in scored[:MAX_GROUPS]]


def tools_for(request: str, all_tools: list, skill_tools=(), previous=(), max_groups=None):
    """The tool schemas to send this turn, and why.

    Returns (tools, groups). The second value exists so the caller can log
    it: the only honest way to find out whether this grouping matches how
    people actually ask is to record what was chosen and whether the model
    then called something from it. Guessing at the grouping from an armchair
    is how it drifts.

    `skill_tools` are the tools a matched skill declares, and they are
    ALWAYS sent. The keyword groups alone lost the main tool of a skill on
    37 of the 123 trigger phrases the skills ship with — "passport photo"
    went to the camera group because it says "photo", "update my resume" to
    the updates group — so the skill's instructions told the model to use a
    tool it had not been given. A skill that recognised the request is far
    better evidence of what is needed than a keyword, so it wins.
    """
    groups = pick_groups(request, previous)
    if max_groups is not None:
        groups = groups[:max_groups]
    wanted = set(CORE) | set(skill_tools or ())
    for g in groups:
        wanted.update(GROUPS.get(g, []))
    # A tool in no group at all — a plugin dropped into tools.d, say — is
    # sent every turn rather than never. Unreachable is the one outcome that
    # is not allowed, and a plugin the user installed is a tool they chose.
    known = set(CORE) | {n for v in GROUPS.values() for n in v}
    chosen = [t for t in all_tools
              if t.get("name") in wanted or t.get("name") not in known]
    return chosen, groups


def ungrouped(all_tools: list) -> list:
    """Tools belonging to no group. Used by the tests and the release guard.

    Empty for everything OSprime ships; a plugin may legitimately appear
    here, which is why this reports rather than raises.
    """
    known = set(CORE) | {n for v in GROUPS.values() for n in v}
    return sorted(t.get("name") for t in all_tools
                  if t.get("name") not in known)


def duplicates() -> list:
    """Tools listed in more than one group, or in a group and the core."""
    seen, dupes = set(), set()
    for name in CORE + [n for v in GROUPS.values() for n in v]:
        if name in seen:
            dupes.add(name)
        seen.add(name)
    return sorted(dupes)


def skill_selftest(skills: list, all_tools: list) -> list:
    """Every trigger phrase a skill ships with must reach that skill's tools.

    Run against the skills' own phrasings because they are the best record
    this project has of how people actually ask. The failure it guards
    against shipped once: 30% of triggers lost their skill's main tool.
    """
    import skills as skills_mod
    names = {t.get("name") for t in all_tools}
    bad = []
    for skill in skills:
        tools = [t for t in skill.get("tools", []) if t in names]
        for t in skill.get("tools", []):
            if t not in names:
                bad.append(f"skill {skill.get('name')}: lists '{t}', which "
                           "does not exist")
        for trig in skill.get("triggers", []):
            matched = skills_mod.match(trig)
            extra = matched.get("tools", []) if matched else []
            offered = {t.get("name") for t in tools_for(trig, all_tools, extra)[0]}
            if tools and tools[0] not in offered:
                bad.append(f"skill {skill.get('name')}: {trig!r} does not "
                           f"reach {tools[0]}")
    return bad


def worst_case(all_tools: list, skill_tool_sets=()) -> tuple:
    """The largest tool payload any single request can produce, in schema
    characters, and the group that produces it. What the release guard has
    to measure — checking the average would pass a build that breaks on the
    one question somebody actually asks."""
    import json
    by_name = {t.get("name"): t for t in all_tools}
    extra = [by_name[n] for n in ungrouped(all_tools) if n in by_name]
    core = [by_name[n] for n in CORE if n in by_name] + extra

    def size(tools):
        return len(json.dumps(tools, ensure_ascii=False))

    # Up to MAX_GROUPS may be sent together, so the worst case is the
    # largest combination, not the largest single group. Measuring one group
    # would be a guard that measures something adjacent — the mistake that
    # caused all of this.
    # And a matched skill adds its own tools on top, so the worst turn is
    # the worst combination PLUS the worst skill.
    import itertools
    worst, which = 0, ()
    names = list(GROUPS)
    skill_sets = [()] + [tuple(s) for s in (skill_tool_sets or ())]
    for n in range(1, MAX_GROUPS + 1):
        for combo in itertools.combinations(names, n):
            for extra in skill_sets:
                wanted = {x for g in combo for x in GROUPS[g]} | set(extra)
                tools = core + [by_name[x] for x in sorted(wanted)
                                if x in by_name and x not in CORE]
                s = size(tools)
                if s > worst:
                    worst, which = s, combo + (("+skill",) if extra else ())
    return worst, which


# --------------------------------------------------------------------------
# How a person actually asks for each tool, in English and in Persian.
#
# Checked on every release by routing_selftest(): each phrase must reach
# its tool. Written after the first version of the grouping shipped and
# lost the tool on 12 of these phrases and on 37 of the 123 phrases the
# skills carry — "open youtube" went to the apps group, "فلشم وصله" to the
# network group, "convert all my videos in the background" to neither. The
# grouping was measured for size and never for whether it was right.
#
# A new tool gets a line here, or the release refuses to build.
# --------------------------------------------------------------------------
ROUTING_EXAMPLES = {
 "take_photo": ("take a picture of me", "یه عکس ازم بگیر"),
 "look": ("what do you see through the camera", "با دوربین ببین چی جلوته"),
 "list_capture_devices": ("which cameras and microphones do I have", "چه دوربین و میکروفنی دارم"),
 "set_volume": ("turn the volume up", "صدا رو زیاد کن"),
 "media": ("pause the music", "آهنگ بعدی رو بذار"),
 "manage_files": ("move the photos from Downloads to Pictures", "این فایل رو به پوشه اسناد منتقل کن"),
 "archive": ("unzip the file I downloaded", "این فایل زیپ رو باز کن"),
 "processes": ("why is my computer so slow", "کامپیوترم چرا کند شده"),
 "brightness": ("make the screen brighter", "نور صفحه رو کم کن"),
 "search_files": ("find the contract about the shop rent", "فایلی که درباره اجاره مغازه بود رو پیدا کن"),
 "read_file": ("read notes.txt to me", "فایل notes.txt رو بخون"),
 "write_file": ("save this text to a file", "این متن رو توی یه فایل ذخیره کن"),
 "delete_files": ("delete the old screenshots", "اسکرین‌شات‌های قدیمی رو پاک کن"),
 "disk_usage": ("how much space is left", "چقدر فضا مونده"),
 "list_drives": ("is my usb stick connected", "فلشم وصله"),
 "mount_drive": ("open my usb drive", "فلش رو باز کن"),
 "make_document": ("write a letter to my landlord", "یه نامه برای صاحبخونه بنویس"),
 "merge_pdfs": ("merge these pdfs", "این پی‌دی‌اف‌ها رو یکی کن"),
 "compress_pdf": ("make this pdf smaller", "این پی‌دی‌اف رو کم حجم کن"),
 "ocr_pdf": ("make this scanned pdf searchable", "متن این پی‌دی‌اف اسکن‌شده رو قابل جستجو کن"),
 "convert_images": ("convert these images to jpg", "این عکس‌ها رو به jpg تبدیل کن"),
 "passport_photo": ("make a passport photo", "عکس پاسپورتی درست کن"),
 "remove_background": ("remove the background from this photo", "پس‌زمینه این عکس رو حذف کن"),
 "make_signature": ("make a signature for me", "یه امضا برام درست کن"),
 "list_apps": ("what apps do I have", "چه برنامه‌هایی دارم"),
 "search_apps": ("find me a video editor", "یه برنامه ویرایش ویدیو پیدا کن"),
 "app_info": ("tell me about gimp", "درباره برنامه gimp بگو"),
 "install_app": ("install gimp", "gimp رو نصب کن"),
 "uninstall_app": ("uninstall gimp", "gimp رو حذف نصب کن"),
 "open_app": ("open the calculator", "ماشین حساب رو باز کن"),
 "close_app": ("close the browser", "مرورگر رو ببند"),
 "list_windows": ("what windows are open", "چه پنجره‌هایی بازه"),
 "list_wifi": ("show wifi networks", "شبکه‌های وای‌فای رو نشون بده"),
 "connect_wifi": ("connect to my home wifi", "به وای‌فای خونه وصل شو"),
 "forget_wifi": ("forget the cafe wifi", "وای‌فای کافه رو فراموش کن"),
 "wifi_radio": ("turn wifi off", "وای‌فای رو خاموش کن"),
 "network_status": ("am I online", "اینترنتم وصله"),
 "web_search": ("search the web for pasta recipes", "دستور پاستا رو سرچ کن"),
 "fetch_url": ("what does this page say https://example.org", "این صفحه چی نوشته https://example.org"),
 "open_url": ("open youtube", "یوتیوب رو باز کن"),
 "weather": ("what's the weather", "هوا چطوره"),
 "set_wallpaper": ("change my wallpaper", "والپیپر رو عوض کن"),
 "list_backgrounds": ("show me the backgrounds", "پس‌زمینه‌ها رو نشون بده"),
 "set_display": ("make everything bigger", "همه چیز رو بزرگ‌تر کن"),
 "get_display": ("what is my screen resolution", "رزولوشن صفحه چنده"),
 "set_language": ("switch to persian", "زبان رو فارسی کن"),
 "set_keyboard": ("add a persian keyboard", "کیبورد فارسی اضافه کن"),
 "recall": ("what do you know about Ali", "درباره علی چی میدونی"),
 "forget": ("forget that I live in Tehran", "فراموش کن که من تهران زندگی می‌کنم"),
 "save_skill": ("learn how to do my weekly report: every time I say weekly report, list my Documents/Reports folder and make a document",
                "یاد بگیر: هر وقت گفتم گزارش هفتگی، پوشه گزارش‌ها رو نشون بده"),
 "take_screenshot": ("take a screenshot", "یه اسکرین‌شات بگیر"),
 "get_time": ("what time is it", "ساعت چنده"),
 "set_time": ("set the time to 14:30", "ساعت رو روی ۱۴:۳۰ تنظیم کن"),
 "set_timezone": ("set my timezone to Tehran", "منطقه زمانی رو تهران کن"),
 "set_auto_time": ("set the clock automatically", "ساعت رو خودکار تنظیم کن"),
 "check_update": ("check for updates", "آپدیت جدید هست"),
 "self_update": ("update yourself", "خودت رو آپدیت کن"),
 "update_status": ("did the update finish", "آپدیت تموم شد"),
 "rollback_update": ("go back to the previous version", "به نسخه قبلی برگرد"),
 "model_status": ("which model are you running", "با کدوم مدل کار می‌کنی"),
 "run_job": ("convert all my videos in the background", "همه ویدیوهام رو در پس‌زمینه تبدیل کن"),
 "job_status": ("is the background job done", "کار پس‌زمینه تموم شد"),
 "list_jobs": ("what jobs are running", "چه کارهایی در حال اجراست"),
 "list_shortcuts": ("what keyboard shortcuts do I have", "میانبرهای کیبوردم چیه"),
 "set_shortcut": ("make ctrl+alt+t open the terminal", "یه میانبر کیبورد بساز"),
 "schedule_task": ("remind me every morning at 8", "هر روز ساعت ۸ یادم بنداز"),
 "list_schedules": ("what reminders do I have", "چه یادآورهایی دارم"),
 "guide_me": ("show me how to change the wallpaper", "نشونم بده چطور پس‌زمینه رو عوض کنم"),
 "research_papers": ("find papers on sleep and memory", "مقاله درباره خواب و حافظه پیدا کن"),
 "market_price": ("what is the price of bitcoin", "قیمت طلا چنده"),
 "watchlist": ("add ETH to my watchlist", "اتریوم رو به فهرست بازار اضافه کن"),
 "repos_status": ("what state are my git projects in", "وضعیت پروژه‌های گیت من چیه"),
 "github_repo": ("is the CI green on the github repo torvalds/linux", "وضعیت ریپو گیت‌هاب torvalds/linux چیه"),
 "create_helper": ("make me a helper for my accounting", "یه کمک‌کار برای حسابداری بساز"),
 "watch": ("tell me when bitcoin goes over 70000", "وقتی قیمت طلا از ۴۰۰۰ رد شد خبرم کن"),
 "health_info": ("what are the side effects of ibuprofen", "عوارض داروی ایبوپروفن چیه"),
 "look_up": ("what does wikipedia say about photosynthesis", "معنی کلمه serendipity چیه"),
 "do_on_screen": ("do it for me: turn on dark mode in the text editor",
                  "خودت انجام بده: فرم ثبت‌نام رو برام پر کن"),
 "deep_answer": ("think deeply about whether I should rent or buy a flat",
                 "عمیق فکر کن: بهترین راه یادگیری برنامه‌نویسی برای من چیه؟"),
 "make_video": ("make a video of waves on a beach at sunset", "animate the last picture",
                "یه ویدیو بساز از بارون روی شیشه", "این عکس رو متحرک کن"),
 "make_image": ("make me a picture of a cat on the moon", "draw a logo for my bakery",
                "یه تصویر بساز از یه جنگل در مه", "یه گربه بکش"),
 "remove_schedule": ("delete the drink water reminder", "یادآوری آب خوردن رو حذف کن"),
 "calc": ("what is 17 times 23", "۱۷ ضرب در ۲۳ چند میشه"),
 "random_number": ("pick a random number", "یه عدد تصادفی بگو"),
 "save_chat": ("save this chat as a text file", "از این چت یک فایل تکسی بساز"),
}


# Phrasings from the real log, 24 September, and what they must — and must
# not — be given. (phrase, tool that must be offered, tool that must not be)
ROUTING_FROM_LOG = [
    ("can you take a picture and describe it", "take_photo", None),
    ("show me the last photo in the camera folder", "list_files", None),
    ("I'm trying to cook dinner, can you suggest a persian dish", None,
     "set_language"),
    ("answer me in persian please", None, "set_language"),
    ("switch the language to persian", "set_language", None),
    ("حالا بگو ببینم فارسی هم بلدی ؟", None, "take_photo"),
    ("بگو ببینم هوا چطوره", "weather", "take_photo"),
    ("Extract this chat to a .txt", "save_chat", None),
    ("کارت گرافیکی که استفاده میکنی چی هست ؟", "model_status", None),
    ("در مورد سخت افزار لپتاپ بگو", "model_status", None),
]


def routing_selftest(all_tools: list) -> list:
    import skills as skills_mod
    bad = []
    names = {t.get("name") for t in all_tools}
    for tool in sorted(names - set(ROUTING_EXAMPLES) - set(CORE)):
        bad.append(f"routing: {tool} has no example phrases in "
                   "ROUTING_EXAMPLES")
    for q, must, must_not in ROUTING_FROM_LOG:
        offered = {t.get("name") for t in tools_for(q, all_tools)[0]}
        if must and must in names and must not in offered:
            bad.append(f"routing: {q!r} does not reach {must}")
        if must_not and must_not in offered:
            bad.append(f"routing: {q!r} is offered {must_not}")
    for tool, phrases in ROUTING_EXAMPLES.items():
        for q in phrases:
            matched = skills_mod.match(q)
            extra = matched.get("tools", []) if matched else []
            offered = {t.get("name") for t in tools_for(q, all_tools, extra)[0]}
            if tool in names and tool not in offered:
                bad.append(f"routing: {q!r} does not reach {tool} "
                           f"(went to {pick_groups(q)})")
    return bad
