"""Choose the local model from what the machine can actually run.

Every OSprime so far has shipped the same 1.5B model to every computer,
because the ISO has to boot on anything. That is the right thing for a
bootstrap and the wrong thing forever: on a laptop with 16 GB of RAM it
leaves most of the machine unused, and the difference between a 1.5B and a
3B was the difference between "described the tool instead of calling it"
and "just did it".

The rule that decides the tier is deliberately not "how much RAM is there".
It is "how fast will the answer come back", and on a CPU that is bounded by
memory bandwidth, not capacity. A 7B model fits in 16 GB comfortably and
still produces about three words a second on an eighth-generation laptop
chip, which is not a computer you can talk to. So without a GPU the ladder
stops at 3B however much memory is installed.

Nothing here downloads anything on its own. It reports what it would
choose; installing is a separate, explicit act.
"""

import glob
import json
import os
import pathlib
import re
import shutil
import subprocess

MODELS_DIR = pathlib.Path(os.environ.get("OSPRIME_MODELS",
                                         "/var/lib/osprime/models"))
MODEL_ENV = pathlib.Path(os.environ.get("OSPRIME_MODEL_ENV",
                                        "/etc/osprime/model.env"))

HF = "https://huggingface.co/Qwen"

# Verified against the Hugging Face API rather than assumed. The 7B q4_k_m
# is published as two shards — llama.cpp loads the rest of a split GGUF
# automatically when handed the first one, but both have to be downloaded,
# and a single-file URL guessed from the pattern would have 404'd.
TIERS = {
    "tiny": {
        "label": "Qwen2.5 0.5B",
        "repo": "Qwen2.5-0.5B-Instruct-GGUF",
        "files": ["qwen2.5-0.5b-instruct-q4_k_m.gguf"],
        "disk_mb": 500, "ram_gb": 2, "ctx": 8192,
        "note": "the smallest thing that still follows instructions",
    },
    "small": {
        "label": "Qwen2.5 1.5B",
        "repo": "Qwen2.5-1.5B-Instruct-GGUF",
        "files": ["qwen2.5-1.5b-instruct-q4_k_m.gguf"],
        "disk_mb": 1200, "ram_gb": 4, "ctx": 16384,
        "note": "what the installer ships; runs anywhere",
    },
    "medium": {
        "label": "Qwen2.5 3B",
        "repo": "Qwen2.5-3B-Instruct-GGUF",
        "files": ["qwen2.5-3b-instruct-q4_k_m.gguf"],
        "disk_mb": 2200, "ram_gb": 8, "ctx": 16384,
        "note": "the first size that reliably calls tools instead of "
                "describing them",
    },
    "large": {
        "label": "Qwen2.5 7B",
        "repo": "Qwen2.5-7B-Instruct-GGUF",
        "files": ["qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf",
                  "qwen2.5-7b-instruct-q4_k_m-00002-of-00002.gguf"],
        "disk_mb": 5200, "ram_gb": 16, "ctx": 16384,
        "note": "needs a GPU to be worth it; on a CPU it is too slow to "
                "talk to",
    },
}

ORDER = ["tiny", "small", "medium", "large"]

# --------------------------------------------------------------------------
# Models that can also see
#
# Deliberately a separate table, and deliberately NOT in ORDER — so
# recommend() never picks one on its own. Vision is something the user asks
# for, not something the machine decides to switch its brain for.
#
# Why separate rather than replacing the tiers above: this product lives on
# tool calling, and there is no evidence that Qwen2.5-VL is as good at it
# as Qwen2.5. Trading tool reliability for eyesight would be a bad deal,
# and worse, a silent one — everything would get slightly less reliable
# with no visible cause. So it is a choice, and it is reversible: the old
# model stays on disk. (Agreed with Ehsan, 21 September.)
#
# The owner is unsloth, not Qwen. Qwen publishes no official GGUF of the VL
# models, so unlike every tier above, this is a third-party build: 213
# likes and 161,000 downloads on the 7B, apache-2.0, and it ships the
# projector. We chose Flathub's *verified* subset for applications for
# exactly this kind of reason, so this exception is written down rather
# than glossed over.
#
# Sizes are the real file sizes from the Hugging Face API, not estimates.
# Note what they show: the projector barely shrinks between the 7B and the
# 3B (1291 MB against 1276 MB). The vision encoder is not quantised the way
# the language model is, so on a small machine it is most of the cost —
# which is why there is no VL tier below 3B.
VISION_TIERS = {
    "vision-medium": {
        "label": "Qwen2.5-VL 3B (sees)",
        "owner": "unsloth",
        "repo": "Qwen2.5-VL-3B-Instruct-GGUF",
        "files": ["Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf"],
        "mmproj": "mmproj-F16.gguf",
        # 1840 MB model + 1276 MB projector, plus room for the cache.
        # 16384, not 8192: run at 16384 on the reference laptop (RTX 4070
        # Laptop, 8 GB) on 23 September without trouble. The cache for 16k
        # on a 3B is roughly 600 MB. 8192 left ~4,500 tokens for the
        # conversation once the tools were in, which a long chat or one web
        # page fills.
        "disk_mb": 3400, "ram_gb": 8, "ctx": 16384,
        "note": "can look at a photo; smaller, so less reliable at tools",
    },
    "vision-large": {
        "label": "Qwen2.5-VL 7B (sees)",
        "owner": "unsloth",
        "repo": "Qwen2.5-VL-7B-Instruct-GGUF",
        "files": ["Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf"],
        "mmproj": "mmproj-F16.gguf",
        # 4466 MB model + 1291 MB projector. This said "on an 8 GB card that
        # plus a 16k cache does not fit" and set 8192 — an estimate, not a
        # measurement. Measured on 24 September on the reference laptop (RTX
        # 4070 Laptop, 8 GB): it runs at 16384. If a smaller card cannot
        # hold it, osprime-model.sh's fallback ladder still starts the
        # engine with fewer GPU layers rather than not at all.
        "disk_mb": 6400, "ram_gb": 16, "ctx": 16384,
        "note": "needs a GPU with 8 GB, and even then the context is "
                "halved to make room for the vision encoder",
    },
}


def _run(args, timeout=15):
    try:
        r = subprocess.run(args, capture_output=True, text=True,
                           timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception:
        return 1, ""


def _ram_gb() -> float:
    try:
        kb = int(re.search(r"MemTotal:\s+(\d+)",
                           pathlib.Path("/proc/meminfo").read_text()).group(1))
        return round(kb / 1024 / 1024, 1)
    except Exception:
        return 0.0


def _disk_free_mb(path=MODELS_DIR) -> int:
    """Free space on the filesystem the models live on.

    Walk up until something exists. On a fresh machine neither the models
    directory nor its parent has been created yet, and looking at only one
    level up reported zero free space — which then quietly downgraded the
    recommendation to the smallest model on a machine with a half-empty
    disk.
    """
    target = path
    for _ in range(6):
        if target.exists():
            try:
                st = os.statvfs(str(target))
                return int(st.f_bavail * st.f_frsize / 1024 / 1024)
            except Exception:
                return 0
        if target.parent == target:
            break
        target = target.parent
    return 0


def _gpu() -> dict:
    """Is there a GPU worth offloading to, and how much memory has it?

    Deliberately conservative. Claiming a GPU that turns out not to work
    means picking a model the machine then cannot run at a usable speed,
    and the symptom of that is a computer that takes a minute to answer —
    which reads as broken rather than as a wrong setting.
    """
    out = {"present": False, "kind": "", "vram_gb": 0.0, "why": "",
           # "present" means hardware exists. "useful" means offloading to it
           # is worth doing — an old integrated chip is present and useless,
           # and a card whose driver is missing is present and not yet usable.
           "useful": False, "vendor": "", "driver_missing": False}

    # NVIDIA reports its own memory precisely; take it when offered.
    if shutil.which("nvidia-smi"):
        code, text = _run(["nvidia-smi",
                           "--query-gpu=memory.total,name",
                           "--format=csv,noheader,nounits"])
        if code == 0 and text.strip():
            first = text.strip().splitlines()[0].split(",")
            try:
                # nvidia-smi already says "NVIDIA GeForce RTX 4070 Laptop
                # GPU", so prefixing the vendor produced "NVIDIA NVIDIA
                # GeForce ...".
                model = first[1].strip()
                out.update(present=True, useful=True,
                           kind=model if model.upper().startswith("NVIDIA")
                                else f"NVIDIA {model}",
                           vram_gb=round(int(first[0]) / 1024, 1),
                           why="reported by nvidia-smi")
                return out
            except Exception:
                pass

    if shutil.which("vulkaninfo"):
        # vulkaninfo segfaults on a hybrid laptop whose discrete card has no
        # driver. A crash is not an answer, so a non-zero return falls
        # through to the PCI bus rather than being read as "no GPU".
        code, text = _run(["vulkaninfo", "--summary"], timeout=25)
        if code == 0 and "deviceName" in text:
            m = re.search(r"deviceName\s*=\s*(.+)", text)
            name = m.group(1).strip() if m else "Vulkan device"
            discrete = "DISCRETE_GPU" in text
            out.update(present=True, kind=name)
            if discrete:
                m = re.search(r"deviceLocalMemory\D+(\d+)\s*MB", text)
                if m:
                    out["vram_gb"] = round(int(m.group(1)) / 1024, 1)
                out["why"] = "a discrete GPU with its own memory"
                out["useful"] = True
            else:
                # An earlier version dismissed every integrated GPU as
                # "shares system memory and gains nothing". That was true of
                # the Intel UHD chips it was written for and is wrong about
                # what came after: Arc and RDNA integrated graphics have real
                # compute units and read the same memory the CPU does, which
                # is exactly what reading a long prompt needs.
                out["why"] = ("integrated graphics; useful for this if it is "
                              "a recent Arc or RDNA part")
                # \M is not a Python escape — it was a typo for \b, and it
                # made re.search raise, which took the whole of
                # model_status down with it. The chat could only say "I was
                # unable to determine the model of this machine".
                # The AMD integrated parts worth using are named 740M, 760M,
                # 780M, 880M, 890M. Requiring a word boundary right after
                # the digits missed all of them, because the M is a word
                # character — "Radeon 780M" did not match.
                out["useful"] = _worth_offloading(name)
            return out

    # Last and most reliable: ask the PCI bus. Everything above needs
    # software that comes WITH a driver, so a machine whose driver is not
    # installed was reported as having no GPU — which is exactly backwards,
    # because that machine is the one that needs telling. A laptop with an
    # RTX card was told it had no graphics hardware at all.
    pci = _pci_gpus()
    if pci:
        best = pci[0]
        out.update(present=True, kind=best["name"], vendor=best["vendor"])
        out["why"] = (f"found on the PCI bus, but its driver is not "
                      f"installed, so it cannot be used yet")
        out["driver_missing"] = True
        return out

    out["why"] = "no graphics hardware found"
    return out


# Integrated graphics worth putting a model on. The AMD parts are named
# 740M/760M/780M/880M/890M; Intel's are Arc and Iris Xe. Everything older
# shares system memory without having the compute to make up for it.
_USEFUL_IGPU = re.compile(
    r"\bArc\b|Radeon\s+(?:74|76|78|88|89)0M\b|RDNA|Iris\S*\s+Xe", re.I)


def _worth_offloading(name: str) -> bool:
    return bool(_USEFUL_IGPU.search(name or ""))


# Real device names, and what the answer has to be for each. This exists
# because the pattern above shipped with `\M` in it — not a Python escape —
# and raised the moment it ran on a machine with integrated graphics. It
# could not have run here: this box has no GPU, so the branch was never
# reached and the bug travelled all the way to a user's laptop, where it
# took down the whole tool and reported itself as "I was unable to
# determine the model of this machine".
_SELFTEST_GPUS = [
    ("Intel(R) Arc(tm) Graphics (MTL)", True),
    ("Intel(R) Iris(R) Xe Graphics", True),
    ("AMD Radeon 780M Graphics", True),
    ("AMD Radeon 890M", True),
    ("AMD Radeon Graphics (RDNA 3)", True),
    ("Intel(R) UHD Graphics 620", False),
    ("AMD Radeon Vega 8", False),
    ("", False),
]


def selftest() -> list:
    """Exercise the parts that only run on hardware this machine lacks.

    Returns a list of failures, empty when all is well. Called by
    release.sh, so a pattern that cannot run never leaves the workshop.
    """
    bad = []
    for line, want in _SELFTEST_LOG:
        try:
            got = ("gpu" if _says_gpu(line)
                   else "cpu" if _says_cpu(line) else "neither")
        except Exception as e:
            bad.append(f"log line {line!r} raised {type(e).__name__}: {e}")
            continue
        if got != want:
            bad.append(f"log line {line!r} read as {got}, expected {want}")
    for name, want in _SELFTEST_GPUS:
        try:
            got = _worth_offloading(name)
        except Exception as e:
            bad.append(f"{name!r} raised {type(e).__name__}: {e}")
            continue
        if got != want:
            bad.append(f"{name!r} -> {got}, expected {want}")
    # Every tier must name files and produce reachable-looking URLs.
    for tier, spec in TIERS.items():
        if not spec.get("files"):
            bad.append(f"tier {tier} names no files")
        for f in spec["files"]:
            if not f.endswith(".gguf"):
                bad.append(f"tier {tier}: {f} is not a .gguf")
    # And a recommendation must come back for any shape of machine.
    for ram in (2, 4, 8, 16, 64):
        for gpu in ({"present": False, "useful": False, "vram_gb": 0.0,
                     "driver_missing": False, "kind": "", "why": ""},
                    {"present": True, "useful": True, "vram_gb": 12.0,
                     "driver_missing": False, "kind": "test", "why": ""},
                    {"present": True, "useful": False, "vram_gb": 0.0,
                     "driver_missing": True, "kind": "test", "why": ""}):
            try:
                recommend({"cpu": "t", "cores": 8, "ram_gb": float(ram),
                           "disk_free_mb": 500000, "gpu": gpu})
            except Exception as e:
                bad.append(f"recommend({ram}GB, {gpu['kind'] or 'no gpu'}) "
                           f"raised {type(e).__name__}: {e}")
    return bad


_PCI_VENDORS = {"0x10de": "NVIDIA", "0x1002": "AMD", "0x8086": "Intel"}


def _pci_gpus() -> list:
    """Graphics hardware, straight from the bus. Needs no driver at all."""
    found = []
    for d in sorted(glob.glob("/sys/bus/pci/devices/*")):
        try:
            cls = pathlib.Path(d, "class").read_text().strip()
            if not (cls.startswith("0x0300") or cls.startswith("0x0302")):
                continue
            vend = pathlib.Path(d, "vendor").read_text().strip()
        except Exception:
            continue
        name = _PCI_VENDORS.get(vend, vend)
        found.append({"vendor": name, "name": name + " graphics",
                      "discrete": cls.startswith("0x0300") and vend != "0x8086"})
    # lspci knows the model names; use them when pciutils is installed.
    if found and shutil.which("lspci"):
        code, text = _run(["lspci", "-mm"])
        if code == 0:
            for line in text.splitlines():
                if '"VGA compatible controller"' in line or '"3D controller"' in line:
                    parts = re.findall(r'"([^"]*)"', line)
                    if len(parts) >= 3:
                        for f in found:
                            if f["vendor"].lower() in parts[1].lower():
                                f["name"] = f"{parts[1].split()[0]} {parts[2]}"
    # A discrete card first: it is the one worth doing anything about.
    found.sort(key=lambda f: not f["discrete"])
    return found


def profile() -> dict:
    cores = os.cpu_count() or 1
    ram = _ram_gb()
    gpu = _gpu()
    try:
        cpu = re.search(r"model name\s*:\s*(.+)",
                        pathlib.Path("/proc/cpuinfo").read_text()).group(1)
    except Exception:
        cpu = "unknown"
    return {
        "cpu": cpu.strip(), "cores": cores, "ram_gb": ram,
        "disk_free_mb": _disk_free_mb(), "gpu": gpu,
    }


def recommend(p: dict = None) -> dict:
    """Which tier this machine should run, and the reasoning, in words."""
    p = p or profile()
    ram, cores, gpu = p["ram_gb"], p["cores"], p["gpu"]
    reasons = []

    if ram >= 16:
        tier = "medium"
        reasons.append(f"{ram} GB of memory is plenty")
    elif ram >= 8:
        tier = "medium"
        reasons.append(f"{ram} GB of memory fits a 3B model")
    elif ram >= 4:
        tier = "small"
        reasons.append(f"{ram} GB of memory is enough for 1.5B, not more")
    else:
        tier = "tiny"
        reasons.append(f"only {ram} GB of memory")

    # What decides whether 7B is reachable is the card's own memory, not the
    # machine's. An earlier version required 16 GB of system RAM as well,
    # which ruled out a laptop with 15 GB and an 8 GB RTX card — a machine
    # that can run 7B comfortably, because on a GPU the model lives in VRAM.
    if gpu.get("useful") and gpu["vram_gb"] >= 6 and ram >= 8:
        tier = "large"
        reasons.append(f"a {gpu['kind']} with {gpu['vram_gb']} GB can carry 7B")
    elif gpu.get("useful") and gpu["vram_gb"]:
        reasons.append(
            f"the {gpu['kind']} has {gpu['vram_gb']} GB, not enough for 7B, "
            "so 3B stays the larger useful size")
    elif gpu.get("useful"):
        reasons.append(
            f"the {gpu['kind']} shares system memory, so it speeds this up "
            "without making a bigger model affordable")
    elif gpu.get("driver_missing"):
        reasons.append(
            f"there is a {gpu['kind']} here but its driver is not installed, "
            "so nothing can use it yet — setup-gpu.sh fixes that, and a "
            "larger model may become worth it afterwards")
    elif ram >= 16:
        reasons.append("but with no GPU, 7B would answer at about three "
                       "words a second, so 3B is the larger useful size")

    if cores <= 2 and tier != "tiny":
        tier = ORDER[max(0, ORDER.index(tier) - 1)]
        reasons.append(f"stepped down one size: {cores} cores is not enough "
                       "to keep a larger model responsive")

    need = TIERS[tier]["disk_mb"]
    if p["disk_free_mb"] and p["disk_free_mb"] < need + 1000:
        while tier != "tiny" and p["disk_free_mb"] < TIERS[tier]["disk_mb"] + 1000:
            tier = ORDER[ORDER.index(tier) - 1]
        reasons.append(f"limited by free disk space "
                       f"({p['disk_free_mb']} MB available)")

    return spec_for(tier, why="; ".join(reasons))


def spec_for(tier: str, why: str = "") -> dict:
    """Everything needed to fetch and run one tier, vision ones included.

    The owner is part of the spec rather than a constant, because the VL
    builds do not come from Qwen. Baking the owner into the URL was fine
    while every model came from one place and would have quietly produced
    a 404 the first time one did not.
    """
    table = VISION_TIERS if tier in VISION_TIERS else TIERS
    if tier not in table:
        raise KeyError(tier)
    spec = dict(table[tier])
    spec["tier"] = tier
    spec["why"] = why
    owner = spec.get("owner", "Qwen")
    base = f"https://huggingface.co/{owner}/{spec['repo']}/resolve/main"
    spec["urls"] = [f"{base}/{f}" for f in spec["files"]]
    # The projector is downloaded like any other file, but named
    # separately: llama-server needs it as --mmproj, not as a model.
    if spec.get("mmproj"):
        spec["files"] = list(spec["files"]) + [spec["mmproj"]]
        spec["urls"] = list(spec["urls"]) + [f"{base}/{spec['mmproj']}"]
    spec["sees"] = bool(spec.get("mmproj"))
    return spec


def vision_options() -> list:
    """The vision models, with a plain answer about whether each would fit.

    Reported rather than chosen. recommend() will never return one of
    these, so something has to be able to say "this machine could run the
    7B one" without switching to it.
    """
    p = profile()
    out = []
    for tier in ("vision-medium", "vision-large"):
        spec = spec_for(tier)
        gpu = p["gpu"]
        vram = gpu.get("vram_gb", 0) if gpu.get("useful") else 0
        weights_gb = spec["disk_mb"] / 1024
        fits_gpu = vram >= weights_gb + 1.5      # + cache and buffers
        out.append({
            "tier": tier, "label": spec["label"], "note": spec["note"],
            "download_mb": spec["disk_mb"],
            "enough_disk": p["disk_free_mb"] >= spec["disk_mb"] + 500,
            "enough_ram": p["ram_gb"] >= spec["ram_gb"] - 1,
            "fits_on_the_graphics_card": fits_gpu,
            "how_to_install":
                f"sudo bash /opt/osprime/shell/osprime-profile.sh {tier}",
        })
    return out


def installed() -> dict:
    """What is on this machine now, according to the environment file."""
    current = {}
    try:
        for line in MODEL_ENV.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            current[k.strip()] = v.strip().strip('"')
    except Exception:
        pass
    path = pathlib.Path(current.get("MODEL_PATH",
                                    str(MODELS_DIR / "bootstrap.gguf")))
    size = path.stat().st_size if path.is_file() else 0
    return {
        "path": str(path),
        "exists": path.is_file(),
        "size_mb": round(size / 1024 / 1024) if size else 0,
        "tier": current.get("OSPRIME_MODEL_TIER", "unknown"),
        "label": current.get("OSPRIME_MODEL_LABEL", ""),
        "context": current.get("MODEL_CTX", "4096"),
        # Whether the running model can look at an image, decided by the
        # projector being on disk rather than by the tier name. A model
        # installed to see and then missing its projector answers questions
        # about images by inventing an answer, so this has to be a fact
        # about files, not a label.
        "mmproj": current.get("MODEL_MMPROJ", ""),
        "sees": bool(current.get("MODEL_MMPROJ")
                     and pathlib.Path(current["MODEL_MMPROJ"]).is_file()),
    }


# What llama.cpp actually prints when it loads a model. Two mistakes lived
# here, and both were the same mistake: writing a pattern from memory
# instead of from output.
#
#   * The weights buffer is named "CPU_Mapped model buffer size" when the
#     file is memory-mapped, not "CPU model buffer size". Requiring a space
#     after CPU matched nothing, so a machine plainly running on its
#     processor reported "unknown" and the GPU setup script gave up.
#   * "offloading 0 repeating layers to GPU" is what it prints when nothing
#     was offloaded. Matching the word "offloading" therefore called a
#     CPU-only run a GPU run.
_GPU_SAYS = re.compile(
    r"(?:CUDA|Vulkan|ROCm|SYCL|HIP|Metal)\d+\s+model buffer"
    r"|offloaded\s+[1-9]\d*\s*/"
    r"|offloading\s+[1-9]\d*\s+repeating layers"
    r"|offloading output layer to GPU",
    re.I)
_CPU_SAYS = re.compile(r"\bCPU\S*\s+model buffer", re.I)


def _says_gpu(line: str) -> bool:
    return bool(_GPU_SAYS.search(line or ""))


def _says_cpu(line: str) -> bool:
    return bool(_CPU_SAYS.search(line or ""))


# Real lines, copied from llama.cpp output, and what each has to mean.
_SELFTEST_LOG = [
    ("load_tensors:   CPU_Mapped model buffer size =  1918.35 MiB", "cpu"),
    ("load_tensors:        CPU model buffer size =   102.64 MiB", "cpu"),
    ("load_tensors:  CPU_REPACK model buffer size =   900.00 MiB", "cpu"),
    ("load_tensors: offloading 0 repeating layers to GPU", "neither"),
    ("load_tensors: offloading 28 repeating layers to GPU", "gpu"),
    ("load_tensors: offloading output layer to GPU", "gpu"),
    ("load_tensors: offloaded 29/29 layers to GPU", "gpu"),
    ("load_tensors: offloaded 0/29 layers to GPU", "neither"),
    ("load_tensors:      CUDA0 model buffer size =  4155.99 MiB", "gpu"),
    ("load_tensors:    Vulkan0 model buffer size =  4155.99 MiB", "gpu"),
    ("load_tensors:  CUDA_Host model buffer size =   102.64 MiB", "neither"),
    ("llama_context: n_ctx = 16384", "neither"),
]


def engine_status() -> dict:
    """Is the model running on the processor or on the graphics card?

    A fair question that should not require a terminal, and one that cannot
    be answered by looking at settings: a GPU flag can be passed and then
    ignored, and a driver can be installed and not used. The only honest
    source is what the engine itself said when it loaded the model.
    """
    out = {"running_on": "unknown", "gpu_layers_requested": False,
           "evidence": ""}

    # What was actually asked for, from the process that is running — not
    # from a configuration file that may not match it.
    for pid in glob.glob("/proc/[0-9]*"):
        try:
            cmd = pathlib.Path(pid, "cmdline").read_bytes().split(b"\0")
        except Exception:
            continue
        if not cmd or b"llama-server" not in cmd[0]:
            continue
        args = [a.decode(errors="replace") for a in cmd if a]
        out["command"] = " ".join(args)
        out["pid"] = os.path.basename(pid)
        out["gpu_layers_requested"] = any(
            a in ("--n-gpu-layers", "-ngl") for a in args)
        break

    # The definitive test, where it is available: is the engine's own
    # process holding graphics memory? This is ground truth and needs no
    # guessing about wording. It went in because reading the journal did not
    # work — this build of llama.cpp does not log the buffer lines at all,
    # so the log-based answer stayed "unknown" no matter how the patterns
    # were written.
    if out.get("pid") and shutil.which("nvidia-smi"):
        code, text = _run(["nvidia-smi",
                           "--query-compute-apps=pid,used_memory",
                           "--format=csv,noheader,nounits"])
        if code == 0:
            for line in text.splitlines():
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 2 and parts[0] == out["pid"]:
                    out["running_on"] = "graphics card"
                    out["evidence"] = (f"the engine is holding {parts[1]} MiB "
                                       "of graphics memory")
                    return out
            if text.strip():
                out["evidence"] = ("the graphics card is in use by something, "
                                   "but not by the engine")
            else:
                out["running_on"] = "processor"
                out["evidence"] = ("nothing is using the graphics card, so "
                                   "the engine is not")
                return out

    # _run here returns (code, text) — this module's own helper, not the
    # three-value one in system_tools.
    code, log = _run(["journalctl", "-u", "osprime-model", "-b",
                      "--no-pager", "-o", "cat"], timeout=30)
    if code == 0 and log:
        gpu_lines = [l.strip() for l in log.splitlines() if _says_gpu(l)]
        cpu_lines = [l.strip() for l in log.splitlines() if _says_cpu(l)]
        if gpu_lines:
            out["running_on"] = "graphics card"
            out["evidence"] = gpu_lines[-1][:200]
        elif cpu_lines:
            out["running_on"] = "processor"
            out["evidence"] = cpu_lines[-1][:200]
        rung = [l.strip() for l in log.splitlines() if l.startswith("running (")]
        if rung:
            out["startup_settings"] = rung[-1]
    if out["running_on"] == "unknown" and not out.get("command"):
        out["evidence"] = "the inference engine does not appear to be running"
    return out


def report() -> dict:
    p = profile()
    return {"machine": p, "running_now": installed(), "engine": engine_status(),
            "recommended": recommend(p)}


def write_env(tier: str, model_path: str) -> str:
    """Point the engine at a model. Written only after it has been proved
    to load — see osprime-profile.sh."""
    spec = TIERS.get(tier) or VISION_TIERS.get(tier)
    if not spec:
        return f"ERROR: unknown tier {tier}"
    # The projector sits beside the model, because that is where the
    # profiler downloaded it. Named here so osprime-model.sh does not have
    # to guess, and absent for a text-only model so the flag is simply not
    # passed rather than passed empty.
    proj = ""
    if spec.get("mmproj"):
        candidate = pathlib.Path(model_path).with_name(spec["mmproj"])
        if candidate.is_file():
            proj = str(candidate)
        else:
            return (f"ERROR: {spec['label']} needs its vision file "
                    f"{spec['mmproj']} next to the model, and it is not "
                    f"there. Nothing was changed.")
    try:
        MODEL_ENV.parent.mkdir(parents=True, exist_ok=True)
        MODEL_ENV.write_text(
            "# Written by the OSprime hardware profiler.\n"
            "# Read by osprime-model.service, after its built-in defaults,\n"
            "# so anything set here wins. Delete this file to go back to\n"
            "# the model the system was installed with.\n"
            f'MODEL_PATH="{model_path}"\n'
            f'MODEL_CTX="{spec["ctx"]}"\n'
            f'MODEL_MMPROJ="{proj}"\n'
            f'OSPRIME_MODEL_TIER="{tier}"\n'
            f'OSPRIME_MODEL_LABEL="{spec["label"]}"\n',
            encoding="utf-8")
    except PermissionError:
        return "ERROR: this needs root — run the profiler with sudo."
    except Exception as e:
        return f"ERROR: could not write {MODEL_ENV}: {e}"
    return f"{MODEL_ENV} now points at {spec['label']}"


if __name__ == "__main__":
    print(json.dumps(report(), indent=2))
