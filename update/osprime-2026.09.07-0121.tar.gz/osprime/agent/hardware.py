"""Choose the local model from what the machine can actually run.

Every OSprime so far has shipped the same 1.5B model to every computer,
because the ISO has to boot on anything. That is the right thing for a
bootstrap and the wrong thing forever: on a laptop with 16 GB of RAM it
leaves most of the machine unused, and the difference between a 1.5B and a
3B was the difference between "described the tool instead of calling it"
and "just did it".

The rule that decides the tier is deliberately not "how much RAM is there".
It is "how fast will the answer come back", and on a CPU that is bounded by
memory bandwidth, not capacity. A 7B model fits in 16 GB comfortably and
still produces about three words a second on an eighth-generation laptop
chip, which is not a computer you can talk to. So without a GPU the ladder
stops at 3B however much memory is installed.

Nothing here downloads anything on its own. It reports what it would
choose; installing is a separate, explicit act.
"""

import json
import os
import pathlib
import re
import shutil
import subprocess

MODELS_DIR = pathlib.Path(os.environ.get("OSPRIME_MODELS",
                                         "/var/lib/osprime/models"))
MODEL_ENV = pathlib.Path(os.environ.get("OSPRIME_MODEL_ENV",
                                        "/etc/osprime/model.env"))

HF = "https://huggingface.co/Qwen"

# Verified against the Hugging Face API rather than assumed. The 7B q4_k_m
# is published as two shards — llama.cpp loads the rest of a split GGUF
# automatically when handed the first one, but both have to be downloaded,
# and a single-file URL guessed from the pattern would have 404'd.
TIERS = {
    "tiny": {
        "label": "Qwen2.5 0.5B",
        "repo": "Qwen2.5-0.5B-Instruct-GGUF",
        "files": ["qwen2.5-0.5b-instruct-q4_k_m.gguf"],
        "disk_mb": 500, "ram_gb": 2, "ctx": 4096,
        "note": "the smallest thing that still follows instructions",
    },
    "small": {
        "label": "Qwen2.5 1.5B",
        "repo": "Qwen2.5-1.5B-Instruct-GGUF",
        "files": ["qwen2.5-1.5b-instruct-q4_k_m.gguf"],
        "disk_mb": 1200, "ram_gb": 4, "ctx": 4096,
        "note": "what the installer ships; runs anywhere",
    },
    "medium": {
        "label": "Qwen2.5 3B",
        "repo": "Qwen2.5-3B-Instruct-GGUF",
        "files": ["qwen2.5-3b-instruct-q4_k_m.gguf"],
        "disk_mb": 2200, "ram_gb": 8, "ctx": 8192,
        "note": "the first size that reliably calls tools instead of "
                "describing them",
    },
    "large": {
        "label": "Qwen2.5 7B",
        "repo": "Qwen2.5-7B-Instruct-GGUF",
        "files": ["qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf",
                  "qwen2.5-7b-instruct-q4_k_m-00002-of-00002.gguf"],
        "disk_mb": 5200, "ram_gb": 16, "ctx": 8192,
        "note": "needs a GPU to be worth it; on a CPU it is too slow to "
                "talk to",
    },
}

ORDER = ["tiny", "small", "medium", "large"]


def _run(args, timeout=15):
    try:
        r = subprocess.run(args, capture_output=True, text=True,
                           timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception:
        return 1, ""


def _ram_gb() -> float:
    try:
        kb = int(re.search(r"MemTotal:\s+(\d+)",
                           pathlib.Path("/proc/meminfo").read_text()).group(1))
        return round(kb / 1024 / 1024, 1)
    except Exception:
        return 0.0


def _disk_free_mb(path=MODELS_DIR) -> int:
    """Free space on the filesystem the models live on.

    Walk up until something exists. On a fresh machine neither the models
    directory nor its parent has been created yet, and looking at only one
    level up reported zero free space — which then quietly downgraded the
    recommendation to the smallest model on a machine with a half-empty
    disk.
    """
    target = path
    for _ in range(6):
        if target.exists():
            try:
                st = os.statvfs(str(target))
                return int(st.f_bavail * st.f_frsize / 1024 / 1024)
            except Exception:
                return 0
        if target.parent == target:
            break
        target = target.parent
    return 0


def _gpu() -> dict:
    """Is there a GPU worth offloading to, and how much memory has it?

    Deliberately conservative. Claiming a GPU that turns out not to work
    means picking a model the machine then cannot run at a usable speed,
    and the symptom of that is a computer that takes a minute to answer —
    which reads as broken rather than as a wrong setting.
    """
    out = {"present": False, "kind": "", "vram_gb": 0.0, "why": ""}

    # NVIDIA reports its own memory precisely; take it when offered.
    if shutil.which("nvidia-smi"):
        code, text = _run(["nvidia-smi",
                           "--query-gpu=memory.total,name",
                           "--format=csv,noheader,nounits"])
        if code == 0 and text.strip():
            first = text.strip().splitlines()[0].split(",")
            try:
                out.update(present=True, kind=f"NVIDIA {first[1].strip()}",
                           vram_gb=round(int(first[0]) / 1024, 1),
                           why="reported by nvidia-smi")
                return out
            except Exception:
                pass

    # Anything else: only count it if a Vulkan-capable llama build could
    # actually use it. A DRM device on its own may be integrated graphics
    # sharing system memory, which buys nothing.
    if shutil.which("vulkaninfo"):
        code, text = _run(["vulkaninfo", "--summary"], timeout=25)
        if code == 0 and "deviceName" in text:
            name = ""
            m = re.search(r"deviceName\s*=\s*(.+)", text)
            if m:
                name = m.group(1).strip()
            discrete = "DISCRETE_GPU" in text
            out.update(present=discrete, kind=name or "Vulkan device",
                       why="Vulkan reports a discrete GPU" if discrete else
                           "only integrated graphics, which shares system "
                           "memory and gains nothing")
            if discrete:
                m = re.search(r"deviceLocalMemory\D+(\d+)\s*MB", text)
                if m:
                    out["vram_gb"] = round(int(m.group(1)) / 1024, 1)
            return out

    out["why"] = "no GPU detected"
    return out


def profile() -> dict:
    cores = os.cpu_count() or 1
    ram = _ram_gb()
    gpu = _gpu()
    try:
        cpu = re.search(r"model name\s*:\s*(.+)",
                        pathlib.Path("/proc/cpuinfo").read_text()).group(1)
    except Exception:
        cpu = "unknown"
    return {
        "cpu": cpu.strip(), "cores": cores, "ram_gb": ram,
        "disk_free_mb": _disk_free_mb(), "gpu": gpu,
    }


def recommend(p: dict = None) -> dict:
    """Which tier this machine should run, and the reasoning, in words."""
    p = p or profile()
    ram, cores, gpu = p["ram_gb"], p["cores"], p["gpu"]
    reasons = []

    if ram >= 16:
        tier = "medium"
        reasons.append(f"{ram} GB of memory is plenty")
    elif ram >= 8:
        tier = "medium"
        reasons.append(f"{ram} GB of memory fits a 3B model")
    elif ram >= 4:
        tier = "small"
        reasons.append(f"{ram} GB of memory is enough for 1.5B, not more")
    else:
        tier = "tiny"
        reasons.append(f"only {ram} GB of memory")

    # The ladder stops at 3B without a GPU, whatever the memory says. A 7B
    # model fits in 16 GB easily and still writes about three words a second
    # on a laptop processor, which is not something you can hold a
    # conversation with.
    if gpu["present"] and gpu["vram_gb"] >= 6 and ram >= 16:
        tier = "large"
        reasons.append(f"a {gpu['kind']} with {gpu['vram_gb']} GB can carry 7B")
    elif ram >= 16:
        if gpu["present"]:
            reasons.append(
                f"but the {gpu['kind']} has only {gpu['vram_gb']} GB, which "
                "cannot hold 7B, so 3B is the larger useful size")
        else:
            reasons.append("but with no GPU, 7B would answer at about three "
                           "words a second, so 3B is the larger useful size")

    if cores <= 2 and tier != "tiny":
        tier = ORDER[max(0, ORDER.index(tier) - 1)]
        reasons.append(f"stepped down one size: {cores} cores is not enough "
                       "to keep a larger model responsive")

    need = TIERS[tier]["disk_mb"]
    if p["disk_free_mb"] and p["disk_free_mb"] < need + 1000:
        while tier != "tiny" and p["disk_free_mb"] < TIERS[tier]["disk_mb"] + 1000:
            tier = ORDER[ORDER.index(tier) - 1]
        reasons.append(f"limited by free disk space "
                       f"({p['disk_free_mb']} MB available)")

    spec = dict(TIERS[tier])
    spec["tier"] = tier
    spec["why"] = "; ".join(reasons)
    spec["urls"] = [f"{HF}/{spec['repo']}/resolve/main/{f}"
                    for f in spec["files"]]
    return spec


def installed() -> dict:
    """What is on this machine now, according to the environment file."""
    current = {}
    try:
        for line in MODEL_ENV.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            current[k.strip()] = v.strip().strip('"')
    except Exception:
        pass
    path = pathlib.Path(current.get("MODEL_PATH",
                                    str(MODELS_DIR / "bootstrap.gguf")))
    size = path.stat().st_size if path.is_file() else 0
    return {
        "path": str(path),
        "exists": path.is_file(),
        "size_mb": round(size / 1024 / 1024) if size else 0,
        "tier": current.get("OSPRIME_MODEL_TIER", "unknown"),
        "label": current.get("OSPRIME_MODEL_LABEL", ""),
        "context": current.get("MODEL_CTX", "4096"),
    }


def report() -> dict:
    p = profile()
    return {"machine": p, "running_now": installed(), "recommended": recommend(p)}


def write_env(tier: str, model_path: str) -> str:
    """Point the engine at a model. Written only after it has been proved
    to load — see osprime-profile.sh."""
    spec = TIERS.get(tier)
    if not spec:
        return f"ERROR: unknown tier {tier}"
    try:
        MODEL_ENV.parent.mkdir(parents=True, exist_ok=True)
        MODEL_ENV.write_text(
            "# Written by the OSprime hardware profiler.\n"
            "# Read by osprime-model.service, after its built-in defaults,\n"
            "# so anything set here wins. Delete this file to go back to\n"
            "# the model the system was installed with.\n"
            f'MODEL_PATH="{model_path}"\n'
            f'MODEL_CTX="{spec["ctx"]}"\n'
            f'OSPRIME_MODEL_TIER="{tier}"\n'
            f'OSPRIME_MODEL_LABEL="{spec["label"]}"\n',
            encoding="utf-8")
    except PermissionError:
        return "ERROR: this needs root — run the profiler with sudo."
    except Exception as e:
        return f"ERROR: could not write {MODEL_ENV}: {e}"
    return f"{MODEL_ENV} now points at {spec['label']}"


if __name__ == "__main__":
    print(json.dumps(report(), indent=2))
