#!/usr/bin/env bash
# Launch the local inference server.
#
# This lives in a script rather than inline in the unit file because the
# one-liner version failed silently: systemd splits Environment= on
# whitespace, so "--ctx-size 4096 --jinja" became three assignments and
# llama-server was started with a valueless --ctx-size. All you saw was a
# restart loop and "local model engine is not running".
#
# Run it by hand to see exactly what is wrong:
#     bash /opt/osprime/shell/osprime-model.sh
set -u

MODEL="${MODEL_PATH:-/var/lib/osprime/models/bootstrap.gguf}"
PORT="${MODEL_PORT:-8087}"
CTX="${MODEL_CTX:-4096}"

BIN="$(command -v llama-server || command -v llama-cpp-server || true)"
if [ -z "$BIN" ]; then
    echo "FATAL: no llama-server binary in PATH." >&2
    echo "Binaries provided by the llama-cpp package:" >&2
    pacman -Ql llama-cpp 2>/dev/null | grep '/usr/bin/' >&2 || echo "  llama-cpp not installed" >&2
    exit 1
fi

if [ ! -s "$MODEL" ]; then
    echo "FATAL: model file missing or empty: $MODEL" >&2
    ls -l "$(dirname "$MODEL")" >&2 2>/dev/null || true
    exit 1
fi

# No --threads: llama.cpp defaults to -1, which auto-detects the core count.
# Passing it explicitly only adds a way for the value to arrive malformed.
ARGS=(-m "$MODEL"
      --host 127.0.0.1
      --port "$PORT"
      --ctx-size "$CTX")

# --jinja turns on the chat template that native tool calling needs, but it
# is not in every llama.cpp build. Probe rather than assume: without the
# probe an unsupported flag kills the server on startup, which looks
# identical to a missing model.
if "$BIN" --help 2>&1 | grep -q -- '--jinja'; then
    ARGS+=(--jinja)
else
    echo "note: this llama-server has no --jinja; falling back to the" >&2
    echo "      text tool-call protocol in agent/local.py." >&2
fi

# Reuse the cached prefix between turns. The system prompt and the tool
# definitions are identical every request and are the bulk of the input —
# roughly 2,000 tokens that otherwise get re-read from scratch each time,
# which is where the multi-second wait before the first word comes from.
if "$BIN" --help 2>&1 | grep -q -- '--cache-reuse'; then
    ARGS+=(--cache-reuse 256)
fi

# Every flag below is probed, never assumed. An unsupported flag makes
# llama-server exit immediately, which from the outside looks exactly like a
# missing model file — a whole evening went into that distinction once.
has() { "$BIN" --help 2>&1 | grep -q -- "$1"; }

# Keep the weights in RAM. Without this the file is memory-mapped and the
# first question of the day pages several gigabytes in from disk while the
# user watches nothing happen. On a spinning disk this alone was most of the
# wait.
if has '--mlock'; then
    ARGS+=(--mlock)
fi

# Reading the prompt is a different job from writing the answer, and it is
# the one that keeps people waiting: about two thousand tokens of system
# prompt and tool definitions before a single word comes back. It
# parallelises across cores far better than generation does, so give it
# every core even when generation is left on the default.
CORES="$(nproc 2>/dev/null || echo 0)"
if [ "$CORES" -gt 0 ] && has '--threads-batch'; then
    ARGS+=(--threads-batch "$CORES")
fi

# A larger batch reads that prompt in fewer passes.
if has '--batch-size'; then
    ARGS+=(--batch-size 512)
fi

if has '--flash-attn'; then
    ARGS+=(--flash-attn)
fi

echo "starting: $BIN ${ARGS[*]}"
exec "$BIN" "${ARGS[@]}"
