#!/usr/bin/env bash
# Secure Boot with this computer's own keys. docs/ENCRYPTION.md, plan C.
#
#   osprime-secureboot.sh status            where it stands (no root needed)
#   osprime-secureboot.sh prepare           keys, one signed startup file (UKI)
#   osprime-secureboot.sh enroll            put our keys in the firmware
#   osprime-secureboot.sh finish [--auto]   bind the disk to them, tidy up
#   osprime-secureboot.sh firmware          restart into the firmware setup
#   osprime-secureboot.sh verify            everything that boots is signed
#
# Why: the kernel and initramfs sit on the unencrypted boot partition. With
# only the TPM, someone with the laptop for an afternoon can swap the
# initramfs for one that copies the disk key out, and the TPM cannot tell.
# After this, the kernel, initramfs and kernel command line are one file
# signed with keys made on this computer; the firmware refuses anything
# else, and the TPM (PCR 7) releases the disk only after a boot checked
# against those keys.
#
# The order, and who drives it:
#   prepare   the installer, or Settings on a machine installed before this
#   enroll    needs the firmware in Setup Mode — clearing its keys is done
#             by a person in the firmware screen; it differs on every laptop
#   (restart; Secure Boot on — some firmware does that itself)
#   finish    runs by itself at the next start (osprime-secureboot-finish
#             .service), or from Settings when the disk also needs a PIN
#
# The one restart where Secure Boot turns on changes PCR 7, so the TPM
# would refuse the disk that once. `enroll` therefore adds a temporary TPM
# way in that is not tied to PCR 7, for that restart only; `finish` binds a
# new one to PCR 7 and wipes both the old one and the temporary one
# (decided, Ehsan, 26 September: 2 = A). Microsoft's keys are kept next to
# ours (1 = yes): some graphics and network cards will not start without
# them, and PCR 7 records which key approved the boot, so a Microsoft-signed
# USB stick still does not get the disk.
#
# A PIN, when the disk has one, arrives on stdin — never on a command line.
set -u
R="${OSPRIME_SB_ROOT:-}"
GUID=8be4df61-93ca-11d2-aa0d-00e098032b8c
EFIVARS="$R/sys/firmware/efi/efivars"
STATE="$R/var/lib/osprime/secureboot.json"
CRYPTTAB="$R/etc/crypttab.initramfs"
DISK_STATE="$R/etc/osprime/disk.json"
CMDLINE="$R/etc/kernel/cmdline"
PRESET="$R/etc/mkinitcpio.d/linux.preset"
LOADER="$R/boot/loader/loader.conf"
OLD_ENTRY="$R/boot/loader/entries/osprime.conf"
UKI=/boot/EFI/Linux/osprime.efi
# Two ways back, both signed (27 September, VM: one broken UKI left a boot
# menu with nothing to start and nothing to say why):
#   FALLBACK  the same kernel with every driver (mkinitcpio's fallback) -
#             for an initramfs autodetect got wrong, or a half-written file
#   PREVIOUS  the last UKI that worked, kept just before a kernel upgrade -
#             for a kernel update that does not start
# Both are signed with the same keys, so the TPM still opens the disk.
FALLBACK=/boot/EFI/Linux/osprime-fallback.efi
PREVIOUS=/boot/EFI/Linux/osprime-previous.efi
HOOK="$R/etc/pacman.d/hooks/osprime-keep-previous-uki.hook"
BOOT_EFI=/usr/lib/systemd/boot/efi/systemd-bootx64.efi
FINISH_UNIT=osprime-secureboot-finish.service
# The installer's TPM key has no PCRs; the first start of the installed
# system binds one to PCR 7 (10 October, VM: a key bound to PCR 7 while the
# installer ran from the live USB was refused at every start — PCR 7 is not
# the same there). Written by the installer, removed once bound.
BIND_FLAG="$R/var/lib/osprime/tpm-bind.pending"

die()  { echo "ERROR: $*" >&2; exit 1; }
say()  { echo "> $*"; }
root() { [ "$(id -u)" -eq 0 ] || [ -n "${OSPRIME_SB_TEST:-}" ] || die "run as root"; }

efivar() {  # the value byte after the 4 attribute bytes, or empty
    local f="$EFIVARS/$1-$GUID"
    [ -r "$f" ] || { echo ""; return; }
    od -An -tu1 -j4 -N1 "$f" 2>/dev/null | tr -d ' \n'
}
uefi()       { [ -d "$R/sys/firmware/efi" ]; }
sb_on()      { [ "$(efivar SecureBoot)" = 1 ]; }
setup_mode() { [ "$(efivar SetupMode)" = 1 ]; }

jget() {  # jget FILE KEY
    python3 - "$1" "$2" <<'PY' 2>/dev/null
import json, sys
try:
    v = json.load(open(sys.argv[1])).get(sys.argv[2], "")
except Exception:
    v = ""
print(v if v is not None else "")
PY
}
stage()  { local s; s="$(jget "$STATE" stage)"; echo "${s:-none}"; }
unlock() { jget "$DISK_STATE" unlock; }
write_state() {  # write_state STAGE [TEMP_SLOT]
    mkdir -p "$(dirname "$STATE")"
    printf '{"stage": "%s", "temp_slot": "%s"}\n' "$1" "${2:-}" > "$STATE"
    chmod 644 "$STATE"        # Settings reads it without root
}

luks_dev() {
    [ -n "${OSPRIME_SB_DEV:-}" ] && { echo "$OSPRIME_SB_DEV"; return; }
    local uuid f
    # /etc/crypttab since 9 October (x-initrd.attach), the old file before.
    for f in "$R/etc/crypttab" "$CRYPTTAB"; do
        [ -f "$f" ] || continue
        uuid="$(awk '$1=="osprime-root"{sub(/^UUID=/,"",$2); print $2}' "$f")"
        [ -n "$uuid" ] && break
    done
    [ -n "$uuid" ] && echo "/dev/disk/by-uuid/$uuid"
}
tpm_slots() { systemd-cryptenroll "$1" 2>/dev/null | awk '$2=="tpm2"{print $1}' | sort -n; }
uses_tpm()  { case "$(unlock)" in tpm|tpm-pin) return 0;; esac; return 1; }

# Secrets arrive on stdin, two lines, either may be empty:
#   1. the disk's PIN (a PIN disk only)
#   2. the disk password or the recovery key — only needed when the TPM
#      cannot open the disk right now (27 September, VM: the TPM refused,
#      and without this line there was no way forward from Settings).
# systemd-cryptenroll takes them from $PIN/$NEWPIN and $PASSWORD — never
# from a command line.
read_secrets() {
    IFS= read -r PIN || true
    IFS= read -r DISKPW || true
    if [ "$(unlock)" = tpm-pin ]; then
        [ -n "${PIN:-}" ] || die "this disk needs its PIN to do this"
        export PIN NEWPIN="$PIN"
    fi
}

# Add a TPM key; opened by the TPM, or else by the disk password/recovery
# key if one was given. On failure, says what systemd-cryptenroll said.
tpm_enroll() {  # tpm_enroll DEV PCRS
    local err
    if err="$(systemd-cryptenroll --tpm2-device=auto --tpm2-pcrs="$2" $(pin_flag) \
              --unlock-tpm2-device=auto "$1" 2>&1)"; then
        return 0
    fi
    if [ -n "${DISKPW:-}" ]; then
        err="$(PASSWORD="$DISKPW" systemd-cryptenroll --tpm2-device=auto \
               --tpm2-pcrs="$2" $(pin_flag) "$1" 2>&1)" && return 0
    fi
    TPM_ERR="$(echo "$err" | grep -v '^$' | tail -3 | paste -sd' ' -)"
    return 1
}
pin_flag() { [ "$(unlock)" = tpm-pin ] && echo "--tpm2-with-pin=yes"; }

# What must be signed: the files the firmware actually starts. NOT the
# plain kernel, /boot/vmlinuz-linux: `sbctl verify` lists it as unsigned
# (it is an EFI program too), and signing it would reopen the very hole
# this closes — a signed kernel starts with ANY initramfs, so a boot entry
# written next to it on the unencrypted partition would pass Secure Boot
# with the same PCR 7. Unsigned, it cannot start at all. (27 September, VM:
# prepare stopped at "still unsigned" because of exactly that file.)
REQUIRED="$UKI $FALLBACK /boot/EFI/BOOT/BOOTX64.EFI /boot/EFI/systemd/systemd-bootx64.efi"
unsigned_required() {  # prints the required files sbctl calls unsigned
    local out f
    out="$(sbctl verify 2>/dev/null)"
    for f in $REQUIRED; do
        echo "$out" | grep -F " $f " | grep -q "not signed" && echo "$f"
    done
}

sbctl_keys() { [ -d "$R/var/lib/sbctl/keys" ] || [ -d "$R/usr/share/secureboot/keys" ]; }

# ---------------------------------------------------------------------------
cmd="${1:-}"; shift || true
case "$cmd" in
status)
    echo "uefi=$(uefi && echo yes || echo no)"
    echo "secure_boot=$(sb_on && echo on || echo off)"
    echo "setup_mode=$(setup_mode && echo yes || echo no)"
    echo "stage=$(stage)"
    echo "unlock=$(unlock)"
    ;;

prepare)
    root
    uefi || die "this computer starts in BIOS mode — Secure Boot needs UEFI"
    command -v sbctl >/dev/null || die "sbctl is missing: sudo pacman -Syu --needed sbctl"
    case "$(stage)" in enrolled|done) say "already prepared ($(stage))"; exit 0;; esac

    # The kernel command line goes INSIDE the signed file: nobody can add
    # init=/bin/sh at the boot menu any more. Taken from the entry the
    # installer wrote, the first time.
    if [ ! -s "$CMDLINE" ]; then
        opts="$(sed -n 's/^options[[:space:]]\+//p' "$OLD_ENTRY" 2>/dev/null | head -1)"
        [ -n "$opts" ] || die "no kernel command line: neither $CMDLINE nor $OLD_ENTRY"
        mkdir -p "$(dirname "$CMDLINE")"
        echo "$opts" > "$CMDLINE"
    fi
    say "kernel command line: $(cat "$CMDLINE")"

    if ! sbctl_keys; then
        say "making this computer's own Secure Boot keys"
        sbctl create-keys || die "sbctl could not create keys"
    fi

    # The initramfs image stays as well, for the old boot entry — it is the
    # way back if the signed file ever fails, until `finish` removes it.
    say "building one signed startup file ($UKI)"
    mkdir -p "$R/boot/EFI/Linux"
    cat > "$PRESET" <<EOF
# written by osprime-secureboot.sh (docs/ENCRYPTION.md, plan C)
ALL_kver="/boot/vmlinuz-linux"
PRESETS=('default' 'fallback')
default_image="/boot/initramfs-linux.img"
default_uki="$UKI"
fallback_options="-S autodetect"
fallback_uki="$FALLBACK"
EOF
    mkinitcpio -P || die "mkinitcpio failed — nothing else was changed; the old entry still starts"
    [ -s "$R$UKI" ] || die "mkinitcpio did not write $UKI"
    [ -s "$R$FALLBACK" ] || die "mkinitcpio did not write $FALLBACK"

    # Before every kernel upgrade, the UKI that works now is kept.
    mkdir -p "$(dirname "$HOOK")"
    cat > "$HOOK" <<EOF
# written by osprime-secureboot.sh (docs/ENCRYPTION.md, plan C)
[Trigger]
Type = Package
Operation = Upgrade
Target = linux

[Action]
Description = Keeping the startup file that works now, as a way back...
When = PreTransaction
Exec = /usr/bin/bash /opt/osprime/shell/osprime-secureboot.sh keep-previous
EOF

    say "signing it, and the boot menu"
    sbctl sign -s "$UKI" || die "could not sign $UKI"
    sbctl sign -s "$FALLBACK" || die "could not sign $FALLBACK"
    sbctl sign -s -o "$BOOT_EFI.signed" "$BOOT_EFI" || die "could not sign systemd-boot"
    bootctl --path=/boot install >/dev/null 2>&1 || bootctl --path=/boot update || true
    for f in /boot/EFI/BOOT/BOOTX64.EFI /boot/EFI/systemd/systemd-bootx64.efi; do
        [ -e "$R$f" ] && { sbctl sign -s "$f" || die "could not sign $f"; }
    done

    # The signed file first; no editing of the command line at the menu.
    printf 'default osprime.efi\ntimeout 3\neditor no\n' > "$LOADER"
    [ -f "$OLD_ENTRY" ] && sed -i 's/^title .*/title OSprime (old way, without Secure Boot)/' "$OLD_ENTRY"

    bad="$(unsigned_required)"
    [ -z "$bad" ] || die "still unsigned: $bad"
    write_state prepared
    say "prepared. Next: put the keys in the firmware (enroll)."
    ;;

enroll)
    root
    case "$(stage)" in
        prepared) ;;
        none) die "run prepare first" ;;
        *) say "keys are already in the firmware ($(stage))"; exit 0 ;;
    esac
    setup_mode || die "the firmware is not in Setup Mode. Restart into the firmware \
setup, clear the Secure Boot keys (often called 'Reset to Setup Mode' or \
'Delete all keys'), save, and come back."
    read_secrets

    # The temporary key FIRST, the firmware second. 27 September, VM: the
    # other way round, the keys went into the firmware, the TPM step then
    # failed, and the machine was left half-way — firmware changed, disk
    # not — with nothing in Settings able to continue. Now a failure here
    # changes nothing at all and can simply be tried again.
    temp=""
    DEV="$(luks_dev)"
    if [ -n "$DEV" ] && uses_tpm; then
        say "adding a temporary TPM key for the next start only"
        before="$(tpm_slots "$DEV")"
        tpm_enroll "$DEV" "" || die "nothing was changed: the TPM key could not be added \
(${TPM_ERR:-no reason given}). If the disk asked for its password at the last start, \
type the disk password or the recovery key and try again."
        temp="$(comm -13 <(echo "$before") <(tpm_slots "$DEV") | head -1)"
        [ -n "$temp" ] || die "the temporary TPM key did not appear"
    fi

    say "putting this computer's keys in the firmware (with Microsoft's, for the hardware)"
    if ! sbctl enroll-keys -m; then
        [ -n "$temp" ] && systemd-cryptenroll --wipe-slot="$temp" "$DEV" >/dev/null 2>&1
        die "the firmware did not accept the keys — nothing was changed"
    fi
    write_state enrolled "$temp"
    systemctl enable "$FINISH_UNIT" >/dev/null 2>&1 || true
    say "done. Restart; if the firmware does not turn Secure Boot on by itself, turn it on there."
    ;;

finish)
    root
    auto=no; [ "${1:-}" = --auto ] && auto=yes
    # First start after installing: bind the TPM to THIS system's PCR 7 and
    # drop the installer's key. Not when Secure Boot is half-way (enrolled):
    # then PCR 7 changes once more when it is switched on, and the finish
    # below binds it at that point instead.
    if [ $auto = yes ] && [ -f "$BIND_FLAG" ] && [ "$(stage)" != enrolled ]; then
        DEV="$(luks_dev)"
        if [ "$(unlock)" != tpm ] || [ -z "$DEV" ]; then
            rm -f "$BIND_FLAG"               # a PIN or password disk: nothing to bind here
        else
            old="$(tpm_slots "$DEV")"
            if tpm_enroll "$DEV" 7; then
                new="$(comm -13 <(echo "$old") <(tpm_slots "$DEV") | head -1)"
                wipe="$(echo "$old" | grep -vx "$new" | paste -sd, -)"
                if [ -n "$new" ] && [ -n "$wipe" ]; then
                    systemd-cryptenroll --wipe-slot="$wipe" "$DEV" >/dev/null 2>&1 \
                        || echo "bound to PCR 7; the installer's key (slot $wipe) stays until the next start"
                fi
                if [ -n "$new" ]; then
                    rm -f "$BIND_FLAG"
                    say "the disk is now bound to this computer's start-up (PCR 7)"
                fi
            else
                # The installer's key still opens the disk; the next start tries again.
                echo "could not bind the TPM yet (${TPM_ERR:-no reason given}); trying at the next start"
            fi
        fi
        if [ ! -f "$BIND_FLAG" ] && [ "$(stage)" != enrolled ]; then
            systemctl disable "$FINISH_UNIT" >/dev/null 2>&1 || true
            exit 0
        fi
    fi
    if [ "$(stage)" != enrolled ]; then
        [ $auto = yes ] && exit 0
        die "nothing to finish (stage: $(stage))"
    fi
    if ! sb_on; then
        [ $auto = yes ] && { echo "Secure Boot is still off in the firmware — waiting."; exit 0; }
        die "Secure Boot is still off. Restart into the firmware and turn it on."
    fi
    # A PIN is only known to the person: at start-up there is nobody to
    # type it, so a PIN disk is finished from Settings.
    if [ $auto = yes ] && [ "$(unlock)" = tpm-pin ]; then
        echo "The disk has a PIN — finish from Settings."; exit 0
    fi
    read_secrets

    temp="$(jget "$STATE" temp_slot)"
    DEV="$(luks_dev)"
    if [ -n "$DEV" ] && uses_tpm; then
        old="$(tpm_slots "$DEV")"
        say "binding the disk to this computer's own keys (PCR 7)"
        tpm_enroll "$DEV" 7 || die "could not bind the TPM — nothing was removed \
(${TPM_ERR:-no reason given}). Type the disk password or the recovery key and try again."
        new="$(comm -13 <(echo "$old") <(tpm_slots "$DEV") | head -1)"
        [ -n "$new" ] || die "the new TPM key did not appear — nothing was removed"
        wipe="$(echo "$old" | grep -vx "$new" | paste -sd, -)"
        if [ -n "$wipe" ]; then
            say "removing the old and the temporary TPM keys (slots $wipe)"
            systemd-cryptenroll --wipe-slot="$wipe" "$DEV" \
                || die "the new key works, but slots $wipe could not be removed — run finish again"
        fi
    fi
    # The old entry would not start with Secure Boot on anyway; gone, so the
    # menu offers nothing that fails.
    rm -f "$OLD_ENTRY" "$BIND_FLAG"
    write_state done
    systemctl disable "$FINISH_UNIT" >/dev/null 2>&1 || true
    say "Secure Boot is on with this computer's own keys."
    ;;

keep-previous)
    # From the pacman hook, before the kernel is replaced. Only a UKI that
    # is signed right now is worth keeping; never fails the upgrade.
    [ "$(stage)" = none ] && exit 0
    [ -s "$R$UKI" ] || exit 0
    if [ -z "$(unsigned_required | grep -Fx "$UKI")" ]; then
        cp -f "$R$UKI" "$R$PREVIOUS" && echo "kept $PREVIOUS"
    fi
    exit 0
    ;;

firmware)
    root
    uefi || die "this computer starts in BIOS mode"
    systemctl reboot --firmware-setup
    ;;

verify)
    root
    [ "$(stage)" = none ] && { echo "Secure Boot is not in use here."; exit 0; }
    if [ -n "$(unsigned_required)" ]; then
        say "re-signing"
        sbctl sign-all >/dev/null 2>&1
        bad="$(unsigned_required)"
        [ -z "$bad" ] || die "unsigned startup files ($bad) — do NOT restart until this is fixed"
    fi
    echo "Everything that starts the computer is signed."
    ;;

*)
    sed -n '2,9p' "$0"; exit 2 ;;
esac
