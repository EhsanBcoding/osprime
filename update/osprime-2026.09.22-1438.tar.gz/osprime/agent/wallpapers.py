"""Backgrounds for the desktop.

Three sources, and the reason there are three is a constraint rather than
a preference:

1. **Generated.** An OSprime update is about 180 KB. One photograph is
   several megabytes, so photographs cannot travel in an update — but the
   RECIPE for a background is a few hundred bytes. These are drawn with
   ImageMagick at the screen's own resolution, so they are sharp on any
   panel and cost nothing to ship. Every new release can add more.

2. **Shipped photographs**, in /usr/share/osprime/wallpapers. That folder
   is deliberately created empty: the pictures go in before the ISO is
   given to anyone, and the code path that reads them is exercised from
   today rather than written blind on the day it matters.

3. **The user's own pictures.** Their Pictures folder, and anything the
   camera took.

Nothing here draws anything on screen. It produces files and lists them;
system_tools.set_wallpaper is what tells swaybg to use one.
"""

import glob
import hashlib
import json
import os
import pathlib
import shutil
import subprocess

GENERATED_DIR = pathlib.Path(os.environ.get(
    "OSPRIME_WALLPAPERS", "/var/lib/osprime/wallpapers"))
SHIPPED_DIR = pathlib.Path(os.environ.get(
    "OSPRIME_WALLPAPERS_SHIPPED", "/usr/share/osprime/wallpapers"))

IMAGE_TYPES = (".png", ".jpg", ".jpeg", ".webp", ".bmp")


# --------------------------------------------------------------------------
# the designs
#
# Three families, because a machine that offers only one taste is a machine
# that suits one person. Each entry is a recipe, not a picture: a function
# of the screen size, so the same name gives a sharp result on a 1366x768
# laptop and a 4K monitor.
#
# The dark ones come first on purpose. Desktop icons and the panel sit on
# top of this, and a background that makes them hard to read is a pretty
# picture and a bad background.
# --------------------------------------------------------------------------

DESIGNS = {
    # --- calm and dark -------------------------------------------------
    "petrol": {"family": "calm", "label": "Petrol",
               "kind": "linear", "colors": ("#12232E", "#060B12")},
    "midnight": {"family": "calm", "label": "Midnight",
                 "kind": "linear", "colors": ("#101A2E", "#04060B")},
    "slate": {"family": "calm", "label": "Slate",
              "kind": "linear", "colors": ("#2B2E33", "#0D0E10")},
    "depth": {"family": "calm", "label": "Depth",
              "kind": "glow", "colors": ("#1A2333", "#07090D", "#3A5A8C")},

    # --- colourful and alive -------------------------------------------
    "dusk": {"family": "bright", "label": "Dusk",
             "kind": "angle", "colors": ("#2B1055", "#7597DE"), "angle": 135},
    "ember": {"family": "bright", "label": "Ember",
              "kind": "angle", "colors": ("#5B1A28", "#E0803C"), "angle": 160},
    "lagoon": {"family": "bright", "label": "Lagoon",
               "kind": "angle", "colors": ("#0B3C49", "#3ABFA0"), "angle": 120},
    "aurora": {"family": "bright", "label": "Aurora",
               "kind": "glow", "colors": ("#14213D", "#05070E", "#3ABFA0")},

    # --- geometric and minimal -----------------------------------------
    "grid": {"family": "geometric", "label": "Grid",
             "kind": "grid", "colors": ("#0D1117", "#1B2836")},
    "weave": {"family": "geometric", "label": "Weave",
              "kind": "stripes", "colors": ("#101A2E", "#16233C")},
    "dots": {"family": "geometric", "label": "Dots",
             "kind": "dots", "colors": ("#0B0B0B", "#22303F")},
}

FAMILY_LABEL = {"calm": "Calm", "bright": "Colourful",
                "geometric": "Geometric"}


def _magick(*args):
    """ImageMagick 7 renamed `convert` to `magick`. Ask which one is here."""
    exe = shutil.which("magick") or shutil.which("convert")
    return ([exe] + [str(a) for a in args]) if exe else []


def _run(args, timeout=90):
    if not args:
        return 1, "ImageMagick is not installed"
    try:
        r = subprocess.run(args, capture_output=True, text=True,
                           timeout=timeout)
        return r.returncode, ((r.stdout or "") + (r.stderr or "")).strip()
    except Exception as e:
        return 1, str(e)


# Which file format each family is saved in.
#
# Measured, not assumed. A 4K "depth" is 5.5 MB as a PNG and 148 KB as a
# JPEG, and the two differ by 0.27% per pixel — invisible. PNG stores a
# smooth gradient badly because there is nothing to repeat; JPEG stores it
# almost for free.
#
# The geometric ones go the other way: they are hard one-pixel lines, which
# JPEG smears and PNG compresses to nothing. A 4K grid is 56 KB as a PNG.
#
# Eleven designs at several resolutions each, on a laptop with 15 GB — the
# difference between choosing per family and always using PNG is tens of
# megabytes of somebody's disk for no visible gain.
_SMOOTH = {"linear", "angle", "glow"}


def _extension(name: str) -> str:
    return ".jpg" if DESIGNS[name]["kind"] in _SMOOTH else ".png"


def _draw(name: str, w: int, h: int, dest: pathlib.Path) -> str:
    """Draw one design. Returns "" on success or a reason on failure.

    Every command here was run against a real ImageMagick before being
    written down — including the two that needed a different shape than
    the obvious one. Guessing at a command line is how this project once
    shipped a tool that called a program that does not exist.
    """
    d = DESIGNS[name]
    kind, cols = d["kind"], d["colors"]
    size = f"{w}x{h}"
    # Applied to every command; ImageMagick ignores it when the output is
    # a PNG, so it costs nothing to pass unconditionally.
    q = ("-quality", "92")

    if kind == "linear":
        cmd = _magick("-size", size, f"gradient:{cols[0]}-{cols[1]}", *q, dest)
    elif kind == "angle":
        cmd = _magick("-size", size,
                      "-define", f"gradient:angle={d.get('angle', 135)}",
                      f"gradient:{cols[0]}-{cols[1]}", *q, dest)
    elif kind == "glow":
        # A flat gradient with a soft light behind it. The radial layer is
        # faded to 45% so it reads as depth rather than as a spotlight.
        cmd = _magick(
            "-size", size, f"gradient:{cols[0]}-{cols[1]}",
            "(", "-size", size, f"radial-gradient:{cols[2]}-#00000000",
            "-alpha", "set", "-channel", "A", "-evaluate", "multiply", "0.45",
            "+channel", ")", "-compose", "over", "-composite", *q, dest)
    elif kind == "grid":
        step = max(40, w // 48)
        prims = []
        for x in range(0, w + step, step):
            prims.append(f"line {x},0 {x},{h}")
        for y in range(0, h + step, step):
            prims.append(f"line 0,{y} {w},{y}")
        # One -draw with many primitives. Separate -draw flags would work
        # too and would be dozens of arguments long.
        cmd = _magick("-size", size, f"xc:{cols[0]}", "-stroke", cols[1],
                      "-strokewidth", "1", "-draw", " ".join(prims), *q, dest)
    elif kind == "stripes":
        # Drawn once as a small tile and repeated, which is both faster and
        # the only way to get a seamless diagonal.
        tile = dest.with_name(dest.stem + "-tile.png")
        c, e = _run(_magick("-size", "24x24", f"xc:{cols[0]}",
                            "-stroke", cols[1], "-strokewidth", "6",
                            "-draw", "line 0,24 24,0", tile))
        if c != 0:
            return e or "could not draw the tile"
        cmd = _magick("-size", size, f"tile:{tile}", *q, dest)
    elif kind == "dots":
        step = max(48, w // 40)
        r = max(2, step // 24)
        prims = [f"circle {x},{y} {x + r},{y}"
                 for x in range(step // 2, w, step)
                 for y in range(step // 2, h, step)]
        cmd = _magick("-size", size, f"xc:{cols[0]}", "-fill", cols[1],
                      "-stroke", "none", "-draw", " ".join(prims), *q, dest)
    else:
        return f"unknown design kind {kind}"

    code, err = _run(cmd)
    if kind == "stripes":
        # The tile is scaffolding, not a wallpaper. Left behind it would
        # show up in the chooser as a 24-pixel square.
        tile = dest.with_name(dest.stem + "-tile.png")
        try:
            tile.unlink()
        except OSError:
            pass
    if code != 0 or not dest.is_file():
        return err or "ImageMagick produced nothing"
    return ""


def ensure(name: str, width: int = 1920, height: int = 1080):
    """Make sure one design exists at this size. Returns (path, error).

    The size is in the filename, so a laptop that gains a second monitor
    gets a fresh, sharp copy rather than a stretched one — and the old file
    is still there for the old screen.
    """
    if name not in DESIGNS:
        return None, f"there is no background called '{name}'"
    if not _magick():
        return None, ("drawing a background needs ImageMagick, which is not "
                      "installed on this system")
    try:
        GENERATED_DIR.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return None, f"could not create {GENERATED_DIR}: {e}"

    dest = GENERATED_DIR / f"{name}-{width}x{height}{_extension(name)}"
    if dest.is_file() and dest.stat().st_size > 0:
        return str(dest), ""
    err = _draw(name, int(width), int(height), dest)
    if err:
        try:
            dest.unlink()
        except OSError:
            pass
        return None, err
    return str(dest), ""


def _pictures(folder: pathlib.Path, limit: int = 60):
    out = []
    if not folder.is_dir():
        return out
    for p in sorted(folder.rglob("*")):
        if p.is_file() and p.suffix.lower() in IMAGE_TYPES:
            out.append(p)
            if len(out) >= limit:
                break
    return out


def catalogue(home: str = "") -> dict:
    """Everything that could be a background, grouped, without drawing any.

    Listing is separate from drawing on purpose: opening the chooser should
    not spend a second of ImageMagick per design. The pictures are drawn
    when one is picked, and after that they are already on disk.
    """
    designs = []
    for name, d in DESIGNS.items():
        designs.append({"name": name, "label": d["label"],
                        "family": d["family"],
                        "family_label": FAMILY_LABEL.get(d["family"], "")})

    shipped = [{"path": str(p), "label": p.stem.replace("-", " ").title()}
               for p in _pictures(SHIPPED_DIR)]

    mine = []
    if home:
        for sub in ("Pictures", "Pictures/Camera"):
            for p in _pictures(pathlib.Path(home) / sub, limit=40):
                s = str(p)
                if not any(m["path"] == s for m in mine):
                    mine.append({"path": s, "label": p.name})

    return {
        "designs": designs,
        "shipped": shipped,
        "mine": mine,
        # Said plainly rather than left as an empty list nobody can explain.
        "shipped_note": ("" if shipped else
                         "No photographs are installed on this system yet."),
        "can_draw": bool(_magick()),
    }
