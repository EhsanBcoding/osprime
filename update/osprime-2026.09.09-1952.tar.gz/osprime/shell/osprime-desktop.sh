#!/usr/bin/env bash
# Start the desktop — the icons on the background and the right-click menu.
#
# Separate from the Python so autostart has one thing to call and so the
# checks live somewhere a person can read them. Every failure here is
# survivable: without the desktop the session is exactly what it was before,
# a wallpaper and a panel, and labwc's own right-click menu comes back.

HERE="$(cd "$(dirname "$0")" && pwd)"
LOG=/tmp/osprime-desktop.log

fail() {
    echo "$(date +%H:%M:%S) not starting: $1" >> "$LOG"
    exit 1
}

command -v python3 >/dev/null || fail "python3 missing"

# gtk-layer-shell is what lets a normal GTK window become the background
# rather than a window floating in the middle of the screen. Without it
# there is no desktop to draw, and starting anyway would put a titlebar in
# the middle of the user's screen — worse than nothing.
python3 - <<'PY' 2>>"$LOG" || fail "gtk-layer-shell or python-gobject missing"
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("GtkLayerShell", "0.1")
from gi.repository import Gtk, GtkLayerShell
PY

# Only one. Restarting the session must not leave two stacked on each other.
pkill -f "osprime-desktop.py" 2>/dev/null
sleep 0.2

exec python3 "$HERE/osprime-desktop.py" >>"$LOG" 2>&1
