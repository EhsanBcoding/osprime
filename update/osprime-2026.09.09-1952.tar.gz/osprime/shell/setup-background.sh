#!/usr/bin/env bash
# Install background removal for OSprime.
#
# Usage:  sudo bash /opt/osprime/shell/setup-background.sh
#
# Why this is not in the ISO: rembg carries a neural network and the runtime
# to execute it — roughly 200 MB before the model itself downloads. The ISO
# has to fit on a stick and boot on a laptop with a small disk, and most
# people never remove a background. So it is one command, run once, by
# someone who wants it.
#
# It goes in its own virtual environment rather than into the system Python.
# rembg pins versions of numpy and onnxruntime, and letting a pip install
# rearrange the packages the assistant itself runs on is how a machine stops
# being able to talk.
set -e

VENV="${OSPRIME_VENV:-/opt/osprime/venv}"
[ "$EUID" -eq 0 ] || { echo "Run this with sudo."; exit 1; }

echo "> checking prerequisites"
command -v python3 >/dev/null || { echo "python3 is missing."; exit 1; }
if ! python3 -c "import venv" 2>/dev/null; then
    echo "python venv support is missing."; exit 1
fi

if [ ! -x "$VENV/bin/pip" ]; then
    echo "> creating $VENV"
    python3 -m venv "$VENV"
fi

echo "> installing rembg (this downloads about 200 MB — it takes a while)"
"$VENV/bin/pip" install --quiet --upgrade pip
# The CLI extra is what provides the `rembg` command the assistant calls.
"$VENV/bin/pip" install --quiet "rembg[cli]" onnxruntime

if [ ! -x "$VENV/bin/rembg" ]; then
    echo "Installation finished but the rembg command is not there."
    echo "Nothing else on the system was changed."
    exit 1
fi

# On PATH, so the tool finds it whether or not it knows about the venv.
ln -sf "$VENV/bin/rembg" /usr/local/bin/rembg

echo "> fetching the model, so the first real use is not the slow one"
TMP="$(mktemp -d)"
python3 - "$TMP/probe.png" <<'PY'
import struct, sys, zlib
path = sys.argv[1]
def chunk(tag, data):
    body = tag + data
    return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body))
raw = b"".join(b"\x00" + b"\x40\x80\xc0" * 8 for _ in range(8))
png = (b"\x89PNG\r\n\x1a\n"
       + chunk(b"IHDR", struct.pack(">IIBBBBB", 8, 8, 8, 2, 0, 0, 0))
       + chunk(b"IDAT", zlib.compress(raw))
       + chunk(b"IEND", b""))
open(path, "wb").write(png)
PY
"$VENV/bin/rembg" i "$TMP/probe.png" "$TMP/out.png" >/dev/null 2>&1 || true
rm -rf "$TMP"

echo
echo "Done. Ask OSprime to remove the background from a picture."
