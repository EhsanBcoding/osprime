#!/usr/bin/env bash
# Look at this machine and pick the model that suits it.
#
#   bash osprime-profile.sh              report only — changes nothing
#   sudo bash osprime-profile.sh --install   download it and switch over
#
# Reporting and installing are separate on purpose. The install downloads
# gigabytes; on a phone tether that is somebody's money, and a script that
# spends it because it was run to see what it would say is a script nobody
# should run.
#
# The switch is also staged rather than done in one step: the new model is
# downloaded beside the old one, started on a spare port and asked a
# question, and only if it answers is the engine pointed at it. A model
# that downloads but will not load leaves the machine exactly as it was,
# still able to talk — which is the difference between a bad update and an
# unusable computer.
set -u

HERE="$(cd "$(dirname "$0")" && pwd)"
AGENT="$(cd "$HERE/../agent" && pwd)"
MODELS="${OSPRIME_MODELS:-/var/lib/osprime/models}"
PROBE_PORT="${OSPRIME_PROBE_PORT:-8091}"

py() { PYTHONPATH="$AGENT" python3 "$@"; }

read_field() {   # read_field <python expression on the recommendation>
    py -c "
import hardware, json
r = hardware.recommend()
print($1)
"
}

# --------------------------------------------------------------------------
# report
# --------------------------------------------------------------------------

py -c "
import hardware
r = hardware.report()
m, now, rec = r['machine'], r['running_now'], r['recommended']
print()
print('This machine')
print(f\"  processor    {m['cpu']}\")
print(f\"  cores        {m['cores']}\")
print(f\"  memory       {m['ram_gb']} GB\")
print(f\"  free disk    {m['disk_free_mb']} MB\")
g = m['gpu']
print(f\"  graphics     {g['kind'] or 'none usable'} — {g['why']}\")
print()
print('Running now')
print(f\"  {now['label'] or 'the model the system was installed with'}\")
print(f\"  {now['path']} ({now['size_mb']} MB)\" if now['exists']
      else f\"  MISSING: {now['path']}\")
print()
print('Recommended')
print(f\"  {rec['label']}  ({rec['disk_mb']} MB download)\")
print(f\"  {rec['why']}\")
print(f\"  {rec['note']}\")
print()
"

[ "${1:-}" = "--install" ] || {
    echo "Nothing was changed. To download and switch over:"
    echo "    sudo bash $0 --install"
    exit 0
}

[ "$EUID" -eq 0 ] || { echo "The install step needs sudo."; exit 1; }

# --------------------------------------------------------------------------
# install
# --------------------------------------------------------------------------

TIER="$(read_field "r['tier']")"
LABEL="$(read_field "r['label']")"
FIRST="$(read_field "r['files'][0]")"
URLS="$(read_field "'\n'.join(r['urls'])")"
FILES="$(read_field "'\n'.join(r['files'])")"

CURRENT_TIER="$(py -c "import hardware; print(hardware.installed()['tier'])")"
if [ "$TIER" = "$CURRENT_TIER" ]; then
    echo "Already running $LABEL. Nothing to do."
    exit 0
fi

mkdir -p "$MODELS"
echo "> downloading $LABEL"
paste -d' ' <(printf '%s\n' "$URLS") <(printf '%s\n' "$FILES") |
while read -r url name; do
    dest="$MODELS/$name"
    if [ -s "$dest" ]; then
        echo "  already have $name"
        continue
    fi
    echo "  $name"
    # --continue-at so a dropped connection resumes rather than restarting a
    # two-gigabyte download.
    curl -fL --retry 3 --continue-at - -o "$dest.part" "$url" || {
        echo "  download failed — nothing was changed."; exit 1; }
    mv "$dest.part" "$dest"
done || exit 1

TARGET="$MODELS/$FIRST"
[ -s "$TARGET" ] || { echo "Download incomplete — nothing was changed."; exit 1; }

# --------------------------------------------------------------------------
# prove it works before switching to it
# --------------------------------------------------------------------------

BIN="$(command -v llama-server || command -v llama-cpp-server || true)"
[ -n "$BIN" ] || { echo "No llama-server to test with — nothing was changed."; exit 1; }

echo "> checking it actually loads and answers"
"$BIN" -m "$TARGET" --host 127.0.0.1 --port "$PROBE_PORT" --ctx-size 512 \
       >/tmp/osprime-probe.log 2>&1 &
PROBE_PID=$!
# shellcheck disable=SC2064
trap "kill $PROBE_PID 2>/dev/null" EXIT

ok=0
for _ in $(seq 1 120); do
    sleep 1
    kill -0 "$PROBE_PID" 2>/dev/null || break     # it died; stop waiting
    if curl -fsS --max-time 5 -X POST "http://127.0.0.1:$PROBE_PORT/v1/chat/completions" \
        -H 'Content-Type: application/json' \
        -d '{"messages":[{"role":"user","content":"Say OK"}],"max_tokens":5}' \
        >/tmp/osprime-probe-answer.json 2>/dev/null; then
        ok=1; break
    fi
done
kill "$PROBE_PID" 2>/dev/null
wait "$PROBE_PID" 2>/dev/null
trap - EXIT

if [ "$ok" -ne 1 ]; then
    echo
    echo "$LABEL downloaded but would not answer. The machine is unchanged"
    echo "and still running its previous model. The engine's own log:"
    tail -20 /tmp/osprime-probe.log
    exit 1
fi
echo "  it answered — switching over"

py -c "
import hardware
print(hardware.write_env('$TIER', '$TARGET'))
"

systemctl restart osprime-model.service 2>/dev/null || \
    echo "note: restart osprime-model.service to use it."

echo
echo "Now running $LABEL. The previous model is still in $MODELS —"
echo "delete it once you are happy, or keep it to fall back to."
