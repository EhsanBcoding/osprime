---json
{
  "name": "remove-image-background",
  "title": "Remove the background from a photo",
  "type": "shared",
  "teachable": true,
  "triggers": [
    "remove the background", "cut out the background", "transparent background",
    "background remover", "make the background white", "photo for a listing",
    "product photo", "profile picture background", "erase background"
  ],
  "tools": ["remove_background", "list_files", "open_file"],
  "packages": ["rembg"],
  "setup": "sudo bash /opt/osprime/shell/setup-background.sh",
  "sources": [
    {"what": "rembg", "licence": "MIT",
     "note": "installed after setup, not shipped — the model is too large"},
    {"what": "U^2-Net model weights", "licence": "Apache-2.0",
     "note": "downloaded by rembg on first use"}
  ]
}
---

## Do it

Use `remove_background`. There is no useful way to do this with a shell
command — it needs the model.

1. Get the real path with `list_files` on the folder, `kind` set to
   `pictures`. Never invent a filename.
2. Call `remove_background` with that path. The result is a new PNG next to
   the original, ending `-cutout.png`. The original is untouched.
3. If it reports that setup is needed, pass on the one command exactly as
   given and stop. Do not try to install anything yourself, and do not
   attempt a substitute that will produce a worse result the user did not
   ask for.
4. Show the result with `open_file` so the user can judge it. This is a
   picture; only they can say whether it is right.

Transparency requires PNG. If the user needs a solid white background — most
print shops and passport photos do — say that the cutout is the first step
and that placing it on white is a second one.

## Teach it

1. Removing a background well is a model, not a filter. That is why it is a
   one-time download and why it works on hair and fur, which older tools
   never managed.
2. The quality of the result depends mostly on the photo: an evenly lit
   subject that contrasts with what is behind it comes out cleanly. A dark
   coat against a dark sofa will not.
3. Ask OSprime to "remove the background from <the picture>".
4. The result is a PNG with nothing behind the subject. Opened in a viewer,
   transparency usually shows as a checkerboard — that is correct, not a
   fault.
5. Keep the original. Every edit should produce a new file; a photo edited in
   place is a photo you cannot go back to.

## Check

Confirm the output file exists, then open it. Ask the user to look at the
edges — especially hair and thin objects, which is where it fails.

Never report success on a file the tool did not create.

## Common mistakes

- Guessing a filename instead of listing the folder.
- Trying to install rembg during a conversation. It is a large download and
  belongs in the one-time setup command, run by the user in a terminal.
- Falling back to a crude colour-key trick when the model is not installed,
  and presenting the result as the same thing.
- Saving as JPEG. JPEG cannot hold transparency, so the background comes
  back as black.
- Overwriting the original.
- Promising it will work on any photo. Say what it does badly, before it
  does it badly.
