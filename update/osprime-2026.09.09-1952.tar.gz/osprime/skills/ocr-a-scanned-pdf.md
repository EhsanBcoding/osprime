---json
{
  "name": "ocr-a-scanned-pdf",
  "title": "Make a scanned PDF searchable",
  "type": "shared",
  "teachable": true,
  "triggers": [
    "cannot select the text", "scanned pdf", "make this pdf searchable",
    "copy text from a scan", "ocr this", "text recognition",
    "the pdf is just an image", "cannot search this document",
    "extract text from a scan", "photographed document"
  ],
  "tools": ["ocr_pdf", "list_files", "compress_pdf", "open_file"],
  "packages": ["tesseract"],
  "sources": [
    {"what": "Tesseract OCR", "licence": "Apache-2.0",
     "note": "invoked as a program, not linked"},
    {"what": "ocrmypdf", "licence": "MPL-2.0",
     "note": "used when present; not required"}
  ]
}
---

## Do it

Use `ocr_pdf`.

1. Confirm this is really the problem. A scanned PDF is a picture of text:
   the words cannot be selected, searched or copied. If the user can already
   select text, OCR will not help and something else is wrong.
2. Get the real path with `list_files`, `kind` set to `pdf`.
3. **Ask which language the document is in** unless it is obvious from the
   conversation. Recognising Persian text with the English model produces
   confident nonsense rather than an error, which is the worst outcome
   available here.
4. Call `ocr_pdf` with the path and the language. It can take several minutes
   on a long document — say so before starting, not after.
5. The result is a new file ending `-searchable.pdf`. The original is
   untouched.

If it reports that the language data is not installed, say which languages
are installed rather than trying to install anything.

## Teach it

1. There are two kinds of PDF that look identical: one made from a document,
   where the text is text, and one made from a scanner, where the page is a
   photograph. Try to select a word — that is the whole test.
2. OCR adds an invisible text layer behind the picture. The page still looks
   exactly the same; it just becomes searchable. Nothing is redrawn or
   replaced.
3. Quality of the scan decides quality of the result. 300 dpi, straight, and
   evenly lit. A crooked phone photo will produce crooked results.
4. Ask OSprime to "make this PDF searchable" and say what language it is in.
5. Check the result by searching for a word you know is on page one.
   Recognition is never perfect, and it is worst on handwriting, tables and
   unusual fonts.

## Check

Open the result and confirm text can be selected. Recognition that silently
produced garbage still creates a valid file, so file-exists is not proof.

Report how many pages were recognised out of how many. If some pages failed,
say which.

## Common mistakes

- Running OCR on a PDF that already has text. It wastes minutes and gains
  nothing.
- Using English for a document that is not in English, and reporting the
  resulting nonsense as success.
- Promising a fast result. This is slow, and being told beforehand is the
  difference between waiting and thinking it has frozen.
- Overwriting the original.
- Treating a created file as a correct file.
- Expecting handwriting to work. It mostly does not — say so first.
