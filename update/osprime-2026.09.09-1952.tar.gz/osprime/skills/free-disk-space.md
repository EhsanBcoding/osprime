---json
{
  "name": "free-disk-space",
  "title": "Make room when the disk is full",
  "type": "system",
  "teachable": true,
  "triggers": [
    "no space left", "disk is full", "out of space", "free up space",
    "what is taking up space", "clean up my disk", "not enough space",
    "make room", "storage is full", "why is my disk full"
  ],
  "tools": ["disk_usage", "list_files", "search_files", "run_shell"],
  "packages": ["coreutils:du"],
  "sources": []
}
---

## Do it

Call `disk_usage` first, always. It returns three things: how full the disk
is, which folders are largest, and what is genuinely safe to delete. Never
estimate any of them.

1. Report the real numbers — free space and percentage used. "Your disk is
   nearly full" is not information.
2. Offer the entries under `safe_to_delete` first, one at a time, naming what
   each one is. These cost nothing to remove:
   - cached data, which programs rebuild by themselves
   - the trash, which the user already chose to discard
   - downloaded installer packages for software already installed
   - backups of previous OSprime versions
3. Only after those, mention the largest folders. Those are the user's own
   files — describe what is big and let them decide. Never propose deleting
   anything of theirs.
4. Delete only what the user agrees to, one thing at a time, and say how much
   was recovered afterwards by calling `disk_usage` again.

Two absolute rules. Never delete anything in the user's own folders without
being asked for that exact thing. Never run a recursive delete on a path you
built rather than one a tool returned.

If the largest folder is one of theirs and they want it smaller, that is a
different job — finding big files inside it — not a cleanup.

## Teach it

1. Space disappears in three places, and only one of them is the user's
   fault: caches, the trash, and their own big files.
2. Ask OSprime "what is taking up space". The answer separates the three, so
   it is clear what can go without losing anything.
3. Empty the trash first. Most people are surprised it still holds gigabytes
   of things they deleted months ago.
4. Caches are safe to clear. Programs rebuild them; the only cost is that a
   few things load slowly once.
5. For their own files, sort by size in Files (**View → sort by size**) and
   look at the top ten. Videos and disk images are almost always what it is.
6. Keep about 10% of the disk free. A disk with nothing left cannot install
   updates, and that is how a computer becomes unfixable.

## Check

Call `disk_usage` again after deleting anything and report the difference.
"Freed 3.2 GB; 41 GB now free" is the answer. Do not calculate what should
have been freed — measure it.

## Common mistakes

- Guessing at sizes instead of calling `disk_usage`.
- Suggesting the user delete personal files to save space.
- Running `rm -rf` on a constructed path.
- Clearing caches without saying what a cache is, so it sounds dangerous.
- Reporting freed space without measuring it afterwards.
- Forgetting old OSprime backups, which are often the single largest item
  and are the safest thing on the list to remove.
