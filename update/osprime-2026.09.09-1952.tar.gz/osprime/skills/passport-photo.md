---json
{
  "name": "passport-photo",
  "title": "Make a passport or ID photo from an ordinary picture",
  "type": "shared",
  "teachable": true,
  "triggers": [
    "passport photo", "id photo", "visa photo", "photo for my application",
    "3x4 photo", "35x45 photo", "photo booth", "biometric photo",
    "personnel photo", "photo for a form"
  ],
  "tools": ["passport_photo", "remove_background", "list_files", "open_file"],
  "packages": ["imagemagick:magick"],
  "sources": []
}
---

## Do it

Use `passport_photo`. Be honest about what it does and does not do — this is
a document that gets rejected, and a rejection costs the person an
appointment, not five minutes.

1. **Ask which country and which document.** The size is not a detail: 35x45
   mm for most of the world, 51x51 mm for the United States and Canada,
   40x60 mm for an Iranian passport, 30x40 mm for Iranian ID documents.
   Never assume from where the user seems to be.
2. Get the real path with `list_files`, `kind` set to `pictures`.
3. If the background is not plain, call `remove_background` first and tell
   the user the result needs a white background behind it. Almost every
   authority requires plain light grey or white.
4. Call `passport_photo` with the path and size. It produces the correctly
   sized photo and a 10x15 cm sheet with as many copies as fit.
5. Tell them plainly what has not been checked: **head size and position**.
   The tool crops to the centre of the picture. It does not find the face.
   Every authority specifies how much of the frame the head must fill and
   where the eyes must sit, and only the person can compare against that.
6. Point them at the official template for their country and tell them to
   hold the result against it before paying to print.

## Teach it

1. The rules are stricter than people expect and vary by country: size, how
   much of the frame the head fills, background colour, expression, glasses,
   head covering. Find the official page for the country first — anything
   else is a guess.
2. Take the photo properly, because no amount of processing fixes it later:
   plain wall, face square to the camera, even light with no shadow behind
   the head, neutral expression, eyes open, nothing covering the face.
3. Stand about two metres away and zoom in rather than holding the camera
   close. Close-up lenses distort a face, and it is a common rejection.
4. Ask OSprime to make the photo at the size for your country.
5. It also makes a 10x15 cm sheet — the standard cheap print. Take that to
   any kiosk and print it **at actual size**, never "fit to page", or every
   photo comes out slightly wrong.
6. Compare the result to the official template before printing. Head too
   small or too low is the most common reason for rejection.

## Check

Confirm both files exist and open the sized one so the user can see it.

Say explicitly that head position has not been verified. A photo that is the
right number of millimetres and the wrong composition still gets rejected,
and reporting only the millimetres implies more than was checked.

## Common mistakes

- Assuming a size instead of asking which country.
- Claiming the photo meets requirements. Only the dimensions were set.
- Leaving a busy background, or a shadow on the wall behind the head.
- Printing "fit to page", which silently rescales everything.
- Using a close-up selfie, which distorts the face.
- Cropping so the head is too small — the single most common rejection.
- Not telling the user which rules were not checked.
