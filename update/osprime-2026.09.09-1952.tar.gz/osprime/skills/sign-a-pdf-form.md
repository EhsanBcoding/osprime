---json
{
  "name": "sign-a-pdf-form",
  "title": "Fill in and sign a PDF without printing it",
  "type": "shared",
  "teachable": true,
  "triggers": [
    "sign this pdf", "fill in this form", "add my signature",
    "sign a document", "fill out a pdf", "i need to print and sign",
    "scan and send back", "digital signature", "sign and return the form"
  ],
  "tools": ["make_signature", "remove_background", "list_files", "open_file",
            "open_app", "compress_pdf"],
  "packages": ["imagemagick:magick"],
  "sources": []
}
---

## Do it

This one is mostly done by the user, not by you, and saying so plainly is
better than pretending otherwise. There is no reliable way to place a
signature at the right point on an arbitrary form without seeing the page —
and you cannot see it. What you can do is remove the hard part and then get
out of the way.

1. Ask whether they already have a picture of their signature. If not, tell
   them: sign a blank white sheet with a dark pen, photograph it straight on
   in good light, and say where the photo is.
2. Call `make_signature` on that photo. It comes back as a PNG with the paper
   removed, which is the part people cannot do themselves.
3. Open the form with `open_file`, and then open **LibreOffice Draw** with
   `open_app`. Draw opens PDFs directly and can place text and images
   anywhere on the page.
4. Walk them through it with the steps below. Do not claim to have filled
   anything in.
5. When they save, remind them to use **File → Export as PDF**, not Save —
   saving produces an ODG, which the other party cannot open.
6. If the result is too large to email, offer `compress_pdf`.

Never fill in a form on someone's behalf without them seeing it, and never
apply a signature to a document you have not been asked to sign.

## Teach it

1. Make the signature once and keep it. Sign a white sheet, photograph it,
   ask OSprime to clean it up. That file is reusable forever.
2. Open the PDF: right-click it in Files and choose **LibreOffice Draw**. It
   opens PDFs as editable pages.
3. For text: click the **T** tool, click where the answer goes, type. Match
   the size of the printed text so it does not look pasted on.
4. For the signature: **Insert → Image**, choose the cleaned PNG, drag it to
   the line, and drag a corner to size it. Corners keep the proportions;
   edges distort it.
5. **File → Export as PDF**. This is the step everyone gets wrong — Save
   writes a drawing file, not a PDF.
6. Check every page before sending. Draw sometimes shifts fonts it does not
   have, and a form with moved text looks careless.

## Check

Confirm the signature PNG exists and have the user look at it before it goes
anywhere near a document.

After they export, open the result and confirm it is a PDF, that the pages
are all there, and that the signature is on the right line.

Never report a form as filled or signed. You did not do it, and claiming
otherwise about a legal document is worse here than anywhere else.

## Common mistakes

- Claiming to have filled in or signed the form.
- Photographing the signature in shadow, which loses the thin strokes.
- Signing on lined or coloured paper, which cannot be cleaned up well.
- Using Save instead of Export as PDF.
- Stretching the signature image by dragging an edge instead of a corner.
- Sending it without opening the exported file once.
- Emailing a signed document without checking it is the final version.
