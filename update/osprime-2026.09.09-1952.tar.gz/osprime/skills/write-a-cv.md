---json
{
  "name": "write-a-cv",
  "title": "Write a CV as a real document",
  "type": "shared",
  "teachable": true,
  "triggers": [
    "write my cv", "write a resume", "help me with my cv", "update my resume",
    "cover letter", "applying for a job", "job application",
    "make me a resume", "my cv needs work"
  ],
  "tools": ["make_document", "open_file", "read_file", "list_files"],
  "packages": ["libreoffice-writer:soffice"],
  "sources": []
}
---

## Do it

Use `make_document`. A CV is a file somebody keeps, edits and sends for
years — putting one in a chat window is not an answer to the request.

1. **Ask before writing.** A CV built from assumptions is worse than no CV,
   because it reads as though it belongs to someone else. Ask for:
   - the job or kind of work being applied for
   - their last two or three roles, with dates and what they actually did
   - education, and anything formally certified
   - how to contact them
   If they already have one, ask for the path and `read_file` it — improving
   what exists beats starting again.
2. Write it, following these:
   - one page for under ten years of experience, two at most beyond that
   - each role: what they were responsible for, then what changed because of
     them. "Managed the store" says nothing. "Managed a team of six; cut
     stock losses by a third in a year" says everything.
   - numbers wherever they exist. They are what the reader remembers.
   - no photo, no date of birth, no marital status, unless the country
     expects it — ask if unsure, since it varies and getting it wrong looks
     careless in both directions
   - plain words. Someone who is not in the field reads it first.
3. Call `make_document` with `odt` unless they ask otherwise, so they can
   edit it. Use `docx` if they say the employer wants Word, `pdf` only for
   the final version being sent — a PDF cannot be tailored to the next
   application.
4. Open it with `open_file` and go through it with them.
5. Offer a cover letter as a second document. Never merge the two.

Never invent a job, a qualification, a date or a number. This is a document
someone will be asked about in an interview, and an invented line is worse
here than anywhere else in this system.

## Teach it

1. A CV is not a history; it is an argument that you can do one specific job.
   That means it changes for each application. Keep the editable ODT and
   export a fresh PDF each time.
2. The reader spends well under a minute on the first pass. What matters
   goes at the top of the first page.
3. For each role write two things: what you were responsible for, and what
   was different because you were there. The second one is what nobody
   writes and everybody remembers.
4. Numbers beat adjectives. "Improved sales" is invisible; "grew repeat
   orders 20% in six months" is not.
5. Send PDF, never ODT or DOCX. Formatting moves between computers, and a
   CV that opens looking broken is not read.
6. Name the file properly: `Firstname-Lastname-CV.pdf`. An attachment called
   `cv-final-2.pdf` is the first impression.
7. Have somebody else read it. Every typo is invisible to the person who
   wrote it.

## Check

Open the document. Confirm it is one or two pages, that no section is empty,
and that every date and place came from the user rather than from you.

Read the contact details back to them. A CV with a wrong phone number has
failed completely and looks perfect.

## Common mistakes

- Writing it before asking, then having the user correct invented history.
- Inventing employers, dates, qualifications or figures.
- Putting the document in the chat instead of writing a file.
- Producing a PDF as the only copy, leaving nothing to edit next time.
- Three pages for four years of experience.
- Listing duties with no outcomes.
- Adding a photo or date of birth where the country does not expect it.
- Not checking the phone number and email.
