---json
{
  "name": "merge-pdfs",
  "title": "Join several PDFs into one file",
  "type": "shared",
  "teachable": true,
  "triggers": [
    "merge pdfs", "combine pdf", "join pdf files", "put pdfs together",
    "make one pdf from", "scanned each page separately",
    "attach several pdfs as one", "combine these documents into one pdf"
  ],
  "tools": ["merge_pdfs", "list_files", "compress_pdf", "open_file"],
  "packages": ["qpdf"],
  "sources": [
    {"what": "qpdf", "licence": "Apache-2.0",
     "note": "invoked as a program, not linked"}
  ]
}
---

## Do it

Use `merge_pdfs`. Do not build a qpdf or ghostscript command by hand.

1. Get the real paths. Call `list_files` on the folder with `kind` set to
   `pdf`. Never type a filename the user has not confirmed and you have not
   seen in a listing.
2. **Order matters and only the user knows it.** If the names sort obviously
   — `page-1`, `page-2`, `scan-01` — use that order and say which order you
   used. If they do not sort obviously, show the list and ask before joining.
   A merged document in the wrong order looks finished and is useless.
3. Call `merge_pdfs` with the full paths in that order.
4. Report where the new file is and how big it is.
5. If the result is too large to send, offer `compress_pdf` — this is the
   commonest next question after scanning a stack of pages.

The original files are never touched; the result is a new file. Say so, so
the user is not afraid to try it.

## Teach it

1. This comes up most often after scanning: many scanners produce one PDF per
   page, and nobody wants to receive eleven attachments.
2. Put the files in one folder and name them so they sort in the right order:
   `01-cover`, `02-page`, `03-page`. Leading zeros matter — without them
   `10` sorts before `2`.
3. Ask OSprime to "merge the PDFs in this folder into one".
4. Check the page order in the result before sending it. This is the one step
   people skip and the one that goes wrong.
5. If the file is then too big to email, ask to make it smaller — that is a
   separate step and it does not undo the joining.

## Check

Open the result with `open_file` and tell the user to confirm the page order
and that nothing is missing. Report the file size.

If the output does not exist, say the merge failed and why. Never describe a
file that was not created.

## Common mistakes

- Guessing filenames instead of listing the folder first.
- Merging in alphabetical order silently when the user meant a different one.
- Assuming `page10` comes after `page9` — as text, it does not.
- Writing a qpdf command by hand.
- Overwriting one of the originals by naming the output after an input file.
- Not offering to shrink the result when it was obviously made for emailing.
