---json
{
  "name": "batch-process-images",
  "title": "Resize or convert a whole folder of pictures at once",
  "type": "shared",
  "teachable": true,
  "triggers": [
    "resize all my photos", "make these images smaller", "convert to jpg",
    "batch resize", "photos are too big to upload", "shrink these pictures",
    "convert all these images", "compress my photos", "images for a website",
    "too large to attach"
  ],
  "tools": ["convert_images", "list_files", "open_file"],
  "packages": ["imagemagick:magick"],
  "sources": [
    {"what": "ImageMagick", "licence": "ImageMagick (Apache-2.0 compatible)",
     "note": "invoked as a program, not linked"}
  ]
}
---

## Do it

Use `convert_images`. It writes to a new `converted` folder and never touches
the originals — say so, because that is the fear that stops people trying.

1. Call `list_files` with `kind` set to `pictures` first. Report how many
   there are. Someone who thinks they have twenty and has four hundred wants
   to know before it starts.
2. Ask what it is for, because the answer decides the numbers and nothing
   else does:
   - **email or messaging** — 1600 px wide, quality 85
   - **a website** — 1200 px wide, quality 80, or webp for smaller files
   - **printing** — do not resize at all; reduce quality only
   - **an upload limit** — start at 1600 px and check the sizes
3. Call `convert_images` with the folder and those settings.
4. Report how many were converted and where they went. Then call
   `list_files` on the `converted` folder so the new sizes are real numbers
   rather than a promise.
5. Have the user open one and confirm it still looks right before they delete
   anything.

Never resize in place. Never delete the originals — that is the user's
decision, made after they have seen the results.

## Teach it

1. Two different things make a photo file large, and they are fixed
   differently. **Dimensions** are how many pixels wide it is; **quality** is
   how much detail is kept in each one.
2. A modern phone photo is around 4000 px wide. A screen shows about 1600.
   Resizing to 1600 typically removes 80% of the file size and nothing anyone
   can see on a screen.
3. Quality is the second dial. 85 is invisible to almost everyone; below 70
   the sky goes blotchy and it does not come back.
4. Never resize photos you might print later. A 1600 px photo prints at about
   13 cm wide before it looks soft. Keep the originals.
5. Ask OSprime to "resize the photos in this folder to 1600 pixels wide".
   Results go in a new folder, so a bad guess costs nothing.
6. Look at one at full size before deleting anything. Quality loss is
   permanent and is only obvious once the original is gone.

## Check

Call `list_files` on the `converted` folder and report the real count and
sizes. Open one with `open_file`.

If some pictures failed, name them. A batch that silently converted 380 of
400 and reported success is exactly the kind of failure that is discovered
much later.

## Common mistakes

- Converting without asking what it is for, and picking numbers blindly.
- Resizing photos the user intends to print.
- Overwriting the originals, or suggesting they be deleted straight away.
- Choosing a quality below 70 because it is smaller.
- Converting PNG screenshots to JPEG, which makes text edges fuzzy.
- Reporting a count without checking the results exist.
- Starting on four hundred files without telling the user how many there are.
