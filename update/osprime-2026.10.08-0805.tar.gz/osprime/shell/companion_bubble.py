"""The bubble beside the companion: ask something right where it lives.

Clicking the character opens it; Esc or the character again hides it. It is
a small conversation, not a second chat app:

  * it talks to the same assistant over the same socket as the terminal
    chat (agent/agent.py's JSON lines), so tools, confirmations, memory and
    the cloud switch all behave exactly as in the chat window;
  * the conversation lasts until "New" or until the companion closes; hiding
    the bubble keeps it, so a second question has the first one's context;
  * "Open the chat" is one click away for anything long.

It opens with the keyboard (EXCLUSIVE) so you can type at once, and lets go
of it (ON_DEMAND) once you have sent something, so you can click back into
your work while the answer arrives. A click on the bubble takes it again.

The character's mouth moves while the answer streams in (Companion.set_talking).
"""
import json
import os
import socket
import threading
import unicodedata

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("GtkLayerShell", "0.1")
from gi.repository import Gtk, Gdk, GLib, GtkLayerShell, Pango  # noqa: E402

import paths  # noqa: E402

WIDTH = 380
MAX_HEIGHT = 420

CSS = b"""
#bubble { background-color: transparent; }
.card { background-color: #161b22; border: 1px solid #30363d; border-radius: 14px;
        padding: 10px; }
.card label { color: #e6edf3; }
.head { color: #8b949e; font-size: 11px; }
.you { background-color: #1f6feb; color: #ffffff; border-radius: 10px; padding: 6px 10px; }
.it { background-color: #21262d; border-radius: 10px; padding: 6px 10px; }
.dim { color: #8b949e; font-size: 11px; }
.err { color: #ff7b72; }
entry { background-color: #0d1117; color: #e6edf3; border: 1px solid #30363d;
        border-radius: 8px; padding: 6px 8px; }
button { background-image: none; background-color: #21262d; color: #e6edf3;
         border: 1px solid #30363d; border-radius: 7px; padding: 2px 8px; }
button:hover { background-color: #30363d; }
button.go { background-color: #238636; border-color: #238636; }
button.no { background-color: #21262d; }
"""


def is_rtl(text: str) -> bool:
    """Persian or Arabic first: the line reads right to left."""
    for ch in text or "":
        d = unicodedata.bidirectional(ch)
        if d in ("R", "AL"):
            return True
        if d == "L":
            return False
    return False


class AgentLink:
    """One conversation with the assistant over its socket. Messages come
    back on a thread and are handed to the GTK loop with GLib.idle_add."""

    def __init__(self, on_message):
        self.on_message = on_message
        self.sock = None
        self.f = None

    def connected(self) -> bool:
        return self.f is not None

    def connect(self):
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(str(paths.socket_path()))
        self.sock, self.f = s, s.makefile("rwb")
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        f = self.f
        try:
            for line in f:
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue
                GLib.idle_add(self.on_message, msg)
        except Exception:
            pass
        GLib.idle_add(self.on_message, {"type": "_closed"})

    def send(self, obj: dict):
        if not self.f:
            self.connect()
        self.f.write((json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8"))
        self.f.flush()

    def close(self):
        """Ends the conversation: the assistant keeps what it learned."""
        try:
            if self.sock:
                self.sock.close()
        except Exception:
            pass
        self.sock = self.f = None


class Bubble:
    def __init__(self, companion):
        self.c = companion
        self.link = AgentLink(self.on_message)
        self.busy = False
        self.answer = None          # the label the current answer streams into
        self.answer_text = ""
        self._quiet_id = None

        prov = Gtk.CssProvider()
        prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        self.win = Gtk.Window()
        self.win.set_name("bubble")
        GtkLayerShell.init_for_window(self.win)
        GtkLayerShell.set_layer(self.win, GtkLayerShell.Layer.TOP)
        GtkLayerShell.set_namespace(self.win, "osprime-companion-bubble")
        GtkLayerShell.set_exclusive_zone(self.win, 0)
        visual = self.win.get_screen().get_rgba_visual()
        if visual is not None:
            self.win.set_visual(visual)
        self.win.set_app_paintable(True)
        self.win.connect("draw", self._clear)
        self.win.connect("key-press-event", self.on_key)
        self.win.connect("button-press-event", lambda *_: self.keyboard(True))

        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        card.get_style_context().add_class("card")
        card.set_size_request(WIDTH, -1)
        self.win.add(card)

        head = Gtk.Box(spacing=6)
        self.who = Gtk.Label(label="", xalign=0)
        self.who.get_style_context().add_class("head")
        head.pack_start(self.who, True, True, 0)
        for text, tip, fn in (("Open the chat", "Continue in the chat window", self.open_chat),
                              ("New", "Start a new conversation", self.new),
                              ("✕", "Hide (Esc)", lambda *_: self.hide())):
            b = Gtk.Button(label=text)
            b.set_tooltip_text(tip)
            b.connect("clicked", fn)
            head.pack_start(b, False, False, 0)
        card.pack_start(head, False, False, 0)

        self.scroll = Gtk.ScrolledWindow()
        self.scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.scroll.set_max_content_height(MAX_HEIGHT)
        self.scroll.set_min_content_height(0)     # empty: no gap
        self.list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.scroll.add(self.list)
        card.pack_start(self.scroll, True, True, 0)

        # Listening (phase 2): a live level meter and the way out.
        self.listen_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.wave = Gtk.DrawingArea()
        self.wave.set_size_request(-1, 34)
        self.wave.connect("draw", self._draw_wave)
        self.listen_label = Gtk.Label(label="", xalign=0)
        self.listen_label.get_style_context().add_class("dim")
        lrow = Gtk.Box(spacing=6)
        lrow.pack_start(self.listen_label, True, True, 0)
        self.stop_btn = Gtk.Button(label="Stop")
        self.stop_btn.get_style_context().add_class("go")
        self.stop_btn.connect("clicked", lambda *_: self.stop_listening("done"))
        cancel = Gtk.Button(label="Cancel")
        cancel.connect("clicked", lambda *_: self.stop_listening("cancelled"))
        lrow.pack_start(self.stop_btn, False, False, 0)
        lrow.pack_start(cancel, False, False, 0)
        self.listen_box.pack_start(self.wave, False, False, 0)
        self.listen_box.pack_start(lrow, False, False, 0)
        self.listen_box.set_no_show_all(True)
        card.pack_start(self.listen_box, False, False, 0)

        # Point and ask (phase 3): the selected area, waiting for a question.
        self.point_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.point_img = Gtk.Image()
        self.point_box.pack_start(self.point_img, False, False, 0)
        self.point_btns = Gtk.Box(spacing=6)
        self.point_box.pack_start(self.point_btns, False, False, 0)
        self.point_box.set_no_show_all(True)
        card.pack_start(self.point_box, False, False, 0)
        self.point_path = None

        row = Gtk.Box(spacing=6)
        self.entry = Gtk.Entry()
        self.entry.set_placeholder_text("Ask anything…  (Esc to hide)")
        self.entry.connect("activate", self.on_send)
        row.pack_start(self.entry, True, True, 0)
        mic = Gtk.Button()
        mic.set_image(Gtk.Image.new_from_icon_name("audio-input-microphone-symbolic",
                                                   Gtk.IconSize.BUTTON))
        mic.set_tooltip_text("Talk (Super+Space)")
        mic.connect("clicked", lambda *_: self.listen_toggle())
        row.pack_start(mic, False, False, 0)
        pt = Gtk.Button()
        pt.set_image(Gtk.Image.new_from_icon_name("edit-select-symbolic", Gtk.IconSize.BUTTON))
        pt.set_tooltip_text("Ask about part of the screen (Super+T)")
        pt.connect("clicked", lambda *_: self.start_point())
        row.pack_start(pt, False, False, 0)
        card.pack_start(row, False, False, 0)
        self.recording = None
        self.levels = []
        self.spoken = False          # was the question asked out loud?
        self.update_who()

    # ---- window ---------------------------------------------------------
    def _clear(self, _w, cr):
        import cairo
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        return False

    def reposition(self):
        """Beside the character, on the side that faces the middle of the
        screen, its bottom (or top) edge level with the character's."""
        c = self.c
        for e in (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.BOTTOM,
                  GtkLayerShell.Edge.LEFT, GtkLayerShell.Edge.RIGHT):
            GtkLayerShell.set_anchor(self.win, e, False)
        v, h = c.CORNERS[c.corner]
        GtkLayerShell.set_anchor(self.win, v, True)
        GtkLayerShell.set_anchor(self.win, h, True)
        GtkLayerShell.set_margin(self.win, h, max(0, c.mx + c.w + 6))
        GtkLayerShell.set_margin(self.win, v, max(0, c.my + int(c.h * 0.12)))

    def keyboard(self, on: bool):
        mode = getattr(GtkLayerShell.KeyboardMode, "EXCLUSIVE" if on else "ON_DEMAND", None)
        try:
            if mode is not None:
                GtkLayerShell.set_keyboard_mode(self.win, mode)
            else:
                GtkLayerShell.set_keyboard_interactivity(self.win, True)
        except Exception:
            pass
        return False

    def toggle(self):
        if self.win.get_visible():
            self.hide()
        else:
            self.show()

    def show(self):
        self.reposition()
        self.update_who()
        self.win.show_all()
        self.keyboard(True)
        self.entry.grab_focus()

    def hide(self):
        self.keyboard(False)
        self.win.hide()

    def on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            if self.recording:
                self.stop_listening("cancelled")
            else:
                self.hide()
            return True
        return False

    # ---- listening (shell/companion_voice.py) ----------------------------
    def listen_toggle(self):
        """Super+Space or the microphone button: start, or stop and send."""
        if self.recording:
            self.stop_listening("done")
            return
        if self.busy:
            return
        import companion_voice as cv
        if not self.win.get_visible():
            self.show()
        ok, why = cv.can_listen()
        if not ok:
            self._line("🎤 " + why, "err")
            return
        self.levels = []
        self.listen_label.set_text("Listening… stops when you pause. Esc cancels.")
        self._show_listen()
        self.c.set_local_state("listening")
        self.recording = cv.Recording(
            on_level=lambda lv: GLib.idle_add(self._on_level, lv),
            on_end=lambda r, pcm, d: GLib.idle_add(self._on_end, r, pcm, d))
        try:
            self.recording.start()
        except Exception as e:
            self.recording = None
            self.listen_box.hide()
            self.c.set_local_state(None)
            self._line(f"🎤 The microphone could not open ({e}).", "err")

    def _show_listen(self):
        # show_all() skips a widget marked no_show_all — which this one is,
        # so the window's own show_all() does not open it uninvited.
        self.listen_box.show()
        for child in self.listen_box.get_children():
            child.show_all()

    # ---- point and ask (shell/companion_point.py) -------------------------
    def start_point(self):
        """Super+T: the bubble steps aside, you drag over what you mean, and
        it comes back with that picture and three ways to ask."""
        import companion_point as cp
        if self.busy or self.recording:
            return
        ok, why = cp.can_point()
        if not ok:
            self.show()
            self._line(why, "err")
            return
        was_open = self.win.get_visible()
        self.win.hide()             # out of the way of the selection
        self.c.set_local_state("reading")

        def work():
            geom, why = cp.select_area()
            path = None
            if geom:
                path, why = cp.capture(geom)
            GLib.idle_add(self._pointed, path, why, was_open)
        threading.Thread(target=work, daemon=True).start()

    def _pointed(self, path, why, was_open):
        self.c.set_local_state(None)
        if not path:
            if why or was_open:
                self.show()
            if why:
                self._line("Could not select: " + why, "err")
            return False
        self.drop_point()
        self.point_path = str(path)
        try:
            from gi.repository import GdkPixbuf
            pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(self.point_path, WIDTH - 40, 200, True)
            self.point_img.set_from_pixbuf(pb)
        except Exception:
            self.point_img.clear()
        import companion_point as cp
        for child in self.point_btns.get_children():
            self.point_btns.remove(child)
        for label, question in cp.presets():
            b = Gtk.Button(label=label)
            b.connect("clicked", lambda _b, q=question: self.ask(q))
            self.point_btns.pack_start(b, False, False, 0)
        x = Gtk.Button(label="✕")
        x.set_tooltip_text("Forget this picture")
        x.connect("clicked", lambda *_: self.drop_point())
        self.point_btns.pack_end(x, False, False, 0)
        self.point_box.show()
        for child in self.point_box.get_children():
            child.show_all()
        self.entry.set_placeholder_text("Ask about this…")
        self.show()
        return False

    def drop_point(self, delete=True):
        """The picture leaves the bubble (and the disk)."""
        if self.point_path and delete:
            try:
                os.unlink(self.point_path)
            except OSError:
                pass
        self.point_path = None
        self.point_box.hide()
        self.entry.set_placeholder_text("Ask anything…  (Esc to hide)")

    def ask(self, question):
        self.entry.set_text(question)
        self.on_send(None)

    def stop_listening(self, why="done"):
        if self.recording:
            self.recording.stop(why)

    def _on_level(self, lv):
        self.levels = (self.levels + [lv])[-60:]
        self.c.set_level(lv)
        self.wave.queue_draw()
        return False

    def _draw_wave(self, w, cr):
        width, height = w.get_allocated_width(), w.get_allocated_height()
        n = 60
        bw = width / n
        for i, lv in enumerate(self.levels[-n:]):
            h = max(2, min(1.0, lv * 9) * height)
            cr.rectangle(i * bw + 1, (height - h) / 2, max(1, bw - 2), h)
        cr.set_source_rgba(0.35, 0.85, 0.85, 0.9)
        cr.fill()
        return False

    def _on_end(self, result, pcm, detail):
        self.recording = None
        self.c.set_level(0)
        if result != "done":
            self.listen_box.hide()
            self.c.set_local_state(None)
            if result == "nothing":
                self._line("🎤 I didn't hear anything.", "dim")
            elif result == "error":
                self._line("🎤 The microphone stopped" + (f": {detail}" if detail else "."), "err")
            return False
        self.listen_label.set_text("Writing down what you said…")
        self.stop_btn.set_sensitive(False)
        self.c.set_local_state("working")

        def work():
            # Whatever happens, the bubble hears back: an exception here
            # used to leave it on "Writing down what you said…" for ever.
            try:
                import companion_voice as cv
                text = cv.transcribe(pcm)
            except Exception as e:
                text = f"ERROR: could not turn the recording into words ({e})"
            GLib.idle_add(self._heard, text)
        threading.Thread(target=work, daemon=True).start()
        return False

    def _heard(self, text):
        import companion_voice as cv
        self.listen_box.hide()
        self.stop_btn.set_sensitive(True)
        self.c.set_local_state(None)
        if text.startswith("ERROR:"):
            self._line("🎤 " + text[6:].strip(), "err")
            return False
        text = cv.clean(text)
        if not text:
            self._line("🎤 I didn't catch any words.", "dim")
            return False
        self.spoken = True
        self.entry.set_text(text)
        self.on_send(None)
        return False

    def update_who(self):
        try:
            import cloud
            e = cloud.current()
            self.who.set_text(("☁ " + cloud.label(e)) if e else "⌂ This computer")
        except Exception:
            self.who.set_text("⌂ This computer")

    # ---- the conversation -----------------------------------------------
    def _line(self, text, cls, wrap=True):
        lab = Gtk.Label(label=text)
        lab.set_line_wrap(wrap)
        lab.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        lab.set_selectable(True)
        lab.set_max_width_chars(46)
        lab.set_xalign(0)
        rtl = is_rtl(text)
        lab.set_direction(Gtk.TextDirection.RTL if rtl else Gtk.TextDirection.LTR)
        lab.get_style_context().add_class(cls)
        # Yours on the right, its on the left, whatever the language. GTK
        # mirrors START and END for a right-to-left widget, so the side is
        # chosen after the direction.
        right = cls == "you"
        lab.set_halign(Gtk.Align.START if right == rtl else Gtk.Align.END)
        self.list.pack_start(lab, False, False, 0)
        lab.show()
        GLib.idle_add(self._to_bottom)
        return lab

    def _to_bottom(self):
        # The window grows with the conversation up to MAX_HEIGHT, then
        # scrolls. GTK3 will not do "natural height, but at most" for a
        # scrolled window on its own, so it is measured here.
        nat = self.list.get_preferred_height()[1]
        self.scroll.set_min_content_height(min(nat, MAX_HEIGHT))
        adj = self.scroll.get_vadjustment()
        adj.set_value(adj.get_upper())
        return False

    def on_send(self, _entry):
        text = self.entry.get_text().strip()
        if not text or self.busy:
            return
        self.entry.set_text("")
        self._line(text, "you")
        self.busy = True
        self.entry.set_sensitive(False)
        self.answer, self.answer_text = None, ""
        msg = {"type": "user_message", "text": text}
        if self.point_path:
            # Sent once, with the first question about it; after that the
            # conversation already holds what it showed. The file goes two
            # minutes later (companion_point.KEEP_SECONDS).
            msg["image"] = self.point_path
            self._line("🖼 the area you selected", "dim")
            path = self.point_path
            self.drop_point(delete=False)
            GLib.timeout_add_seconds(120, lambda: (os.path.exists(path) and os.unlink(path)) and False)
        try:
            self.link.send(msg)
        except OSError:
            self._line("The assistant is not running. It starts with the "
                       "desktop; give it a moment, or open the chat.", "err")
            self.done()
            return
        # Let go of the keyboard while it works: the person can carry on.
        self.keyboard(False)

    def done(self):
        self.busy = False
        self.entry.set_sensitive(True)
        self.c.set_talking(False)
        if self.win.get_visible():
            self.entry.grab_focus()

    def _quiet(self):
        self._quiet_id = None
        self.c.set_talking(False)
        return False

    def on_message(self, msg):
        t = msg.get("type")
        if t == "delta":
            if self.answer is None:
                self.answer = self._line("", "it")
            self.answer_text += msg.get("text", "")
            self.answer.set_text(self.answer_text)
            rtl = is_rtl(self.answer_text)
            self.answer.set_direction(Gtk.TextDirection.RTL if rtl else Gtk.TextDirection.LTR)
            self.answer.set_halign(Gtk.Align.END if rtl else Gtk.Align.START)
            self.c.set_talking(True)
            if self._quiet_id:
                GLib.source_remove(self._quiet_id)
            self._quiet_id = GLib.timeout_add(450, self._quiet)
            GLib.idle_add(self._to_bottom)
        elif t == "tool_use":
            self.answer = None
            self.answer_text = ""
            self._line(f"⚙ {msg.get('name', '')}: {msg.get('detail', '')}"[:160], "dim")
        elif t == "remembered":
            self._line("Remembered: " + str(msg.get("fact", "")), "dim")
        elif t == "forgotten":
            self._line("Forgot from " + str(msg.get("note", "your notes")), "dim")
        elif t == "image":
            self._line("🖼 " + str(msg.get("path", "")), "dim")
        elif t == "status":
            self._line(str(msg.get("text", "")), "dim")
        elif t == "confirm":
            self.ask_confirm(msg)
        elif t == "assistant":
            text = msg.get("text") or ""
            if self.answer is None:
                self.answer = self._line(text, "it")
            else:
                self.answer.set_text(text)
            if self.spoken:
                self.spoken = False
                self.say(text)
            if msg.get("label") or msg.get("backend"):
                self.who.set_text(("☁ " + msg["label"]) if msg.get("backend") == "cloud"
                                  else "⌂ This computer")
            self.done()
        elif t == "error":
            self._line("⚠ " + str(msg.get("text", "")), "err")
            if msg.get("action") == "use_local":
                b = Gtk.Button(label="Use the local model")
                b.connect("clicked", self.use_local)
                self.list.pack_start(b, False, False, 0)
                b.show()
            self.done()
        elif t == "_closed":
            if self.busy:
                self._line("The assistant stopped. Try again in a moment.", "err")
                self.done()
            self.link.close()
        return False

    def say(self, text):
        """An answer to a spoken question is read aloud, if this computer
        can speak (piper) and Settings has not turned it off."""
        import companion_voice as cv
        try:
            import paths as _p
            if _p.read_desktop_env().get("OSPRIME_COMPANION_SPEAK", "yes").strip('"') == "no":
                return
        except Exception:
            pass
        if not cv.can_speak():
            return
        cv.speak(text,
                 on_start=lambda: GLib.idle_add(self.c.set_local_state, "speaking"),
                 on_end=lambda: GLib.idle_add(self.c.set_local_state, None))

    def ask_confirm(self, msg):
        """A risky step, asked here, the same way the chat asks."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.get_style_context().add_class("it")
        q = Gtk.Label(label="🔒 " + str(msg.get("text", "")), xalign=0)
        q.set_line_wrap(True)
        q.set_max_width_chars(46)
        box.pack_start(q, False, False, 0)
        if msg.get("detail"):
            d = Gtk.Label(label=str(msg["detail"])[:600], xalign=0)
            d.set_line_wrap(True)
            d.set_max_width_chars(46)
            d.get_style_context().add_class("dim")
            box.pack_start(d, False, False, 0)
        row = Gtk.Box(spacing=6)
        for text, ok, cls in (("Allow", True, "go"), ("Don't", False, "no")):
            b = Gtk.Button(label=text)
            b.get_style_context().add_class(cls)

            def answer(_b, ok=ok):
                for child in row.get_children():
                    child.set_sensitive(False)
                try:
                    self.link.send({"type": "confirm_response", "id": msg.get("id"),
                                    "approved": ok})
                except OSError:
                    pass
            b.connect("clicked", answer)
            row.pack_start(b, False, False, 0)
        box.pack_start(row, False, False, 0)
        self.list.pack_start(box, False, False, 0)
        box.show_all()
        self.keyboard(True)          # an answer is needed: take the focus back
        GLib.idle_add(self._to_bottom)

    def use_local(self, button):
        button.set_sensitive(False)

        def go():
            try:
                import cloud
                import engines
                cloud.set_on(False)
                engines.start_main(wait=False)
            except Exception:
                pass
        threading.Thread(target=go, daemon=True).start()
        self._line("Cloud model off. The local model is starting — about 10 to 30 seconds.", "dim")
        self.update_who()

    def new(self, *_):
        self.link.close()
        self.drop_point()
        try:
            import companion_point as cp
            cp.sweep(0)
        except Exception:
            pass
        for child in self.list.get_children():
            self.list.remove(child)
        self.answer, self.answer_text = None, ""
        self.done()

    def open_chat(self, *_):
        self.hide()
        self.c.toggle_chat()
