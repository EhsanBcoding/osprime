"""OSprime system control.

Narrow, named operations instead of asking the model to compose shell
commands. A 1.5B model cannot reliably remember that setting the clock means
`timedatectl set-time "2026-08-15 14:30:00"` — it can reliably pick
`set_time` from a list and fill one field. That difference is why asking
OSprime to fix the clock failed.

Every function here also has a second consumer: Settings. Both read and write
through this module so the two can never disagree about what the system
currently is.

Each returns a short human sentence, because the result is shown to the user.
"""

import glob
import json
import os
import pathlib
import re
import shutil
import subprocess

CONFIG_PATH = pathlib.Path(os.environ.get("OSPRIME_DESKTOP_ENV",
                                          "/etc/osprime/desktop.env"))
TIMEOUT = 30


def _wayland_env():
    """The environment a program needs to talk to the screen.

    wlr-randr, grim and swaybg all connect to the compositor through
    WAYLAND_DISPLAY and XDG_RUNTIME_DIR. The agent and the web UI are
    systemd services, and a service inherits neither — so every one of those
    tools failed, and Settings reported "could not find the screen" and
    "resolution: not available" on a laptop whose screen was plainly there.
    Nothing was wrong with the display. The process asking simply had no way
    to reach it.

    So find the compositor's socket rather than assume it. There is normally
    exactly one.
    """
    e = os.environ.copy()
    if e.get("WAYLAND_DISPLAY") and e.get("XDG_RUNTIME_DIR"):
        return e
    for sock in sorted(glob.glob("/run/user/*/wayland-*")):
        if sock.endswith(".lock"):
            continue
        e["XDG_RUNTIME_DIR"] = os.path.dirname(sock)
        e["WAYLAND_DISPLAY"] = os.path.basename(sock)
        return e
    return e


def _no_display_error() -> str:
    """One sentence for the one cause worth distinguishing."""
    if not glob.glob("/run/user/*/wayland-*"):
        return ("ERROR: no graphical session is running, so there is no "
                "screen to read. This works from the desktop.")
    return ""


def _run(args, timeout: int = TIMEOUT, env=None):
    """Run a command directly — no shell, so nothing can be injected."""
    try:
        r = subprocess.run(args, capture_output=True, text=True,
                           timeout=timeout, env=env)
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", f"{args[0]} is not installed"
    except subprocess.TimeoutExpired:
        return 124, "", f"{args[0]} timed out"


def _sudo(args):
    """These actions need root. The agent runs unprivileged by design."""
    if os.geteuid() == 0:
        return _run(args)
    if shutil.which("sudo"):
        return _run(["sudo", "-n"] + args)
    return 1, "", "root privileges are required and sudo is unavailable"


# --------------------------------------------------------------------------
# time
# --------------------------------------------------------------------------

_DT = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$")


def get_time() -> str:
    code, out, _ = _run(["timedatectl", "show", "--property=Timezone",
                         "--property=NTP", "--property=TimeUSec", "--value"])
    if code != 0:
        return "ERROR: could not read the clock"
    parts = out.splitlines()
    return json.dumps({"timezone": parts[0] if parts else "",
                       "auto_sync": (parts[1] if len(parts) > 1 else "") == "yes",
                       "time": parts[2] if len(parts) > 2 else ""})


def set_time(datetime: str) -> str:
    """Set the clock. Expects `YYYY-MM-DD HH:MM` or with seconds.

    The parameter is named to match the tool schema exactly — the dispatcher
    passes arguments through by keyword, so a mismatch here is a runtime
    failure the model cannot recover from.
    """
    s = (datetime or "").strip().replace("T", " ")
    if not _DT.match(s):
        return ("ERROR: I need the time as YYYY-MM-DD HH:MM, "
                f"and I was given '{datetime}'.")
    if len(s) == 16:
        s += ":00"
    # Automatic sync overrides any manual setting, so it has to go first.
    _sudo(["timedatectl", "set-ntp", "false"])
    code, _, err = _sudo(["timedatectl", "set-time", s])
    if code != 0:
        return f"ERROR: could not set the clock: {err}"
    return f"clock set to {s}" + _host_clock_note()


def _host_clock_note() -> str:
    """Warn when something outside this system owns the clock.

    A virtual machine's guest agent resets the guest clock from the host on
    every boot, so a manually set time silently reverts and the user is left
    thinking the setting did not save. Saying so is better than letting them
    set it again and again.
    """
    for agent in ("vmtoolsd", "qemu-ga", "VBoxService"):
        if subprocess.run(["pgrep", "-x", agent],
                          capture_output=True).returncode == 0:
            return (" — note: this machine is a virtual machine and its host "
                    "resets the clock on every restart, so this will not "
                    "survive a reboot. On real hardware it will.")
    return ""


def resolve_timezone(text: str):
    """Turn what a person types into an IANA zone name.

    Nobody living in Irvine knows their timezone is called
    America/Los_Angeles. Requiring the exact name made a correct request look
    like a user error, so the city is resolved here instead — the tz database
    already lists every city it knows.

    Returns (zone, candidates). Exactly one of them is meaningful.
    """
    want = (text or "").strip()
    if not want:
        return None, []
    code, out, _ = _run(["timedatectl", "list-timezones", "--no-pager"])
    if code != 0:
        return want, []          # cannot check; let timedatectl decide
    zones = out.split()

    if want in zones:
        return want, []

    norm = want.replace(" ", "_").lower()
    exact = [z for z in zones if z.lower() == norm]
    if exact:
        return exact[0], []

    # A bare city: match the last component of the zone name.
    city = [z for z in zones if z.rsplit("/", 1)[-1].lower() == norm.rsplit("/", 1)[-1]]
    if len(city) == 1:
        return city[0], []
    if city:
        return None, city[:6]

    loose = [z for z in zones if norm.rsplit("/", 1)[-1] in z.lower()]
    if len(loose) == 1:
        return loose[0], []
    return None, loose[:6]


def set_timezone(zone: str) -> str:
    resolved, options = resolve_timezone(zone)
    if not resolved:
        if options:
            return (f"ERROR: '{zone}' matches several timezones. "
                    f"Which one: {', '.join(options)}?")
        return (f"ERROR: '{zone}' does not match any timezone. Give me the "
                "nearest large city, or a name like Europe/Berlin.")
    code, _, err = _sudo(["timedatectl", "set-timezone", resolved])
    if code != 0:
        return f"ERROR: could not set timezone: {err}"
    if resolved != (zone or "").strip():
        return f"timezone set to {resolved} (matched from '{zone}')"
    return f"timezone set to {resolved}"


def set_auto_time(enabled: bool = True) -> str:
    code, _, err = _sudo(["timedatectl", "set-ntp", "true" if enabled else "false"])
    if code != 0:
        return f"ERROR: could not change automatic time: {err}"
    return "clock now syncs automatically" if enabled else "automatic clock sync off"


# --------------------------------------------------------------------------
# network
# --------------------------------------------------------------------------

def _tsplit(line: str) -> list:
    """Split one line of `nmcli -t` output.

    nmcli separates fields with a colon and escapes any colon inside a value
    as `\\:`. Splitting naively tore apart every network whose name contains
    one, which is common enough on phone hotspots.
    """
    fields, cur, esc = [], [], False
    for ch in line:
        if esc:
            cur.append(ch)
            esc = False
        elif ch == "\\":
            esc = True
        elif ch == ":":
            fields.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    fields.append("".join(cur))
    return fields


def wifi_radio(on: bool = True) -> str:
    code, _, err = _sudo(["nmcli", "radio", "wifi", "on" if on else "off"])
    if code != 0:
        return f"ERROR: could not turn the Wi-Fi radio {'on' if on else 'off'}: {err}"
    return f"Wi-Fi radio {'on' if on else 'off'}"


def _has_wifi_device() -> bool:
    code, out, _ = _run(["nmcli", "-t", "-f", "TYPE", "device", "status"])
    return code == 0 and any(l.strip() == "wifi" for l in out.splitlines())


def list_wifi() -> str:
    if not shutil.which("nmcli"):
        return "ERROR: NetworkManager is not available on this system."
    if not _has_wifi_device():
        return ("ERROR: this machine has no Wi-Fi adapter. If it is connected "
                "by cable, it may already be online.")

    # A blocked radio reports zero networks, which reads as "nothing nearby"
    # rather than "the switch is off" — so turn it on rather than mislead.
    code, out, _ = _run(["nmcli", "-t", "-f", "WIFI", "radio"])
    if code == 0 and out.strip().endswith("disabled"):
        r = wifi_radio(True)
        if r.startswith("ERROR"):
            return r

    # Without an explicit rescan the list is whatever was cached, which on a
    # freshly booted machine is usually nothing at all.
    _run(["nmcli", "device", "wifi", "rescan"], timeout=30)

    code, out, err = _run(["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY,IN-USE",
                           "device", "wifi", "list"], timeout=45)
    if code != 0:
        return f"ERROR: could not scan for networks: {err}"

    known = _saved_networks()
    seen, rows = set(), []
    for line in out.splitlines():
        p = _tsplit(line)
        ssid = (p[0] if p else "").strip()
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        rows.append({
            "ssid": ssid,
            "signal": p[1].strip() if len(p) > 1 else "",
            "secured": bool(p[2].strip()) if len(p) > 2 else True,
            "active": (p[3].strip() == "*") if len(p) > 3 else False,
            "saved": ssid in known,
        })
    if not rows:
        return "no networks found"
    rows.sort(key=lambda r: int(r["signal"] or 0), reverse=True)
    return json.dumps(rows[:20])


def _saved_networks() -> set:
    code, out, _ = _run(["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"])
    if code != 0:
        return set()
    names = set()
    for line in out.splitlines():
        p = _tsplit(line)
        if len(p) > 1 and "wireless" in p[1]:
            names.add(p[0])
    return names


def connect_wifi(ssid: str, password: str = "") -> str:
    if not ssid:
        return "ERROR: I need the network name."
    if not shutil.which("nmcli"):
        return "ERROR: NetworkManager is not available on this system."

    # -w is a global option and must come before the object. Appending it
    # after the command made nmcli reject every connection attempt outright,
    # which is why joining a network never once worked.
    base = ["nmcli", "-w", "30"]

    # A network joined before has its password stored; asking for it again
    # would be a worse experience than simply bringing the profile up.
    if not password and ssid in _saved_networks():
        code, _, err = _sudo(base + ["connection", "up", "id", ssid])
        if code == 0:
            return f"connected to {ssid}"

    args = base + ["device", "wifi", "connect", ssid]
    if password:
        args += ["password", password]
    code, _, err = _sudo(args)
    if code != 0:
        low = (err or "").lower()
        if "secrets" in low or "no key available" in low or "802-11" in low:
            return f"ERROR: '{ssid}' needs a password, or the password was wrong."
        if "not found" in low or "no network" in low:
            return f"ERROR: '{ssid}' is not in range. Scan again and pick it from the list."
        return f"ERROR: could not connect to {ssid}: {err or 'unknown reason'}"
    return f"connected to {ssid}"


def forget_wifi(ssid: str) -> str:
    if not ssid:
        return "ERROR: I need the network name."
    code, _, err = _sudo(["nmcli", "connection", "delete", "id", ssid])
    if code != 0:
        return f"ERROR: could not forget {ssid}: {err}"
    return f"forgot {ssid}"


def network_status() -> str:
    code, out, _ = _run(["nmcli", "-t", "-f", "TYPE,STATE,CONNECTION",
                         "device", "status"])
    if code != 0:
        return "ERROR: could not read network status"
    active = [l for l in out.splitlines() if ":connected:" in l]
    if not active:
        return "not connected to any network"
    return json.dumps([{"type": l.split(":")[0], "name": l.split(":")[2]}
                       for l in active])


# --------------------------------------------------------------------------
# appearance and locale — shared with Settings through desktop.env
# --------------------------------------------------------------------------

def _read_env() -> dict:
    out = {}
    try:
        for line in CONFIG_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except Exception:
        pass
    return out


def _write_env(key: str, value: str) -> bool:
    """Update one key, preserving comments and the rest of the file."""
    try:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        lines = (CONFIG_PATH.read_text(encoding="utf-8").splitlines()
                 if CONFIG_PATH.exists() else [])
        done = False
        for i, line in enumerate(lines):
            if line.strip().startswith(f"{key}="):
                lines[i] = f"{key}={value}"
                done = True
                break
        if not done:
            lines.append(f"{key}={value}")
        CONFIG_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return True
    except Exception:
        return False


_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")


def set_wallpaper(color: str) -> str:
    """Solid colour only for now — no image support yet."""
    c = (color or "").strip()
    named = {"petrol": "#12232E", "beige": "#D9CFBC", "black": "#0B0B0B",
             "navy": "#101A2E", "grey": "#2B2E33", "gray": "#2B2E33"}
    c = named.get(c.lower(), c)
    if not _HEX.match(c):
        return (f"ERROR: '{color}' is not a colour I understand. "
                "Give me a hex value like #12232E, or: petrol, beige, navy, grey.")
    if not _write_env("OSPRIME_WALLPAPER", c):
        return "ERROR: could not save the setting"
    if shutil.which("swaybg"):
        subprocess.run(["pkill", "swaybg"], capture_output=True)
        # Same reason as the display tools: a service has no Wayland socket
        # of its own, so swaybg would exit immediately and the background
        # would keep its old colour with nothing to say why.
        subprocess.Popen(["swaybg", "-c", c], env=_wayland_env(),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return f"background set to {c}"


def set_language(code: str) -> str:
    code = (code or "").strip().lower()
    if not re.match(r"^[a-z]{2}$", code):
        return f"ERROR: '{code}' is not a language code. Use two letters, such as en or fa."
    if not _write_env("OSPRIME_LANG", code):
        return "ERROR: could not save the setting"
    return f"language set to {code}. Reopen the chat window to see it."


def get_settings() -> str:
    """Everything Settings displays, from the one place that holds it."""
    env = _read_env()
    code, tz, _ = _run(["timedatectl", "show", "--property=Timezone", "--value"])
    return json.dumps({
        "language": env.get("OSPRIME_LANG", "en"),
        "wallpaper": env.get("OSPRIME_WALLPAPER", "#12232E"),
        "timezone": tz if code == 0 else "",
        "cloud_mode": env.get("OSPRIME_CLOUD_MODE",
                              os.environ.get("OSPRIME_CLOUD_MODE", "off")),
        "desktop": env.get("OSPRIME_DESKTOP", "yes") == "yes",
        "scale": env.get("OSPRIME_SCALE", ""),
    })


# --------------------------------------------------------------------------
# display and sound
# --------------------------------------------------------------------------

def set_volume(percent: int) -> str:
    try:
        p = max(0, min(100, int(percent)))
    except (TypeError, ValueError):
        return f"ERROR: '{percent}' is not a number between 0 and 100."
    if shutil.which("wpctl"):
        code, _, err = _run(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{p}%"])
    elif shutil.which("amixer"):
        code, _, err = _run(["amixer", "-q", "sset", "Master", f"{p}%"])
    else:
        return "ERROR: no audio control available"
    return f"volume set to {p}%" if code == 0 else f"ERROR: could not set volume: {err}"


def list_drives() -> str:
    """Removable and mounted storage, so the assistant can find a USB stick.

    Asked where the files on a memory stick are, the assistant had no way to
    look: it could list directories but had no idea the device existed.
    """
    code, out, _ = _run(["lsblk", "-J", "-o",
                         "NAME,SIZE,TYPE,MOUNTPOINT,RM,LABEL,FSTYPE"])
    if code != 0:
        return "ERROR: could not read the drives on this machine."
    try:
        tree = json.loads(out).get("blockdevices", [])
    except json.JSONDecodeError:
        return "ERROR: could not read the drives on this machine."

    drives = []

    def walk(node, removable=False):
        rm = bool(node.get("rm")) or removable
        # Anything carrying a filesystem, whether it is a partition or the
        # whole device. Plenty of USB sticks are formatted with no partition
        # table at all, and only listing partitions made those invisible —
        # which is the same as not supporting them.
        if node.get("fstype") and node.get("type") in ("part", "disk"):
            drives.append({
                "device": "/dev/" + node.get("name", ""),
                "size": node.get("size", ""),
                "label": node.get("label") or "",
                "filesystem": node.get("fstype") or "",
                "mounted_at": node.get("mountpoint") or "",
                "removable": rm,
            })
        for child in node.get("children", []) or []:
            walk(child, rm)

    for dev in tree:
        walk(dev)

    if not drives:
        return "no storage devices found"
    return json.dumps(drives)


def mount_drive(device: str) -> str:
    """Mount a partition under /media so its files can be reached."""
    dev = (device or "").strip()
    if not re.match(r"^/dev/[a-zA-Z0-9]+$", dev):
        return f"ERROR: '{device}' is not a device name. Use something like /dev/sdb1."

    # Already mounted somewhere? Say where instead of mounting it twice.
    code, out, _ = _run(["findmnt", "-n", "-o", "TARGET", "--source", dev])
    if code == 0 and out.strip():
        return f"{dev} is already available at {out.strip().splitlines()[0]}"

    if shutil.which("udisksctl"):
        code, out, err = _run(["udisksctl", "mount", "-b", dev], timeout=45)
        if code == 0:
            m = re.search(r"at (\S+)", out)
            return f"{dev} is available at {m.group(1).rstrip('.') if m else '/run/media'}"

    if not pathlib.Path(dev).exists():
        # The commonest failure by far, and the kernel's own wording for it —
        # "Can't lookup blockdev" — tells a user nothing at all.
        return (f"ERROR: there is no device called {dev}. Use list_drives to "
                "see what is actually connected; the name changes depending "
                "on what was plugged in first.")

    point = "/media/" + dev.rsplit("/", 1)[-1]
    _sudo(["mkdir", "-p", point])
    code, _, err = _sudo(["mount", dev, point])
    if code != 0:
        low = (err or "").lower()
        if "unknown filesystem" in low or "wrong fs type" in low:
            return (f"ERROR: {dev} is formatted in a way this system cannot "
                    "read yet. Tell the user which format it is if you know.")
        return f"ERROR: could not open {dev}: {err or 'unknown reason'}"
    return f"{dev} is available at {point}"


def compress_pdf(path: str, quality: str = "ebook") -> str:
    """Shrink a PDF, writing a new file beside the original.

    A tool rather than a shell command the model composes. Asked to do this
    with `run_shell` it produced a ghostscript line with a bare filename, no
    directory, and repeated it unchanged after being given the full path.
    Quoting, paths and flags are exactly the parts a small model gets wrong,
    and they are all fixed here.
    """
    src = pathlib.Path(os.path.expanduser((path or "").strip()))
    if not src.is_absolute():
        return (f"ERROR: '{path}' is not a full path. Give the whole path "
                "starting with /, such as /home/osprime/Desktop/file.pdf.")
    if not src.is_file():
        return f"ERROR: there is no file at {src}."
    if src.suffix.lower() != ".pdf":
        return f"ERROR: {src.name} is not a PDF."
    if not shutil.which("gs"):
        return "ERROR: ghostscript is not installed, so PDFs cannot be compressed yet."

    presets = {"screen": "/screen", "ebook": "/ebook",
               "printer": "/printer", "prepress": "/prepress"}
    preset = presets.get((quality or "ebook").strip().lower())
    if not preset:
        return (f"ERROR: '{quality}' is not a quality setting. Use screen, "
                "ebook, printer or prepress.")

    dest = src.with_name(src.stem + "-small.pdf")
    before = src.stat().st_size
    code, _, err = _run(["gs", "-sDEVICE=pdfwrite", "-dCompatibilityLevel=1.4",
                         f"-dPDFSETTINGS={preset}", "-dNOPAUSE", "-dQUIET",
                         "-dBATCH", f"-sOutputFile={dest}", str(src)],
                        timeout=600)
    if code != 0 or not dest.is_file():
        return f"ERROR: could not compress {src.name}: {err[:200] or 'unknown reason'}"

    after = dest.stat().st_size

    def mb(n):
        return f"{n / 1024 / 1024:.1f} MB" if n >= 1024 * 1024 else f"{n // 1024} KB"

    if after >= before:
        dest.unlink(missing_ok=True)
        return (f"{src.name} is already about as small as it goes "
                f"({mb(before)}). Removing pages would be the other way to "
                "get under a size limit.")
    pct = round((1 - after / before) * 100)
    return (f"{src.name}: {mb(before)} -> {mb(after)}, {pct}% smaller. "
            f"Saved as {dest.name} next to the original.")


def get_display() -> str:
    """Screens, their resolution and their scale."""
    if not shutil.which("wlr-randr"):
        return "ERROR: the display tool is not installed on this system yet."
    code, out, err = _run(["wlr-randr"], env=_wayland_env())
    if code != 0:
        return _no_display_error() or f"ERROR: could not read the display: {err}"

    screens, cur = [], None
    for line in out.splitlines():
        if line and not line[0].isspace():
            cur = {"name": line.split()[0], "modes": [], "current": "", "scale": ""}
            screens.append(cur)
        elif cur is not None:
            t = line.strip()
            if t.startswith("Scale:"):
                cur["scale"] = t.split(":", 1)[1].strip()
            elif "current" in t:
                cur["current"] = t.split()[0]
                cur["modes"].append(t.split()[0])
            elif "px," in t or re.match(r"^\d+x\d+", t):
                cur["modes"].append(t.split()[0])
    for s in screens:
        # Only the distinct sizes matter to a person choosing one.
        seen, keep = set(), []
        for m in s["modes"]:
            if m not in seen:
                seen.add(m)
                keep.append(m)
        s["modes"] = keep[:12]
    return json.dumps(screens) if screens else "no screens found"


def set_display(scale: str = "", resolution: str = "", output: str = "") -> str:
    """Change how large everything looks, or the resolution.

    Scale is the one people actually want: a 1920x1080 panel on a 14-inch
    laptop renders everything too small at 1.0, and lowering the resolution
    to compensate makes it blurry. 1.25 or 1.5 keeps it sharp.
    """
    if not shutil.which("wlr-randr"):
        return "ERROR: the display tool is not installed on this system yet."
    if not scale and not resolution:
        return "ERROR: tell me a scale (such as 1.25) or a resolution (such as 1920x1080)."

    env = _wayland_env()
    if not output:
        code, out, err = _run(["wlr-randr"], env=env)
        if code != 0 or not out.strip():
            return (_no_display_error()
                    or f"ERROR: could not find the screen: {err[:160]}")
        output = out.splitlines()[0].split()[0]

    args = ["wlr-randr", "--output", output]
    if resolution:
        if not re.match(r"^\d{3,5}x\d{3,5}$", resolution.strip()):
            return f"ERROR: '{resolution}' is not a resolution. Use a form like 1920x1080."
        args += ["--mode", resolution.strip()]
    if scale:
        try:
            s = float(str(scale).strip().rstrip("x%"))
            if s > 4:            # someone typed 125 meaning 125%
                s = s / 100
            if not 0.5 <= s <= 4:
                raise ValueError
        except ValueError:
            return f"ERROR: '{scale}' is not a scale. Use something between 1 and 2, such as 1.25."
        args += ["--scale", f"{s:g}"]

    code, _, err = _run(args, timeout=20, env=env)
    if code != 0:
        return f"ERROR: could not change the display: {err[:160]}"

    # Persist it, or it is gone at the next login.
    if scale:
        _write_env("OSPRIME_SCALE", f"{s:g}")
    if resolution:
        _write_env("OSPRIME_RESOLUTION", resolution.strip())
    _write_env("OSPRIME_OUTPUT", output)

    what = []
    if resolution:
        what.append(f"resolution {resolution}")
    if scale:
        what.append(f"scale {s:g}")
    return f"{output}: {' and '.join(what)}"


def take_screenshot(area: bool = False) -> str:
    """Save a picture of the screen.

    Every X11 screenshot program the model reached for is absent here; this
    is the one that works, and naming it removes the guessing.
    """
    if not shutil.which("grim"):
        return "ERROR: the screenshot tool is not installed on this system yet."
    home = os.path.expanduser("~" + (os.environ.get("SUDO_USER") or "osprime"))
    folder = pathlib.Path(home) / "Pictures" / "Screenshots"
    try:
        folder.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return f"ERROR: could not create {folder}: {e}"

    import datetime as _dt
    dest = folder / (_dt.datetime.now().strftime("%Y-%m-%d_%H-%M-%S") + ".png")
    env = _wayland_env()
    args = ["grim", str(dest)]
    if area and shutil.which("slurp"):
        code, region, _ = _run(["slurp"], timeout=60, env=env)
        if code != 0 or not region:
            return "the selection was cancelled, so nothing was saved"
        args = ["grim", "-g", region, str(dest)]

    code, _, err = _run(args, timeout=60, env=env)
    if code != 0 or not dest.is_file():
        return (_no_display_error()
                or f"ERROR: could not take the screenshot: {err[:160]}")
    if shutil.which("wl-copy"):
        subprocess.run(["sh", "-c", f"wl-copy < '{dest}'"],
                       capture_output=True, env=env)
    return f"screenshot saved to {dest}"


def system_summary() -> str:
    """Facts about this machine, for answering 'what am I running on'."""
    out = {}
    code, o, _ = _run(["uname", "-r"])
    out["kernel"] = o if code == 0 else ""
    try:
        mem = pathlib.Path("/proc/meminfo").read_text()
        kb = int(re.search(r"MemTotal:\s+(\d+)", mem).group(1))
        out["memory_gb"] = round(kb / 1024 / 1024, 1)
    except Exception:
        pass
    out["cpu_cores"] = os.cpu_count()
    code, o, _ = _run(["df", "-h", "--output=avail,pcent", "/"])
    if code == 0 and len(o.splitlines()) > 1:
        avail, pcent = o.splitlines()[1].split()
        out["disk_free"] = avail
        out["disk_used"] = pcent
    return json.dumps(out)
