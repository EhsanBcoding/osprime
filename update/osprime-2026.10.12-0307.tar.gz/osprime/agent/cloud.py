"""Cloud models: the person's own keys, one switch (docs/CLOUD.md).

Agreed with Ehsan on 7 October, replacing the three modes ("never", "only
when I ask", "when the local model cannot cope"):

* One switch. Off: the local model answers everything. On: the chosen
  cloud model answers everything, pictures included, and the local model is
  stopped so its memory and graphics card are free. Turning it off starts
  the local model again (10-30 s).
* Several keys can be saved, one per line, for different services; one is
  active at a time.
* Nothing changes on its own. When the cloud cannot be reached, the answer
  says so and offers "Use the local model"; it never falls back by itself,
  in either direction.
* File search by meaning and speech to text stay on this computer.

Keys live in one file per person (cloud.json, mode 0600, next to
secrets.env), never on a command line, never in a log, and the window only
ever sees the last four characters. A paired phone cannot read or change
any of it (ui/remote.py).

Two ways of talking cover every service: Anthropic's own API, and the
OpenAI-compatible /chat/completions that OpenAI, Google (its compatibility
endpoint), OpenRouter, DeepSeek, Groq, Mistral and xAI all speak. Plain
urllib, no SDK: one less thing to install, and the same code path for all.

    python3 cloud.py status      # JSON for the panel (waybar custom/cloud)
"""
import json
import os
import pathlib
import secrets as _rand
import urllib.error
import urllib.request

import paths

TIMEOUT = int(os.environ.get("OSPRIME_CLOUD_TIMEOUT", "120"))
ANTHROPIC_VERSION = "2023-06-01"

# Order is the order shown in Settings. "prefer" picks the starting model
# from the service's own list (the newest names change every few months, so
# none is written down here as THE model); the person can change it.
PROVIDERS = {
    "anthropic":  {"name": "Anthropic", "kind": "anthropic",
                   "base": "https://api.anthropic.com/v1",
                   "prefer": ["sonnet", "opus", "haiku"], "order": "api"},
    "openai":     {"name": "OpenAI", "kind": "openai",
                   "base": "https://api.openai.com/v1",
                   "prefer": ["gpt-5", "gpt-4.1", "gpt-4o"]},
    "google":     {"name": "Google Gemini", "kind": "openai",
                   "base": "https://generativelanguage.googleapis.com/v1beta/openai",
                   "prefer": ["gemini-3-pro", "gemini-2.5-pro", "pro", "flash"]},
    "openrouter": {"name": "OpenRouter", "kind": "openai",
                   "base": "https://openrouter.ai/api/v1", "check": "/key",
                   "prefer": ["anthropic/claude-sonnet", "openai/gpt-5", "google/gemini"]},
    "deepseek":   {"name": "DeepSeek", "kind": "openai",
                   "base": "https://api.deepseek.com/v1",
                   "prefer": ["deepseek-chat"]},
    "groq":       {"name": "Groq", "kind": "openai",
                   "base": "https://api.groq.com/openai/v1",
                   "prefer": ["gpt-oss-120b", "llama-3.3-70b", "llama"]},
    "mistral":    {"name": "Mistral", "kind": "openai",
                   "base": "https://api.mistral.ai/v1",
                   "prefer": ["mistral-large", "mistral-medium"]},
    "xai":        {"name": "xAI (Grok)", "kind": "openai",
                   "base": "https://api.x.ai/v1",
                   "prefer": ["grok-4", "grok-3", "grok"]},
    "other":      {"name": "Other (OpenAI-compatible)", "kind": "openai",
                   "base": "", "prefer": []},
}

# Not chat models. Listed so the model menu is not half embeddings.
_NOT_CHAT = ("embed", "tts", "whisper", "dall-e", "imagen", "image", "audio",
             "realtime", "moderation", "transcribe", "search", "babbage",
             "davinci", "aqa", "veo", "guard", "ocr")
_SMALL = ("mini", "nano", "lite", "tiny", "small", "8b", "preview")


class CloudError(Exception):
    """A sentence for the person, never a stack trace or the key."""
    def __init__(self, msg, code: int = 0):
        super().__init__(msg)
        self.code = code


# ---------------------------------------------------------------------------
# the key file
# ---------------------------------------------------------------------------
def store_path() -> pathlib.Path:
    return paths._pick("OSPRIME_CLOUD", "/etc/osprime/cloud.json",
                       ".config/osprime/cloud.json")


def _empty() -> dict:
    return {"on": False, "active": "", "keys": []}


def _migrate() -> dict:
    """The one Anthropic key of the old design becomes the first saved key.
    The switch stays off whatever the old mode was: the person turns it on
    in the new window, knowing what it now means."""
    st = _empty()
    key = ""
    sec = paths.secrets()
    lines = []
    try:
        lines = sec.read_text(encoding="utf-8").splitlines()
        for l in lines:
            if l.strip().startswith("ANTHROPIC_API_KEY="):
                key = l.split("=", 1)[1].strip().strip('"\'')
    except Exception:
        pass
    key = key or os.environ.get("ANTHROPIC_API_KEY", "")
    if key:
        st["keys"].append({"id": _new_id(), "provider": "anthropic", "key": key,
                           "model": os.environ.get("OSPRIME_CLAUDE_MODEL", ""),
                           "base_url": ""})
        st["active"] = st["keys"][0]["id"]
        try:   # one copy of a key, not two
            keep = [l for l in lines if not l.strip().startswith("ANTHROPIC_API_KEY=")]
            sec.write_text("\n".join(keep) + ("\n" if keep else ""), encoding="utf-8")
        except Exception:
            pass
    return st


def load() -> dict:
    p = store_path()
    try:
        st = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(st, dict) or not isinstance(st.get("keys"), list):
            raise ValueError
        st.setdefault("on", False)
        st.setdefault("active", "")
        return st
    except FileNotFoundError:
        st = _migrate()
        if st["keys"]:
            try:
                save(st)
            except Exception:
                pass
        return st
    except Exception:
        return _empty()


def save(st: dict):
    p = store_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    # Created 0600 before the key is written into it, not chmod-ed after.
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=1)
    os.chmod(tmp, 0o600)
    os.replace(tmp, p)


def _new_id() -> str:
    return "k" + _rand.token_hex(4)


def _find(st: dict, kid: str):
    return next((k for k in st["keys"] if k.get("id") == kid), None)


def active():
    """The active key's entry, whether or not the switch is on."""
    st = load()
    return _find(st, st.get("active", "")) or (st["keys"][0] if st["keys"] else None)


def enabled() -> bool:
    st = load()
    return bool(st.get("on")) and bool(_find(st, st.get("active", "")))


def current():
    """The entry that answers now, or None when the local model does."""
    st = load()
    return _find(st, st.get("active", "")) if st.get("on") else None


def provider_name(entry) -> str:
    return PROVIDERS.get((entry or {}).get("provider", ""), {}).get("name", "Cloud")


def label(entry) -> str:
    """'Anthropic · claude-sonnet-…' for the chat badge and the panel."""
    if not entry:
        return "Local model"
    m = entry.get("model") or "no model chosen"
    return f"{provider_name(entry)} · {m}"


def public_view() -> dict:
    """What the window may see: everything but the keys themselves."""
    st = load()
    return {
        "on": bool(st.get("on")),
        "active": st.get("active", ""),
        "keys": [{"id": k["id"], "provider": k["provider"],
                  "name": provider_name(k),
                  "tail": (k.get("key") or "")[-4:],
                  "model": k.get("model", ""),
                  "base_url": k.get("base_url", "")} for k in st["keys"]],
        "providers": [{"id": pid, "name": p["name"], "needs_url": not p["base"]}
                      for pid, p in PROVIDERS.items()],
    }


# ---------------------------------------------------------------------------
# changing it (Settings → Assistant → Cloud model)
# ---------------------------------------------------------------------------
def add_key(provider: str, key: str, base_url: str = "", model: str = "") -> dict:
    """Test the key first; save it only if the service accepts it."""
    provider = str(provider or "").strip()
    key = str(key or "").strip()
    base_url = str(base_url or "").strip().rstrip("/")
    if provider not in PROVIDERS:
        raise CloudError("Unknown service.")
    if not key:
        raise CloudError("Paste the key first.")
    if provider == "other":
        if not base_url.startswith(("https://", "http://")):
            raise CloudError("Give the service's address, e.g. https://example.com/v1")
    entry = {"id": _new_id(), "provider": provider, "key": key,
             "model": str(model or "").strip(), "base_url": base_url}
    models = check_key(entry)
    if not entry["model"]:
        entry["model"] = pick_default(provider, models)
    if not entry["model"]:
        raise CloudError("The key works, but no model could be chosen "
                         "automatically. Type the model's name.")
    st = load()
    st["keys"].append(entry)
    if not _find(st, st.get("active", "")):
        st["active"] = entry["id"]
    save(st)
    return {"id": entry["id"], "model": entry["model"], "models": models}


def remove_key(kid: str) -> dict:
    st = load()
    st["keys"] = [k for k in st["keys"] if k.get("id") != kid]
    if st.get("active") == kid:
        st["active"] = st["keys"][0]["id"] if st["keys"] else ""
    if not st["keys"]:
        st["on"] = False
    save(st)
    return st


def set_active(kid: str):
    st = load()
    if not _find(st, kid):
        raise CloudError("That key is not saved any more.")
    st["active"] = kid
    save(st)


def set_model(kid: str, model: str):
    st = load()
    k = _find(st, kid)
    if not k:
        raise CloudError("That key is not saved any more.")
    model = str(model or "").strip()
    if not model or len(model) > 200 or any(c.isspace() for c in model):
        raise CloudError("That is not a model name.")
    k["model"] = model
    save(st)


def set_on(on: bool):
    st = load()
    if on and not _find(st, st.get("active", "")):
        raise CloudError("Add a key first.")
    st["on"] = bool(on)
    save(st)


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------
def _base(entry) -> str:
    return (entry.get("base_url") or PROVIDERS[entry["provider"]]["base"]).rstrip("/")


def _headers(entry) -> dict:
    h = {"Content-Type": "application/json", "User-Agent": "OSprime"}
    if PROVIDERS[entry["provider"]]["kind"] == "anthropic":
        h["x-api-key"] = entry["key"]
        h["anthropic-version"] = ANTHROPIC_VERSION
    else:
        h["Authorization"] = "Bearer " + entry["key"]
    if entry["provider"] == "openrouter":
        h["HTTP-Referer"] = "https://osprime.app"
        h["X-Title"] = "OSprime"
    return h


def _explain(entry, code: int, body: str) -> str:
    who = provider_name(entry)
    detail = ""
    try:
        j = json.loads(body)
        e = j.get("error", j)
        detail = e.get("message", "") if isinstance(e, dict) else str(e)
    except Exception:
        detail = (body or "")[:200]
    detail = detail.replace(entry.get("key") or "\0", "…")
    if code in (401, 403):
        return f"{who} refused the key. Check it in Settings → Assistant → Cloud model."
    if code == 402:
        return f"{who} says the account has no credit left."
    if code == 429:
        return f"{who} is limiting requests or the account is out of credit. Try again in a minute."
    if code == 404:
        return f"{who} does not know the model \"{entry.get('model')}\". Choose another in Settings."
    if code >= 500:
        return f"{who} is having trouble right now ({code}). Try again later."
    return f"{who} did not accept the request ({code}): {detail}".strip()


def _request(entry, method: str, path: str, body=None, timeout: int = TIMEOUT):
    url = _base(entry) + path
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers=_headers(entry))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        raise CloudError(_explain(entry, e.code, e.read().decode("utf-8", "replace")), e.code)
    except Exception:
        raise CloudError(f"Could not reach {provider_name(entry)}. Is the internet on?")
    try:
        return json.loads(raw)
    except ValueError:
        raise CloudError(f"{provider_name(entry)} sent an answer that is not JSON.")


# ---------------------------------------------------------------------------
# keys and models
# ---------------------------------------------------------------------------
def _model_ids(entry, j) -> list:
    out = []
    for m in (j.get("data") or j.get("models") or []):
        mid = (m.get("id") or m.get("name") or "") if isinstance(m, dict) else str(m)
        mid = mid[len("models/"):] if mid.startswith("models/") else mid
        if mid and not any(w in mid.lower() for w in _NOT_CHAT):
            out.append(mid)
    return out


def list_models(entry) -> list:
    kind = PROVIDERS[entry["provider"]]["kind"]
    j = _request(entry, "GET", "/models?limit=1000" if kind == "anthropic" else "/models",
                 timeout=30)
    return _model_ids(entry, j)


def check_key(entry) -> list:
    """Raises CloudError if the key is refused. Returns the model list
    (possibly empty for a service that has none to give)."""
    check = PROVIDERS[entry["provider"]].get("check")
    if check:                          # OpenRouter lists models without a key
        _request(entry, "GET", check, timeout=30)
    try:
        return list_models(entry)
    except CloudError as e:
        # Only a server with no model list at all gets the second chance;
        # a refused key is a refused key.
        if check or entry["provider"] != "other" or e.code not in (404, 405, 501):
            raise
        # An OpenAI-compatible server without /models: one tiny question.
        if not entry.get("model"):
            raise CloudError("This service does not list its models. Type the model's name.")
        complete(entry, "Reply with OK.", max_tokens=5)
        return []


def pick_default(provider: str, models: list) -> str:
    p = PROVIDERS.get(provider, {})
    best, best_score = "", None
    for i, mid in enumerate(models):
        low = mid.lower()
        for rank, want in enumerate(p.get("prefer", [])):
            if want in low:
                small = any(s in low for s in _SMALL)
                tie = i if p.get("order") == "api" else (len(mid), i)
                score = (rank, small, tie)
                if best_score is None or score < best_score:
                    best, best_score = mid, score
                break
    if best:
        return best
    # nothing preferred: the first one that is not a small variant
    return next((m for m in models if not any(x in m.lower() for x in _SMALL)),
                models[0] if models else "")


# ---------------------------------------------------------------------------
# asking
# ---------------------------------------------------------------------------
def _openai_tools(tools: list) -> list:
    return [{"type": "function", "function": {
        "name": t["name"], "description": t.get("description", ""),
        "parameters": t.get("input_schema") or {"type": "object", "properties": {}}}}
        for t in tools]


def _need_model(entry):
    if not entry.get("model"):
        raise CloudError(f"No model is chosen for {provider_name(entry)}. Choose one in Settings.")


def turn(entry, system: str, history: list, tools: list, run_tool, send=None,
         max_turns: int = 12) -> str:
    """One answer, with as many tool calls as it takes. history holds plain
    {"role", "content": str} turns; the tool traffic of this answer lives
    only in here, in the shape the service expects."""
    _need_model(entry)
    send = send or (lambda o: None)
    msgs = [{"role": m["role"], "content": m["content"]} for m in history
            if m.get("role") in ("user", "assistant") and isinstance(m.get("content"), str)]
    if PROVIDERS[entry["provider"]]["kind"] == "anthropic":
        return _turn_anthropic(entry, system, msgs, tools, run_tool, send, max_turns)
    return _turn_openai(entry, system, msgs, tools, run_tool, send, max_turns)


# ---------------------------------------------------------------------------
# streaming (10 October, priority 3): the answer shows as it is written
# ---------------------------------------------------------------------------
class _Whole(Exception):
    """A streamed request answered in one piece: here it is."""
    def __init__(self, obj):
        super().__init__("whole")
        self.obj = obj


def _sse(entry, path: str, body: dict, timeout: int = TIMEOUT):
    """Server-sent events from one streamed request: each data line, parsed."""
    url = _base(entry) + path
    req = urllib.request.Request(url, data=json.dumps(dict(body, stream=True)).encode("utf-8"),
                                 method="POST", headers=_headers(entry))
    try:
        r = urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        raise CloudError(_explain(entry, e.code, e.read().decode("utf-8", "replace")), e.code)
    except Exception:
        raise CloudError(f"Could not reach {provider_name(entry)}. Is the internet on?")
    with r:
        if "json" in (r.headers.get("Content-Type") or "").lower():
            # A service that ignored "stream" and answered in one piece.
            try:
                raise _Whole(json.loads(r.read().decode("utf-8", "replace")))
            except ValueError:
                raise CloudError(f"{provider_name(entry)} sent an answer that is not JSON.")
        for raw in r:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                return
            try:
                yield json.loads(data)
            except ValueError:
                continue


def _stream_anthropic(entry, body, send) -> dict:
    """The Messages API, streamed; returns the same shape as a plain call."""
    blocks, stop = {}, None
    for ev in _sse(entry, "/messages", body):
        t = ev.get("type")
        if t == "error":
            raise CloudError(f"{provider_name(entry)}: " + str((ev.get("error") or {}).get("message", "error")))
        if t == "content_block_start":
            cb = dict(ev.get("content_block") or {})
            if cb.get("type") == "text":
                cb["text"] = cb.get("text", "")
            if cb.get("type") == "tool_use":
                cb["_json"] = ""
            blocks[ev.get("index", len(blocks))] = cb
        elif t == "content_block_delta":
            b = blocks.setdefault(ev.get("index", 0), {"type": "text", "text": ""})
            d = ev.get("delta") or {}
            if d.get("type") == "text_delta":
                b["text"] = b.get("text", "") + d.get("text", "")
                if d.get("text"):
                    send({"type": "delta", "text": d["text"]})
            elif d.get("type") == "input_json_delta":
                b["_json"] = b.get("_json", "") + d.get("partial_json", "")
        elif t == "message_delta":
            stop = (ev.get("delta") or {}).get("stop_reason") or stop
    content = []
    for i in sorted(blocks):
        b = blocks[i]
        if b.get("type") == "tool_use":
            raw = b.pop("_json", "") or ""
            try:
                b["input"] = json.loads(raw) if raw.strip() else (b.get("input") or {})
            except ValueError:
                b["input"] = {}
        if b.get("type") in ("text", "tool_use"):
            content.append(b)
    return {"content": content, "stop_reason": stop}


def _stream_openai(entry, body, send) -> dict:
    """/chat/completions, streamed; returns the same shape as a plain call."""
    text, calls = "", {}
    for ev in _sse(entry, "/chat/completions", body):
        if ev.get("error"):
            raise CloudError(f"{provider_name(entry)}: " + str(ev["error"].get("message", ev["error"])
                                                              if isinstance(ev["error"], dict) else ev["error"]))
        for ch in ev.get("choices") or []:
            d = ch.get("delta") or {}
            c = d.get("content")
            if isinstance(c, list):
                c = "".join(p.get("text", "") for p in c if isinstance(p, dict))
            if c:
                text += c
                send({"type": "delta", "text": c})
            for tc in d.get("tool_calls") or []:
                slot = calls.setdefault(tc.get("index", len(calls)),
                                        {"id": "", "type": "function", "function": {"name": "", "arguments": ""}})
                if tc.get("id"):
                    slot["id"] = tc["id"]
                fn = tc.get("function") or {}
                if fn.get("name"):
                    slot["function"]["name"] += fn["name"]
                if fn.get("arguments"):
                    slot["function"]["arguments"] += fn["arguments"]
    return {"choices": [{"message": {"content": text,
                                     "tool_calls": [calls[i] for i in sorted(calls)]}}]}


def _ask(entry, path: str, body: dict, send):
    """(response, streamed). Streams when it can; a service that refuses a
    streamed request (an error before any word arrived) is asked plainly."""
    words = []

    def track(obj):
        words.append(1)
        send(obj)
    try:
        if path == "/messages":
            return _stream_anthropic(entry, body, track), True
        return _stream_openai(entry, body, track), True
    except _Whole as w:
        return w.obj, False
    except CloudError as e:
        # Words already shown, a refused key, a rate limit or no internet:
        # asking again without streaming would not help.
        if words or e.code in (0, 401, 403, 429):
            raise
    return _request(entry, "POST", path, body), False


def _turn_anthropic(entry, system, msgs, tools, run_tool, send, max_turns):
    for _ in range(max_turns):
        body = {"model": entry["model"], "max_tokens": 4096, "system": system,
                "messages": msgs}
        if tools:
            body["tools"] = tools
        r, streamed = _ask(entry, "/messages", body, send)
        blocks = r.get("content") or []
        text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
        if r.get("stop_reason") != "tool_use":
            return text
        if text and not streamed:
            send({"type": "delta", "text": text})
        msgs.append({"role": "assistant", "content": blocks})
        results = []
        for b in blocks:
            if b.get("type") == "tool_use":
                out = run_tool(b.get("name", ""), b.get("input") or {})
                results.append({"type": "tool_result", "tool_use_id": b.get("id"),
                                "content": str(out)})
        msgs.append({"role": "user", "content": results})
    return "Hit the step limit — try describing the task more simply."


def _turn_openai(entry, system, msgs, tools, run_tool, send, max_turns):
    conv = [{"role": "system", "content": system}] + msgs
    otools = _openai_tools(tools) if tools else None
    for _ in range(max_turns):
        body = {"model": entry["model"], "messages": conv}
        if otools:
            body["tools"] = otools
        r, streamed = _ask(entry, "/chat/completions", body, send)
        try:
            msg = r["choices"][0]["message"]
        except Exception:
            raise CloudError(f"{provider_name(entry)} sent an empty answer.")
        text = msg.get("content") or ""
        if isinstance(text, list):    # some services send parts
            text = "".join(p.get("text", "") for p in text if isinstance(p, dict))
        calls = msg.get("tool_calls") or []
        if not calls:
            return text
        if text and not streamed:
            send({"type": "delta", "text": text})
        # Only what every service accepts back: no reasoning fields.
        conv.append({"role": "assistant", "content": text, "tool_calls": calls})
        for c in calls:
            fn = c.get("function") or {}
            try:
                args = json.loads(fn.get("arguments") or "{}")
            except ValueError:
                args = {}
            out = run_tool(fn.get("name", ""), args if isinstance(args, dict) else {})
            conv.append({"role": "tool", "tool_call_id": c.get("id", ""),
                         "content": str(out)})
    return "Hit the step limit — try describing the task more simply."


def complete(entry, prompt: str, max_tokens: int = 500, system: str = "") -> str:
    """A plain question with a plain answer (memory review, key checks)."""
    _need_model(entry)
    if PROVIDERS[entry["provider"]]["kind"] == "anthropic":
        body = {"model": entry["model"], "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": prompt}]}
        if system:
            body["system"] = system
        r = _request(entry, "POST", "/messages", body)
        return "".join(b.get("text", "") for b in r.get("content") or []
                       if b.get("type") == "text")
    conv = ([{"role": "system", "content": system}] if system else []) + \
           [{"role": "user", "content": prompt}]
    r = _request(entry, "POST", "/chat/completions",
                 {"model": entry["model"], "messages": conv})
    try:
        return r["choices"][0]["message"].get("content") or ""
    except Exception:
        return ""


def describe_image(entry, data: bytes, mime: str, ask: str, system: str) -> str:
    """The picture goes to the cloud model too (Ehsan, 7 October). Returns
    'ERROR: …' like local.describe_image."""
    import base64
    b64 = base64.b64encode(data).decode("ascii")
    try:
        _need_model(entry)
        if PROVIDERS[entry["provider"]]["kind"] == "anthropic":
            r = _request(entry, "POST", "/messages", {
                "model": entry["model"], "max_tokens": 600, "system": system,
                "messages": [{"role": "user", "content": [
                    {"type": "image", "source": {"type": "base64",
                                                 "media_type": mime, "data": b64}},
                    {"type": "text", "text": ask}]}]})
            text = "".join(b.get("text", "") for b in r.get("content") or []
                           if b.get("type") == "text")
        else:
            r = _request(entry, "POST", "/chat/completions", {
                "model": entry["model"],
                "messages": [{"role": "system", "content": system},
                             {"role": "user", "content": [
                                 {"type": "text", "text": ask},
                                 {"type": "image_url",
                                  "image_url": {"url": f"data:{mime};base64,{b64}"}}]}]})
            text = r["choices"][0]["message"].get("content") or ""
    except CloudError as e:
        return (f"ERROR: {e} If this model cannot see pictures, choose one that "
                "can in Settings → Assistant → Cloud model.")
    except Exception:
        return "ERROR: the cloud model's answer was not in the expected shape"
    return text.strip() or "ERROR: the cloud model returned nothing"


# ---------------------------------------------------------------------------
# the panel
# ---------------------------------------------------------------------------
def status_json() -> dict:
    e = current()
    if not e:
        return {"text": "", "tooltip": "", "class": "off"}
    return {"text": "☁ " + provider_name(e).split(" ")[0],
            "tooltip": f"Cloud model on: {label(e)}.\nWhat you ask goes to "
                       f"{provider_name(e)}. Click to change.",
            "class": "on"}


if __name__ == "__main__":
    import sys
    if sys.argv[1:] == ["status"]:
        print(json.dumps(status_json(), ensure_ascii=False))
    else:
        print(__doc__.split("\n\n")[0])
