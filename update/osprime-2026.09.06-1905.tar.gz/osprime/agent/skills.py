"""Skill loading and matching.

A skill is one Markdown file with a JSON header. The header holds what the
system must search — trigger phrases, required tools, required packages,
source licences. The body holds four sections written for a reader:

    ## Do it            how the assistant performs it
    ## Teach it         how the user is taught to perform it
    ## Check            how to know it actually worked
    ## Common mistakes  what goes wrong, accumulated over time

Skills are retrieved per request rather than all loaded into the prompt.
Sixty-three skills in every system prompt would cost more tokens than the
conversation, and a 1.5B model reads a shorter prompt more reliably anyway.

Matching is keyword scoring over the trigger phrases, deliberately not a
model call: asking a small model to choose from sixty options is exactly the
kind of decision it gets wrong, and a wrong choice here is invisible.
"""

import json
import os
import pathlib
import re
import shutil

SKILL_DIR = pathlib.Path(os.environ.get(
    "OSPRIME_SKILLS",
    str(pathlib.Path(__file__).resolve().parent.parent / "skills")))

_SECTION = re.compile(r"^##\s+(.+?)\s*$", re.M)
_HEADER = re.compile(r"^---json\s*\n(.*?)\n---\s*\n", re.S)

# Phrasing that asks to be taught rather than served. The user's own words
# choose the mode; presenting a menu before doing anything is itself an
# interruption.
_TEACH = ("how do i", "how can i", "how to", "teach me", "show me how",
          "walk me through", "i want to learn", "learn how", "explain how",
          "step by step")
_WATCH = ("show me", "demonstrate", "watch")

_CACHE = {"mtime": None, "skills": []}


def _parse(path: pathlib.Path):
    try:
        raw = path.read_text(encoding="utf-8")
    except Exception:
        return None
    m = _HEADER.match(raw)
    if not m:
        return None
    try:
        meta = json.loads(m.group(1))
    except json.JSONDecodeError:
        return None

    body = raw[m.end():]
    sections, bounds = {}, [(mm.group(1).lower(), mm.start(), mm.end())
                            for mm in _SECTION.finditer(body)]
    for i, (title, _s, e) in enumerate(bounds):
        end = bounds[i + 1][1] if i + 1 < len(bounds) else len(body)
        sections[title] = body[e:end].strip()

    meta["sections"] = sections
    meta.setdefault("triggers", [])
    meta.setdefault("packages", [])
    meta.setdefault("tools", [])
    meta.setdefault("type", "shared")
    return meta


def load(refresh: bool = False) -> list:
    """Read the skill directory, caching until a file changes."""
    if not SKILL_DIR.is_dir():
        return []
    try:
        stamp = max((p.stat().st_mtime for p in SKILL_DIR.glob("*.md")),
                    default=0)
    except Exception:
        stamp = 0
    if not refresh and _CACHE["mtime"] == stamp:
        return _CACHE["skills"]
    skills = [s for s in (_parse(p) for p in sorted(SKILL_DIR.glob("*.md"))) if s]
    _CACHE.update(mtime=stamp, skills=skills)
    return skills


# Common words carry no signal and inflate every score. Without this,
# "what is the capital of France" matched the clock skill: it shares "the"
# and "is" with the trigger "the time is off", which was half the phrase.
_STOP = {
    "a", "an", "and", "are", "as", "at", "be", "by", "can", "do", "does",
    "for", "from", "has", "have", "how", "i", "in", "is", "it", "its", "me",
    "my", "of", "on", "or", "please", "so", "that", "the", "then", "there",
    "this", "to", "up", "want", "was", "what", "when", "where", "with",
    "would", "you", "your",
}


def _words(text: str) -> set:
    return set(re.findall(r"[a-z0-9]+", (text or "").lower()))


def _content(text: str) -> set:
    return _words(text) - _STOP


def match(message: str, minimum: float = 0.5):
    """Best matching skill for this message, or None.

    Scores each trigger phrase by how much of it appears in the message. A
    two-word trigger that fully matches beats a six-word trigger that half
    matches, which keeps short specific phrases like "compress a pdf" from
    being drowned out.
    """
    msg = _content(message)
    if not msg:
        return None
    best, best_score = None, 0.0
    for skill in load():
        for trigger in skill.get("triggers", []):
            tw = _content(trigger)
            if not tw:
                continue
            overlap = tw & msg
            # At least one real word in common, not just a high ratio from a
            # short trigger.
            if not overlap:
                continue
            score = len(overlap) / len(tw)
            if score > best_score:
                best, best_score = skill, score
    return best if best_score >= minimum else None


def detect_mode(message: str) -> str:
    """'teach', 'watch' or 'do' — taken from how the user phrased it."""
    low = (message or "").lower()
    if any(p in low for p in _TEACH):
        return "teach"
    if any(p in low for p in _WATCH):
        return "watch"
    return "do"


def missing_packages(skill: dict) -> list:
    """Packages the skill needs that are not present."""
    missing = []
    for pkg in skill.get("packages", []):
        # A package name is usually its command; where it is not, the skill
        # can name the command explicitly as "package:command".
        cmd = pkg.split(":")[-1]
        if not shutil.which(cmd):
            missing.append(pkg.split(":")[0])
    return missing


def render(skill: dict, mode: str = "do") -> str:
    """The guidance to put in front of the model for this request."""
    if not skill:
        return ""
    s = skill.get("sections", {})
    parts = [f"SKILL: {skill.get('title', skill.get('name', ''))}"]

    if mode == "teach" and s.get("teach it"):
        parts.append("The user asked to be taught, not served. Follow this, "
                     "one step at a time, and wait for them between steps.")
        parts.append(s["teach it"])
    else:
        if s.get("do it"):
            parts.append(s["do it"])
        if mode == "watch" and s.get("teach it"):
            parts.append("Explain each step as you perform it.")

    if s.get("check"):
        parts.append("VERIFY BEFORE REPORTING SUCCESS:\n" + s["check"])
    if s.get("common mistakes"):
        parts.append("AVOID:\n" + s["common mistakes"])

    gone = missing_packages(skill)
    if gone:
        # Some skills need something an update cannot deliver — a model too
        # large to ship, for instance. Telling the user to "install an
        # update" when the real remedy is one specific command sends them
        # somewhere that will not help.
        setup = skill.get("setup")
        remedy = (f"Tell the user to run this once in a terminal, exactly as "
                  f"written, and then ask again:\n    {setup}"
                  if setup else
                  "Tell the user this needs an update before it can run.")
        parts.append("NOT INSTALLED: " + ", ".join(gone) + ". " + remedy +
                     "\nDo not attempt the steps, and do not substitute a "
                     "different method that gives a worse result.")
    return "\n\n".join(parts)


def for_message(message: str) -> str:
    """One call for the agent: matched skill guidance, or empty."""
    skill = match(message)
    if not skill:
        return ""
    return render(skill, detect_mode(message))
