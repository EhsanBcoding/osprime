---json
{
  "name": "find-a-lost-file",
  "title": "Find a file when you cannot remember where you put it",
  "type": "shared",
  "teachable": true,
  "triggers": [
    "i lost a file", "cannot find my file", "where did i save",
    "find the file called", "i saved it yesterday", "search for a file",
    "where is my document", "i downloaded something", "find my photo",
    "which folder did i put", "i cannot remember where"
  ],
  "tools": ["search_files", "list_files", "open_file"],
  "packages": ["findutils:find"],
  "sources": []
}
---

## Do it

Use `search_files`. It looks through everything of theirs at once, which is
the difference between answering this and guessing at folders one at a time.

1. Get one of two things from the user: **part of the name**, or **roughly
   when** they saved it. Either is enough on its own. Both together is best.
2. Call `search_files`. A fragment is better than a full name — someone who
   remembers "the invoice" should be searched for as `invoice`, not
   `invoice.pdf`, because the extension is often not what they think.
3. If nothing comes back, widen before you give up:
   - try a shorter fragment
   - try `days` alone, with no name, to list everything recent
   - ask whether it might be on a USB stick, and use `list_drives` if so
4. When there are a few results, show name, folder and date modified. The
   date is usually what lets them recognise it.
5. Offer to open it with `open_file`. Finding it is not the goal; getting
   back to work is.

Never say a file does not exist because one search missed it. Say what you
searched for and offer a wider search.

## Teach it

1. The reason files get lost is almost always the same: they were saved
   wherever the program last saved something, usually **Downloads**.
2. Ask OSprime "find a file called <part of the name>" — a fragment is
   enough, and it searches everywhere at once.
3. If the name is gone entirely, ask "what did I save in the last 2 days".
   Recognising a file by its date is easier than remembering its name.
4. To stop it happening again: when saving, look at the folder name in the
   save window before clicking Save. That one glance is the whole fix.

## Check

Report only files `search_files` actually returned, with their real paths.
If the count was zero, say zero — do not offer a plausible filename as
though it had been found.

Before saying something does not exist, search at least twice: once by name
and once by date.

## Common mistakes

- Listing one folder at a time instead of searching.
- Searching for the full filename with an extension the user guessed at.
- Reporting "not found" after a single narrow search.
- Inventing a path that looks right. A wrong path that looks right costs
  more time than no answer.
- Forgetting Downloads, which is where most lost files actually are.
- Ignoring an attached USB stick.
