#!/usr/bin/env bash
# Move the model onto the graphics chip.
#
#   sudo bash /opt/osprime/shell/setup-gpu.sh
#   sudo bash /opt/osprime/shell/setup-gpu.sh --undo
#
# The shipped llama-cpp is a plain CPU build, on purpose: it runs on any
# machine that boots the ISO, including ones with no usable graphics at all.
# But reading a long prompt is the part that keeps people waiting, and it is
# exactly the part a GPU is good at — even an integrated one, which is what
# most laptops have.
#
# This swaps in the Vulkan build and tells it to put the model's layers on
# the GPU. It is measured, not assumed: the prompt-reading speed is timed
# before and after, and if the GPU is not faster the whole thing is put back.
# A change that cannot be shown to help is not an improvement.
set -u

MODEL_ENV=/etc/osprime/model.env
PORT="${MODEL_PORT:-8087}"
LOG=/tmp/osprime-gpu-setup.log

[ "$EUID" -eq 0 ] || { echo "Run this with sudo."; exit 1; }

# --------------------------------------------------------------------------

undo() {
    echo "> putting the CPU build back"
    sed -i '/^OSPRIME_GPU_LAYERS=/d' "$MODEL_ENV" 2>/dev/null
    pacman -S --noconfirm llama-cpp >>"$LOG" 2>&1 || {
        echo "Could not reinstall llama-cpp. Do it by hand:"
        echo "    sudo pacman -S llama-cpp"; exit 1; }
    systemctl restart osprime-model
    echo "Back on the CPU build."
    exit 0
}
[ "${1:-}" = "--undo" ] && undo

# --------------------------------------------------------------------------
# how fast is it now?
# --------------------------------------------------------------------------

# Reading a long prompt is what we are trying to speed up, so that is what
# gets timed — not generation, which a shared-memory GPU barely changes.
measure() {
    local filler
    filler="$(head -c 6000 /dev/urandom | base64 | tr -d '\n' | head -c 6000)"
    local start end
    start="$(date +%s%N)"
    curl -fsS --max-time 300 -X POST \
        "http://127.0.0.1:$PORT/v1/chat/completions" \
        -H 'Content-Type: application/json' \
        -d "{\"messages\":[{\"role\":\"user\",\"content\":\"Reply with OK only. Ignore this: $filler\"}],\"max_tokens\":4}" \
        >/dev/null 2>&1 || { echo "0"; return; }
    end="$(date +%s%N)"
    echo $(( (end - start) / 1000000 ))
}

wait_up() {
    for _ in $(seq 1 120); do
        sleep 1
        curl -fsS --max-time 5 "http://127.0.0.1:$PORT/v1/models" >/dev/null 2>&1 \
            && return 0
    done
    return 1
}

echo "> timing the current setup"
wait_up || { echo "The engine is not answering. Fix that first:"; \
             echo "    systemctl status osprime-model"; exit 1; }
BEFORE="$(measure)"
[ "$BEFORE" -gt 0 ] || { echo "Could not time it — nothing changed."; exit 1; }
echo "  reading a long prompt takes ${BEFORE} ms on the CPU"

# --------------------------------------------------------------------------
# install
# --------------------------------------------------------------------------

echo "> installing the graphics driver and the Vulkan build"
# The driver is per-vendor; installing all three is a few megabytes and
# removes a question nobody should have to answer about their own laptop.
pacman -Sy --noconfirm --needed vulkan-tools vulkan-intel vulkan-radeon \
    mesa >>"$LOG" 2>&1 || {
    echo "Could not install the graphics drivers. Nothing was changed."
    tail -5 "$LOG"; exit 1; }

vulkaninfo --summary >>"$LOG" 2>&1 || {
    echo "Vulkan still reports no usable device on this machine."
    echo "Nothing was changed; the CPU build is untouched."; exit 1; }
echo "  graphics: $(vulkaninfo --summary 2>/dev/null | grep -m1 deviceName | cut -d= -f2-)"

# llama-cpp and llama-cpp-vulkan provide the same binary, so pacman replaces
# one with the other rather than installing both.
pacman -S --noconfirm llama-cpp-vulkan >>"$LOG" 2>&1 || {
    echo "Could not install llama-cpp-vulkan. Putting the CPU build back."
    pacman -S --noconfirm llama-cpp >>"$LOG" 2>&1
    tail -5 "$LOG"; exit 1; }

# 99 means "all of them". The launch script passes this through, and the
# ladder in it means a driver that cannot cope falls back rather than
# leaving the machine without an assistant.
touch "$MODEL_ENV"
sed -i '/^OSPRIME_GPU_LAYERS=/d' "$MODEL_ENV"
echo 'OSPRIME_GPU_LAYERS="99"' >> "$MODEL_ENV"

systemctl restart osprime-model
echo "> timing it again on the GPU"
wait_up || {
    echo "The engine did not come back. Putting everything as it was."
    undo; }

AFTER="$(measure)"
if [ "$AFTER" -le 0 ]; then
    echo "Could not time it on the GPU. Putting everything as it was."
    undo
fi
echo "  reading the same prompt takes ${AFTER} ms on the GPU"

# --------------------------------------------------------------------------
# keep it only if it earned its place
# --------------------------------------------------------------------------

if [ "$AFTER" -lt "$BEFORE" ]; then
    SAVED=$(( (BEFORE - AFTER) * 100 / BEFORE ))
    echo
    echo "Keeping the GPU build: ${SAVED}% faster at reading a prompt"
    echo "(${BEFORE} ms -> ${AFTER} ms)."
    echo "To undo this at any time:  sudo bash $0 --undo"
else
    echo
    echo "The GPU was not faster (${BEFORE} ms -> ${AFTER} ms), so it is not"
    echo "worth the extra moving parts. Putting the CPU build back."
    undo
fi
