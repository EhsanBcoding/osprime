"""Choose the local model from what the machine can actually run.

Every OSprime so far has shipped the same 1.5B model to every computer,
because the ISO has to boot on anything. That is the right thing for a
bootstrap and the wrong thing forever: on a laptop with 16 GB of RAM it
leaves most of the machine unused, and the difference between a 1.5B and a
3B was the difference between "described the tool instead of calling it"
and "just did it".

The rule that decides the tier is deliberately not "how much RAM is there".
It is "how fast will the answer come back", and on a CPU that is bounded by
memory bandwidth, not capacity. A 7B model fits in 16 GB comfortably and
still produces about three words a second on an eighth-generation laptop
chip, which is not a computer you can talk to. So without a GPU the ladder
stops at 3B however much memory is installed.

Nothing here downloads anything on its own. It reports what it would
choose; installing is a separate, explicit act.
"""

import glob
import json
import os
import pathlib
import re
import shutil
import subprocess

MODELS_DIR = pathlib.Path(os.environ.get("OSPRIME_MODELS",
                                         "/var/lib/osprime/models"))
MODEL_ENV = pathlib.Path(os.environ.get("OSPRIME_MODEL_ENV",
                                        "/etc/osprime/model.env"))

HF = "https://huggingface.co/Qwen"

# Verified against the Hugging Face API rather than assumed. The 7B q4_k_m
# is published as two shards — llama.cpp loads the rest of a split GGUF
# automatically when handed the first one, but both have to be downloaded,
# and a single-file URL guessed from the pattern would have 404'd.
TIERS = {
    "tiny": {
        "label": "Qwen2.5 0.5B",
        "repo": "Qwen2.5-0.5B-Instruct-GGUF",
        "files": ["qwen2.5-0.5b-instruct-q4_k_m.gguf"],
        "disk_mb": 500, "ram_gb": 2, "ctx": 8192,
        "note": "the smallest thing that still follows instructions",
    },
    "small": {
        "label": "Qwen2.5 1.5B",
        "repo": "Qwen2.5-1.5B-Instruct-GGUF",
        "files": ["qwen2.5-1.5b-instruct-q4_k_m.gguf"],
        "disk_mb": 1200, "ram_gb": 4, "ctx": 16384,
        "note": "what the installer ships; runs anywhere",
    },
    "medium": {
        "label": "Qwen2.5 3B",
        "repo": "Qwen2.5-3B-Instruct-GGUF",
        "files": ["qwen2.5-3b-instruct-q4_k_m.gguf"],
        "disk_mb": 2200, "ram_gb": 8, "ctx": 16384,
        "note": "the first size that reliably calls tools instead of "
                "describing them",
    },
    "large": {
        "label": "Qwen2.5 7B",
        "repo": "Qwen2.5-7B-Instruct-GGUF",
        "files": ["qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf",
                  "qwen2.5-7b-instruct-q4_k_m-00002-of-00002.gguf"],
        "disk_mb": 5200, "ram_gb": 16, "ctx": 16384,
        "note": "needs a GPU to be worth it; on a CPU it is too slow to "
                "talk to",
    },
}

ORDER = ["tiny", "small", "medium", "large"]


def _run(args, timeout=15):
    try:
        r = subprocess.run(args, capture_output=True, text=True,
                           timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception:
        return 1, ""


def _ram_gb() -> float:
    try:
        kb = int(re.search(r"MemTotal:\s+(\d+)",
                           pathlib.Path("/proc/meminfo").read_text()).group(1))
        return round(kb / 1024 / 1024, 1)
    except Exception:
        return 0.0


def _disk_free_mb(path=MODELS_DIR) -> int:
    """Free space on the filesystem the models live on.

    Walk up until something exists. On a fresh machine neither the models
    directory nor its parent has been created yet, and looking at only one
    level up reported zero free space — which then quietly downgraded the
    recommendation to the smallest model on a machine with a half-empty
    disk.
    """
    target = path
    for _ in range(6):
        if target.exists():
            try:
                st = os.statvfs(str(target))
                return int(st.f_bavail * st.f_frsize / 1024 / 1024)
            except Exception:
                return 0
        if target.parent == target:
            break
        target = target.parent
    return 0


def _gpu() -> dict:
    """Is there a GPU worth offloading to, and how much memory has it?

    Deliberately conservative. Claiming a GPU that turns out not to work
    means picking a model the machine then cannot run at a usable speed,
    and the symptom of that is a computer that takes a minute to answer —
    which reads as broken rather than as a wrong setting.
    """
    out = {"present": False, "kind": "", "vram_gb": 0.0, "why": "",
           # "present" means hardware exists. "useful" means offloading to it
           # is worth doing — an old integrated chip is present and useless,
           # and a card whose driver is missing is present and not yet usable.
           "useful": False, "vendor": "", "driver_missing": False}

    # NVIDIA reports its own memory precisely; take it when offered.
    if shutil.which("nvidia-smi"):
        code, text = _run(["nvidia-smi",
                           "--query-gpu=memory.total,name",
                           "--format=csv,noheader,nounits"])
        if code == 0 and text.strip():
            first = text.strip().splitlines()[0].split(",")
            try:
                out.update(present=True, useful=True,
                           kind=f"NVIDIA {first[1].strip()}",
                           vram_gb=round(int(first[0]) / 1024, 1),
                           why="reported by nvidia-smi")
                return out
            except Exception:
                pass

    if shutil.which("vulkaninfo"):
        # vulkaninfo segfaults on a hybrid laptop whose discrete card has no
        # driver. A crash is not an answer, so a non-zero return falls
        # through to the PCI bus rather than being read as "no GPU".
        code, text = _run(["vulkaninfo", "--summary"], timeout=25)
        if code == 0 and "deviceName" in text:
            m = re.search(r"deviceName\s*=\s*(.+)", text)
            name = m.group(1).strip() if m else "Vulkan device"
            discrete = "DISCRETE_GPU" in text
            out.update(present=True, kind=name)
            if discrete:
                m = re.search(r"deviceLocalMemory\D+(\d+)\s*MB", text)
                if m:
                    out["vram_gb"] = round(int(m.group(1)) / 1024, 1)
                out["why"] = "a discrete GPU with its own memory"
                out["useful"] = True
            else:
                # An earlier version dismissed every integrated GPU as
                # "shares system memory and gains nothing". That was true of
                # the Intel UHD chips it was written for and is wrong about
                # what came after: Arc and RDNA integrated graphics have real
                # compute units and read the same memory the CPU does, which
                # is exactly what reading a long prompt needs.
                out["why"] = ("integrated graphics; useful for this if it is "
                              "a recent Arc or RDNA part")
                out["useful"] = bool(re.search(
                    r"\bArc\b|Radeon (?:78|76|74|89)\d\M|RDNA|Iris Xe",
                    name, re.I))
            return out

    # Last and most reliable: ask the PCI bus. Everything above needs
    # software that comes WITH a driver, so a machine whose driver is not
    # installed was reported as having no GPU — which is exactly backwards,
    # because that machine is the one that needs telling. A laptop with an
    # RTX card was told it had no graphics hardware at all.
    pci = _pci_gpus()
    if pci:
        best = pci[0]
        out.update(present=True, kind=best["name"], vendor=best["vendor"])
        out["why"] = (f"found on the PCI bus, but its driver is not "
                      f"installed, so it cannot be used yet")
        out["driver_missing"] = True
        return out

    out["why"] = "no graphics hardware found"
    return out


_PCI_VENDORS = {"0x10de": "NVIDIA", "0x1002": "AMD", "0x8086": "Intel"}


def _pci_gpus() -> list:
    """Graphics hardware, straight from the bus. Needs no driver at all."""
    found = []
    for d in sorted(glob.glob("/sys/bus/pci/devices/*")):
        try:
            cls = pathlib.Path(d, "class").read_text().strip()
            if not (cls.startswith("0x0300") or cls.startswith("0x0302")):
                continue
            vend = pathlib.Path(d, "vendor").read_text().strip()
        except Exception:
            continue
        name = _PCI_VENDORS.get(vend, vend)
        found.append({"vendor": name, "name": name + " graphics",
                      "discrete": cls.startswith("0x0300") and vend != "0x8086"})
    # lspci knows the model names; use them when pciutils is installed.
    if found and shutil.which("lspci"):
        code, text = _run(["lspci", "-mm"])
        if code == 0:
            for line in text.splitlines():
                if '"VGA compatible controller"' in line or '"3D controller"' in line:
                    parts = re.findall(r'"([^"]*)"', line)
                    if len(parts) >= 3:
                        for f in found:
                            if f["vendor"].lower() in parts[1].lower():
                                f["name"] = f"{parts[1].split()[0]} {parts[2]}"
    # A discrete card first: it is the one worth doing anything about.
    found.sort(key=lambda f: not f["discrete"])
    return found


def profile() -> dict:
    cores = os.cpu_count() or 1
    ram = _ram_gb()
    gpu = _gpu()
    try:
        cpu = re.search(r"model name\s*:\s*(.+)",
                        pathlib.Path("/proc/cpuinfo").read_text()).group(1)
    except Exception:
        cpu = "unknown"
    return {
        "cpu": cpu.strip(), "cores": cores, "ram_gb": ram,
        "disk_free_mb": _disk_free_mb(), "gpu": gpu,
    }


def recommend(p: dict = None) -> dict:
    """Which tier this machine should run, and the reasoning, in words."""
    p = p or profile()
    ram, cores, gpu = p["ram_gb"], p["cores"], p["gpu"]
    reasons = []

    if ram >= 16:
        tier = "medium"
        reasons.append(f"{ram} GB of memory is plenty")
    elif ram >= 8:
        tier = "medium"
        reasons.append(f"{ram} GB of memory fits a 3B model")
    elif ram >= 4:
        tier = "small"
        reasons.append(f"{ram} GB of memory is enough for 1.5B, not more")
    else:
        tier = "tiny"
        reasons.append(f"only {ram} GB of memory")

    # What decides whether 7B is reachable is the card's own memory, not the
    # machine's. An earlier version required 16 GB of system RAM as well,
    # which ruled out a laptop with 15 GB and an 8 GB RTX card — a machine
    # that can run 7B comfortably, because on a GPU the model lives in VRAM.
    if gpu.get("useful") and gpu["vram_gb"] >= 6 and ram >= 8:
        tier = "large"
        reasons.append(f"a {gpu['kind']} with {gpu['vram_gb']} GB can carry 7B")
    elif gpu.get("useful") and gpu["vram_gb"]:
        reasons.append(
            f"the {gpu['kind']} has {gpu['vram_gb']} GB, not enough for 7B, "
            "so 3B stays the larger useful size")
    elif gpu.get("useful"):
        reasons.append(
            f"the {gpu['kind']} shares system memory, so it speeds this up "
            "without making a bigger model affordable")
    elif gpu.get("driver_missing"):
        reasons.append(
            f"there is a {gpu['kind']} here but its driver is not installed, "
            "so nothing can use it yet — setup-gpu.sh fixes that, and a "
            "larger model may become worth it afterwards")
    elif ram >= 16:
        reasons.append("but with no GPU, 7B would answer at about three "
                       "words a second, so 3B is the larger useful size")

    if cores <= 2 and tier != "tiny":
        tier = ORDER[max(0, ORDER.index(tier) - 1)]
        reasons.append(f"stepped down one size: {cores} cores is not enough "
                       "to keep a larger model responsive")

    need = TIERS[tier]["disk_mb"]
    if p["disk_free_mb"] and p["disk_free_mb"] < need + 1000:
        while tier != "tiny" and p["disk_free_mb"] < TIERS[tier]["disk_mb"] + 1000:
            tier = ORDER[ORDER.index(tier) - 1]
        reasons.append(f"limited by free disk space "
                       f"({p['disk_free_mb']} MB available)")

    spec = dict(TIERS[tier])
    spec["tier"] = tier
    spec["why"] = "; ".join(reasons)
    spec["urls"] = [f"{HF}/{spec['repo']}/resolve/main/{f}"
                    for f in spec["files"]]
    return spec


def installed() -> dict:
    """What is on this machine now, according to the environment file."""
    current = {}
    try:
        for line in MODEL_ENV.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            current[k.strip()] = v.strip().strip('"')
    except Exception:
        pass
    path = pathlib.Path(current.get("MODEL_PATH",
                                    str(MODELS_DIR / "bootstrap.gguf")))
    size = path.stat().st_size if path.is_file() else 0
    return {
        "path": str(path),
        "exists": path.is_file(),
        "size_mb": round(size / 1024 / 1024) if size else 0,
        "tier": current.get("OSPRIME_MODEL_TIER", "unknown"),
        "label": current.get("OSPRIME_MODEL_LABEL", ""),
        "context": current.get("MODEL_CTX", "4096"),
    }


def report() -> dict:
    p = profile()
    return {"machine": p, "running_now": installed(), "recommended": recommend(p)}


def write_env(tier: str, model_path: str) -> str:
    """Point the engine at a model. Written only after it has been proved
    to load — see osprime-profile.sh."""
    spec = TIERS.get(tier)
    if not spec:
        return f"ERROR: unknown tier {tier}"
    try:
        MODEL_ENV.parent.mkdir(parents=True, exist_ok=True)
        MODEL_ENV.write_text(
            "# Written by the OSprime hardware profiler.\n"
            "# Read by osprime-model.service, after its built-in defaults,\n"
            "# so anything set here wins. Delete this file to go back to\n"
            "# the model the system was installed with.\n"
            f'MODEL_PATH="{model_path}"\n'
            f'MODEL_CTX="{spec["ctx"]}"\n'
            f'OSPRIME_MODEL_TIER="{tier}"\n'
            f'OSPRIME_MODEL_LABEL="{spec["label"]}"\n',
            encoding="utf-8")
    except PermissionError:
        return "ERROR: this needs root — run the profiler with sudo."
    except Exception as e:
        return f"ERROR: could not write {MODEL_ENV}: {e}"
    return f"{MODEL_ENV} now points at {spec['label']}"


if __name__ == "__main__":
    print(json.dumps(report(), indent=2))
