"""Brainy does it for you, in the background (docs/ACT.md; Ehsan, 13 October).

Asked "do it for me: …", the assistant first uses its own tools (the
direct way, no screen at all). When the job lives in an app's window, it
hands the goal here, and this works in that window through accessibility
(act_probe.py): pressing and filling in, with no mouse and no keyboard —
the person goes on working in their own window at the same time.

  * One approval for the whole task; anything irreversible (send, delete,
    pay, install, shut down…) is asked about on its own (Ehsan).
  * Never a password field, a terminal, or a window that asks for a
    password (act_logic.validate / act_probe.window_ok).
  * Super+Escape, or Stop in the panel, stops it at once.
  * At most 15 steps; each step is one model call with words only.
"""
import os
import threading
import time

from gi.repository import GLib

import act_logic as al
import act_probe as ap


class ActSession:
    def __init__(self, companion, bubble):
        self.c = companion
        self.b = bubble
        self.active = False
        self.goal = ""
        self.history = []
        self.win = None              # the window being worked in (title, app)
        self.on_desk = False         # Brainy opened something on its own desk (desk.py)
        self.screen = None           # screen_turns.Screen while taking turns (step 4)
        self.target = None           # (handle, app, title) of the window worked in, in turns
        self.pending = None
        self._reply = None
        self._reply_ev = threading.Event()
        self._answer = None
        self._answer_ev = threading.Event()
        self._stop = threading.Event()

    # ---- control (GTK thread) ----------------------------------------------
    def start(self, goal: str):
        self.stop(quiet=True)
        self.goal = " ".join((goal or "").split())[:300]
        if not self.goal:
            return
        self.history, self.win, self.on_desk = [], None, False
        self._stop.clear()
        self.b.guide_card(
            f"Brainy will do this for you, in the background: “{self.goal}”.\n"
            "It presses and fills in through the app itself — your mouse and keyboard stay "
            "yours. Up to 15 steps; anything that cannot be undone is asked first. "
            "Super+Esc stops it.",
            [("Do it", self._go), ("Cancel", lambda: self.stop(quiet=True))])

    def _go(self):
        self.active = True
        self.c.set_local_state("reading")
        threading.Thread(target=self._run, daemon=True, name="act").start()

    def stop(self, quiet=False):
        was = self.active
        self.active = False
        scr, self.screen = self.screen, None
        if scr:
            scr.close()
        self._stop.set()
        self._answer_ev.set()
        self._reply_ev.set()
        try:
            self.c.set_local_state(None)
        except Exception:
            pass
        if was and not quiet:
            GLib.idle_add(lambda: self.b.guide_card("Stopped. Nothing more will be pressed.", [], final=True)
                          and False)

    # ---- the work (its own thread) ---------------------------------------------
    def _ui(self, text, buttons=(), final=False):
        GLib.idle_add(lambda: self.b.guide_card(text, list(buttons), final=final) and False)

    def _ask_person(self, text) -> bool:
        """An irreversible step: asked on its own, the task waits."""
        self._answer, self._answer_ev = None, threading.Event()

        def yes():
            self._answer = True
            self._answer_ev.set()

        def no():
            self._answer = False
            self._answer_ev.set()
        self._ui(text, [("Yes, do it", yes), ("Skip", no), ("Stop", self.stop)])
        self._answer_ev.wait(600)
        return bool(self._answer) and not self._stop.is_set()

    def ask(self, prompt, image=None) -> str:
        """Words only on the person's screen; with a picture of Brainy's own
        desk when it works there (that picture shows exactly its window)."""
        self._reply_ev.clear()
        self._reply = None
        self.pending = f"a{time.time():.3f}"
        msg = {"type": "guide_step", "id": self.pending, "prompt": prompt, "system": al.SYSTEM}
        if image:
            msg["image"] = image
        else:
            msg["text_only"] = True
        try:
            self.b.guide_link().send(msg)
        except OSError:
            return "ERROR: the assistant is not running"
        if not self._reply_ev.wait(240):
            return "ERROR: no answer in four minutes"
        return self._reply or "ERROR: empty answer"

    def on_reply(self, msg):
        if msg.get("id") == self.pending:
            self._reply = str(msg.get("raw") or "")
            self._reply_ev.set()

    def _current(self, wins):
        """The window worked in, found again (windows come and go). After
        Brainy opened something on its desk: the desk's newest window."""
        if self.win:
            for w in wins:
                if w["app"] == self.win[1] and w["title"] == self.win[0]:
                    return w
            for w in wins:
                if w["app"] == self.win[1] or (self.win[1] and self.win[1].lower() in w["app"].lower()):
                    return w
        if self.on_desk:
            desk_wins = [w for w in wins if w.get("desk") and not w["ok"]]
            if desk_wins:
                self.win = (desk_wins[-1]["title"], desk_wins[-1]["app"])
                return desk_wins[-1]
        return None

    def watch(self):
        try:
            import companion_desk_view
            companion_desk_view.open_view()
        except Exception as e:
            self._ui(f"The desk cannot be shown: {e}", [("Stop", self.stop)])

    def _buttons(self):
        try:
            import desk
            if desk.running():
                return [("Watch", self.watch), ("Stop", self.stop)]
        except Exception:
            pass
        return [("Stop", self.stop)]

    def _desk_picture(self):
        try:
            import companion_point as cp
            import desk
            cp.sweep()
            path = str(cp.folder() / f"desk-{int(time.time() * 1000)}.png")
            return path if desk.screenshot(path) else None
        except Exception:
            return None

    # ---- step 4: turns on the person's own screen ------------------------------
    def _offer_turns(self, why) -> bool:
        """The card Brainy shows itself when steps 1-3 could not (Ehsan)."""
        self._answer, self._answer_ev = None, threading.Event()

        def yes():
            self._answer = True
            self._answer_ev.set()

        def no():
            self._answer = False
            self._answer_ev.set()
        reason = f" ({why})" if why and why != "stuck" else ""
        self._ui("I could not do this in the background" + reason + ".\n"
                 "May I use your own screen, in turns? I act only while your hands rest, "
                 "pause the moment you move, and never touch terminals or password windows. "
                 "Each step, a picture of your whole screen goes to the assistant's model "
                 "(the cloud one when the cloud switch is on). Super+Esc stops.",
                 [("Use my screen", yes), ("No", no)])
        self._answer_ev.wait(600)
        return bool(self._answer) and not self._stop.is_set()

    def _turn_windows(self):
        """The person's windows, numbered, with the same checks as step 2."""
        out = []
        for n, w in enumerate(self.screen.windows(), 1):
            out.append(dict(w, id=n, ok=ap.window_ok(w["app"], w["title"]), desk=False))
        return out

    def _turn_target(self, wins):
        if not self.target:
            return None
        h, app, title = self.target
        return (next((w for w in wins if w["handle"] == h), None) or
                next((w for w in wins if w["app"] == app and w["title"] == title), None) or
                next((w for w in wins if w["app"] == app), None))

    def _front_is(self, cur) -> bool:
        """The window worked in is in front — bringing it there if needed."""
        f = self.screen.front()
        if f and f["handle"] == cur["handle"]:
            return True
        return self.screen.activate(cur["handle"])

    def _run_turns(self, first, did):
        import screen_turns as st
        try:
            self.screen = st.Screen()
        except Exception as e:
            self._ui(f"Your screen cannot be used in turns: {e}. Nothing else was pressed.", final=True)
            return
        scr = self.screen
        self.history.append("(the user allowed turns: you now see their screen and click_at, keys, key "
                            "and scroll work there; pick the window with window first)")
        step = first
        try:
            while step <= al.MAX_STEPS:
                if self._stop.is_set() or scr.closed:
                    return
                if not scr.idle:
                    self._ui("Paused — I go on when your hands rest.", [("Stop", self.stop)])
                    if not scr.wait_idle(self._stop):
                        if not self._stop.is_set():
                            self._ui("You stayed busy, so I stopped. Nothing else was pressed.", final=True)
                        return
                wins = self._turn_windows()
                cur = self._turn_target(wins)
                if cur is None:
                    f = next((w for w in wins if w["active"] and not w["ok"]), None)
                    if f:
                        cur = f
                        self.target = (f["handle"], f["app"], f["title"])
                if cur and not cur["ok"] and not cur["active"]:
                    # Bring it forward before the picture (no input event: still idle).
                    if self._front_is(cur):
                        wins = self._turn_windows()
                        cur = self._turn_target(wins) or cur
                seen = scr.changes
                self._ui(f"Step {step}: looking at your screen…", [("Stop", self.stop)])
                import companion_point as cp
                cp.sweep()
                pic = str(cp.folder() / f"screen-{int(time.time() * 1000)}.png")
                size = st.screenshot(pic)
                if not size:
                    self._ui("I cannot take a picture of your screen. Nothing else was pressed.", final=True)
                    return
                prompt = al.build_request(
                    self.goal, self.history, ap.describe_windows(wins),
                    (f'{cur["app"]} — "{cur["title"]}" (on the user\'s screen, in turns)' if cur else ""),
                    "(not readable here — use the picture)")
                prompt += ("\nA picture of the user's whole screen is attached. click_at, keys, key and "
                           "scroll act on it, in the window you work in.")
                raw = self.ask(prompt, pic)
                try:
                    os.unlink(pic)
                except OSError:
                    pass
                if self._stop.is_set():
                    return
                if raw.startswith("ERROR:"):
                    self._ui("Turns need a model that can see pictures: " + raw[6:].strip() +
                             ". Nothing else was pressed.", final=True)
                    return
                r = al.validate(al.parse_reply(raw), [], wins, on_desk=True)
                if r["ok"] and r["do"] in ("open", "web", "press", "type", "turns"):
                    r = dict(r, ok=False, why="in turns, work in the user's window with click_at, keys, "
                                              "key or scroll")
                step += 1
                if not r["ok"]:
                    self.history.append(f"(refused: {r['why']})")
                    if all(h.startswith("(refused") for h in self.history[-3:]):
                        self._ui(f"I keep getting stuck ({r['why']}). Stopped; nothing else was pressed.",
                                 final=True)
                        return
                    continue
                say = r["say"] or r["do"]
                if r["do"] == "done":
                    self._ui("✓ " + (say or "Done.") + ("\n" + "\n".join("• " + d for d in did) if did else ""),
                             final=True)
                    return
                if r["do"] == "stuck":
                    self._ui("I could not do it: " + say + ". Nothing else was pressed.", final=True)
                    return
                if r["do"] == "window":
                    w = r["window"]
                    self.target = (w["handle"], w["app"], w["title"])
                    self.history.append(f"Working in {w['app']}")
                    continue
                if cur is None or cur["ok"]:
                    self.history.append("(choose the window to work in with window first)")
                    continue
                if r["irreversible"]:
                    if not self._ask_person(f"Step {step - 1}: {say}\nThis cannot be undone. Do it?"):
                        if self._stop.is_set():
                            return
                        self.history.append("(the user said no to that; do not do it)")
                        continue
                    # Answering moved their hands and focused the panel: wait, then go on.
                    if not scr.wait_idle(self._stop):
                        return
                    seen = scr.changes
                # The last checks, right before acting on their screen.
                if not scr.idle or scr.changes != seen:
                    self.history.append("(the user moved meanwhile; look again)")
                    continue
                if not self._front_is(cur):
                    self.history.append("(your window could not be brought to the front; look again)")
                    continue
                f = scr.front()
                if not f or f["handle"] != cur["handle"] or ap.window_ok(f["app"], f["title"]):
                    self.history.append("(another window is in front; look again)")
                    continue
                w, h = size
                if r["do"] == "click_at":
                    ok = st.click(r["x"] * w, r["y"] * h, w, h)
                elif r["do"] == "scroll":
                    ok = st.scroll(r["x"] * w, r["y"] * h, w, h, r["steps"])
                elif r["do"] == "keys":
                    ok = st.type_text(r["text"])
                else:
                    ok = st.key(r["key"])
                self.history.append(say if ok else f"(that did not work: {r['do']})")
                if ok:
                    did.append(say + " (on your screen)")
                    self._ui(f"Step {step - 1}: {say}", [("Stop", self.stop)])
                time.sleep(0.3)
            self._ui("That is a lot of steps — I stopped here.\n" + "\n".join("• " + d for d in did),
                     final=True)
        finally:
            self.screen = None
            scr.close()

    @staticmethod
    def _desk_input():
        try:
            import desk
            return desk.user_input
        except Exception:
            return 0

    def _wait_while_taken_over(self):
        """While the person has taken over the desk, Brainy does nothing there."""
        try:
            import companion_desk_view as dv
        except Exception:
            return
        told = False
        while dv.taken_over() and not self._stop.is_set():
            if not told:
                self._ui("You have the desk — I wait until you hand it back (Take over off).",
                         self._buttons())
                told = True
            time.sleep(0.5)

    def _run(self):
        did = []
        try:
            for step in range(1, al.MAX_STEPS + 1):
                if self._stop.is_set():
                    return
                self._ui(f"Step {step}: looking…", self._buttons())
                wins = ap.list_windows()
                cur = self._current(wins)
                ctrls = ap.controls(cur) if cur and not cur["ok"] else []
                here = bool(cur and cur.get("desk"))
                if here:
                    self._wait_while_taken_over()
                    if self._stop.is_set():
                        return
                seen_input = self._desk_input()
                picture = self._desk_picture() if here else None
                prompt = al.build_request(self.goal, self.history, ap.describe_windows(wins),
                                          (f'{cur["app"]} — "{cur["title"]}"' + (" (on your own desk)" if here else ""))
                                          if cur else "",
                                          ap.describe_controls(ctrls))
                if picture:
                    prompt += "\nA picture of your own desk is attached (its whole screen)."
                raw = self.ask(prompt, picture)
                if picture and raw.startswith("ERROR:"):
                    # Nothing that can see right now: carry on with the words.
                    raw = self.ask(prompt.replace("\nA picture of your own desk is attached (its whole screen).", ""))
                if picture:
                    try:
                        os.unlink(picture)
                    except OSError:
                        pass
                if self._stop.is_set():
                    return
                if raw.startswith("ERROR:"):
                    self._ui(f"I could not go on: {raw[6:].strip()}.", final=True)
                    return
                focused = next((c for c in ctrls if c.get("focused")), None)
                r = al.validate(al.parse_reply(raw), ctrls, wins, on_desk=here, focused=focused)
                if not r["ok"]:
                    # Told to the model as a step, so it can choose differently.
                    self.history.append(f"(refused: {r['why']})")
                    if len(self.history) >= 3 and all(h.startswith("(refused") for h in self.history[-3:]):
                        self._ui(f"I keep getting stuck ({r['why']}). Stopped; nothing else was pressed.",
                                 final=True)
                        return
                    continue
                say = r["say"] or r["do"]
                if r["do"] == "done":
                    self._ui("✓ " + (say or "Done.") + ("\n" + "\n".join("• " + d for d in did) if did else ""),
                             final=True)
                    return
                if r["do"] in ("stuck", "turns") and not here:
                    # Steps 1-3 could not: Brainy itself offers turns (Ehsan, 14 October).
                    if self._offer_turns(say if r["do"] == "stuck" else ""):
                        self._run_turns(step + 1, did)
                        return
                    if self._stop.is_set():
                        return
                    self._ui("Then I cannot do it. Nothing else was pressed.", final=True)
                    return
                if r["do"] in ("stuck", "turns"):
                    self._ui("I could not do it here: " + (say or "no way forward") +
                             ". Nothing else was pressed.", final=True)
                    return
                if r["do"] == "window":
                    self.win = (r["window"]["title"], r["window"]["app"])
                    self.history.append(f"Working in {r['window']['app']}")
                    continue
                if r["do"] in ("open", "web"):
                    # On Brainy's own desk: nothing appears on the person's screen.
                    try:
                        import desk
                        if r["do"] == "open":
                            desk.open_app(r["app"])
                        else:
                            desk.open_url(r["url"])
                    except Exception as e:
                        self.history.append(f"(could not open it: {e})")
                        continue
                    what = r["app"] or r["url"]
                    self.history.append(f"Opened {what} on your own desk")
                    did.append(f"opened {what} on Brainy's desk")
                    self.on_desk, self.win = True, ("", r["app"])
                    time.sleep(4)
                    continue
                if r["do"] in al.DESK_ONLY:
                    import desk
                    if self._desk_input() != seen_input:
                        # The person scrolled or clicked on the desk since the
                        # picture: the point may be wrong now. Look again.
                        self.history.append("(the user moved the page on your desk; look again)")
                        continue
                    if r["irreversible"] and not self._ask_person(
                            f"Step {step}: {say}\nThis cannot be undone. Do it?"):
                        if self._stop.is_set():
                            return
                        self.history.append("(the user said no to that; do not do it)")
                        continue
                    if r["do"] == "click_at":
                        ok = desk.click(r["x"] * desk.WIDTH, r["y"] * desk.HEIGHT)
                    elif r["do"] == "scroll":
                        ok = desk.scroll(r["x"] * desk.WIDTH, r["y"] * desk.HEIGHT, r["steps"])
                    elif r["do"] == "keys":
                        ok = desk.type_text(r["text"])
                    else:
                        ok = desk.key(r["key"])
                    self.history.append((say or r["do"]) if ok else f"(that did not work: {r['do']})")
                    if ok:
                        did.append(say or r["do"])
                        self._ui(f"Step {step}: {say}", self._buttons())
                    time.sleep(0.8)
                    continue
                c = r["ctrl"]
                if r["irreversible"] and not self._ask_person(
                        f"Step {step}: {say}\n“{c['name']}” cannot be undone. Do it?"):
                    if self._stop.is_set():
                        return
                    self.history.append(f"(the user said no to pressing {c['name']!r}; do not press it)")
                    continue
                ok = ap.do_type(c, r["text"]) if r["do"] == "type" else ap.do_press(c)
                what = (f"typed into “{c['name']}”" if r["do"] == "type"
                        else f"pressed “{c['name']}”")
                if ok:
                    self.history.append(say or what)
                    did.append(what)
                    self._ui(f"Step {step}: {say}", self._buttons())
                else:
                    self.history.append(f"(that did not work: {what})")
                time.sleep(0.6)
            self._ui("That is a lot of steps — I stopped here.\n" + "\n".join("• " + d for d in did),
                     final=True)
        finally:
            self.active = False
            GLib.idle_add(lambda: self.c.set_local_state(None) and False)
