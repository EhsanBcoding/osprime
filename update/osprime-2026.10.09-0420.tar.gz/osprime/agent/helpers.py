"""Helpers: specialist assistants, each a small coloured Brainy
(docs/HELPERS.md; Ehsan, 9 October).

OSprime is bought by researchers, traders, engineers, doctors… A helper is
the same assistant with a job: its own instructions, the tools it always
has, its own conversation in the companion's panel, and a "glance" — the
card on the panel's home page that shows what matters for that job without
asking (a watchlist's prices, a project's state).

A helper is a Markdown file, so a person can read and change one:

    ---
    name: Trader
    color: "#3fb950"
    tools: [market_price, watchlist]
    glance: markets
    ---
    What it is for and how it must behave (kept short: it rides on every
    turn, and the small local model has 8k tokens for everything).

The shipped ones are agent/helpers/*.md; a person's own are
~/Memory/Helpers/*.md (made by asking, or in Notes) and win on a clash.

The data tools here use free public sources that need no account or key
(Ehsan, 9 October: "free global sources"): OpenAlex and arXiv for papers,
CoinGecko, Frankfurter (the European Central Bank's rates) and Stooq for
prices, the public GitHub API. Every answer names its source.
"""
import json
import os
import pathlib
import re
import subprocess
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

import paths

HERE = pathlib.Path(__file__).resolve().parent / "helpers"
UA = {"User-Agent": "OSprime/1.0 (helpers; +https://github.com/EhsanBcoding/osprime)"}
TIMEOUT = 12
_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,40}$")


# ---------------------------------------------------------------------------
# the packs
# ---------------------------------------------------------------------------
def _personal_dir() -> pathlib.Path:
    try:
        import vault
        return vault.root() / "Helpers"
    except Exception:
        return paths.home() / "Memory" / "Helpers"


def _parse(text: str):
    meta, body = {}, text
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end > 0:
            for line in text[3:end].splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    v = v.strip().strip('"').strip("'")
                    if v.startswith("[") and v.endswith("]"):
                        v = [x.strip().strip('"\'') for x in v[1:-1].split(",") if x.strip()]
                    meta[k.strip()] = v
            body = text[end + 4:].strip()
    return meta, body


def slug(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (name or "").lower()).strip("-")[:40]
    return s or "helper-" + str(abs(hash(name)) % 10000)


def all_helpers() -> dict:
    """{id: {id, name, name_fa, color, tools, glance, body, own, order}}"""
    out = {}
    for d, own in ((HERE, False), (_personal_dir(), True)):
        try:
            files = sorted(d.glob("*.md"))
        except Exception:
            files = []
        for f in files:
            try:
                meta, body = _parse(f.read_text(encoding="utf-8"))
            except Exception:
                continue
            hid = f.stem.lower() if not own else slug(meta.get("name") or f.stem)
            if not _ID.match(hid):
                continue
            tools = meta.get("tools") or []
            out[hid] = {"id": hid, "name": meta.get("name") or f.stem,
                        "name_fa": meta.get("name_fa", ""),
                        "color": meta.get("color") if re.match(r"^#[0-9a-fA-F]{6}$", meta.get("color", ""))
                        else "#8b949e",
                        "tools": tools if isinstance(tools, list) else [],
                        "glance": meta.get("glance", ""), "body": body[:1500], "own": own,
                        "order": int(meta.get("order", 50)) if str(meta.get("order", "")).isdigit() else 50,
                        "file": str(f)}
    return dict(sorted(out.items(), key=lambda kv: (kv[1]["order"], kv[1]["name"])))


def get(hid):
    return all_helpers().get(hid or "")


def prompt_block(hid) -> str:
    """The helper's job, for the system prompt. Empty for General."""
    h = get(hid)
    if not h or hid == "general" or not h["body"]:
        return ""
    return (f"YOU ARE THE {h['name'].upper()} HELPER in this conversation. "
            f"{h['body'].strip()}\n\n")


def tools_of(hid) -> list:
    h = get(hid)
    return list(h["tools"]) if h else []


def create(name: str, purpose: str, color: str = "") -> dict:
    """A helper the person asked for ("make me a helper for my accounts"):
    a note in ~/Memory/Helpers they can read and change."""
    name = " ".join((name or "").split())[:40]
    purpose = (purpose or "").strip()[:1200]
    if not name or not purpose:
        return {"ok": False, "message": "A helper needs a name and what it is for."}
    hid = slug(name)
    if hid in all_helpers() and not all_helpers()[hid]["own"]:
        return {"ok": False, "message": f"There is already a built-in {name} helper."}
    if not re.match(r"^#[0-9a-fA-F]{6}$", color or ""):
        palette = ["#f78166", "#d29922", "#db61a2", "#2ea043", "#58a6ff", "#bc8cff"]
        color = palette[sum(map(ord, hid)) % len(palette)]
    d = _personal_dir()
    d.mkdir(parents=True, exist_ok=True)
    f = d / f"{name}.md"
    f.write_text(f'---\nname: {name}\ncolor: "{color}"\ntools: []\n---\n{purpose}\n',
                 encoding="utf-8")
    return {"ok": True, "id": hid, "message": f"{name} is ready. It is a note in Memory/Helpers you can change."}


# ---------------------------------------------------------------------------
# small state per helper (watchlist, recent searches)
# ---------------------------------------------------------------------------
def _state_file() -> pathlib.Path:
    return paths.state_dir() / "helpers.json"


def _state() -> dict:
    try:
        return json.loads(_state_file().read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(st: dict):
    f = _state_file()
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(f)


def last() -> str:
    """The helper the panel opens with: the one used last (Ehsan, 9 October)."""
    hid = (_state().get("_panel") or {}).get("last") or "general"
    return hid if hid in all_helpers() else "general"


def set_last(hid: str):
    if hid not in all_helpers():
        return
    st = _state()
    st.setdefault("_panel", {})["last"] = hid
    _save(st)


def _get_json(url, timeout=TIMEOUT):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def _get_text(url, timeout=TIMEOUT):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


# ---------------------------------------------------------------------------
# researcher: papers
# ---------------------------------------------------------------------------
def _abstract(inv) -> str:
    """OpenAlex keeps abstracts as {word: [positions]}."""
    if not isinstance(inv, dict):
        return ""
    words = sorted((p, w) for w, ps in inv.items() for p in ps)
    return " ".join(w for _, w in words)


def parse_openalex(j) -> list:
    out = []
    for w in (j or {}).get("results", []):
        loc = (w.get("primary_location") or {}).get("source") or {}
        out.append({
            "title": w.get("title") or w.get("display_name") or "",
            "authors": [a.get("author", {}).get("display_name", "") for a in (w.get("authorships") or [])][:6],
            "year": w.get("publication_year"),
            "venue": loc.get("display_name", ""),
            "cited_by": w.get("cited_by_count", 0),
            "doi": (w.get("doi") or "").replace("https://doi.org/", ""),
            "url": w.get("doi") or (w.get("primary_location") or {}).get("landing_page_url") or w.get("id", ""),
            "abstract": _abstract(w.get("abstract_inverted_index"))[:600],
            "source": "OpenAlex"})
    return out


def parse_arxiv(xml_text: str) -> list:
    ns = {"a": "http://www.w3.org/2005/Atom"}
    out = []
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return out
    for e in root.findall("a:entry", ns):
        get = lambda tag: (e.findtext(f"a:{tag}", default="", namespaces=ns) or "").strip()
        out.append({
            "title": " ".join(get("title").split()),
            "authors": [a.findtext("a:name", default="", namespaces=ns) for a in e.findall("a:author", ns)][:6],
            "year": get("published")[:4],
            "venue": "arXiv (preprint, not peer reviewed)",
            "cited_by": None, "doi": "",
            "url": get("id"),
            "abstract": " ".join(get("summary").split())[:600],
            "source": "arXiv"})
    return out


def research_papers(query: str, limit: int = 5, source: str = "both") -> str:
    q = (query or "").strip()[:200]
    if not q:
        return "ERROR: say what to search for"
    limit = max(1, min(int(limit or 5), 10))
    found, errors = [], []
    if source in ("both", "openalex"):
        try:
            j = _get_json("https://api.openalex.org/works?per-page=%d&search=%s"
                          % (limit, urllib.parse.quote(q)))
            found += parse_openalex(j)
        except Exception as e:
            errors.append(f"OpenAlex: {e}")
    if source in ("both", "arxiv"):
        try:
            x = _get_text("https://export.arxiv.org/api/query?max_results=%d&search_query=%s"
                          % (min(limit, 5), urllib.parse.quote("all:" + q)))
            found += parse_arxiv(x)
        except Exception as e:
            errors.append(f"arXiv: {e}")
    if not found:
        return "ERROR: nothing found" + (f" ({'; '.join(errors)})" if errors else "")
    st = _state()
    recent = st.setdefault("researcher", {}).setdefault("recent", [])
    recent.insert(0, {"q": q, "at": int(time.time()),
                      "top": [p["title"][:90] for p in found[:3]]})
    del recent[8:]
    try:
        _save(st)
    except Exception:
        pass
    return json.dumps({"papers": found, "note": "Cite each with authors, year, title and DOI/link."},
                      ensure_ascii=False)


# ---------------------------------------------------------------------------
# trader: prices
# ---------------------------------------------------------------------------
CRYPTO = {"btc": "bitcoin", "bitcoin": "bitcoin", "eth": "ethereum", "ethereum": "ethereum",
          "usdt": "tether", "tether": "tether", "bnb": "binancecoin", "sol": "solana",
          "solana": "solana", "xrp": "ripple", "ada": "cardano", "doge": "dogecoin",
          "ton": "the-open-network", "trx": "tron", "dot": "polkadot", "ltc": "litecoin",
          "avax": "avalanche-2", "link": "chainlink", "matic": "matic-network", "shib": "shiba-inu"}
CURRENCIES = {"usd", "eur", "gbp", "jpy", "chf", "cad", "aud", "nzd", "cny", "try", "sek",
              "nok", "dkk", "pln", "inr", "krw", "brl", "mxn", "zar", "sgd", "hkd", "czk", "huf",
              "idr", "ils", "isk", "myr", "php", "ron", "thb", "bgn"}
METALS = {"gold": "xauusd", "xau": "xauusd", "silver": "xagusd", "xag": "xagusd",
          "oil": "cl.f", "brent": "cb.f"}


def classify(sym: str):
    """(kind, normalised): crypto / fx / stooq, or (None, why)."""
    s = (sym or "").strip().lower().replace(" ", "")
    if not s or len(s) > 20 or not re.match(r"^[a-z0-9.^/=-]+$", s):
        return None, "not a symbol"
    if s in CRYPTO:
        return "crypto", CRYPTO[s]
    pair = s.replace("/", "")
    if len(pair) == 6 and pair[:3] in CURRENCIES and pair[3:] in CURRENCIES:
        return "fx", (pair[:3].upper(), pair[3:].upper())
    if s in METALS:
        return "stooq", METALS[s]
    if "/" in s or s.startswith("-") or not re.search(r"[a-z]", s):
        return None, "not a symbol"
    if "." not in s and "^" not in s:
        s += ".us"                      # AAPL → aapl.us, Stooq's name for it
    return "stooq", s


def parse_stooq(csv_text: str) -> dict:
    lines = [l for l in (csv_text or "").strip().splitlines() if l]
    if len(lines) < 2:
        return {}
    head = [h.strip().lower() for h in lines[0].split(",")]
    row = dict(zip(head, [c.strip() for c in lines[1].split(",")]))
    if row.get("close") in (None, "", "N/D"):
        return {}
    try:
        close, op = float(row["close"]), float(row.get("open") or 0)
    except ValueError:
        return {}
    ch = (close - op) / op * 100 if op else None
    return {"price": close, "change_pct": round(ch, 2) if ch is not None else None,
            "date": row.get("date", ""), "time": row.get("time", ""),
            "change_basis": "since today's open"}


def market_price(symbols) -> str:
    if isinstance(symbols, str):
        symbols = re.split(r"[,\s]+", symbols)
    symbols = [s for s in (symbols or []) if s][:12]
    if not symbols:
        return "ERROR: give one or more symbols (BTC, EURUSD, AAPL, gold)"
    out = {}
    crypto = {}
    for s in symbols:
        kind, norm = classify(s)
        if kind is None:
            out[s] = {"error": norm}
        elif kind == "crypto":
            crypto[s] = norm
        elif kind == "fx":
            try:
                j = _get_json("https://api.frankfurter.app/latest?from=%s&to=%s" % norm)
                out[s] = {"price": j["rates"][norm[1]], "date": j.get("date"),
                          "source": "European Central Bank (via Frankfurter), daily reference rate"}
            except Exception as e:
                out[s] = {"error": f"Frankfurter: {e}"}
        else:
            try:
                q = _get_text("https://stooq.com/q/l/?s=%s&f=sd2t2ohlcv&h&e=csv"
                              % urllib.parse.quote(norm))
                r = parse_stooq(q)
                out[s] = dict(r, source="Stooq (may be delayed)") if r else {"error": "Stooq has no price for it"}
            except Exception as e:
                out[s] = {"error": f"Stooq: {e}"}
    if crypto:
        try:
            ids = ",".join(sorted(set(crypto.values())))
            j = _get_json("https://api.coingecko.com/api/v3/simple/price?ids=%s"
                          "&vs_currencies=usd&include_24hr_change=true" % ids)
            for s, cid in crypto.items():
                d = j.get(cid) or {}
                out[s] = ({"price": d["usd"], "currency": "USD",
                           "change_pct": round(d.get("usd_24h_change") or 0, 2),
                           "change_basis": "24 hours", "source": "CoinGecko"}
                          if "usd" in d else {"error": "CoinGecko has no price for it"})
        except Exception as e:
            for s in crypto:
                out[s] = {"error": f"CoinGecko: {e}"}
    return json.dumps({"prices": out, "note": "Information only, not advice."}, ensure_ascii=False)


def watchlist(action: str = "list", symbol: str = "") -> str:
    st = _state()
    wl = st.setdefault("trader", {}).setdefault("watchlist", ["BTC", "ETH", "EURUSD", "gold"])
    sym = (symbol or "").strip().upper()
    if action == "add":
        if classify(sym)[0] is None:
            return f"ERROR: {symbol!r} is not a symbol I can price"
        if sym not in wl:
            wl.append(sym)
    elif action == "remove":
        if sym in wl:
            wl.remove(sym)
    elif action != "list":
        return "ERROR: action is list, add or remove"
    del wl[20:]
    _save(st)
    return json.dumps({"watchlist": wl}, ensure_ascii=False)


# ---------------------------------------------------------------------------
# software engineer: projects
# ---------------------------------------------------------------------------
def find_repos(root=None, depth=3, limit=12) -> list:
    root = pathlib.Path(root or paths.home())
    found = []
    for dirpath, dirnames, _files in os.walk(root):
        rel = pathlib.Path(dirpath).relative_to(root)
        if ".git" in dirnames:
            found.append(pathlib.Path(dirpath))
            dirnames[:] = []
            if len(found) >= limit:
                break
            continue
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in
                       ("node_modules", "venv", ".venv", "__pycache__", "Memory")]
        if len(rel.parts) >= depth:
            dirnames[:] = []
    return found


def repo_state(path) -> dict:
    def git(*a):
        r = subprocess.run(["git", "-C", str(path), *a], capture_output=True, text=True, timeout=10)
        return r.stdout.strip() if r.returncode == 0 else ""
    st = git("status", "--porcelain=v1", "--branch")
    lines = st.splitlines()
    head = lines[0] if lines else ""
    m = re.search(r"\[ahead (\d+)(?:, behind (\d+))?\]|\[behind (\d+)\]", head)
    ahead = int(m.group(1)) if m and m.group(1) else 0
    behind = int(m.group(2) or m.group(3) or 0) if m else 0
    return {"name": pathlib.Path(path).name, "path": str(path),
            "branch": git("rev-parse", "--abbrev-ref", "HEAD"),
            "changed": len(lines) - 1 if lines else 0, "ahead": ahead, "behind": behind,
            "last_commit": git("log", "-1", "--format=%cr — %s")[:100]}


def repos_status(path: str = "") -> str:
    if path:
        p = pathlib.Path(os.path.expanduser(path))
        if not (p / ".git").exists():
            return f"ERROR: {path} is not a git project"
        return json.dumps(repo_state(p), ensure_ascii=False)
    repos = find_repos()
    if not repos:
        return "No git projects in the home folder (looked three folders deep)."
    return json.dumps([repo_state(r) for r in repos], ensure_ascii=False)


def github_repo(repo: str) -> str:
    repo = (repo or "").strip().replace("https://github.com/", "").strip("/")
    if not re.match(r"^[\w.-]+/[\w.-]+$", repo):
        return "ERROR: give it as owner/name"
    try:
        info = _get_json(f"https://api.github.com/repos/{repo}")
        prs = _get_json(f"https://api.github.com/repos/{repo}/pulls?state=open&per_page=5")
        runs = _get_json(f"https://api.github.com/repos/{repo}/actions/runs?per_page=1")
    except Exception as e:
        return f"ERROR: GitHub: {e} (public repositories only; 60 requests an hour without an account)"
    run = (runs.get("workflow_runs") or [{}])[0]
    return json.dumps({
        "repo": repo, "stars": info.get("stargazers_count"),
        "open_issues_and_prs": info.get("open_issues_count"),
        "open_prs": [{"number": p["number"], "title": p["title"], "by": p["user"]["login"]} for p in prs],
        "latest_ci": {"name": run.get("name"), "status": run.get("status"),
                      "conclusion": run.get("conclusion"), "branch": run.get("head_branch"),
                      "when": run.get("created_at")} if run else None,
        "source": "GitHub public API"}, ensure_ascii=False)


# ---------------------------------------------------------------------------
# the panel's glance cards — data only, no model
# ---------------------------------------------------------------------------
def _price(v) -> str:
    """60000 → 60,000; 1.0843 → 1.0843; 0.00001234 → 1.234e-05."""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return str(v)
    if abs(v) >= 1000:
        return f"{v:,.0f}"
    if abs(v) >= 1:
        return f"{v:,.4g}" if abs(v) < 10 else f"{v:,.2f}"
    return f"{v:.4g}"


def glance(hid) -> dict:
    """{"title", "lines": [[left, right, tone]]}; tone: up/down/dim/""."""
    h = get(hid) or {}
    kind = h.get("glance", "")
    try:
        if kind == "markets":
            wl = json.loads(watchlist("list"))["watchlist"]
            prices = json.loads(market_price(wl[:6]))["prices"]
            lines = []
            for s in wl[:6]:
                p = prices.get(s, {})
                if "price" in p:
                    ch = p.get("change_pct")
                    lines.append([s, _price(p["price"]) + (f"  {ch:+.2f}%" if ch is not None else ""),
                                  "up" if (ch or 0) > 0 else "down" if (ch or 0) < 0 else ""])
                else:
                    lines.append([s, "—", "dim"])
            return {"title": "Watchlist", "lines": lines, "foot": "Free sources, may be delayed. Not advice."}
        if kind == "code":
            lines = []
            for r in find_repos(limit=5):
                s = repo_state(r)
                bits = [s["branch"]] + ([f"{s['changed']} changed"] if s["changed"] else []) + \
                       ([f"↑{s['ahead']}"] if s["ahead"] else []) + ([f"↓{s['behind']}"] if s["behind"] else [])
                lines.append([s["name"], " · ".join(b for b in bits if b), "up" if not s["changed"] else ""])
            return {"title": "Projects", "lines": lines or [["No git projects in your home folder", "", "dim"]]}
        if kind == "research":
            rec = _state().get("researcher", {}).get("recent", [])[:3]
            lines = [[r["q"], time.strftime("%d %b", time.localtime(r["at"])), "dim"] for r in rec]
            return {"title": "Recent searches",
                    "lines": lines or [["Ask me to find papers on anything", "", "dim"]]}
        if kind == "today":
            import proactive
            items = proactive.list_schedules(paths.agent_config())
            lines = [[i["time"], i["label"] or i["prompt"][:40], ""] for i in items[:4]]
            return {"title": "Today", "lines": lines or [["Nothing scheduled", "", "dim"]]}
    except Exception as e:
        return {"title": h.get("name", ""), "lines": [[f"Could not load: {e}", "", "dim"]]}
    return {"title": h.get("name", ""), "lines": []}
