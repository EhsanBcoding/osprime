#!/usr/bin/env bash
# Runs as root at the end of an update, from inside the new package.
#
# This exists for the half of a change that an update cannot deliver by
# copying files. Ownership and sudo rules are not code, and a release that
# ships new service units without them produces exactly the failure this
# project keeps meeting: an update that reports success while half of it did
# not happen.
#
# The change it completes: the OSprime services now run as the osprime user
# instead of root, so everything the assistant writes has to belong to that
# user, and the few things it still needs root for have to be named in
# sudoers.
#
# Anything essential that fails exits non-zero, and the updater rolls the
# whole release back. That is the point — a machine half-moved to an
# unprivileged agent is worse than one that never moved.
set -u

SRC="$(cd "$(dirname "$0")" && pwd)"
SUDOERS_SRC="$SRC/shell/osprime-sudoers"

# Everything this script touches is under one prefix, empty in real use.
# A script that must not fail is a script that has to be runnable against a
# throwaway directory first — otherwise the only way to test it is to run it
# on the machine it would break.
R="${OSPRIME_POST_ROOT:-}"
SUDOERS_DST="$R/etc/sudoers.d/osprime"
fail=0

echo "> making the assistant's own files belong to it"
# /opt/osprime is deliberately absent: the code stays root-owned, which is
# what stops the unprivileged agent rewriting the script it is allowed to
# ask root to run.
for d in "$R/var/lib/osprime" "$R/etc/osprime"; do
    mkdir -p "$d"
    chown -R osprime:osprime "$d" 2>/dev/null || \
        { [ -z "$R" ] && { echo "  could not chown $d"; fail=1; }; }
    chmod 770 "$d" || fail=1
done
# setgid on /etc/osprime specifically.
#
# The recursive chown above is what actually lets the companion save its
# position — it runs in the user's session as `osprime`, and it is the first
# thing on this machine that writes here as somebody other than root. This
# line is for what comes after: a file created here later by a root process
# would otherwise land in root's group, and the next unprivileged write to it
# would fail silently, which for a floating button means it quietly forgets
# where it was put at every login.
chmod 2770 "$R/etc/osprime" 2>/dev/null || true
# The backups are ROOT's, and live outside the directory above on purpose.
#
# They used to be /var/lib/osprime/backups — inside the tree this loop hands
# to the osprime user. Rollback runs as root and copies a backup into
# /opt/osprime, so the agent could write code into a backup, ask root to
# roll back (sudoers allows it without a password) and become the operating
# system. docs/SECURITY.md, #2.
#
# The old backups are deliberately NOT moved across. Anything the agent
# could write may already have been written, and chowning it to root here
# would not make it trustworthy — it would only make the ownership check in
# updater.untrusted() pass on a file it exists to reject. The update running
# right now has just taken a fresh backup, as root, into the new place; that
# one is sound. The old directory is left where it is, unused, and is listed
# as reclaimable space.
mkdir -p "$R/var/lib/osprime-backups"
if [ -z "$R" ]; then
    chown root:root "$R/var/lib/osprime-backups" || fail=1
fi
chmod 755 "$R/var/lib/osprime-backups" || fail=1

# The key file keeps its own mode; only its owner changes.
[ -f "$R/etc/osprime/secrets.env" ] && chmod 600 "$R/etc/osprime/secrets.env"

# Where photographs that ship with the system live. Created empty on a
# machine that was installed before this folder existed, so the chooser
# reads a real directory rather than a missing one — and so the pictures
# have somewhere to land when there are any.
mkdir -p "$R/usr/share/osprime/wallpapers" 2>/dev/null || true

echo "> making the code readable by the user that has to run it"
# Root-owned and world-readable. Those are two separate properties and the
# device needs both: root-owned is what stops the unprivileged agent
# rewriting the scripts it is allowed to ask root to run, and world-readable
# is what lets it read them at all.
#
# One release shipped an archive of mode-700 files. Extracted as root they
# became root-owned and unreadable, and the machine came up in a rescue
# shell unable to execute its own session script. release.sh now refuses to
# build such an archive — but the archive is this machine's brain, and the
# check that matters is the one on the machine. A mode should never be the
# reason a desktop does not appear.
for d in "$SRC" "$R/opt/osprime"; do
    [ -d "$d" ] || continue
    find "$d" -type d -exec chmod 755 {} + || fail=1
    find "$d" -type f -exec chmod 644 {} + || fail=1
    # A shebang is the file saying it is meant to be run.
    while IFS= read -r f; do
        [ "$(head -c 2 "$f" 2>/dev/null)" = '#!' ] && chmod 755 "$f"
    done < <(find "$d" -type f)
done

echo "> installing the sudo rules"
if [ ! -f "$SUDOERS_SRC" ]; then
    echo "  $SUDOERS_SRC is missing from this package"
    fail=1
else
    tmp="$(mktemp)"
    cp "$SUDOERS_SRC" "$tmp"
    chmod 440 "$tmp"
    # Validated before it replaces anything. An invalid file in
    # /etc/sudoers.d stops sudo running AT ALL, and root is locked on this
    # system — there would be no way back.
    if visudo -c -f "$tmp" >/dev/null 2>&1; then
        # The exit code is checked. The first version printed "updated"
        # whether or not the install worked, which is the same bug this
        # script exists to stop shipping.
        # Ownership is only settable as root; under a test prefix it is not
        # root and does not need to be.
        OWNER=()
        [ -z "$R" ] && OWNER=(-o root -g root)
        # Exists on a real machine; under a test prefix it does not, and
        # that made the one script that must not fail impossible to
        # rehearse — it failed on the harness, not on the thing being tested.
        mkdir -p "$(dirname "$SUDOERS_DST")"
        if install -m 440 "${OWNER[@]}" "$tmp" "$SUDOERS_DST"; then
            echo "  $SUDOERS_DST updated"
        else
            echo "  could not write $SUDOERS_DST"
            fail=1
        fi
    else
        echo "  the new sudo rules did not validate — the old ones were kept"
        visudo -c -f "$tmp" 2>&1 | sed 's/^/    /'
        fail=1
    fi
    rm -f "$tmp"
fi

# Leftovers from the live image, harmless but confusing on every root login.
rm -f "$R/root/.zlogin" "$R/root/.automated_script.sh" 2>/dev/null

if [ "$fail" -ne 0 ]; then
    echo "post-install did not complete — the update will be rolled back"
    exit 1
fi
echo "post-install complete"
