"""The Settings window.

Kept separate from web.py only so neither file becomes unreadable; it is
served by the same process on the same port, at /settings.

Three rules this file exists to keep, from docs/CONTROL_PANEL.md:

1. Every control goes through agent/system_tools.py — the same functions
   the assistant calls. There is deliberately no second path to the same
   setting: when a product grows two ways to change one value they drift,
   and the user ends up with an interface that disagrees with itself.

2. Nothing here may depend on the assistant being alive. osprime-web is a
   separate service from osprime-agent, so this window keeps working when
   the model will not load — which is exactly when a person needs to reach
   the network settings and the update button.

3. It earns its place by showing state, by doing what words are bad at,
   and by working when the assistant does not. A control that serves none
   of those belongs in the conversation instead.

The URL stays /settings and the launcher stays osprime-settings.sh. Both
are wired into the desktop menu, the app list and any keyboard shortcut a
user has already saved; renaming them would break those for a word.
"""

PAGE = r"""<!DOCTYPE html>
<html lang="{{LANG}}" dir="{{DIR}}">
<meta charset="utf-8">
<title>Settings — OSprime</title>
<style>
  :root { --bg:#0d1117; --panel:#161b22; --line:#21262d; --text:#e6edf3;
          --dim:#8b949e; --accent:#2d6cdf; --ok:#2ea043; --warn:#d29922; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--text); height:100vh;
         display:flex; flex-direction:column;
         font-family:system-ui,'Noto Sans','Noto Sans Arabic',sans-serif; }
  header { padding:14px 22px; background:var(--panel);
           border-bottom:1px solid var(--line); display:flex;
           align-items:center; gap:10px; }
  header .logo { font-size:18px; font-weight:700; color:var(--accent); }
  header .sub { color:var(--dim); font-size:13px; }
  #body { flex:1; display:flex; min-height:0; }
  nav { width:210px; flex:none; background:var(--panel); padding:14px 10px;
        border-inline-end:1px solid var(--line); overflow-y:auto; }
  nav a { display:block; padding:9px 12px; border-radius:8px; font-size:14px;
          color:var(--text); text-decoration:none; cursor:pointer;
          margin-bottom:2px; }
  nav a:hover { background:#1c2330; }
  nav a.on { background:var(--accent); color:#fff; }
  main { flex:1; overflow-y:auto; padding:22px; }
  .page { display:none; max-width:720px; }
  .page.on { display:block; }
  h1 { font-size:20px; font-weight:600; margin:0 0 4px; }
  .lede { color:var(--dim); font-size:13px; margin:0 0 18px; }
  section { background:var(--panel); border:1px solid var(--line);
            border-radius:12px; padding:16px 20px; margin-bottom:16px; }
  h2 { font-size:15px; font-weight:600; margin:0 0 14px; }
  .row { display:flex; align-items:center; gap:12px; padding:9px 0;
         border-top:1px solid var(--line); }
  .row:first-of-type { border-top:0; }
  .row label { flex:1; font-size:14px; }
  .row .hint { display:block; color:var(--dim); font-size:12px; margin-top:2px; }
  input, select { background:#0d1117; color:var(--text);
                  border:1px solid var(--line); border-radius:7px;
                  padding:7px 10px; font-size:13px; min-width:190px;
                  font-family:inherit; }
  input[type=checkbox] { min-width:auto; width:18px; height:18px; }
  button { background:var(--accent); color:#fff; border:0; border-radius:7px;
           padding:7px 16px; font-size:13px; cursor:pointer;
           font-family:inherit; }
  button.ghost { background:transparent; border:1px solid var(--line);
                 color:var(--text); }
  button:disabled { opacity:.5; cursor:default; }
  #note { position:fixed; left:50%; transform:translateX(-50%); bottom:22px;
          background:var(--panel); border:1px solid var(--line);
          border-radius:9px; padding:10px 18px; font-size:13px;
          display:none; z-index:5; }
  .nets { margin-top:10px; display:flex; flex-direction:column; gap:6px; }
  .net { display:flex; align-items:center; gap:10px; padding:8px 10px;
         border:1px solid var(--line); border-radius:8px; font-size:13px;
         cursor:pointer; }
  .net:hover { border-color:var(--accent); }
  .net .sig { color:var(--dim); font-size:12px; margin-inline-start:auto; }
  .facts { display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr));
           gap:12px; }
  .fact { background:#0d1117; border:1px solid var(--line); border-radius:10px;
          padding:12px 14px; }
  .fact .k { color:var(--dim); font-size:12px; }
  .fact .v { font-size:16px; margin-top:3px; }
  .fact .v small { color:var(--dim); font-size:12px; }
  .mems { display:flex; flex-direction:column; gap:6px; }
  .mem { display:flex; align-items:center; gap:10px; padding:9px 12px;
         background:#0d1117; border:1px solid var(--line); border-radius:8px;
         font-size:13px; }
  .mem .txt { flex:1; overflow-wrap:anywhere; }
  .mem .when { color:var(--dim); font-size:12px; flex:none; }
  .mem .x { background:transparent; border:1px solid var(--line);
            color:var(--dim); border-radius:6px; padding:3px 9px;
            font-size:12px; flex:none; }
  .mem .x:hover { border-color:#e05555; color:#e05555; }
  .empty { color:var(--dim); font-size:13px; padding:4px 0; }
  /* The background chooser. Swatches rather than a dropdown, because this
     is the one setting in the whole panel that cannot be described in
     words — picking a background is looking at it. */
  .bggroup { margin-bottom:14px; }
  .bggroup h3 { font-size:12px; color:var(--dim); font-weight:600;
                margin:0 0 8px; text-transform:uppercase;
                letter-spacing:.04em; }
  .bgrow { display:grid; grid-template-columns:repeat(auto-fill,minmax(112px,1fr));
           gap:10px; }
  .bg { border:1px solid var(--line); border-radius:10px; overflow:hidden;
        cursor:pointer; background:#0d1117; }
  .bg:hover { border-color:var(--accent); }
  .bg.on { border-color:var(--accent); box-shadow:0 0 0 1px var(--accent); }
  .bg .sw { height:62px; display:block; background-size:cover;
            background-position:center; }
  .bg .nm { font-size:12px; padding:6px 8px; color:var(--dim);
            white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .bg.busy .nm::after { content:" …"; }
  /* The picture browser. A panel over the page rather than another
     window: the Control Panel is already a window, and a second one to
     pick a file is a second thing to find and close. */
  #bgmodal { display:none; position:fixed; inset:0; z-index:40;
             background:rgba(0,0,0,.55); align-items:center;
             justify-content:center; padding:32px; }
  #bgmodal.on { display:flex; }
  #bgmodal .sheet { background:var(--panel); border:1px solid var(--line);
                    border-radius:14px; width:min(760px,100%);
                    max-height:100%; display:flex; flex-direction:column;
                    box-shadow:0 20px 60px rgba(0,0,0,.5); }
  #bgmodal header { border-bottom:1px solid var(--line); border-radius:14px 14px 0 0; }
  #bgmodal .body { padding:18px 20px; overflow-y:auto; }
</style>
<header>
  <span class="logo">Settings</span>
  <span class="sub">OSprime v{{VERSION}}</span>
</header>

<div id="body">
<nav>
  <a data-page="home">Home</a>
  <a data-page="system">System</a>
  <a data-page="devices">Bluetooth &amp; devices</a>
  <a data-page="network">Network &amp; internet</a>
  <a data-page="personal">Personalisation</a>
  <a data-page="apps">Applications</a>
  <a data-page="time">Time &amp; language</a>
  <a data-page="assistant">Assistant</a>
  <a data-page="update">Update &amp; recovery</a>
</nav>

<main>
  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-home">
    <h1>Home</h1>
    <p class="lede">What this computer is, and anything that wants
      attention.</p>
    <section>
      <h2>This device</h2>
      <div class="facts" id="hwfacts"><div class="fact"><div class="k">reading…</div></div></div>
    </section>
    <section>
      <h2>The assistant</h2>
      <div class="facts" id="modelfacts"><div class="fact"><div class="k">reading…</div></div></div>
      <div class="row" id="modeladvice" style="display:none">
        <label><span id="modeladvicetext"></span>
          <span class="hint" id="modeladvicehint"></span></label>
        <button id="switchbtn">Switch</button>
      </div>
    </section>
    <section>
      <h2>Eyes</h2>
      <!-- docs/MODELS.md, step 4. A second model, used only for pictures:
           the one above talks, this one looks. -->
      <div class="row">
        <label><span id="eyesnow">reading…</span>
          <span class="hint" id="eyeshint"></span></label>
        <button id="eyesbtn" style="display:none"></button>
      </div>
      <div class="row" id="eyesprogress" style="display:none">
        <label><span id="eyesphase"></span>
          <span class="hint" id="eyeslog" style="white-space:pre-wrap"></span></label>
      </div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-system">
    <h1>System</h1>
    <section>
      <h2>Display</h2>
      <div class="row">
        <label>Screen size
          <span class="hint">Makes everything bigger — windows, icons and
          buttons together. A 1920×1080 panel on a 14-inch laptop is very
          small at 100%, and this keeps it sharp where lowering the
          resolution would not.</span></label>
        <select id="scale">
          <option value="1">100%</option>
          <option value="1.25">125%</option>
          <option value="1.5">150%</option>
          <option value="1.75">175%</option>
          <option value="2">200%</option>
        </select>
      </div>
      <div class="row">
        <label>Text size
          <span class="hint">Only the words, leaving the layout alone.
          Programs already open keep the old size until restarted.</span></label>
        <select id="textsize">
          <option value="100">100%</option>
          <option value="125">125%</option>
          <option value="150">150%</option>
          <option value="175">175%</option>
          <option value="200">200%</option>
        </select>
      </div>
      <div class="row">
        <label>Resolution</label>
        <select id="resolution"><option value="">detecting…</option></select>
      </div>
    </section>
    <section>
      <h2>Sound</h2>
      <div class="row">
        <label>Volume</label>
        <input type="range" id="volume" min="0" max="100" step="1"
               style="min-width:220px">
        <span id="volval" style="color:var(--dim);font-size:13px">—</span>
      </div>
    </section>
    <section>
      <h2>Storage</h2>
      <div class="facts" id="diskfacts"><div class="fact"><div class="k">reading…</div></div></div>
      <div id="bigfolders" class="mems" style="margin-top:12px"></div>
      <p class="lede" style="margin:12px 0 8px">Safe to delete — caches, the
        trash, downloaded installers and old OSprime backups. Nothing here
        is your own work. Ask the assistant to clear any of them.</p>
      <div id="reclaim" class="mems"></div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-devices">
    <h1>Bluetooth &amp; devices</h1>
    <section>
      <h2>Cameras and microphones</h2>
      <p class="lede" style="margin:0 0 10px">What this computer has. The
        microphone only records while you hold the button in the chat.</p>
      <div id="capdevs" class="mems"><div class="empty">reading…</div></div>
    </section>
    <section>
      <h2>What OSprime may use</h2>
      <p class="lede" style="margin:0 0 10px">Switching one off means
        OSprime will not open it at all — not that it opens it and ignores
        what it hears. These switches do not stop other programs; if
        something else is using a device, the panel at the bottom of the
        screen says so and names it.</p>
      <div class="row">
        <label>Microphone</label>
        <input type="checkbox" id="allowmic">
      </div>
      <div class="row">
        <label>Camera</label>
        <input type="checkbox" id="allowcam">
      </div>
      <div class="row">
        <label id="capnow">Checking what is open…</label>
      </div>
      <div class="row" id="voicerow" style="display:none">
        <label id="voicewhy"></label>
      </div>
    </section>
    <section>
      <h2>Drives</h2>
      <div id="drives" class="mems"><div class="empty">reading…</div></div>
    </section>
  </div>

  <div class="page" id="page-network">
    <h1>Network &amp; internet</h1>
    <section>
      <h2>Wi-Fi</h2>
      <div class="row">
        <label id="netstate">Checking…</label>
        <button class="ghost" id="scan">Scan for networks</button>
      </div>
      <div class="nets" id="nets"></div>
      <div class="row" style="margin-top:6px">
        <label>Hidden network
          <span class="hint">For a network that does not broadcast its
          name.</span></label>
        <input id="hidden" placeholder="network name">
        <button class="ghost" id="joinhidden">Join</button>
      </div>
    </section>
    <!-- Remote access. Managed here, on the computer, and nowhere else: a
         paired phone that opens this page sees only the note below. -->
    <section id="remotesec">
      <h2>Other devices</h2>
      <div id="remotelocal">
        <div class="row">
          <label>Allow other devices on this network
            <span class="hint">A phone or laptop on the same Wi-Fi can use
            OSprime after you pair it here. Only on a network you trust — at
            home, not in a café: on a shared network someone else could
            listen in.</span></label>
          <input type="checkbox" id="remoteon">
        </div>
        <div id="remotemore" style="display:none">
          <div class="row">
            <label id="remoteaddr">…</label>
            <button id="pairbtn">Pair a device</button>
          </div>
          <div id="pairbox" style="display:none; text-align:center; padding:14px 0">
            <div id="pairqr" style="display:inline-block; background:#fff;
                 padding:10px; border-radius:10px"></div>
            <p style="margin:12px 0 4px">Scan with the phone's camera, or open
              <b id="pairurl"></b> on it and type</p>
            <div id="paircode" style="font-size:34px; letter-spacing:8px;
                 font-weight:700; margin:4px 0"></div>
            <p class="hint" id="paircount" style="color:var(--dim)"></p>
            <button class="ghost" id="paircancel">Cancel</button>
          </div>
          <div id="devlist" class="nets"></div>
        </div>
      </div>
      <p id="remotenote" class="lede" style="display:none"></p>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-time">
    <h1>Time &amp; language</h1>
    <section>
      <h2>Date and time</h2>
      <div class="row">
        <label>Set automatically
          <span class="hint">Needs a network connection.</span></label>
        <input type="checkbox" id="autotime">
      </div>
      <div class="row">
        <label>Time zone</label>
        <input id="timezone" placeholder="Europe/Berlin">
      </div>
      <div class="row">
        <label>Set manually
          <span class="hint">YYYY-MM-DD HH:MM</span></label>
        <input id="clock" placeholder="2026-08-30 14:30">
      </div>
    </section>
    <section>
      <h2>Language</h2>
      <div class="row">
        <label>Language
          <span class="hint">Reopen a window to see the change.</span></label>
        <select id="language">
          <option value="en">English</option>
          <option value="fa">فارسی</option>
        </select>
      </div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-assistant">
    <h1>Assistant</h1>
    <p class="lede">These can all be changed by asking, too. They are here
      because this window works when the assistant does not.</p>
    <section>
      <h2>Cloud model</h2>
      <div class="row">
        <label>Use a cloud model
          <span class="hint">Optional. OSprime works fully without it.
          Your key stays on this machine.</span></label>
        <select id="cloudmode">
          <option value="off">Never</option>
          <option value="ask">Only when I ask</option>
          <option value="auto">When the local model cannot cope</option>
        </select>
      </div>
      <div class="row">
        <label>API key</label>
        <input id="apikey" type="password" placeholder="not set">
      </div>
    </section>
    <section>
      <h2>Asking before acting</h2>
      <div class="row">
        <label>Check with me before
          <span class="hint">Deleting files, shutting down and installing
          software are always treated as risky, whatever this is set
          to.</span></label>
        <select id="confirmlevel">
          <option value="everything">anything at all</option>
          <option value="moderate">anything that changes this computer</option>
          <option value="dangerous">only risky things</option>
          <option value="nothing">never ask</option>
        </select>
      </div>
    </section>
    <section>
      <h2>Starting conversations</h2>
      <div class="row">
        <label>Let it speak first
          <span class="hint">Off, it answers and nothing more. On, it may
          raise a few things you already asked it to watch — a full disk, a
          finished job — as a quiet dot on the companion. Never a window,
          never a sound, and at most twice a day.</span></label>
        <input type="checkbox" id="proactive">
      </div>
      <!-- Rule 4 says a refusal is permanent and undone here, never by us.
           So here has to exist, and it has to show what was refused —
           otherwise "permanent" quietly means "lost". -->
      <div id="refusedrow" class="row" style="display:none">
        <label>Things you told it to stop mentioning
          <span class="hint" id="refusedlist"></span></label>
        <button class="ghost" id="refusedclear">Allow again</button>
      </div>
    </section>
    <section>
      <h2>What it remembers about you</h2>
      <div class="row">
        <label id="memcount">Reading…</label>
        <button class="ghost" id="forgetall">Forget everything</button>
      </div>
      <div id="memlist" class="mems"></div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-apps">
    <h1>Applications</h1>
    <p class="lede">Everything here is published by the people who made it,
      runs in a sandbox, and can be removed completely. You can also just
      ask the assistant for what you need.</p>
    <section>
      <h2>Add something</h2>
      <div class="row">
        <label>What do you need it to do?
          <span class="hint">Describe the job — "edit photos", "play
          videos" — rather than guessing a name.</span></label>
        <input id="appq" placeholder="photo editor">
        <button id="appsearch">Search</button>
      </div>
      <div id="appresults" class="mems"></div>
    </section>
    <section>
      <h2>Installed</h2>
      <div id="applist" class="mems"><div class="empty">reading…</div></div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-personal">
    <h1>Personalisation</h1>
    <section>
      <h2>Background</h2>
      <p class="lede" style="margin:0 0 12px">Click one. The designs are
        drawn at your screen's own size, so they stay sharp.</p>
      <div id="bgpick"><div class="empty">reading…</div></div>
    </section>
    <section>
      <h2>Desktop</h2>
      <div class="row">
        <label>Show icons and the right-click menu
          <span class="hint">Turning this off leaves a plain background.
          Log out and back in after changing it.</span></label>
        <input type="checkbox" id="deskicons">
      </div>
      <div class="row">
        <label>Show the companion
          <span class="hint">The round OSprime button that floats on the
          desktop. Drag it anywhere; click it to open the chat. With it
          hidden, the Super key and the desktop's right-click menu still
          open the chat.</span></label>
        <input type="checkbox" id="companion">
      </div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-update">
    <h1>Update &amp; recovery</h1>
    <section>
      <h2>Updates</h2>
      <div class="row">
        <label>Version <span class="hint" id="verline">v{{VERSION}}</span></label>
        <button id="updbtn">Check for updates</button>
      </div>
    </section>
    <section>
      <h2>If an update went wrong</h2>
      <div class="row">
        <label id="rbstate">Checking for a previous version…
          <span class="hint">Puts the code back as it was and restarts.
          Your files and settings are not touched.</span></label>
        <button class="ghost" id="rbbtn" disabled>Go back</button>
      </div>
    </section>
  </div>
</main>
</div>

<div id="bgmodal">
  <div class="sheet">
    <header>
      <span class="logo" style="font-size:15px">Choose a picture</span>
      <span class="sub" id="bgmodalwhere"></span>
      <button class="ghost" id="bgmodalclose"
              style="margin-inline-start:auto">Close</button>
    </header>
    <div class="body" id="bgmodalbody"></div>
  </div>
</div>

<div id="note"></div>

<script>
const $ = id => document.getElementById(id);
let saving = false;

function note(msg, ms = 2600) {
  const n = $("note");
  n.textContent = msg; n.style.display = "block";
  clearTimeout(n._t); n._t = setTimeout(() => n.style.display = "none", ms);
}

// ---- navigation -------------------------------------------------------
// The desktop's right-click menu opens this window at a section, and those
// names are already in shipped code and in menu entries. "appearance" was
// its own section before the pages existed; it is part of Display now, and
// an old link must still land somewhere sensible rather than on a blank
// window.
// Old names still arrive: the desktop's right-click menu and any
// keyboard shortcut a user saved point at the pages as they used to be
// called. An old link must land somewhere sensible, not on a blank window.
const ALIAS = { machine: "home", display: "system", sound: "system",
                storage: "system", about: "update", wifi: "network",
                appearance: "personal", background: "personal",
                clock: "time", memory: "assistant", disk: "system",
                applications: "apps", software: "apps", install: "apps" };
const PAGES = [...document.querySelectorAll("nav a")].map(a => a.dataset.page);
// Every page in the nav must have a panel behind it, and the other way
// round. Getting this wrong shows an empty window rather than an error, so
// it says so in the console instead of failing silently.
(() => {
  const built = [...document.querySelectorAll(".page")].map(p => p.id.slice(5));
  const missing = PAGES.filter(p => !built.includes(p));
  const orphan  = built.filter(p => !PAGES.includes(p));
  if (missing.length) console.error("nav entries with no page:", missing);
  if (orphan.length)  console.error("pages with no nav entry:", orphan);
})();

function show(page) {
  page = ALIAS[page] || page;
  if (!PAGES.includes(page)) page = PAGES[0];
  document.querySelectorAll(".page").forEach(
    p => p.classList.toggle("on", p.id === "page-" + page));
  document.querySelectorAll("nav a").forEach(
    a => a.classList.toggle("on", a.dataset.page === page));
  // Read when the page is opened, not at startup. These change while the
  // window is open — the assistant is still learning things, the disk is
  // still filling — and a number fetched once at load would be a number
  // that was true earlier.
  if (page === "home")     { loadMachine(); loadEyes(); }
  if (page === "system")   { loadStorage(); }
  if (page === "devices")  { loadCapture(); loadDrives(); }
  if (page === "network")  { $("scan").click(); loadRemote(); }
  if (page === "personal") loadBackgrounds();
  if (page === "apps")     loadApps();
  if (page === "assistant") loadMemory();
  if (page === "update")   loadBackups();
}

document.querySelectorAll("nav a").forEach(a => {
  a.onclick = () => { location.hash = a.dataset.page; };
});
window.addEventListener("hashchange", () => show(location.hash.slice(1)));

// ---- settings ---------------------------------------------------------
async function apply(key, value) {
  if (saving) return;
  saving = true;
  try {
    const r = await (await fetch("/api/settings", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({key, value})
    })).json();
    note(r.message || (r.ok ? "Saved" : "Could not save"));
  } catch (e) { note("Could not save: " + e); }
  saving = false;
}

// ---- remote access ------------------------------------------------------
// Who is looking at this page. On a paired phone the security controls are
// switched off here and refused by the server anyway; saying so in the
// page is so the person does not think the switch is broken.
let WHO = { remote: false, device: null };
const LOCAL_ONLY = ["confirmlevel", "cloudmode", "apikey", "allowcam",
                    "allowmic", "proactive", "autotime", "timezone", "clock"];
async function loadWho() {
  try { WHO = await (await fetch("/api/remote/whoami")).json(); } catch (e) {}
  if (!WHO.remote) return;
  LOCAL_ONLY.forEach(id => {
    const el = $(id);
    if (!el) return;
    el.disabled = true;
    el.title = "Change this on the computer itself";
  });
  $("remotelocal").style.display = "none";
  $("remotenote").style.display = "";
  $("remotenote").textContent = "You are connected from " +
    ((WHO.device && WHO.device.name) || "another device") + ". Settings that " +
    "decide what the assistant may do without asking — and pairing other " +
    "devices — are changed on the computer itself.";
}

let pairTimer = null;
function showDevices(devs) {
  const box = $("devlist");
  box.textContent = "";
  (devs || []).forEach(d => {
    const row = document.createElement("div"); row.className = "row";
    const lab = document.createElement("label");
    lab.textContent = d.name;
    const hint = document.createElement("span"); hint.className = "hint";
    hint.textContent = "paired " + (d.created || "") +
                       " · last seen " + (d.last_seen || "never");
    lab.append(hint);
    // The per-device right agreed on 23 September: off by default, so a
    // phone asks and the computer approves. Turned on only here.
    const ap = document.createElement("label");
    ap.style.flex = "0 0 auto"; ap.style.fontSize = "12px";
    const cb = document.createElement("input"); cb.type = "checkbox";
    cb.checked = !!d.can_approve;
    cb.onchange = () => remoteDevice({ id: d.id, can_approve: cb.checked });
    ap.append(cb, document.createTextNode(" can approve"));
    const rm = document.createElement("button"); rm.className = "ghost";
    rm.textContent = "Remove";
    rm.onclick = () => {
      if (confirm("Remove " + d.name + "? It will have to be paired again."))
        remoteDevice({ id: d.id, remove: true });
    };
    row.append(lab, ap, rm);
    box.append(row);
  });
}
async function remoteDevice(body) {
  try {
    const r = await (await fetch("/api/remote/device", { method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(body) })).json();
    showDevices(r.devices);
    note(r.ok ? "Saved" : "Could not change that");
  } catch (e) { note("Could not change that: " + e); }
}
async function loadRemote() {
  if (WHO.remote) return;
  let s;
  try { s = await (await fetch("/api/remote")).json(); } catch (e) { return; }
  $("remoteon").checked = !!s.enabled;
  $("remotemore").style.display = s.enabled ? "" : "none";
  $("remoteaddr").textContent = s.addresses && s.addresses.length
    ? "This computer: " + s.addresses.join(", ")
    : "Not connected to a local network";
  showDevices(s.devices);
}
$("remoteon").onchange = async e => {
  const on = e.target.checked;
  let r;
  try {
    r = await (await fetch("/api/remote/enable", { method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ on }) })).json();
  } catch (err) { r = { ok: false, message: "" + err }; }
  note(r.message || (r.ok ? "Saved" : "Could not change that"), 5000);
  if (!on) closePairing();
  loadRemote();
};
function closePairing() {
  clearInterval(pairTimer); pairTimer = null;
  $("pairbox").style.display = "none";
  $("pairqr").textContent = "";
}
$("pairbtn").onclick = async () => {
  let r;
  try {
    r = await (await fetch("/api/remote/pair", { method: "POST",
      headers: {"Content-Type": "application/json"}, body: "{}" })).json();
  } catch (e) { r = { ok: false, message: "" + e }; }
  if (!r.ok) { note(r.message || "Could not start pairing", 6000); return; }
  // The QR code is an SVG this server drew itself (ui/qr.py). Parsed as an
  // image rather than inserted as markup, so nothing in it can run.
  const img = new Image();
  img.src = "data:image/svg+xml;base64," + btoa(r.svg);
  img.alt = "Pairing code"; img.width = 220; img.height = 220;
  $("pairqr").textContent = ""; $("pairqr").append(img);
  $("pairurl").textContent = r.address + "/pair";
  $("paircode").textContent = r.code;
  $("pairbox").style.display = "";
  let left = r.seconds, before = null;
  try { before = (await (await fetch("/api/remote")).json()).devices.length; }
  catch (e) {}
  clearInterval(pairTimer);
  pairTimer = setInterval(async () => {
    left -= 1;
    $("paircount").textContent = left > 0
      ? "Valid for " + left + " more seconds, for one device."
      : "Expired.";
    // Close the box as soon as a device has paired, so the code is not left
    // on screen looking usable after it has been used.
    if (left % 2 === 0) {
      try {
        const s = await (await fetch("/api/remote")).json();
        if (before !== null && s.devices.length > before) {
          closePairing(); showDevices(s.devices);
          note("Paired: " + s.devices[s.devices.length - 1].name, 5000);
          return;
        }
      } catch (e) {}
    }
    if (left <= 0) closePairing();
  }, 1000);
};
$("paircancel").onclick = async () => {
  closePairing();
  try { await fetch("/api/remote/pair/cancel", { method: "POST",
          headers: {"Content-Type": "application/json"}, body: "{}" }); }
  catch (e) {}
};

async function load() {
  let s;
  try { s = await (await fetch("/api/settings")).json(); }
  catch (e) { return note("Could not read settings"); }
  // Which background is chosen: the picture if there is one, else the
  // colour. Used to tick the right swatch.
  bgCurrent = s.wallpaper_image || s.wallpaper_design || s.wallpaper || "";
  if (s.language)  $("language").value  = s.language;
  $("deskicons").checked = s.desktop !== false;
  // Read, never assumed. A switch that shows a default instead of a reading
  // is a switch that lies the moment the two disagree — and the one that
  // matters here defaults the other way from the rest of them.
  $("companion").checked = s.companion !== false;
  $("proactive").checked = s.proactive === true;
  showRefused(s.proactive_dismissed || []);
  if (s.text_size) $("textsize").value = String(s.text_size);
  if (s.timezone)  $("timezone").value  = s.timezone;
  $("autotime").checked = !!s.auto_time;
  if (s.volume !== undefined && s.volume !== null) {
    $("volume").value = s.volume; $("volval").textContent = s.volume + "%";
  }
  $("cloudmode").value = s.cloud_mode || "off";
  if (s.confirm_level) $("confirmlevel").value = s.confirm_level;
  if (s.has_api_key) $("apikey").placeholder = "key is set";
  $("netstate").textContent = s.network || "Not connected";
}

async function loadDisplay() {
  let d;
  try { d = await (await fetch("/api/display")).json(); } catch (e) { return; }
  const screen = (d.screens || [])[0];
  if (!screen) { $("resolution").innerHTML = "<option>not available</option>"; return; }
  $("resolution").innerHTML = "";
  (screen.modes || []).forEach(m => {
    const o = document.createElement("option");
    o.value = m; o.textContent = m;
    if (m === screen.current) o.selected = true;
    $("resolution").appendChild(o);
  });
  const sc = parseFloat(screen.scale || "1");
  if (!isNaN(sc)) {
    const opt = [...$("scale").options].find(o => parseFloat(o.value) === sc);
    if (opt) opt.selected = true;
  }
}

// ---- this machine -----------------------------------------------------
function fact(k, v, sub) {
  return '<div class="fact"><div class="k">' + k + '</div><div class="v">' +
         v + (sub ? ' <small>' + sub + '</small>' : '') + '</div></div>';
}

// docs/PYTHON.md: which of the common libraries are there, and the one
// command that installs the rest. Plain text — no HTML from the server.
function pythonFact(py) {
  if (!py) return "";
  const libs = py.libraries || {};
  const missing = Object.keys(libs).filter(k => !libs[k]);
  const esc = t => String(t).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
  return fact("Python libraries",
    missing.length ? esc(missing.length + " missing: " + missing.join(", "))
                   : "all installed",
    missing.length ? esc("sudo bash /opt/osprime/shell/osprime-python-setup.sh")
                   : (py.venv ? "pip install works without sudo" : ""));
}

async function loadMachine() {
  let d;
  try { d = await (await fetch("/api/overview")).json(); }
  catch (e) { $("hwfacts").innerHTML = fact("Could not read this machine", "—"); return; }

  const m = d.machine || {}, gpu = m.gpu || {};
  $("hwfacts").innerHTML =
    fact("Processor", m.cpu || "unknown", (m.cores ? m.cores + " cores" : "")) +
    fact("Memory", m.ram_gb ? m.ram_gb + " GB" : "unknown") +
    fact("Free space", d.disk_free || "unknown",
         d.disk_used ? d.disk_used + " used" : "") +
    fact("Graphics", gpu.present ? (gpu.kind || "present") : "none found",
         gpu.present && gpu.vram_gb ? gpu.vram_gb + " GB" : "") +
    fact("Network", d.network || "not connected") +
    fact("System", "OSprime v" + (d.version || "?"),
         d.kernel ? "Linux " + d.kernel : "") +
    pythonFact(d.python);

  const now = d.running_now || {}, eng = d.engine || {};
  $("modelfacts").innerHTML =
    fact("Model", now.label || now.tier || "not running") +
    fact("Running on", eng.running_on === "gpu" ? "the graphics card"
                     : eng.running_on === "cpu" ? "the processor"
                     : "not running",
         eng.running_on === "unknown" ? "" : "") +
    fact("Context", (now.context || "?") + " tokens");

  // The "could do better" line and its Switch button are drawn by
  // loadEyes(), from /api/eyes, which also carries the switch's progress.
}

// ---- eyes: a second model, only for pictures ----------------------------
// Adding one downloads gigabytes and takes minutes, so it runs in the
// background and this polls. Text only — nothing here is inserted as HTML.
let eyesTimer = null;

function ago(iso) {
  const t = Date.parse(iso);
  if (!t) return "";
  const m = Math.round((Date.now() - t) / 60000);
  return m < 1 ? "just now" : m < 60 ? m + " min ago"
       : m < 1440 ? Math.round(m / 60) + " h ago" : Math.round(m / 1440) + " days ago";
}

async function loadEyes() {
  let d;
  try { d = await (await fetch("/api/eyes")).json(); }
  catch (e) { $("eyesnow").textContent = "Could not read this"; return; }
  const plan = d.plan || {}, now = plan.installed, btn = $("eyesbtn");
  const hint = [];

  if (plan.main_sees && !plan.main_is_vision) {
    // Qwen3.5 9B: the talking model has its own eyes (MODELS.md step 7).
    $("eyesnow").textContent = "The model above sees on its own";
    hint.push("Photos go straight to it — no second model, no waiting for a swap.");
    if (plan.unused) hint.push(plan.unused + " is still installed for going back to the " +
                       "previous model; it is not used now.");
    btn.dataset.action = "";
  } else if (now) {
    $("eyesnow").textContent = now.label + " — used only for pictures";
    hint.push("Runs on " + now.on + (now.mode === "swap" && now.on ===
              "the graphics card" ? ", taking turns with the model above" : "") + ".");
    const l = now.last_look;
    if (l && l.ok)
      hint.push("Last look " + ago(l.at) + ", took " + Math.round(l.total_s) + " s.");
    else if (l)
      hint.push("The last look, " + ago(l.at) + ", FAILED: " + (l.error || "unknown") +
                (l.main_back === false ? " — and the main model did not come back."
                                       : ". The conversation was not affected."));
    btn.textContent = "Remove eyes"; btn.className = "ghost";
    btn.dataset.action = "remove";
  } else {
    $("eyesnow").textContent = plan.main_is_vision
      ? "The model above sees as well (the older one-model setup)"
      : "None — the assistant cannot see pictures";
    if (plan.tier) {
      hint.push("Adds " + plan.label + ", on " + plan.on + ". " +
                (plan.download_mb ? "Downloads about " +
                   (plan.download_mb / 1024).toFixed(1) + " GB."
                 : "Already on this computer — no download."));
      if (plan.main_is_vision)
        hint.push("Better than today's setup: afterwards, switch the model " +
                  "above to the text model with: sudo bash " +
                  "/opt/osprime/shell/osprime-profile.sh --install");
      btn.textContent = "Add eyes"; btn.className = "";
      btn.dataset.action = "add";
      btn.disabled = plan.enough_disk === false;
      if (plan.enough_disk === false) hint.push("Not enough free disk space.");
    } else {
      hint.push(plan.why_not || "This computer cannot run a model that can see.");
      btn.dataset.action = "";
    }
  }
  $("eyeshint").textContent = hint.join(" ");
  btn.style.display = btn.dataset.action ? "" : "none";

  // Only shown when it is actionable. A permanent "you could do better"
  // that the user cannot act on is noise.
  const sw = d.switch || {};
  if (sw.better && sw.label) {
    $("modeladvice").style.display = "";
    $("modeladvicetext").textContent = "This computer could run " + sw.label + ".";
    $("modeladvicehint").textContent =
      (sw.download_mb ? "Downloads about " + (sw.download_mb / 1024).toFixed(1) + " GB. "
                      : "Already on this computer — no download. ") +
      "The current model stays on disk to go back to.";
    $("switchbtn").disabled = !!d.running || sw.enough_disk === false;
  } else {
    $("modeladvice").style.display = "none";
  }

  const box = $("eyesprogress");
  if (d.action) {
    box.style.display = "";
    const what = d.action === "add" ? "Adding eyes"
               : d.action === "switch" ? "Switching the model" : "Removing eyes";
    $("eyesphase").textContent = d.running
      ? what + "… " + (d.progress != null ? d.progress + "% downloaded" : "") +
        " (" + d.seconds + " s)"
      : d.ok ? what + " — done." : what + " — did not work. Nothing was changed.";
    $("eyeslog").textContent = (d.log || []).join("\n");
    btn.disabled = d.running;
  } else {
    box.style.display = "none";
  }
  if (d.action === "switch" && !d.running && d.ok) loadMachine();
  clearTimeout(eyesTimer);
  if (d.running) eyesTimer = setTimeout(loadEyes, 2000);
}

$("switchbtn").onclick = async () => {
  const d = await (await fetch("/api/eyes")).json(), sw = d.switch || {};
  if (!sw.better) return;
  const q = "Switch the assistant to " + sw.label + "?\n\n" +
    (sw.download_mb ? "This downloads about " + (sw.download_mb / 1024).toFixed(1) +
       " GB. On a phone connection or a metered plan, that costs money.\n\n"
     : "Everything it needs is already on this computer.\n\n") +
    "It is tested first — it has to load and call a tool — and only then " +
    "takes over. The assistant restarts once; a conversation in progress " +
    "is interrupted. The current model stays on disk to go back to.";
  if (!confirm(q)) return;
  $("switchbtn").disabled = true;
  let r;
  try { r = await (await fetch("/api/eyes/switch", {method: "POST"})).json(); }
  catch (e) { r = {ok: false, message: String(e)}; }
  if (!r.ok) { alert(r.message || "It could not be started."); $("switchbtn").disabled = false; }
  loadEyes();
};

$("eyesbtn").onclick = async () => {
  const btn = $("eyesbtn"), action = btn.dataset.action;
  if (!action) return;
  let q;
  if (action === "add") {
    const d = await (await fetch("/api/eyes")).json(), plan = d.plan || {};
    q = "Add " + plan.label + " so the assistant can see pictures?\n\n" +
        (plan.download_mb
          ? "This downloads about " + (plan.download_mb / 1024).toFixed(1) +
            " GB. On a phone connection or a metered plan, that costs money."
          : "Everything it needs is already on this computer.") +
        "\n\nIt is checked on a test picture before it is used. The " +
        "assistant restarts once at the end.";
  } else {
    q = "Remove the assistant's eyes?\n\nThe model files stay on this " +
        "computer, so adding them back later needs no download.";
  }
  if (!confirm(q)) return;
  btn.disabled = true;
  let r;
  try { r = await (await fetch("/api/eyes/" + action, {method: "POST"})).json(); }
  catch (e) { r = {ok: false, message: String(e)}; }
  if (!r.ok) { alert(r.message || "It could not be started."); btn.disabled = false; }
  loadEyes();
};

// ---- what the assistant remembers -------------------------------------
// Shown in the user's own words, as the assistant stored them, with a way
// to take each one back. A product that remembers you and gives you no way
// to see or erase what it remembers is not one worth selling.
function esc(s) {
  const d = document.createElement("div");
  d.textContent = s == null ? "" : String(s);
  return d.innerHTML;
}

async function loadMemory() {
  let d;
  try { d = await (await fetch("/api/memory")).json(); }
  catch (e) { $("memcount").textContent = "Could not read its memory"; return; }

  if (!d.ok) {
    $("memcount").textContent = "Could not read its memory";
    $("memlist").innerHTML = '<div class="empty">' +
      esc(d.message || "") + "</div>";
    $("forgetall").disabled = true;
    return;
  }
  $("memcount").textContent = d.count === 0 ? "It has not kept anything yet"
    : d.count === 1 ? "It has kept 1 thing" : "It has kept " + d.count + " things";
  $("forgetall").disabled = d.count === 0;

  if (!d.memories.length) {
    $("memlist").innerHTML =
      '<div class="empty">Things it learns from your conversations will ' +
      'appear here. A conversation has to end before it keeps anything.</div>';
    return;
  }
  $("memlist").innerHTML = d.memories.map(m =>
    '<div class="mem" data-id="' + m.id + '">' +
      '<span class="txt">' + esc(m.fact) + '</span>' +
      '<span class="when">' + esc(m.t || "") + '</span>' +
      '<button class="x">Forget</button>' +
    '</div>').join("");
}

$("memlist").onclick = async ev => {
  if (!ev.target.classList.contains("x")) return;
  const row = ev.target.closest(".mem");
  const r = await (await fetch("/api/memory/forget", {
    method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ id: parseInt(row.dataset.id, 10) })
  })).json();
  note(r.message || "Forgotten");
  loadMemory();
};

$("forgetall").onclick = async () => {
  // A real confirm(), because this one cannot be undone. Everything else in
  // this window is a setting you can set back.
  if (!confirm("Forget everything the assistant has learned about you?\n\n" +
               "This cannot be undone.")) return;
  const r = await (await fetch("/api/memory/forget", {
    method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ all: true })
  })).json();
  note(r.message || "Forgotten", 4000);
  loadMemory();
};

// ---- the background chooser -------------------------------------------
// Swatches, not a dropdown. Choosing a background is one of the three
// things this whole window exists for: the ones words are bad at.
//
// The design swatches are drawn in CSS from the same colours the real
// image uses, so opening this page costs no ImageMagick at all — the
// picture itself is only drawn when one is chosen, and after that it is
// already on disk.
const BG_SWATCH = {
  petrol:   "linear-gradient(#12232E,#060B12)",
  midnight: "linear-gradient(#101A2E,#04060B)",
  slate:    "linear-gradient(#2B2E33,#0D0E10)",
  depth:    "radial-gradient(circle at 50% 45%,#3A5A8C,#1A2333 60%,#07090D)",
  dusk:     "linear-gradient(135deg,#2B1055,#7597DE)",
  ember:    "linear-gradient(160deg,#5B1A28,#E0803C)",
  lagoon:   "linear-gradient(120deg,#0B3C49,#3ABFA0)",
  aurora:   "radial-gradient(circle at 50% 45%,#3ABFA0,#14213D 60%,#05070E)",
  grid:     "repeating-linear-gradient(#1B2836 0 1px,#0D1117 1px 14px)," +
            "repeating-linear-gradient(90deg,#1B2836 0 1px,#0D1117 1px 14px)",
  weave:    "repeating-linear-gradient(45deg,#16233C 0 6px,#101A2E 6px 12px)",
  dots:     "radial-gradient(#22303F 1.5px,#0B0B0B 1.6px)",
};

let bgCurrent = "";
let bgStart = "";

function bgTile(id, label, style, isImage) {
  return '<div class="bg' + (id === bgCurrent ? " on" : "") +
         '" data-pick="' + esc(id) + '">' +
         '<span class="sw" style="' + style + '"></span>' +
         '<span class="nm">' + esc(label) + "</span></div>";
}

async function loadBackgrounds() {
  let c;
  try { c = await (await fetch("/api/backgrounds")).json(); }
  catch (e) { $("bgpick").innerHTML = '<div class="empty">Could not read ' +
              "the backgrounds.</div>"; return; }

  const html = [];
  const fams = [["calm", "Calm"], ["bright", "Colourful"],
                ["geometric", "Geometric"]];
  for (const [fam, title] of fams) {
    const mine = (c.designs || []).filter(d => d.family === fam);
    if (!mine.length) continue;
    html.push('<div class="bggroup"><h3>' + title + "</h3><div class='bgrow'>" +
      mine.map(d => bgTile(d.name, d.label,
        "background:" + (BG_SWATCH[d.name] || "#12232E") +
        (d.name === "dots" ? ";background-size:10px 10px" : ""))).join("") +
      "</div></div>");
  }

  if ((c.shipped || []).length) {
    html.push('<div class="bggroup"><h3>Photographs</h3><div class="bgrow">' +
      c.shipped.map(p => bgTile(p.path, p.label,
        "background-image:url('/api/file?path=" +
        encodeURIComponent(p.path) + "')")).join("") + "</div></div>");
  }

  // A button, not a wall of every picture on the machine. See
  // system_tools.browse_pictures for why.
  html.push('<div class="bggroup"><h3>Your own picture</h3>' +
    '<button class="ghost" id="bgbrowse">Choose your own…</button>' +
    '<span class="hint" style="margin-top:6px">Opens your folders so you ' +
    'can pick one.</span></div>');
  bgStart = c.pictures_start || "";

  if (!c.can_draw) {
    html.unshift('<div class="empty">ImageMagick is not installed, so the ' +
                 "drawn designs cannot be made on this computer.</div>");
  }
  $("bgpick").innerHTML = html.join("");
}

// ---- picking your own picture -----------------------------------------
// A small file browser rather than the operating system's, because this
// window is a web page: a native dialog cannot hand a path back to it.
// One folder at a time, confined to the user's home by the endpoint.
let bgBrowseAt = "";

async function bgBrowse(path) {
  let d;
  try {
    d = await (await fetch("/api/browse", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ folder: path || bgStart })
    })).json();
  } catch (e) { note("Could not open that folder"); return; }

  bgBrowseAt = d.path;
  const rows = [];
  if (d.parent) {
    rows.push('<div class="mem" data-go="' + esc(d.parent) +
              '"><span class="txt">⤴ Back</span></div>');
  }
  (d.folders || []).forEach(f => rows.push(
    '<div class="mem" data-go="' + esc(f.path) + '">' +
    '<span class="txt">📁 ' + esc(f.name) + "</span></div>"));

  const pics = (d.images || []).map(i =>
    '<div class="bg" data-use="' + esc(i.path) + '">' +
    "<span class='sw' style=\"background-image:url('/api/file?path=" +
    encodeURIComponent(i.path) + "')\"></span>" +
    '<span class="nm">' + esc(i.name) + "</span></div>").join("");

  $("bgmodalwhere").textContent = d.label || d.path;
  $("bgmodalbody").innerHTML =
    (rows.length ? '<div class="mems" style="margin-bottom:12px">' +
                   rows.join("") + "</div>" : "") +
    (pics ? '<div class="bgrow">' + pics + "</div>"
          : '<div class="empty">' + esc(d.note || "No pictures in here.") +
            "</div>");
  $("bgmodal").classList.add("on");
}

$("bgmodalbody").onclick = async ev => {
  const go = ev.target.closest("[data-go]");
  if (go) { bgBrowse(go.dataset.go); return; }
  const use = ev.target.closest("[data-use]");
  if (!use || use.classList.contains("busy")) return;
  use.classList.add("busy");
  const r = await (await fetch("/api/settings", {
    method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ key: "wallpaper", value: use.dataset.use })
  })).json();
  use.classList.remove("busy");
  note(r.message || (r.ok ? "Background changed" : "Could not change it"));
  if (r.ok) {
    bgCurrent = use.dataset.use;
    $("bgmodal").classList.remove("on");
    loadBackgrounds();
  }
};

$("bgmodalclose").onclick = () => $("bgmodal").classList.remove("on");
$("bgmodal").onclick = ev => {
  if (ev.target === $("bgmodal")) $("bgmodal").classList.remove("on");
};

$("bgpick").onclick = async ev => {
  if (ev.target.id === "bgbrowse") { bgBrowse(); return; }
  const tile = ev.target.closest(".bg");
  if (!tile || tile.classList.contains("busy")) return;
  // Drawing a 4K background takes a moment the first time. Saying so beats
  // a click that appears to do nothing.
  tile.classList.add("busy");
  const r = await (await fetch("/api/settings", {
    method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ key: "wallpaper", value: tile.dataset.pick })
  })).json();
  tile.classList.remove("busy");
  note(r.message || (r.ok ? "Background changed" : "Could not change it"));
  if (r.ok) {
    bgCurrent = tile.dataset.pick;
    document.querySelectorAll("#bgpick .bg").forEach(
      b => b.classList.toggle("on", b === tile));
  }
};

// ---- cameras and microphones ------------------------------------------
// Listing only. Nothing here opens a device, and the page says so — a
// capture control must not exist before the indicator that shows it is
// running, or the machine has a camera nobody can tell is on.
async function loadCapture() {
  let d;
  try { d = await (await fetch("/api/devices")).json(); }
  catch (e) { $("capdevs").innerHTML = '<div class="empty">Could not read ' +
              'the devices.</div>'; return; }

  const rows = [];
  (d.cameras || []).forEach(c => rows.push(
    '<div class="mem"><span class="txt">' + esc(c.name) +
    '</span><span class="when">camera</span></div>'));
  (d.microphones || []).forEach(m => rows.push(
    '<div class="mem"><span class="txt">' + esc(m.name) +
    '</span><span class="when">microphone</span></div>'));
  // The notes are the honest part: "there is no camera" and "there is a
  // camera and I cannot read its name" are different facts.
  (d.notes || []).forEach(n => rows.push(
    '<div class="empty">' + esc(n) + '</div>'));

  $("capdevs").innerHTML = rows.length ? rows.join("")
    : '<div class="empty">Nothing found.</div>';

  loadCaptureState();
}

// Polled while this page is open, because it is a fact about right now and
// a value read once at startup would be a value that was true earlier.
let capTimer = null;
async function loadCaptureState() {
  let c;
  try { c = await (await fetch("/api/capture")).json(); }
  catch (e) { $("capnow").textContent = "Could not check what is open."; return; }

  $("allowmic").checked = c.allowed.microphone !== false;
  $("allowcam").checked = c.allowed.camera !== false;

  const live = [];
  if (c.camera.in_use) live.push("camera (" + (c.camera.by.join(", ") || "unknown") + ")");
  if (c.microphone.in_use) live.push("microphone (" + (c.microphone.by.join(", ") || "unknown") + ")");
  $("capnow").innerHTML = live.length
    ? "<b>In use right now:</b> " + esc(live.join(" and "))
    : "Nothing is using the camera or the microphone right now.";

  clearTimeout(capTimer);
  if (document.getElementById("page-devices").classList.contains("on")) {
    capTimer = setTimeout(loadCaptureState, 3000);
  }

  // Why voice does not work, when it does not. "Unavailable" is not
  // something a person can act on; "install this package, then run that"
  // is. The two halves go missing for different reasons and have
  // different fixes, so the message names which.
  try {
    const v = await fetch("/api/voice/status").then(r => r.json());
    const why = [v.stt_why, v.tts_why].filter(Boolean);
    $("voicerow").style.display = why.length ? "" : "none";
    $("voicewhy").innerHTML = why.map(w =>
      '<span class="hint" style="margin-top:0">' + esc(w) + '</span>').join("");
  } catch (e) { /* leave the row hidden */ }
}

$("allowmic").onchange = e => { apply("allow_microphone", e.target.checked);
                                setTimeout(loadCaptureState, 400); };
$("allowcam").onchange = e => { apply("allow_camera", e.target.checked);
                                setTimeout(loadCaptureState, 400); };

// ---- drives -----------------------------------------------------------
async function loadDrives() {
  let d;
  try { d = await (await fetch("/api/storage")).json(); }
  catch (e) { $("drives").innerHTML = '<div class="empty">Could not read ' +
              "the drives.</div>"; return; }
  const ds = d.drives || [];
  $("drives").innerHTML = ds.length
    ? ds.map(x => '<div class="mem"><span class="txt">' +
        esc(x.label || x.device) + "</span><span class='when'>" +
        esc(x.size || "") + (x.mounted_at ? " · " + esc(x.mounted_at) : "") +
        "</span></div>").join("")
    : '<div class="empty">No drives found.</div>';
}

// ---- applications -----------------------------------------------------
// The same functions the assistant calls, through the same endpoints. A
// button here cannot do anything a person could not also ask for.
async function loadApps() {
  let d;
  try { d = await (await fetch("/api/apps")).json(); }
  catch (e) { $("applist").innerHTML = '<div class="empty">Could not read ' +
              'the list of applications.</div>'; return; }

  const apps = d.apps || [];
  if (!apps.length) {
    $("applist").innerHTML = '<div class="empty">Nothing installed yet.</div>';
    return;
  }
  $("applist").innerHTML = apps.map(a =>
    '<div class="mem" data-id="' + esc(a.id) + '">' +
      '<span class="txt">' + esc(a.name) + '</span>' +
      '<span class="when">' + esc(a.size || "") + '</span>' +
      (a.removable
        ? '<button class="x">Remove</button>'
        : '<span class="when">part of OSprime</span>') +
    '</div>').join("");
}

$("applist").onclick = async ev => {
  if (!ev.target.classList.contains("x")) return;
  const row = ev.target.closest(".mem");
  const name = row.querySelector(".txt").textContent;
  if (!confirm("Remove " + name + " from this computer?")) return;
  ev.target.disabled = true; ev.target.textContent = "…";
  const r = await (await fetch("/api/apps/uninstall", {
    method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ app_id: row.dataset.id })
  })).json();
  note(r.message || "Removed", 6000);
  loadApps();
};

async function searchApps() {
  const q = $("appq").value.trim();
  if (!q) return;
  const b = $("appsearch");
  b.disabled = true; b.textContent = "Searching…";
  $("appresults").innerHTML = '<div class="empty">Looking…</div>';
  let d;
  try {
    d = await (await fetch("/api/apps/search", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ query: q })
    })).json();
  } catch (e) { d = { results: [], note: "" + e }; }
  b.disabled = false; b.textContent = "Search";

  const rs = d.results || [];
  if (!rs.length) {
    // No second catalogue to offer, so do not imply there is one.
    $("appresults").innerHTML = '<div class="empty">' +
      esc(d.note || d.message || "Nothing in the catalogue matches that.") +
      "</div>";
    return;
  }
  $("appresults").innerHTML = rs.map(a =>
    '<div class="mem" data-id="' + esc(a.id) + '">' +
      '<span class="txt"><b>' + esc(a.name) + '</b><br>' +
        '<span style="color:var(--dim);font-size:12px">' +
        esc(a.what_it_is || "") + '</span></span>' +
      '<button class="x add">Install</button>' +
    '</div>').join("");
}

$("appsearch").onclick = searchApps;
$("appq").onkeydown = e => { if (e.key === "Enter") searchApps(); };

$("appresults").onclick = async ev => {
  if (!ev.target.classList.contains("add")) return;
  const row = ev.target.closest(".mem");
  ev.target.disabled = true; ev.target.textContent = "Installing…";
  // Said out loud, because the first install pulls a shared runtime and
  // can take minutes. A button that looks stuck is how people conclude it
  // is broken and click it again.
  note("Installing — the first one takes a few minutes.", 30000);
  let r;
  try {
    r = await (await fetch("/api/apps/install", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ app_id: row.dataset.id })
    })).json();
  } catch (e) { r = { ok: false, message: "" + e }; }
  note(r.message || (r.ok ? "Installed" : "Could not install"), 10000);
  if (r.ok) { row.remove(); loadApps(); }
  else { ev.target.disabled = false; ev.target.textContent = "Install"; }
};

// ---- storage ----------------------------------------------------------
async function loadStorage() {
  let d;
  try { d = await (await fetch("/api/storage")).json(); }
  catch (e) { $("diskfacts").innerHTML = fact("Could not read the disk", "—"); return; }

  const u = (d.usage || {}).disk || {};
  const apps = (d.usage || {}).applications_size;
  $("diskfacts").innerHTML =
    fact("Free", u.free || "unknown") +
    fact("Used", u.used || "unknown", u.used_percent || "") +
    fact("Total", u.total || "unknown") +
    // A fact, not a suggestion. These are the user's own applications.
    (apps ? fact("Applications", apps, "programs you installed") : "");

  const big = (d.usage || {}).largest_folders_in_home || [];
  $("bigfolders").innerHTML = big.length
    ? big.map(b => '<div class="mem"><span class="txt">' + esc(b.folder) +
        '</span><span class="when">' + esc(b.size) + '</span></div>').join("")
    : '<div class="empty">Nothing large enough to be worth listing.</div>';

  const rec = (d.usage || {}).safe_to_delete || [];
  $("reclaim").innerHTML = rec.length
    ? rec.map(r => '<div class="mem"><span class="txt">' + esc(r.what_it_is) +
        '</span><span class="when">' + esc(r.size) + '</span></div>').join("")
    : '<div class="empty">Nothing worth clearing right now.</div>';
}

// ---- rollback ---------------------------------------------------------
async function loadBackups() {
  let d;
  try { d = await (await fetch("/api/backups")).json(); } catch (e) { d = {}; }
  const b = (d.backups || [])[0];
  if (!b) {
    $("rbstate").innerHTML = "No previous version is kept on this machine " +
      '<span class="hint">There will be one after the next update.</span>';
    $("rbbtn").disabled = true;
    return;
  }
  $("rbstate").innerHTML = "Previous version, saved " + esc(b) +
    '<span class="hint">Puts the code back as it was and restarts. ' +
    'Your files and settings are not touched.</span>';
  $("rbbtn").disabled = false;
}

$("rbbtn").onclick = async () => {
  if (!confirm("Go back to the previous version of OSprime?\n\n" +
               "The screen will restart in a moment.")) return;
  const b = $("rbbtn");
  b.disabled = true; b.textContent = "Going back…";
  let r;
  try {
    r = await (await fetch("/api/rollback", {method: "POST"})).json();
  } catch (e) { r = {ok: false, message: "" + e}; }
  note(r.message || (r.ok ? "Done" : "Could not roll back"), 8000);
  if (r.ok) setTimeout(() => location.reload(), 4000);
  else { b.disabled = false; b.textContent = "Go back"; }
};

// ---- wiring -----------------------------------------------------------
$("scale").onchange      = e => apply("scale", e.target.value);
$("textsize").onchange   = e => apply("text_size", e.target.value);
$("resolution").onchange = e => apply("resolution", e.target.value);
$("language").onchange   = e => apply("language", e.target.value);
$("deskicons").onchange  = e => apply("desktop", e.target.checked);
$("companion").onchange  = e => apply("companion", e.target.checked);
$("proactive").onchange  = e => apply("proactive", e.target.checked);

// What the assistant has been told to stop mentioning, and the only way to
// take that back. The row hides itself when there is nothing in it: an
// empty "things you refused" box on a fresh machine is a question nobody
// asked being answered.
const REFUSED_NAMES = {disk: "when the disk is nearly full"};
let refused = [];
function showRefused(list) {
  refused = list || [];
  $("refusedrow").style.display = refused.length ? "" : "none";
  $("refusedlist").textContent =
    refused.map(k => REFUSED_NAMES[k] || k).join(", ");
}
$("refusedclear").onclick = async () => {
  const b = $("refusedclear");
  b.disabled = true;
  try {
    for (const kind of refused.slice()) {
      const r = await (await fetch("/api/proactive/dismiss", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({kind, restore: true})
      })).json();
      showRefused(r.dismissed || []);
    }
    note("It may mention these again");
  } catch (e) { note("Could not change that: " + e); }
  b.disabled = false;
};
$("timezone").onchange   = e => apply("timezone", e.target.value.trim());
$("autotime").onchange   = e => apply("auto_time", e.target.checked);
$("clock").onchange      = e => apply("time", e.target.value.trim());
$("cloudmode").onchange  = e => apply("cloud_mode", e.target.value);
$("confirmlevel").onchange = e => apply("confirm_level", e.target.value);
$("apikey").onchange     = e => { apply("api_key", e.target.value); e.target.value = ""; };
$("volume").oninput      = e => $("volval").textContent = e.target.value + "%";
$("volume").onchange     = e => apply("volume", parseInt(e.target.value, 10));

async function joinNetwork(ssid, password, row) {
  note("Connecting to " + ssid + "…", 20000);
  let r;
  try {
    r = await (await fetch("/api/wifi/connect", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ssid, password: password || ""})
    })).json();
  } catch (e) { r = {ok: false, message: "" + e}; }
  note(r.message || (r.ok ? "Connected" : "Could not connect"), 6000);
  if (r.ok) { if (row) row.remove(); load(); $("scan").click(); }
  return r.ok;
}

// Asking for the password inline rather than through a browser prompt():
// prompt() is blocked or suppressed in an app window, which left clicking a
// secured network doing nothing at all with no way to tell why.
function askPassword(el, ssid) {
  if (el.querySelector("input[type=password]")) return;
  const box = document.createElement("div");
  box.style.cssText = "display:flex;gap:8px;margin-top:8px;width:100%";
  const inp = document.createElement("input");
  inp.type = "password"; inp.placeholder = "Password for " + ssid;
  inp.style.flex = "1";
  const go = document.createElement("button");
  go.textContent = "Join";
  const submit = async () => {
    if (!inp.value) { inp.focus(); return; }
    go.disabled = true; go.textContent = "…";
    const ok = await joinNetwork(ssid, inp.value, null);
    if (!ok) { go.disabled = false; go.textContent = "Join"; inp.select(); }
  };
  go.onclick = submit;
  inp.onkeydown = e => { if (e.key === "Enter") submit(); };
  box.append(inp, go);
  el.appendChild(box);
  inp.focus();
}

$("scan").onclick = async () => {
  if ($("scan").disabled) return;
  $("scan").disabled = true; $("scan").textContent = "Scanning…";
  const box = $("nets"); box.innerHTML = "";
  try {
    const nets = await (await fetch("/api/wifi/scan")).json();
    (nets.networks || []).forEach(n => {
      const el = document.createElement("div");
      el.className = "net";
      el.style.flexWrap = "wrap";
      const tags = [];
      if (n.active) tags.push("connected");
      else if (n.saved) tags.push("saved");
      if (n.secured) tags.push("locked");
      el.innerHTML = "<span>" + n.ssid + "</span>" +
        "<span class='sig'>" + tags.join(" · ") + "</span>" +
        "<span class='sig'>" + (n.signal || "") + "%</span>";
      el.onclick = () => {
        if (n.active) return;
        // A saved network already has its password stored.
        if (!n.secured || n.saved) joinNetwork(n.ssid, "", null);
        else askPassword(el, n.ssid);
      };
      box.appendChild(el);
    });
    if (!(nets.networks || []).length) note(nets.message || "No networks found", 6000);
  } catch (e) { note("Scan failed: " + e); }
  $("scan").disabled = false; $("scan").textContent = "Scan for networks";
};

$("joinhidden").onclick = () => {
  const ssid = $("hidden").value.trim();
  if (!ssid) return;
  askPassword($("joinhidden").parentElement, ssid);
};

$("updbtn").onclick = async () => {
  const b = $("updbtn");
  b.disabled = true; b.textContent = "Checking…";
  let info;
  try { info = await (await fetch("/api/update/check")).json(); }
  catch (e) { note("Could not reach the update server"); b.disabled = false;
              b.textContent = "Check for updates"; return; }
  if (!info.available) {
    note(info.reason ? "Could not reach the update server" : "Already up to date");
    b.disabled = false; b.textContent = "Check for updates"; return;
  }
  b.textContent = "Install " + info.latest;
  b.disabled = false;
  b.onclick = async () => {
    b.disabled = true; b.textContent = "Installing…";
    const r = await (await fetch("/api/update/install", {method: "POST"})).json();
    note(r.message || "Done", 6000);
    if (r.ok) setTimeout(() => location.reload(), 2000);
    else { b.disabled = false; b.textContent = "Retry"; }
  };
};

loadWho();
show(location.hash.slice(1) || "home");
load();
loadDisplay();
</script>
"""
