"""The Notes app — ~/Memory, the person's notes and the assistant's memory
in one place (agent/vault.py). Asked for by Ehsan, 4 October: "like
Obsidian", a simple built-in app whose folder Obsidian can also open.

Served by web.py at /notes, opened as its own window by
shell/osprime-notes.sh. Plain Markdown on disk; this page only reads and
writes files through /api/notes/*, which go through agent/vault.py.

What it does: a list of notes (About me first, then People, Projects,
Places, the rest, the Journal newest first), search, an editor that saves
by itself, a reading view where [[links]] are clickable, completion when
typing [[, and "Linked from" — the notes that point here. A paired phone
gets the same page read-only.

Every name and every line is put on the page with textContent or through
esc(): a note says whatever its author wrote, and the assistant writes too.
"""

PAGE = r"""<!DOCTYPE html>
<html lang="{{LANG}}" dir="ltr">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Notes — OSprime</title>
<style>
  :root { --bg:#0d1117; --panel:#161b22; --line:#21262d; --text:#e6edf3;
          --dim:#8b949e; --accent:#2d6cdf; --link:#7aa2f7; --missing:#8b949e; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--text); height:100vh;
         display:flex; flex-direction:column;
         font-family:system-ui,'Noto Sans','Noto Sans Arabic',sans-serif; }
  header { padding:10px 16px; background:var(--panel); border-bottom:1px solid var(--line);
           display:flex; align-items:center; gap:10px; }
  header .logo { font-size:17px; font-weight:700; color:var(--accent); }
  header .sub { color:var(--dim); font-size:12px; flex:1; }
  button { background:#21262d; color:var(--text); border:1px solid #30363d; border-radius:7px;
           padding:5px 12px; font-size:13px; cursor:pointer; }
  button:hover { background:#2a313c; }
  button.primary { background:var(--accent); border-color:var(--accent); color:#fff; }
  button:disabled { opacity:.5; cursor:default; }
  #body { flex:1; display:flex; min-height:0; }
  aside { width:260px; flex:none; background:var(--panel); border-inline-end:1px solid var(--line);
          display:flex; flex-direction:column; min-height:0; }
  #search { margin:10px; padding:7px 10px; border-radius:7px; border:1px solid #30363d;
            background:var(--bg); color:var(--text); font-size:13px; }
  #list { flex:1; overflow-y:auto; padding:0 6px 10px; }
  .group { color:var(--dim); font-size:11px; text-transform:uppercase; letter-spacing:.05em;
           margin:12px 8px 4px; cursor:pointer; user-select:none; }
  .item { padding:6px 10px; border-radius:6px; font-size:13px; cursor:pointer;
          white-space:nowrap; overflow:hidden; text-overflow:ellipsis; unicode-bidi:plaintext; }
  .item:hover { background:#1c2330; }
  .item.on { background:var(--accent); color:#fff; }
  .item .line { display:block; color:var(--dim); font-size:11px; overflow:hidden; text-overflow:ellipsis; }
  .item.on .line { color:#dde6ff; }
  main { flex:1; display:flex; flex-direction:column; min-width:0; }
  #bar { display:flex; align-items:center; gap:8px; padding:10px 18px; border-bottom:1px solid var(--line); }
  #title { flex:1; font-size:18px; font-weight:600; unicode-bidi:plaintext; cursor:text;
           white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  #state { color:var(--dim); font-size:12px; }
  #pane { flex:1; display:flex; min-height:0; }
  #edit { flex:1; resize:none; border:0; outline:none; background:var(--bg); color:var(--text);
          padding:18px 22px; font:14px/1.6 ui-monospace,Consolas,'Noto Sans Mono','Noto Sans Arabic',monospace;
          unicode-bidi:plaintext; }
  #view { flex:1; overflow-y:auto; padding:18px 26px; font-size:15px; line-height:1.65; }
  #view p, #view li, #view h1, #view h2, #view h3 { unicode-bidi:plaintext; }
  #view h1 { font-size:22px; } #view h2 { font-size:18px; } #view h3 { font-size:16px; }
  #view code { background:#1c2330; padding:1px 5px; border-radius:4px; font-size:13px; }
  #view pre { background:#1c2330; padding:10px 12px; border-radius:8px; overflow-x:auto; }
  #view a, .wl { color:var(--link); cursor:pointer; text-decoration:none; }
  .wl.missing { color:var(--missing); border-bottom:1px dashed var(--missing); }
  #view ul { padding-inline-start:22px; }
  #side { width:250px; flex:none; border-inline-start:1px solid var(--line); overflow-y:auto;
          padding:14px; font-size:13px; }
  #side h3 { font-size:12px; color:var(--dim); text-transform:uppercase; letter-spacing:.05em; margin:0 0 8px; }
  #side .bl { padding:6px 8px; border-radius:6px; cursor:pointer; margin-bottom:4px; background:#161b22; }
  #side .bl .t { color:var(--link); } #side .bl .l { color:var(--dim); font-size:12px; unicode-bidi:plaintext; }
  #empty { margin:auto; color:var(--dim); text-align:center; max-width:420px; line-height:1.6; }
  #complete { position:fixed; display:none; background:var(--panel); border:1px solid #30363d;
              border-radius:8px; box-shadow:0 8px 24px #0008; max-height:220px; overflow-y:auto;
              min-width:200px; z-index:10; }
  #complete div { padding:6px 12px; font-size:13px; cursor:pointer; unicode-bidi:plaintext; }
  #complete div.on, #complete div:hover { background:var(--accent); color:#fff; }
  #toast { position:fixed; bottom:16px; left:50%; transform:translateX(-50%); background:#21262d;
           border:1px solid #30363d; padding:8px 14px; border-radius:8px; font-size:13px; display:none; }
  .ro #edit, .ro #editbtn, .ro #newbtn, .ro #delbtn { display:none; }
  /* the graph (phase 3) */
  #gpane { flex:1; display:none; flex-direction:column; min-height:0; }
  #gbar { display:flex; align-items:center; gap:6px; padding:8px 14px; border-bottom:1px solid var(--line);
          flex-wrap:wrap; }
  .chip { font-size:12px; padding:3px 10px; border-radius:12px; border:1px solid #30363d; cursor:pointer;
          user-select:none; color:var(--dim); }
  .chip.on { color:var(--text); border-color:#58a6ff; background:#1f2a3a; }
  .chip i { display:inline-block; width:8px; height:8px; border-radius:50%; margin-inline-end:5px; }
  #gsearch { margin-inline-start:auto; padding:5px 9px; border-radius:7px; border:1px solid #30363d;
             background:var(--bg); color:var(--text); font-size:12px; width:180px; }
  #gwrap { flex:1; position:relative; min-height:0; }
  #gwrap canvas, #local { display:block; width:100%; height:100%; cursor:grab; }
  #ghint { position:absolute; bottom:10px; left:14px; color:var(--dim); font-size:11px; pointer-events:none; }
  #local { height:200px; border:1px solid var(--line); border-radius:8px; margin-bottom:14px; background:#0b0f14; }
  body.graph #gpane { display:flex; } body.graph #bar, body.graph #pane { display:none; }
  #graphbtn.on { background:#1f2a3a; border-color:#58a6ff; }
</style>
<header>
  <span class="logo">Notes</span>
  <span class="sub" id="where">~/Memory</span>
  <button id="graphbtn" title="See how your notes connect">Graph</button>
  <button id="newbtn" class="primary">New note</button>
</header>
<div id="body">
  <aside>
    <input id="search" placeholder="Search notes" autocomplete="off">
    <div id="list"></div>
  </aside>
  <main>
    <div id="bar">
      <div id="title"></div>
      <span id="state"></span>
      <button id="editbtn">Edit</button>
      <button id="delbtn" title="Move this note to the trash">Delete</button>
    </div>
    <div id="gpane">
      <div id="gbar">
        <span class="chip on" data-f="People"><i style="background:#58a6ff"></i>People</span>
        <span class="chip on" data-f="Projects"><i style="background:#3fb950"></i>Projects</span>
        <span class="chip on" data-f="Places"><i style="background:#f0883e"></i>Places</span>
        <span class="chip on" data-f="other"><i style="background:#a371f7"></i>Other notes</span>
        <span class="chip" data-f="Journal"><i style="background:#6e7681"></i>Journal</span>
        <span class="chip on" data-f="missing"><i style="border:1px solid #8b949e"></i>Not written yet</span>
        <input id="gsearch" placeholder="Find in the graph" autocomplete="off">
      </div>
      <div id="gwrap"><canvas id="gcanvas"></canvas>
        <div id="ghint">Click a note to see its links · double-click to open it · drag, scroll to zoom</div></div>
    </div>
    <div id="pane">
      <div id="empty">Choose a note on the left, or make a new one.<br><br>
        This is your memory and the assistant's: what it keeps about you is
        written here, and what you write here it knows. Link notes with
        <b>[[a name]]</b>.</div>
      <textarea id="edit" spellcheck="false" style="display:none" dir="auto"></textarea>
      <div id="view" style="display:none" dir="auto"></div>
      <div id="side" style="display:none">
        <canvas id="local" title="This note and the notes next to it"></canvas>
        <h3>Linked from</h3><div id="backlinks"></div>
        <h3 style="margin-top:16px">Links to</h3><div id="links"></div>
      </div>
    </div>
  </main>
</div>
<div id="complete"></div>
<div id="toast"></div>
<script>
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c =>
  ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
let NOTES = [], CUR = null, MTIME = 0, DIRTY = false, EDITING = false, RO = false, timer = null;

function toast(msg, ms = 2600) {
  const t = $("toast"); t.textContent = msg; t.style.display = "block";
  clearTimeout(t._h); t._h = setTimeout(() => t.style.display = "none", ms);
}
async function api(path, body) {
  const opt = body === undefined ? {} : {method: "POST",
    headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)};
  return (await fetch(path, opt)).json();
}

// ---- the list ---------------------------------------------------------
const ORDER = ["", "People", "Projects", "Places"];
async function loadList() {
  const d = await api("/api/notes");
  NOTES = d.notes || [];
  if (d.root) $("where").textContent = d.root + " — plain Markdown; Obsidian can open this folder too";
  drawList();
}
function drawList() {
  const q = $("search").value.trim();
  if (q) return searchList(q);
  const box = $("list"); box.textContent = "";
  const groups = {};
  for (const n of NOTES) (groups[n.folder] = groups[n.folder] || []).push(n);
  const names = Object.keys(groups).sort((a, b) => {
    const ia = ORDER.indexOf(a), ib = ORDER.indexOf(b);
    if (a === "Journal") return 1; if (b === "Journal") return -1;
    return (ia < 0 ? 9 : ia) - (ib < 0 ? 9 : ib) || a.localeCompare(b);
  });
  for (const g of names) {
    let items = groups[g];
    if (g === "Journal") items = items.slice().sort((a, b) => b.title.localeCompare(a.title));
    else items = items.slice().sort((a, b) => a.title === "About me" ? -1 : b.title === "About me" ? 1
                                     : a.title.localeCompare(b.title));
    const h = document.createElement("div"); h.className = "group";
    h.textContent = g || "Notes";
    box.append(h);
    const wrap = document.createElement("div");
    if (g === "Journal" && items.length > 7) {
      wrap.dataset.more = "1";
      h.textContent += " (" + items.length + ")";
    }
    items.forEach((n, i) => {
      const it = itemEl(n.title, "", n.path);
      if (wrap.dataset.more && i >= 7) it.style.display = "none";
      wrap.append(it);
    });
    h.onclick = () => wrap.querySelectorAll(".item").forEach(e => e.style.display = "");
    box.append(wrap);
  }
}
function itemEl(title, line, path) {
  const it = document.createElement("div");
  it.className = "item" + (CUR === path ? " on" : "");
  it.textContent = title;
  if (line) { const l = document.createElement("span"); l.className = "line"; l.textContent = line; it.append(l); }
  it.onclick = () => openNote(path);
  return it;
}
async function searchList(q) {
  const d = await api("/api/notes/search?q=" + encodeURIComponent(q));
  const box = $("list"); box.textContent = "";
  if (!(d.results || []).length) {
    const e = document.createElement("div"); e.className = "group"; e.textContent = "Nothing found";
    box.append(e); return;
  }
  for (const r of d.results) box.append(itemEl(r.title, r.line, r.path));
}
$("search").oninput = () => { clearTimeout($("search")._t); $("search")._t = setTimeout(drawList, 200); };

// ---- one note -------------------------------------------------------------
async function openNote(path, edit) {
  if (DIRTY && !(await save())) return;
  const d = await api("/api/notes/read?path=" + encodeURIComponent(path));
  if (!d.ok) { toast(d.message || "Could not open it"); return; }
  CUR = d.path; MTIME = d.mtime; DIRTY = false;
  location.hash = encodeURIComponent(CUR);
  $("empty").style.display = "none"; $("side").style.display = "";
  $("title").textContent = d.title;
  $("edit").value = d.text;
  $("state").textContent = "";
  drawSide(d);
  setMode(!RO && (edit || false));
  loadGraph();
  drawList();
}
function drawSide(d) {
  const bl = $("backlinks"); bl.textContent = "";
  if (!d.backlinks.length) bl.append(dimText("No note links here yet."));
  for (const b of d.backlinks) {
    const e = document.createElement("div"); e.className = "bl";
    const t = document.createElement("div"); t.className = "t"; t.textContent = b.title;
    const l = document.createElement("div"); l.className = "l"; l.textContent = b.line;
    e.append(t, l); e.onclick = () => openNote(b.path); bl.append(e);
  }
  const lk = $("links"); lk.textContent = "";
  if (!d.links.length) lk.append(dimText("None."));
  for (const l of d.links) {
    const e = document.createElement("div"); e.className = "bl";
    const t = document.createElement("span"); t.className = "wl" + (l.exists ? "" : " missing");
    t.textContent = l.title; e.append(t); e.onclick = () => follow(l.title); lk.append(e);
  }
}
function dimText(s) { const e = document.createElement("div"); e.style.color = "var(--dim)"; e.textContent = s; return e; }

function setMode(edit) {
  EDITING = edit;
  $("edit").style.display = edit ? "" : "none";
  $("view").style.display = edit ? "none" : "";
  $("editbtn").textContent = edit ? "Done" : "Edit";
  if (!edit) render();
  else $("edit").focus();
}
$("editbtn").onclick = async () => { if (EDITING && DIRTY) await save(); setMode(!EDITING); };
$("view").ondblclick = () => { if (!RO) setMode(true); };

// ---- Markdown, small and safe: everything escaped first --------------------
function inline(s) {
  s = esc(s);
  s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
  s = s.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>").replace(/(^|[^*])\*([^*\s][^*]*)\*/g, "$1<i>$2</i>");
  s = s.replace(/\[\[([^\]|#]+)(?:#[^\]|]*)?(?:\|([^\]]+))?\]\]/g, (m, t, label) => {
    const exists = NOTES.some(n => n.title.toLowerCase() === t.trim().toLowerCase());
    return '<span class="wl' + (exists ? "" : " missing") + '" data-note="' + t.trim() + '">' +
           (label || t) + "</span>";
  });
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a data-url="$2">$1</a>');
  return s;
}
function render() {
  let text = $("edit").value.replace(/^---\n[\s\S]*?\n---\n/, "");
  const out = []; let list = null, code = null, para = [];
  const flush = () => { if (para.length) { out.push("<p>" + para.map(inline).join(" ") + "</p>"); para = []; } };
  for (const line of text.split("\n")) {
    if (code !== null) {
      if (line.startsWith("```")) { out.push("<pre><code>" + esc(code.join("\n")) + "</code></pre>"); code = null; }
      else code.push(line);
      continue;
    }
    if (line.startsWith("```")) { flush(); if (list) { out.push("</" + list + ">"); list = null; } code = []; continue; }
    const m = line.match(/^\s*([-*]|\d+\.)\s+(.*)$/);
    if (m) {
      flush();
      const kind = /\d/.test(m[1]) ? "ol" : "ul";
      if (list !== kind) { if (list) out.push("</" + list + ">"); out.push("<" + kind + ">"); list = kind; }
      out.push("<li>" + inline(m[2]) + "</li>"); continue;
    }
    if (list) { out.push("</" + list + ">"); list = null; }
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) { flush(); out.push("<h" + h[1].length + ">" + inline(h[2]) + "</h" + h[1].length + ">"); }
    else if (line.trim()) para.push(line);
    else flush();
  }
  flush();
  if (list) out.push("</" + list + ">");
  if (code !== null) out.push("<pre><code>" + esc(code.join("\n")) + "</code></pre>");
  $("view").innerHTML = out.join("\n") || '<p style="color:var(--dim)">Empty. Double-click to write.</p>';
}
$("view").onclick = async ev => {
  const wl = ev.target.closest(".wl");
  if (wl) return follow(wl.dataset.note);
  const a = ev.target.closest("a[data-url]");
  if (a) { await api("/api/open", {url: a.dataset.url}); }
};
async function follow(title) {
  const n = NOTES.find(n => n.title.toLowerCase() === title.toLowerCase());
  if (n) return openNote(n.path);
  if (RO) { toast("There is no note called " + title + " yet."); return; }
  const r = await api("/api/notes/new", {title});
  if (!r.ok) { toast(r.message); return; }
  await loadList(); openNote(r.path, true);
}

// ---- saving ----------------------------------------------------------------
$("edit").oninput = () => {
  DIRTY = true; $("state").textContent = "Editing…";
  clearTimeout(timer); timer = setTimeout(save, 900);
  complete();
};
async function save(force) {
  if (!CUR || !DIRTY) return true;
  clearTimeout(timer);
  const r = await api("/api/notes/save", {path: CUR, text: $("edit").value, base_mtime: force ? 0 : MTIME});
  if (r.ok) { MTIME = r.mtime; DIRTY = false; $("state").textContent = "Saved"; return true; }
  if (r.conflict) {
    const keep = confirm("This note changed while you were writing — the assistant may have " +
                         "added to it.\n\nOK keeps YOUR version (theirs stays in the history).\n" +
                         "Cancel loads THEIR version.");
    if (keep) return save(true);
    $("edit").value = r.text; MTIME = r.mtime; DIRTY = false; $("state").textContent = "Reloaded";
    if (!EDITING) render();
    return true;
  }
  $("state").textContent = "Not saved: " + (r.message || "error");
  return false;
}
window.addEventListener("beforeunload", () => { if (DIRTY) save(); });

// ---- [[ completion ----------------------------------------------------------
let CHOICES = [], PICK = 0;
function complete() {
  const ta = $("edit"), before = ta.value.slice(0, ta.selectionStart);
  const m = before.match(/\[\[([^\]\n|]*)$/);
  const box = $("complete");
  if (!m) { box.style.display = "none"; return; }
  const q = m[1].toLowerCase();
  CHOICES = NOTES.filter(n => n.folder !== "Journal" && n.title.toLowerCase().includes(q)).slice(0, 8)
                 .map(n => n.title);
  if (m[1] && !CHOICES.some(c => c.toLowerCase() === q)) CHOICES.push(m[1]);
  if (!CHOICES.length) { box.style.display = "none"; return; }
  PICK = 0; box.textContent = "";
  CHOICES.forEach((c, i) => {
    const d = document.createElement("div"); d.textContent = c + (NOTES.some(n => n.title === c) ? "" : "  (new)");
    if (i === 0) d.className = "on";
    d.onmousedown = e => { e.preventDefault(); accept(i); };
    box.append(d);
  });
  const r = ta.getBoundingClientRect();
  box.style.left = (r.left + 30) + "px"; box.style.top = (r.top + 40) + "px";
  box.style.display = "block";
}
function accept(i) {
  const ta = $("edit"), pos = ta.selectionStart, before = ta.value.slice(0, pos);
  const start = before.lastIndexOf("[[") + 2;
  const after = ta.value.slice(pos).replace(/^[^\]\n]*\]\]/, "");
  ta.value = ta.value.slice(0, start) + CHOICES[i] + "]]" + after;
  ta.selectionStart = ta.selectionEnd = start + CHOICES[i].length + 2;
  $("complete").style.display = "none";
  ta.oninput();
}
$("edit").onkeydown = e => {
  const box = $("complete");
  if (box.style.display !== "block") return;
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault();
    PICK = (PICK + (e.key === "ArrowDown" ? 1 : CHOICES.length - 1)) % CHOICES.length;
    [...box.children].forEach((c, i) => c.className = i === PICK ? "on" : "");
  } else if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); accept(PICK); }
  else if (e.key === "Escape") box.style.display = "none";
};

// ---- new, rename, delete ----------------------------------------------------
$("newbtn").onclick = async () => {
  const title = prompt("Name of the new note (a person's name goes into People/ if you start it with @):");
  if (!title) return;
  const person = title.startsWith("@");
  const r = await api("/api/notes/new", {title: person ? title.slice(1) : title, folder: person ? "People" : ""});
  if (!r.ok) { toast(r.message); return; }
  await loadList(); openNote(r.path, true);
};
$("title").ondblclick = async () => {
  if (RO || !CUR) return;
  const old = $("title").textContent;
  const t = prompt("Rename this note. Links to it in other notes are updated too.", old);
  if (!t || t === old) return;
  if (DIRTY && !(await save())) return;
  const r = await api("/api/notes/rename", {path: CUR, title: t});
  if (!r.ok) { toast(r.message); return; }
  toast(r.relinked ? "Renamed, and " + r.relinked + " note(s) updated" : "Renamed");
  await loadList(); openNote(r.path);
};
$("delbtn").onclick = async () => {
  if (!CUR || !confirm("Move “" + $("title").textContent + "” to the trash?")) return;
  const r = await api("/api/notes/delete", {path: CUR});
  toast(r.message || "Deleted");
  CUR = null; DIRTY = false; location.hash = "";
  ["edit", "view", "side"].forEach(i => $(i).style.display = "none");
  $("empty").style.display = ""; $("title").textContent = "";
  loadList();
};

// ---- the graph (phase 3) ---------------------------------------------------
// No library: a small force layout on a canvas. Colours by kind, size by how
// many links a note has; a selected note shows its links with direction —
// amber for the notes it points to, teal for the notes that point to it (an
// idea from Graft, trailhq/Graft — the idea only, not its code).
const KIND_COLOR = {"About me": "#e3b341", People: "#58a6ff", Projects: "#3fb950",
                    Places: "#f0883e", Journal: "#6e7681", other: "#a371f7"};
const OUT_C = "#d29922", IN_C = "#39c5bb";
function kindOf(n) {
  if (n.missing) return "missing";
  if (n.title === "About me" && !n.folder) return "About me";
  return KIND_COLOR[n.folder] ? n.folder : "other";
}
function hashPos(s) { let h = 2166136261; for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  return [((h >>> 0) % 1000) / 1000 - 0.5, (((h >>> 10) >>> 0) % 1000) / 1000 - 0.5]; }

class GraphView {
  constructor(canvas, opts) {
    this.c = canvas; this.ctx = canvas.getContext("2d"); this.o = opts || {};
    this.nodes = []; this.edges = []; this.sel = null; this.hover = null; this.match = null;
    this.zoom = 1; this.px = 0; this.py = 0; this.heat = 0; this.drag = null;
    this.bind(); this.loop = this.loop.bind(this); requestAnimationFrame(this.loop);
  }
  set(data) {
    const old = {}; for (const n of this.nodes) old[n.id] = n;
    const byId = {};
    this.nodes = data.nodes.map(n => {
      const o = old[n.id], [hx, hy] = hashPos(n.id);
      const m = Object.assign({}, n, {x: o ? o.x : hx * 400, y: o ? o.y : hy * 400,
                                      vx: 0, vy: 0, kind: kindOf(n)});
      byId[m.id] = m; return m;
    });
    this.edges = data.edges.filter(e => byId[e.source] && byId[e.target])
                           .map(e => Object.assign({}, e, {s: byId[e.source], t: byId[e.target]}));
    this.byId = byId; this.heat = 1;
    // Settle before the first frame (cheap for a few hundred notes), so the
    // graph appears laid out and framed instead of flying apart on screen.
    const fresh = this.nodes.some(n => !old[n.id]);
    if (fresh) { const steps = this.nodes.length > 400 ? 120 : 260;
                 for (let i = 0; i < steps; i++) this.step(); }
    if (!this.touched) { this.fit(); this.fitted = this.c.getBoundingClientRect().width > 0; }
    if (this.sel && !byId[this.sel.id]) this.sel = null;
    else if (this.sel) this.sel = byId[this.sel.id];
  }
  size() {
    const r = this.c.getBoundingClientRect(), d = window.devicePixelRatio || 1;
    if (this.c.width !== Math.round(r.width * d) || this.c.height !== Math.round(r.height * d)) {
      this.c.width = Math.round(r.width * d); this.c.height = Math.round(r.height * d);
    }
    return [r.width, r.height, d];
  }
  step() {
    const N = this.nodes, k = this.o.spring || 70;
    if (this.heat < 0.002 || !N.length) return;
    for (let i = 0; i < N.length; i++) {                 // repulsion
      const a = N[i];
      for (let j = i + 1; j < N.length; j++) {
        const b = N[j]; let dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy + 0.01;
        if (d2 > 250000) continue;
        const f = 900 / d2; dx *= f; dy *= f;
        a.vx += dx; a.vy += dy; b.vx -= dx; b.vy -= dy;
      }
    }
    for (const e of this.edges) {                        // springs
      const dx = e.t.x - e.s.x, dy = e.t.y - e.s.y, d = Math.sqrt(dx * dx + dy * dy) || 1;
      const f = (d - k) * 0.02, fx = dx / d * f, fy = dy / d * f;
      e.s.vx += fx; e.s.vy += fy; e.t.vx -= fx; e.t.vy -= fy;
    }
    for (const n of N) {                                 // gravity, damping
      n.vx -= n.x * 0.004; n.vy -= n.y * 0.004;
      if (n === this.drag) { n.vx = n.vy = 0; continue; }
      n.x += Math.max(-20, Math.min(20, n.vx * this.heat));
      n.y += Math.max(-20, Math.min(20, n.vy * this.heat));
      n.vx *= 0.6; n.vy *= 0.6;
    }
    this.heat *= 0.985;
    if (!this.fitted && !this.touched && this.heat < 0.08) { this.fit(); this.fitted = true; }
  }
  fit() {
    const vis = this.nodes.filter(n => this.visible(n));
    if (!vis.length) return;
    const r = this.c.getBoundingClientRect();
    if (!r.width) return;
    let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
    for (const n of vis) { x0 = Math.min(x0, n.x); x1 = Math.max(x1, n.x); y0 = Math.min(y0, n.y); y1 = Math.max(y1, n.y); }
    this.zoom = Math.max(0.2, Math.min(1.8, (r.width - 80) / (x1 - x0 + 60), (r.height - 70) / (y1 - y0 + 60)));
    this.px = -(x0 + x1) / 2; this.py = -(y0 + y1) / 2;
  }
  radius(n) { return (n.missing ? 4 : 5) + Math.min(12, Math.sqrt(n.degree) * 2.4); }
  visible(n) { return !this.o.filter || this.o.filter(n); }
  toScreen(n, w, h) { return [w / 2 + (n.x + this.px) * this.zoom, h / 2 + (n.y + this.py) * this.zoom]; }
  draw() {
    const [w, h, d] = this.size(), ctx = this.ctx;
    ctx.setTransform(d, 0, 0, d, 0, 0); ctx.clearRect(0, 0, w, h);
    const sel = this.sel, near = new Set();
    if (sel) { near.add(sel); for (const e of this.edges) { if (e.s === sel) near.add(e.t); if (e.t === sel) near.add(e.s); } }
    // edges
    for (const e of this.edges) {
      if (!this.visible(e.s) || !this.visible(e.t)) continue;
      const [x1, y1] = this.toScreen(e.s, w, h), [x2, y2] = this.toScreen(e.t, w, h);
      let col = "#30363d", lw = 1;
      if (sel) {
        if (e.s === sel) { col = OUT_C; lw = 2; } else if (e.t === sel) { col = IN_C; lw = 2; }
        else col = "#1c2128";
      }
      ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      if (sel && (e.s === sel || e.t === sel)) {
        const a = Math.atan2(y2 - y1, x2 - x1), r = this.radius(e.t) * this.zoom + 3;
        const ax = x2 - Math.cos(a) * r, ay = y2 - Math.sin(a) * r;
        ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(ax, ay);
        ctx.lineTo(ax - Math.cos(a - 0.4) * 9, ay - Math.sin(a - 0.4) * 9);
        ctx.lineTo(ax - Math.cos(a + 0.4) * 9, ay - Math.sin(a + 0.4) * 9); ctx.fill();
        if (e.label) {
          ctx.font = "11px system-ui,'Noto Sans','Noto Sans Arabic',sans-serif";
          ctx.fillStyle = col; ctx.textAlign = "center";
          ctx.fillText(e.label, (x1 + x2) / 2, (y1 + y2) / 2 - 4);
        }
      }
    }
    // nodes
    const many = this.nodes.length > 60 && this.zoom < 1.3;
    for (const n of this.nodes) {
      if (!this.visible(n)) continue;
      const [x, y] = this.toScreen(n, w, h), r = this.radius(n) * Math.sqrt(this.zoom);
      const dim = (sel && !near.has(n)) || (this.match && !this.match(n));
      const col = n.missing ? "#8b949e" : KIND_COLOR[n.kind] || KIND_COLOR.other;
      ctx.globalAlpha = dim ? 0.18 : 1;
      ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832);
      if (n.missing) { ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.stroke(); }
      else { ctx.fillStyle = col; ctx.fill(); }
      if (n === sel || n === this.hover || n.id === this.o.current) {
        ctx.strokeStyle = "#e6edf3"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, r + 3, 0, 6.2832); ctx.stroke();
      }
      if (!dim && (!many || near.has(n) || n === this.hover || n.degree > 4 || n.id === this.o.current)) {
        ctx.font = (n === sel ? "600 " : "") + "12px system-ui,'Noto Sans','Noto Sans Arabic',sans-serif";
        ctx.fillStyle = n.missing ? "#8b949e" : "#c9d1d9"; ctx.textAlign = "center";
        ctx.fillText(n.title, x, y + r + 14);
      }
      ctx.globalAlpha = 1;
    }
    if (!this.nodes.length) {
      ctx.fillStyle = "#8b949e"; ctx.font = "13px system-ui"; ctx.textAlign = "center";
      ctx.fillText(this.o.empty || "No notes yet.", w / 2, h / 2);
    }
  }
  loop() { this.step(); this.draw(); requestAnimationFrame(this.loop); }
  at(ev) {
    const r = this.c.getBoundingClientRect(), [w, h] = [r.width, r.height];
    const mx = ev.clientX - r.left, my = ev.clientY - r.top;
    let best = null, bd = 1e9;
    for (const n of this.nodes) {
      if (!this.visible(n)) continue;
      const [x, y] = this.toScreen(n, w, h), d = Math.hypot(x - mx, y - my);
      if (d < this.radius(n) * Math.sqrt(this.zoom) + 6 && d < bd) { best = n; bd = d; }
    }
    return {node: best, mx, my, w, h};
  }
  bind() {
    const c = this.c; let pan = null, moved = false;
    c.addEventListener("mousedown", ev => {
      const {node, mx, my} = this.at(ev); moved = false;
      this.touched = true;
      if (node) { this.drag = node; } else pan = {mx, my, px: this.px, py: this.py};
      c.style.cursor = "grabbing";
    });
    window.addEventListener("mousemove", ev => {
      if (!this.drag && !pan) { if (ev.target === c) { const h = this.at(ev).node; this.hover = h; c.style.cursor = h ? "pointer" : "grab"; } return; }
      const {mx, my, w, h} = this.at(ev); moved = true;
      if (this.drag) {
        this.drag.x = (mx - w / 2) / this.zoom - this.px; this.drag.y = (my - h / 2) / this.zoom - this.py;
        this.heat = Math.max(this.heat, 0.3);
      } else { this.px = pan.px + (mx - pan.mx) / this.zoom; this.py = pan.py + (my - pan.my) / this.zoom; }
    });
    window.addEventListener("mouseup", ev => {
      if ((this.drag || pan) && !moved && ev.target === c) {
        const n = this.at(ev).node;
        this.sel = n && this.sel !== n ? n : null;
        if (this.o.onSelect) this.o.onSelect(this.sel);
      }
      this.drag = null; pan = null; c.style.cursor = "grab";
    });
    c.addEventListener("dblclick", ev => { const n = this.at(ev).node; if (n && this.o.onOpen) this.o.onOpen(n); });
    c.addEventListener("wheel", ev => {
      ev.preventDefault(); this.touched = true;
      const {mx, my, w, h} = this.at(ev), z0 = this.zoom;
      this.zoom = Math.max(0.2, Math.min(4, this.zoom * (ev.deltaY < 0 ? 1.12 : 1 / 1.12)));
      // keep the point under the cursor still
      this.px += (mx - w / 2) / this.zoom - (mx - w / 2) / z0;
      this.py += (my - h / 2) / this.zoom - (my - h / 2) / z0;
    }, {passive: false});
  }
  focus(n) { if (!n) return; this.sel = n; this.touched = true; this.px = -n.x; this.py = -n.y; }
}

// the big graph
const SHOWN = new Set(["People", "Projects", "Places", "other", "missing", "About me"]);
let GDATA = null;
const BIG = new GraphView($("gcanvas"), {
  filter: n => SHOWN.has(n.kind),
  empty: "No notes yet — what you and the assistant write will appear here.",
  onOpen: n => n.missing ? follow(n.title).then(() => toggleGraph(false))
                         : (toggleGraph(false), openNote(n.id)),
});
async function loadGraph() {
  try { GDATA = await api("/api/notes/graph"); } catch (e) { return; }
  BIG.set(GDATA);
  drawLocal();
}
function toggleGraph(on) {
  document.body.classList.toggle("graph", on);
  $("graphbtn").classList.toggle("on", on);
  if (on) { BIG.touched = false; BIG.fitted = false; loadGraph();
            if (CUR && BIG.byId && BIG.byId[CUR]) BIG.sel = BIG.byId[CUR]; }
}
$("graphbtn").onclick = () => toggleGraph(!document.body.classList.contains("graph"));
document.querySelectorAll("#gbar .chip").forEach(ch => ch.onclick = () => {
  const f = ch.dataset.f; ch.classList.toggle("on");
  if (ch.classList.contains("on")) SHOWN.add(f); else SHOWN.delete(f);
  BIG.heat = Math.max(BIG.heat, 0.2);
});
$("gsearch").oninput = () => {
  const q = $("gsearch").value.trim().toLowerCase();
  BIG.match = q ? n => n.title.toLowerCase().includes(q) : null;
  const hit = q && BIG.nodes.find(n => BIG.visible(n) && n.title.toLowerCase().includes(q));
  if (hit) BIG.focus(hit);
};

// the local graph: this note and its neighbours, in the side panel
const LOCAL = new GraphView($("local"), {spring: 55, empty: "No links yet.",
  onOpen: n => n.missing ? follow(n.title) : openNote(n.id)});
function drawLocal() {
  if (!GDATA || !CUR) return;
  const keep = new Set([CUR]);
  for (const e of GDATA.edges) { if (e.source === CUR) keep.add(e.target); if (e.target === CUR) keep.add(e.source); }
  LOCAL.o.current = CUR; LOCAL.touched = false;
  LOCAL.set({nodes: GDATA.nodes.filter(n => keep.has(n.id)),
             edges: GDATA.edges.filter(e => keep.has(e.source) && keep.has(e.target))});
  LOCAL.sel = LOCAL.byId[CUR] || null;
  LOCAL.zoom = Math.min(LOCAL.zoom, 1.4);
}

// ---- keeping up with the assistant ---------------------------------------------
// When it writes to the note that is open and you have not changed it,
// show its version.
setInterval(async () => {
  if (document.hidden) return;
  const before = NOTES.length;
  await loadList();
  const n = NOTES.find(n => n.path === CUR);
  if (n && !DIRTY && Math.abs(n.mtime - MTIME) > 0.001) openNote(CUR, EDITING);
  else if (NOTES.length !== before) drawList();
  if (document.body.classList.contains("graph")) loadGraph();
}, 8000);

(async () => {
  try {
    const who = await api("/api/remote/whoami");
    RO = !!who.remote;
  } catch (e) { RO = false; }
  if (RO) document.body.classList.add("ro");
  await loadList();
  const want = decodeURIComponent(location.hash.slice(1));
  if (want) openNote(want);
  else { const about = NOTES.find(n => n.title === "About me"); if (about) openNote(about.path); }
})();
</script>
"""
