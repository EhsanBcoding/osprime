"""Where a person's things live, and where the machine's do. docs/ACCOUNTS.md.

Until the login exists, one account — `osprime` — is both the service
account and the person, and everything lives in /var/lib/osprime and
/etc/osprime. After it, each person is a real Linux account and the agent
runs AS them, so their memory, logs and settings belong in their own home,
where the kernel keeps other people out.

This module is the one place that knows which. Everything else asks it:

    paths.memory_db()      paths.audit_log()     paths.home()

Running as `osprime` (every machine today, and any machine not yet
migrated) gives exactly the old paths, so this changes nothing until a
person account exists. An OSPRIME_* environment variable still wins over
both — that is how the tests point things at temporary folders.
"""

import os
import pathlib
import pwd

SERVICE_ACCOUNT = "osprime"


def user() -> str:
    """Who this process acts for.

    SUDO_USER first: the tools run under sudo (updater, profiler) act for
    the person who typed the command, not for root.
    """
    if os.environ.get("SUDO_USER"):
        return os.environ["SUDO_USER"]
    try:
        return pwd.getpwuid(os.geteuid()).pw_name
    except KeyError:
        return os.environ.get("USER") or SERVICE_ACCOUNT


def legacy() -> bool:
    """The single-account layout: the service account is also the person."""
    return user() in (SERVICE_ACCOUNT, "root")


def home() -> pathlib.Path:
    name = SERVICE_ACCOUNT if user() == "root" else user()
    try:
        return pathlib.Path(pwd.getpwnam(name).pw_dir)
    except KeyError:
        return pathlib.Path(os.path.expanduser("~" + name))


def _pick(env: str, legacy_path: str, personal: str) -> pathlib.Path:
    if os.environ.get(env):
        return pathlib.Path(os.environ[env])
    return pathlib.Path(legacy_path) if legacy() else home() / personal


# ---- the person's -----------------------------------------------------------
def data_dir() -> pathlib.Path:
    return _pick("OSPRIME_DATA", "/var/lib/osprime", ".local/share/osprime")


def state_dir() -> pathlib.Path:
    return _pick("OSPRIME_STATE", "/var/lib/osprime", ".local/state/osprime")


def config_dir() -> pathlib.Path:
    return _pick("OSPRIME_CONFIG_DIR", "/etc/osprime", ".config/osprime")


def memory_db() -> pathlib.Path:
    return _pick("OSPRIME_MEMORY_DB", "/var/lib/osprime/memory.db",
                 ".local/share/osprime/memory.db")


def memory_json() -> pathlib.Path:
    return _pick("OSPRIME_MEMORY", "/var/lib/osprime/memory.json",
                 ".local/share/osprime/memory.json")


def audit_log() -> pathlib.Path:
    return _pick("OSPRIME_AUDIT", "/var/lib/osprime/audit.log",
                 ".local/state/osprime/audit.log")


def tool_errors() -> pathlib.Path:
    return _pick("OSPRIME_TOOL_ERRORS", "/var/lib/osprime/tool-errors.log",
                 ".local/state/osprime/tool-errors.log")


def group_log() -> pathlib.Path:
    return _pick("OSPRIME_GROUP_LOG", "/var/lib/osprime/tool-groups.log",
                 ".local/state/osprime/tool-groups.log")


def proactive_state() -> pathlib.Path:
    return _pick("OSPRIME_PROACTIVE_STATE", "/var/lib/osprime/proactive.json",
                 ".local/state/osprime/proactive.json")


def agent_config() -> pathlib.Path:
    """confirm level, disk threshold, schedules — how the assistant behaves."""
    return _pick("OSPRIME_CONFIG", "/etc/osprime/config.json",
                 ".config/osprime/config.json")


def profile() -> pathlib.Path:
    """What the assistant knows about the person from onboarding."""
    return _pick("OSPRIME_PROFILE", "/etc/osprime/profile.json",
                 ".config/osprime/profile.json")


def remote_state() -> pathlib.Path:
    """Paired phones belong to a person (ACCOUNTS.md, phase 2)."""
    return _pick("OSPRIME_REMOTE_STATE", "/etc/osprime/remote.json",
                 ".config/osprime/remote.json")


def accounts_enabled() -> bool:
    """People have their own accounts: written by osprime-migrate-accounts.sh."""
    return pathlib.Path(os.environ.get("OSPRIME_ACCOUNTS_FLAG",
                                       "/etc/osprime/accounts")).exists()


def secrets() -> pathlib.Path:
    """The cloud key: the person's own, never shared with another."""
    return _pick("OSPRIME_SECRETS", "/etc/osprime/secrets.env",
                 ".config/osprime/secrets.env")


def companion_state() -> pathlib.Path:
    """What the agent tells the floating companion. /tmp is shared between
    people, so with accounts it moves to the person's runtime directory."""
    if os.environ.get("OSPRIME_COMPANION_STATE"):
        return pathlib.Path(os.environ["OSPRIME_COMPANION_STATE"])
    if legacy():
        return pathlib.Path("/tmp/osprime-companion.state")
    runtime = os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.geteuid()}"
    return pathlib.Path(runtime) / "osprime" / "companion.state"


def shortcuts() -> pathlib.Path:
    """A person's own keyboard shortcuts (docs/ACCOUNTS.md, phase 2) — the
    last personal setting that still lived in /etc/osprime."""
    return _pick("OSPRIME_SHORTCUTS", "/etc/osprime/shortcuts.json",
                 ".config/osprime/shortcuts.json")


def socket_path() -> str:
    if os.environ.get("OSPRIME_SOCKET"):
        return os.environ["OSPRIME_SOCKET"]
    if legacy():
        return "/run/osprime/agent.sock"
    runtime = os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.geteuid()}"
    return f"{runtime}/osprime/agent.sock"


# ---- the machine's ----------------------------------------------------------
# Deliberately not per person: the models and how the engine runs are the
# computer's, and are changed only through the named sudo rules.
MODELS_DIR = pathlib.Path(os.environ.get("OSPRIME_MODELS", "/var/lib/osprime/models"))
MODEL_ENV = pathlib.Path(os.environ.get("OSPRIME_MODEL_ENV", "/etc/osprime/model.env"))
MACHINE_ENV = pathlib.Path("/etc/osprime/desktop.env")


# ---- desktop.env: the machine's defaults, the person's own on top ----------
# One file today, /etc/osprime/desktop.env, written by Settings, the
# assistant and the companion alike. With a login, each person keeps their
# own ~/.config/osprime/desktop.env: it is read ON TOP of the machine's
# file, and every change is written to it — so one person's wallpaper,
# confirm level or companion position never becomes another's. The
# machine's file stays as the defaults the installer wrote.
#
# Running as `osprime`, or with OSPRIME_DESKTOP_ENV set (the tests), there
# is exactly one file, as before.
def desktop_env_files() -> list:
    if os.environ.get("OSPRIME_DESKTOP_ENV"):
        return [pathlib.Path(os.environ["OSPRIME_DESKTOP_ENV"])]
    if legacy():
        return [MACHINE_ENV]
    return [MACHINE_ENV, home() / ".config" / "osprime" / "desktop.env"]


def desktop_env_target() -> pathlib.Path:
    """Where a change is written: the last (most personal) file."""
    return desktop_env_files()[-1]


def read_desktop_env() -> dict:
    out = {}
    for f in desktop_env_files():
        try:
            for line in f.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    out[k.strip()] = v.strip()
        except OSError:
            pass
    return out


def write_desktop_env(key: str, value: str) -> bool:
    """Update one key in the person's file, keeping comments and the rest."""
    target = desktop_env_target()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        lines = (target.read_text(encoding="utf-8").splitlines()
                 if target.exists() else [])
        for i, line in enumerate(lines):
            if line.strip().startswith(f"{key}="):
                lines[i] = f"{key}={value}"
                break
        else:
            lines.append(f"{key}={value}")
        target.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return True
    except Exception:
        return False


def selftest() -> list:
    bad = []
    saved = dict(os.environ)
    try:
        for k in list(os.environ):
            if k.startswith("OSPRIME_"):
                del os.environ[k]
        os.environ.pop("SUDO_USER", None)
        if legacy():
            if str(memory_db()) != "/var/lib/osprime/memory.db":
                bad.append(f"paths: legacy memory at {memory_db()}")
            if socket_path() != "/run/osprime/agent.sock":
                bad.append(f"paths: legacy socket at {socket_path()}")
        else:
            if not str(memory_db()).startswith(str(home())):
                bad.append(f"paths: a person's memory outside their home: {memory_db()}")
        if str(MODELS_DIR).startswith(str(home())) and not legacy():
            bad.append("paths: models under a person's home")
    finally:
        os.environ.clear()
        os.environ.update(saved)
    return bad
