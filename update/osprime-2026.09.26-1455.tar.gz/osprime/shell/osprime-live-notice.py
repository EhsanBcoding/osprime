#!/usr/bin/env python3
"""What Super and "Open chat" show on the live USB. docs/INSTALL.md.

The assistant does not run from the USB — it starts once OSprime is
installed, where it has a disk to remember things on and a model it can
load. So instead of a chat window that cannot connect, one small window
says so and offers the installer.
"""
import subprocess
import sys

LAUNCH = "/opt/osprime/shell/osprime-install-launch.sh"
TEXT = ("This is the OSprime live USB.\n\n"
        "The assistant starts after OSprime is installed on this computer.")


def main() -> int:
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk
    except Exception:
        # No GTK: the terminal says the same thing.
        subprocess.Popen(["foot", "-T", "OSprime", "bash", LAUNCH])
        return 0
    d = Gtk.MessageDialog(message_type=Gtk.MessageType.INFO,
                          buttons=Gtk.ButtonsType.NONE, text="OSprime")
    d.format_secondary_text(TEXT)
    d.add_button("Close", Gtk.ResponseType.CLOSE)
    d.add_button("Install OSprime", Gtk.ResponseType.OK)
    d.set_default_response(Gtk.ResponseType.OK)
    d.set_position(Gtk.WindowPosition.CENTER)
    answer = d.run()
    d.destroy()
    if answer == Gtk.ResponseType.OK:
        subprocess.Popen(["bash", LAUNCH], start_new_session=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
