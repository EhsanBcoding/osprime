#!/usr/bin/env bash
# Add, remove and manage the people who use this computer. docs/ACCOUNTS.md, phase 2.
#
#   osprime-people.sh add NAME "FULL NAME" yes|no     password on stdin
#   osprime-people.sh passwd NAME                     new password on stdin
#   osprime-people.sh admin NAME yes|no
#   osprime-people.sh remove NAME                     home kept as a root-only archive
#   osprime-people.sh archives                        list the archives
#   osprime-people.sh purge ARCHIVE                   delete one archive for good
#
# Run as root, and only by an administrator: Settings calls it through
# `sudo -S` with the administrator's OWN password — there is deliberately no
# password-free rule for it. Adding an administrator is the one thing on
# this machine that must never be one click away from an unlocked screen
# or a language model that has been talked into it.
#
# This script is the boundary, so it trusts nothing it is given: every name
# is checked against one pattern, only people (members of osprime-users,
# uid >= 1000) can be changed, the service and system accounts never, the
# last administrator can be neither removed nor demoted, nobody removes
# themselves, and passwords arrive on stdin — never on a command line.
set -u
R="${OSPRIME_PEOPLE_ROOT:-}"                 # the tests run against a fake root
ARCH="$R/var/lib/osprime-people"
NAME_RE='^[a-z_][a-z0-9_-]{0,30}$'
CALLER="${SUDO_USER:-${OSPRIME_PEOPLE_CALLER:-}}"

die() { echo "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" -eq 0 ] || [ -n "${OSPRIME_PEOPLE_TEST:-}" ] || die "run as root"

valid_name() { printf '%s' "$1" | grep -Eq "$NAME_RE"; }
reserved()   { case "$1" in root|osprime|greeter|nobody|bin|daemon|mail|ftp|http|dbus|systemd-*) return 0;; esac; return 1; }
in_group()   { id -nG "$1" 2>/dev/null | tr ' ' '\n' | grep -qx "$2"; }
is_person()  { getent passwd "$1" >/dev/null && in_group "$1" osprime-users \
               && [ "$(id -u "$1" 2>/dev/null || echo 0)" -ge 1000 ]; }
admins()     { getent group wheel | cut -d: -f4 | tr ',' '\n' | while read -r u; do
                   [ -n "$u" ] && is_person "$u" && echo "$u"; done; }
need_person() {
    valid_name "$1" || die "not a valid name: $1"
    reserved "$1" && die "$1 is a system account"
    is_person "$1" || die "$1 is not a person on this computer"
}
read_password() {
    IFS= read -r PW || true
    [ -n "${PW:-}" ] || die "no password given"
    [ "${#PW}" -ge 6 ] || die "the password must be at least 6 characters"
    case "$PW" in *:*|*$'\n'*) die "the password cannot contain ':'";; esac
}

cmd="${1:-}"; shift || true
case "$cmd" in
add)
    NAME="${1:-}"; FULL="${2:-}"; ADMIN="${3:-no}"
    valid_name "$NAME" || die "user names are lowercase letters, digits, - and _, starting with a letter"
    reserved "$NAME" && die "$NAME is a system account"
    getent passwd "$NAME" >/dev/null && die "$NAME already exists"
    case "$FULL" in *:*|*$'\n'*) die "the full name cannot contain ':'";; esac
    case "$ADMIN" in yes|no) ;; *) die "admin must be yes or no";; esac
    read_password
    # The same groups the installer gives the first person: the hardware
    # groups the osprime account has, osprime (to read the machine's
    # settings), osprime-users (the sudo rules everyone gets).
    GROUPS_="$(id -nG osprime 2>/dev/null | tr ' ' '\n' | grep -vxE 'osprime|wheel|' | paste -sd, -)"
    GROUPS_="${GROUPS_:+$GROUPS_,}osprime,osprime-users"
    [ "$ADMIN" = yes ] && GROUPS_="$GROUPS_,wheel"
    getent group osprime-users >/dev/null || groupadd -r osprime-users
    useradd -m -c "${FULL:-$NAME}" -G "$GROUPS_" -s /bin/bash "$NAME" || die "could not create $NAME"
    printf '%s:%s\n' "$NAME" "$PW" | chpasswd || { userdel -r "$NAME" 2>/dev/null; die "could not set the password"; }
    HOME_="$R$(getent passwd "$NAME" | cut -d: -f6)"
    chmod 700 "$HOME_"
    mkdir -p "$HOME_/.config"
    [ -d "$R/opt/osprime/shell/labwc" ] && cp -a "$R/opt/osprime/shell/labwc" "$HOME_/.config/labwc" 2>/dev/null
    chown -R "$NAME:$NAME" "$HOME_/.config" 2>/dev/null || true
    echo "added $NAME$( [ "$ADMIN" = yes ] && echo ' (administrator)')"
    ;;
passwd)
    NAME="${1:-}"; need_person "$NAME"
    read_password
    printf '%s:%s\n' "$NAME" "$PW" | chpasswd || die "could not set the password"
    echo "password changed for $NAME"
    ;;
admin)
    NAME="${1:-}"; WANT="${2:-}"; need_person "$NAME"
    case "$WANT" in
        yes) gpasswd -a "$NAME" wheel >/dev/null || die "could not"; echo "$NAME is now an administrator" ;;
        no)  in_group "$NAME" wheel || { echo "$NAME is not an administrator"; exit 0; }
             [ "$(admins | grep -cvx "$NAME")" -ge 1 ] || die "$NAME is the last administrator — make someone else one first"
             gpasswd -d "$NAME" wheel >/dev/null || die "could not"; echo "$NAME is no longer an administrator" ;;
        *) die "yes or no" ;;
    esac
    ;;
remove)
    NAME="${1:-}"; need_person "$NAME"
    [ "$NAME" = "$CALLER" ] && die "you cannot remove yourself"
    if in_group "$NAME" wheel && [ "$(admins | grep -cvx "$NAME")" -lt 1 ]; then
        die "$NAME is the last administrator"
    fi
    loginctl show-user "$NAME" >/dev/null 2>&1 && [ -z "${OSPRIME_PEOPLE_TEST:-}" ] \
        && die "$NAME is logged in right now — they have to log out first"
    HOME_="$R$(getent passwd "$NAME" | cut -d: -f6)"
    mkdir -p "$ARCH"; chmod 700 "$ARCH"
    STAMP="$(date +%Y-%m-%d-%H%M)"
    OUT="$ARCH/$NAME-$STAMP.tar.zst"
    tar -C "$(dirname "$HOME_")" --zstd -cf "$OUT" "$(basename "$HOME_")" \
        || die "could not archive $HOME_ — nothing was removed"
    chmod 600 "$OUT"
    userdel -r "$NAME" 2>/dev/null || userdel "$NAME" || die "archived, but could not remove the account"
    rm -rf "$HOME_"
    echo "removed $NAME; their files are kept in $(basename "$OUT") ($(du -h "$OUT" | cut -f1))"
    ;;
archives)
    [ -d "$ARCH" ] || exit 0
    for f in "$ARCH"/*.tar.zst; do
        [ -e "$f" ] && printf '%s\t%s\n' "$(basename "$f")" "$(du -h "$f" | cut -f1)"
    done
    ;;
purge)
    A="${1:-}"
    printf '%s' "$A" | grep -Eq '^[a-z_][a-z0-9_-]{0,30}-[0-9]{4}-[0-9]{2}-[0-9]{2}-[0-9]{4}\.tar\.zst$' \
        || die "not an archive name: $A"
    [ -f "$ARCH/$A" ] || die "no such archive"
    rm -f "$ARCH/$A" && echo "deleted $A for good"
    ;;
*)
    sed -n '2,10p' "$0"; exit 2 ;;
esac
