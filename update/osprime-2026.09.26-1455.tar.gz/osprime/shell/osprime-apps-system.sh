#!/usr/bin/env bash
# Install or remove an application FOR EVERYONE on this computer.
# docs/ACCOUNTS.md, phase 2, apps decision C.
#
#   osprime-apps-system.sh install APP_ID
#   osprime-apps-system.sh uninstall APP_ID
#
# Administrators run it through a password-free sudo rule, like updates.
# Everyone else installs just for themselves (flatpak --user, no root).
#
# The boundary: only an application ID of the usual reverse-DNS shape, and
# only from Flathub's VERIFIED subset — the same catalogue the store shows.
# An ID outside that subset is simply not in the remote and fails to
# install; nothing else can be fetched through here.
set -u
REMOTE=flathub-verified
URL=https://flathub.org/repo/flathub.flatpakrepo
cmd="${1:-}"; APP="${2:-}"
die() { echo "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" -eq 0 ] || [ -n "${OSPRIME_APPS_TEST:-}" ] || die "run as root"
printf '%s' "$APP" | grep -Eq '^[A-Za-z][A-Za-z0-9_-]*(\.[A-Za-z0-9_-]+){2,}$' \
    || die "not an application ID: $APP"
case "$cmd" in
install)
    flatpak --system remote-add --if-not-exists --subset=verified "$REMOTE" "$URL" \
        || die "could not reach the application catalogue"
    flatpak --system install --noninteractive --or-update "$REMOTE" "$APP" \
        || die "could not install $APP"
    echo "$APP is installed for everyone on this computer." ;;
uninstall)
    flatpak --system uninstall --noninteractive "$APP" || die "could not remove $APP"
    flatpak --system uninstall --unused --noninteractive >/dev/null 2>&1 || true
    echo "$APP has been removed for everyone." ;;
*) die "install or uninstall" ;;
esac
