"""Settings → People. docs/ACCOUNTS.md, phase 2.

Who uses this computer, and — for administrators — adding, removing and
managing them. Everything that changes an account goes through
shell/osprime-people.sh, run with `sudo -S -k` and the administrator's OWN
password: there is deliberately no password-free sudo rule for it. The
only thing done without sudo is changing your own password, which is what
`passwd` is for.

Reading the list needs no privilege at all: it is /etc/passwd and
/etc/group.
"""
import grp
import os
import pwd
import re
import select
import subprocess
import time

SCRIPT = "/opt/osprime/shell/osprime-people.sh"
ACCOUNTS_FLAG = os.environ.get("OSPRIME_ACCOUNTS_FLAG", "/etc/osprime/accounts")


def me() -> str:
    return pwd.getpwuid(os.geteuid()).pw_name


def _members(group: str) -> set:
    try:
        return set(grp.getgrnam(group).gr_mem)
    except KeyError:
        return set()


def is_admin(name: str = "") -> bool:
    return (name or me()) in _members("wheel")


def enabled() -> bool:
    return os.path.exists(ACCOUNTS_FLAG)


def list_people() -> list:
    users = _members("osprime-users")
    admins = _members("wheel")
    out = []
    for p in pwd.getpwall():
        if p.pw_name in users and p.pw_uid >= 1000:
            out.append({"name": p.pw_name,
                        "full": (p.pw_gecos or "").split(",")[0] or p.pw_name,
                        "admin": p.pw_name in admins,
                        "you": p.pw_name == me()})
    out.sort(key=lambda d: (not d["you"], d["name"]))
    return out


def status() -> dict:
    return {"enabled": enabled(), "me": me(), "admin": is_admin(),
            "people": list_people() if enabled() else []}


# ---------------------------------------------------------------------------
# administrators: through the helper, with their own password
# ---------------------------------------------------------------------------
def _clean(text: str) -> str:
    return "\n".join(l.replace("ERROR: ", "") for l in text.strip().splitlines()
                     if l.strip() and "[sudo]" not in l)


def run_admin(admin_password: str, args: list, secret: str = "") -> dict:
    """sudo -S reads the administrator's password from the first line of
    stdin; the helper reads the NEW password (if any) from the next."""
    if not enabled():
        return {"ok": False, "message": "this computer has no login yet"}
    if not is_admin():
        return {"ok": False, "message": "only an administrator can do that"}
    if not admin_password:
        return {"ok": False, "message": "type your own password to confirm"}
    stdin = admin_password + "\n" + (secret + "\n" if secret else "")
    try:
        r = subprocess.run(["sudo", "-S", "-k", "-p", "", "/usr/bin/bash", SCRIPT] + args,
                           input=stdin, text=True, capture_output=True, timeout=300)
    except Exception as e:
        return {"ok": False, "message": f"could not run: {e}"}
    err = r.stderr or ""
    if re.search(r"incorrect password|Sorry, try again|no password was provided", err, re.I):
        return {"ok": False, "message": "your password was not accepted"}
    if r.returncode != 0:
        return {"ok": False, "message": _clean(err) or _clean(r.stdout) or "it did not work"}
    return {"ok": True, "message": _clean(r.stdout)}


def add(admin_pw, name, full, password, admin: bool):
    return run_admin(admin_pw, ["add", name, full, "yes" if admin else "no"], password)


def reset_password(admin_pw, name, password):
    return run_admin(admin_pw, ["passwd", name], password)


def set_admin(admin_pw, name, admin: bool):
    return run_admin(admin_pw, ["admin", name, "yes" if admin else "no"])


def remove(admin_pw, name):
    if name == me():
        return {"ok": False, "message": "you cannot remove yourself"}
    return run_admin(admin_pw, ["remove", name])


def archives(admin_pw) -> dict:
    r = run_admin(admin_pw, ["archives"])
    if r["ok"]:
        r["archives"] = [dict(zip(("name", "size"), l.split("\t")))
                         for l in r["message"].splitlines() if "\t" in l]
    return r


def purge(admin_pw, archive):
    return run_admin(admin_pw, ["purge", archive])


# ---------------------------------------------------------------------------
# everyone: their own password, with passwd, as themselves — no sudo
# ---------------------------------------------------------------------------
def change_own_password(old: str, new: str, timeout: float = 25) -> dict:
    """Drive `passwd` through a pseudo-terminal: it asks for the current
    password, the new one, and the new one again. Nothing is echoed, and
    nothing here is logged."""
    import pty
    if not old or not new:
        return {"ok": False, "message": "both passwords are needed"}
    if len(new) < 6:
        return {"ok": False, "message": "the new password must be at least 6 characters"}
    pid, fd = pty.fork()
    if pid == 0:
        os.environ["LC_ALL"] = "C"
        try:
            os.execvp("passwd", ["passwd"])
        finally:
            os._exit(127)
    answers = [old, new, new]
    seen, out = 0, b""
    end = time.time() + timeout
    try:
        while time.time() < end:
            r, _, _ = select.select([fd], [], [], 0.5)
            if fd not in r:
                continue
            try:
                data = os.read(fd, 1024)
            except OSError:
                break
            if not data:
                break
            out += data
            prompts = len(re.findall(rb"password:", out, re.I))
            while seen < prompts and answers:
                os.write(fd, (answers.pop(0) + "\n").encode())
                seen += 1
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
    try:
        _, status = os.waitpid(pid, 0)
        code = os.waitstatus_to_exitcode(status)
    except ChildProcessError:
        code = 1
    text = out.decode(errors="replace")
    if code == 0:
        return {"ok": True, "message": "your password was changed"}
    if re.search(r"authentication token manipulation error|authentication failure", text, re.I):
        return {"ok": False, "message": "the current password was not right"}
    last = [l.strip() for l in text.splitlines()
            if l.strip() and "password:" not in l.lower() and "changing password" not in l.lower()]
    return {"ok": False, "message": (last[-1] if last else "the password was not changed")}
