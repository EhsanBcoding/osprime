"""Find a file by what is in it. Asked for by Ehsan; built 1 October.

`search_files` used to know names and dates only, so "the contract about
renting the shop" or "the file where I wrote Ali's account number" found
nothing. This keeps an index of what each file SAYS, in two layers:

  1. words — SQLite FTS5 over the text. Works on every computer, needs no
     model, and finds exact words ("اجاره", "Ali", an invoice number).
  2. meaning — a small multilingual embedding model (multilingual-e5-small,
     Persian and English) served on the processor by osprime-embed.service.
     "rental agreement" finds "اجاره‌نامه". Without it, layer 1 still works
     and Settings says so.

Decisions (Ehsan, 1 October): on by default; the whole home folder except
hidden folders; text inside pictures (OCR) is off by default and switched
on in Settings → Assistant.

Everything stays on this computer. The index is the person's own, in their
own home (paths.data_dir()), built by their own assistant process — nobody
else's files are in it and nothing here runs as root. The embedding server
holds no data: it turns text into numbers and forgets it.

Switching it off deletes the index: "off" means there is no index, not that
we stop reading it.
"""
import json
import os
import pathlib
import re
import sqlite3
import struct
import subprocess
import threading
import time
import urllib.request
import zipfile

import paths

KEY_ON = "OSPRIME_FILE_INDEX"
KEY_OCR = "OSPRIME_FILE_INDEX_OCR"
EMBED_URL = os.environ.get("OSPRIME_EMBED_URL", "http://127.0.0.1:8093")
EMBED_MODEL = "multilingual-e5-small"
FIRST_WAIT = int(os.environ.get("OSPRIME_INDEX_FIRST_WAIT", "180"))
EVERY = 30 * 60
POLL = 15                      # how often a request from Settings is noticed

MAX_FILES = 200_000
MAX_CONTENT_BYTES = 20 * 1024 * 1024    # bigger than this: the name only
MAX_TEXT = 200_000                       # characters kept from one file
CHUNK, OVERLAP = 800, 120
MAX_VEC_CHUNKS = 48                      # per file; the words layer keeps all
SEM_MIN = float(os.environ.get("OSPRIME_SEM_MIN", "0.80"))

NOISE = {"node_modules", "__pycache__", "venv", "site-packages", "Trash",
         "lost+found", "snap"}
TEXT_EXT = {".txt", ".md", ".markdown", ".csv", ".tsv", ".json", ".xml",
            ".html", ".htm", ".log", ".ini", ".cfg", ".conf", ".yaml", ".yml",
            ".py", ".js", ".ts", ".sh", ".c", ".h", ".cpp", ".java", ".go",
            ".rs", ".php", ".rb", ".css", ".sql", ".tex", ".srt", ".vtt", ".rtf"}
ZIP_DOCS = {".docx": ("word/document.xml",),
            ".pptx": ("ppt/slides/",),
            ".xlsx": ("xl/sharedStrings.xml",),
            ".odt": ("content.xml",), ".ods": ("content.xml",),
            ".odp": ("content.xml",)}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp"}
# Never read, whatever their folder: keys, wallets, password stores.
SECRET_EXT = {".pem", ".key", ".kdbx", ".kdb", ".p12", ".pfx", ".gpg", ".asc",
              ".keystore", ".jks", ".ovpn"}
_SECRET_NAME = re.compile(r"password|passwd|wallet|seed.?phrase|recovery.?key|"
                          r"secret|private.?key|credential", re.I)

_lock = threading.Lock()      # one indexing pass at a time in this process


# ---------------------------------------------------------------------------
# settings and places
# ---------------------------------------------------------------------------
def _flag(key: str, default: str) -> bool:
    return paths.read_desktop_env().get(key, default).strip('"').lower() not in ("no", "0", "off", "false")


def enabled() -> bool:
    return _flag(KEY_ON, "yes")


def ocr_enabled() -> bool:
    return _flag(KEY_OCR, "no")


def db_path() -> pathlib.Path:
    return pathlib.Path(os.environ.get("OSPRIME_FILE_INDEX_DB")
                        or paths.data_dir() / "fileindex.db")


def _request_path() -> pathlib.Path:
    return db_path().with_name("fileindex.request")


def root() -> pathlib.Path:
    return pathlib.Path(os.environ.get("OSPRIME_INDEX_ROOT") or paths.home())


def set_enabled(on: bool) -> str:
    if not paths.write_desktop_env(KEY_ON, "yes" if on else "no"):
        return "ERROR: could not save the setting."
    if on:
        request("run")
        return "File search by content is on. The first pass runs in the background."
    forget()
    return "File search by content is off, and its index has been deleted."


def set_ocr(on: bool) -> str:
    if not paths.write_desktop_env(KEY_OCR, "yes" if on else "no"):
        return "ERROR: could not save the setting."
    request("run")
    return ("Text in pictures will be read too. This is slow the first time."
            if on else "Text in pictures is no longer read; it is being removed from the index.")


def request(what: str = "run"):
    """Ask the assistant's indexer to run soon ("run") or start over
    ("rebuild"). Settings runs in another process; this file is the message."""
    try:
        p = _request_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        if what == "rebuild" or not p.exists():
            p.write_text(what)
    except OSError:
        pass


def forget():
    with _lock:
        for suffix in ("", "-wal", "-shm"):
            try:
                pathlib.Path(str(db_path()) + suffix).unlink()
            except OSError:
                pass


# ---------------------------------------------------------------------------
# text: normalised the same way for the index and for a question
# ---------------------------------------------------------------------------
_AR_FA = str.maketrans({"ي": "ی", "ى": "ی", "ك": "ک", "ة": "ه", "ۀ": "ه",
                        "‌": " ", "‏": " ", "‎": " ",
                        "ـ": ""})
_DIACRITICS = re.compile(r"[ً-ٰٟ]")


def normalize(text: str) -> str:
    return _DIACRITICS.sub("", (text or "").translate(_AR_FA))


_STOP = set("""a an the of to in on for and or is are was were be it this that
these those my me i you your with from by at as about file files document
documents find where which what show open please can could some any thing
called named saved wrote write written
و در به از که این آن را با برای یک تا اون این‌که فایل فایلی فایلها سند
پیدا کن کجاست کجا کو کدوم کدام همون همان بود هست است میخوام می‌خوام
درباره دربارهٔ مربوط توش نوشتم نوشته""".split())


def _terms(query: str) -> list:
    words = re.findall(r"\w+", normalize(query).lower())
    out = []
    for w in words:
        if w not in _STOP and len(w) > 1 and w not in out:
            out.append(w)
    return out[:12]


def _fts_query(query: str) -> str:
    return " OR ".join(f'"{t}"*' for t in _terms(query))


# ---------------------------------------------------------------------------
# reading a file
# ---------------------------------------------------------------------------
def _quiet(cmd: list, timeout: int) -> str:
    """A helper program, at the lowest priority the machine has."""
    pre = []
    if os.path.exists("/usr/bin/nice"):
        pre += ["nice", "-n", "19"]
    if os.path.exists("/usr/bin/ionice"):
        pre += ["ionice", "-c", "3"]
    try:
        r = subprocess.run(pre + cmd, capture_output=True, timeout=timeout)
        return r.stdout.decode("utf-8", "replace")
    except Exception:
        return ""


def _xml_text(data: bytes) -> str:
    t = data.decode("utf-8", "replace")
    t = re.sub(r"</(?:w:p|a:p|text:p|text:h|si|row)>", "\n", t)
    t = re.sub(r"<[^>]+>", " ", t)
    for a, b in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"'), ("&apos;", "'")):
        t = t.replace(a, b)
    return re.sub(r"[ \t]+", " ", t)


def extract(path: pathlib.Path, ocr: bool = False) -> str:
    """The text in a file, or "" when there is none we can read."""
    ext = path.suffix.lower()
    try:
        if ext in TEXT_EXT:
            with open(path, "rb") as f:
                data = f.read(2 * 1024 * 1024)
            if b"\x00" in data[:4096]:
                return ""
            text = data.decode("utf-8", "replace")
            if ext in (".html", ".htm", ".xml"):
                text = _xml_text(data)
            return text
        if ext == ".pdf":
            return _quiet(["pdftotext", "-l", "60", "-q", str(path), "-"], 90)
        if ext in ZIP_DOCS:
            parts = []
            with zipfile.ZipFile(path) as z:
                for name in sorted(z.namelist()):
                    if any(name == w or (w.endswith("/") and name.startswith(w)
                                         and name.endswith(".xml")) for w in ZIP_DOCS[ext]):
                        info = z.getinfo(name)
                        if info.file_size > 30 * 1024 * 1024:
                            continue
                        parts.append(_xml_text(z.read(name)))
            return "\n".join(parts)
        if ext in IMAGE_EXT and ocr:
            if path.stat().st_size < 8 * 1024:
                return ""         # icons and thumbnails
            return _quiet(["tesseract", str(path), "stdout", "-l", _ocr_langs()], 120)
    except Exception:
        return ""
    return ""


_LANGS = None


def _ocr_langs() -> str:
    """English and Persian when tesseract has both (the ISO ships both)."""
    global _LANGS
    if _LANGS is None:
        have = _quiet(["tesseract", "--list-langs"], 20).split()
        _LANGS = "+".join(l for l in ("eng", "fas") if l in have) or "eng"
    return _LANGS


def _chunks(text: str) -> list:
    text = re.sub(r"\s+\n", "\n", re.sub(r"[ \t\r\f\v]+", " ", text or "")).strip()[:MAX_TEXT]
    if not text:
        return []
    out, i = [], 0
    while i < len(text):
        piece = text[i:i + CHUNK]
        if i + CHUNK < len(text):
            cut = max(piece.rfind("\n"), piece.rfind(". "))
            if cut > CHUNK // 2:
                piece = piece[:cut + 1]
        out.append(piece.strip())
        if i + len(piece) >= len(text):
            break
        # step back OVERLAP characters, to the start of a word
        nxt = i + max(len(piece) - OVERLAP, 1)
        sp = text.find(" ", nxt, i + len(piece))
        i = sp + 1 if sp > 0 else nxt
    return [c for c in out if c]


def skipped(path: pathlib.Path, base: pathlib.Path) -> bool:
    """Hidden, noise, or something that looks like a secret."""
    try:
        rel = path.relative_to(base)
    except ValueError:
        return True
    for part in rel.parts:
        if part.startswith(".") or part in NOISE:
            return True
    if path.suffix.lower() in SECRET_EXT or _SECRET_NAME.search(path.name):
        return True
    try:
        import permissions
        if permissions.touches_secret(str(path)):
            return True
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# the embedding server
# ---------------------------------------------------------------------------
def embed(texts: list, timeout: float = 60):
    """Unit vectors for texts, or None if the model is not there."""
    if not texts:
        return []
    body = json.dumps({"input": texts, "model": EMBED_MODEL}).encode()
    req = urllib.request.Request(EMBED_URL + "/v1/embeddings", data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read())["data"]
    except Exception:
        return None
    out = []
    for item in sorted(data, key=lambda d: d.get("index", 0)):
        v = item["embedding"]
        if v and isinstance(v[0], list):      # one vector per token: pool
            n = len(v)
            v = [sum(col) / n for col in zip(*v)]
        norm = sum(x * x for x in v) ** 0.5 or 1.0
        out.append([x / norm for x in v])
    return out if len(out) == len(texts) else None


def model_ready() -> bool:
    try:
        with urllib.request.urlopen(EMBED_URL + "/health", timeout=3) as r:
            return r.status == 200
    except Exception:
        return False


def _pack(v) -> bytes:
    return struct.pack(f"{len(v)}f", *v)


# ---------------------------------------------------------------------------
# the database
# ---------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS files(path TEXT PRIMARY KEY, mtime REAL, size INTEGER,
                                 kind TEXT, ocr INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS chunks(id INTEGER PRIMARY KEY, path TEXT, n INTEGER,
                                  text TEXT, vec BLOB);
CREATE INDEX IF NOT EXISTS chunks_path ON chunks(path);
CREATE VIRTUAL TABLE IF NOT EXISTS fts USING fts5(name, text,
                                  tokenize='unicode61 remove_diacritics 2');
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);
"""


def _connect(create: bool = True):
    p = db_path()
    if not create and not p.exists():
        return None
    p.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(p), timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(SCHEMA)
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
    return conn


def _meta(conn, k, v=None):
    if v is None:
        row = conn.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
        return row[0] if row else None
    conn.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (k, str(v)))


def _drop(conn, path: str):
    ids = [r[0] for r in conn.execute("SELECT id FROM chunks WHERE path=?", (path,))]
    conn.executemany("DELETE FROM fts WHERE rowid=?", [(i,) for i in ids])
    conn.execute("DELETE FROM chunks WHERE path=?", (path,))
    conn.execute("DELETE FROM files WHERE path=?", (path,))


def _add(conn, path: pathlib.Path, st, ocr: bool):
    text = extract(path, ocr) if st.st_size <= MAX_CONTENT_BYTES else ""
    pieces = _chunks(text) or [""]
    name = normalize(path.stem.replace("_", " ").replace("-", " "))
    conn.execute("INSERT INTO files VALUES(?,?,?,?,?)",
                 (str(path), st.st_mtime, st.st_size, path.suffix.lower(),
                  1 if (ocr and path.suffix.lower() in IMAGE_EXT) else 0))
    for n, piece in enumerate(pieces):
        cur = conn.execute("INSERT INTO chunks(path, n, text, vec) VALUES(?,?,?,NULL)",
                           (str(path), n, piece))
        conn.execute("INSERT INTO fts(rowid, name, text) VALUES(?,?,?)",
                     (cur.lastrowid, name, normalize(piece)))


def _walk(base: pathlib.Path):
    for dirpath, dirnames, filenames in os.walk(base, followlinks=False):
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in NOISE]
        for fn in filenames:
            if not fn.startswith("."):
                yield pathlib.Path(dirpath) / fn


def run_once(stop=None, pause: float = 0.01) -> dict:
    """One pass: read new and changed files, forget removed ones, then give
    vectors to whatever has none yet. Returns counts, for the log."""
    if not enabled():
        forget()
        return {"off": True}
    if not _lock.acquire(blocking=False):
        return {"busy": True}
    try:
        return _run(stop, pause)
    finally:
        _lock.release()


def _run(stop, pause) -> dict:
    base = root().resolve()
    ocr = ocr_enabled()
    conn = _connect()
    added = removed = 0
    try:
        known = {p: (m, s, o) for p, m, s, o in
                 conn.execute("SELECT path, mtime, size, ocr FROM files")}
        seen = set()
        _meta(conn, "running", time.time())
        conn.commit()
        for i, path in enumerate(_walk(base)):
            if stop and stop():
                break
            if len(seen) >= MAX_FILES:
                break
            if skipped(path, base):
                continue
            try:
                st = path.lstat()
            except OSError:
                continue
            if not path.is_file() or path.is_symlink():
                continue
            key = str(path)
            seen.add(key)
            old = known.get(key)
            wants_ocr = ocr and path.suffix.lower() in IMAGE_EXT
            if old and old[0] == st.st_mtime and old[1] == st.st_size \
                    and bool(old[2]) == wants_ocr:
                continue
            if old:
                _drop(conn, key)
            _add(conn, path, st, ocr)
            added += 1
            if added % 50 == 0:
                conn.commit()
            time.sleep(pause)
        else:
            # only a COMPLETE walk may conclude a file is gone
            for key in set(known) - seen:
                _drop(conn, key)
                removed += 1
        conn.commit()
        vectors = _fill_vectors(conn, stop)
        _meta(conn, "running", "")
        _meta(conn, "last_run", time.time())
        conn.commit()
        return {"added": added, "removed": removed, "vectors": vectors}
    finally:
        conn.close()


def _fill_vectors(conn, stop) -> int:
    if _meta(conn, "model") not in (None, EMBED_MODEL):
        conn.execute("UPDATE chunks SET vec=NULL")      # another model: start again
    _meta(conn, "model", EMBED_MODEL)
    if not model_ready():
        return 0
    done = 0
    while not (stop and stop()):
        rows = conn.execute(
            "SELECT id, path, text FROM chunks WHERE vec IS NULL AND n < ? "
            "ORDER BY id LIMIT 16", (MAX_VEC_CHUNKS,)).fetchall()
        if not rows:
            break
        texts = [f"passage: {pathlib.Path(p).stem}\n{t}"[:2000] for _, p, t in rows]
        vecs = embed(texts)
        if vecs is None:
            break
        conn.executemany("UPDATE chunks SET vec=? WHERE id=?",
                         [(_pack(v), r[0]) for v, r in zip(vecs, rows)])
        conn.commit()
        done += len(rows)
        time.sleep(0.05)
    return done


# ---------------------------------------------------------------------------
# asking
# ---------------------------------------------------------------------------
def _snippet(text: str, terms: list, width: int = 220) -> str:
    flat = re.sub(r"\s+", " ", text or "").strip()
    low = normalize(flat).lower()
    at = min((low.find(t) for t in terms if low.find(t) >= 0), default=0)
    start = max(0, at - width // 3)
    out = flat[start:start + width]
    return ("…" if start else "") + out + ("…" if start + width < len(flat) else "")


def search(query: str, folder: str = "", days: int = 0, limit: int = 10) -> dict:
    """Files about `query`, best first. Never raises."""
    conn = _connect(create=False)
    if conn is None:
        return {"ready": False, "results": [], "semantic": False}
    try:
        return _search(conn, query, folder, days, limit)
    except sqlite3.Error as e:
        return {"ready": False, "results": [], "semantic": False, "error": str(e)}
    finally:
        conn.close()


def _search(conn, query, folder, days, limit) -> dict:
    terms = _terms(query)
    ranks = {}          # path -> {"words": rank, "meaning": rank, "chunk": text, "score": cos}
    ok_path = _path_filter(conn, folder, days)

    fq = _fts_query(query)
    if fq:
        rows = conn.execute(
            "SELECT c.path, c.text FROM fts JOIN chunks c ON c.id = fts.rowid "
            "WHERE fts MATCH ? ORDER BY bm25(fts, 4.0, 1.0) LIMIT 400", (fq,)).fetchall()
        r = 0
        for path, text in rows:
            if path in ranks or not ok_path(path):
                continue
            ranks[path] = {"words": r, "chunk": text}
            r += 1

    semantic = False
    qv = embed([f"query: {query}"], timeout=20)
    if qv:
        try:
            import numpy as np
            rows = conn.execute("SELECT path, text, vec FROM chunks WHERE vec IS NOT NULL").fetchall()
            if rows:
                semantic = True
                m = np.frombuffer(b"".join(v for _, _, v in rows), dtype=np.float32)
                m = m.reshape(len(rows), -1)
                scores = m @ np.asarray(qv[0], dtype=np.float32)
                best = {}
                for idx in np.argsort(-scores)[:600]:
                    s = float(scores[idx])
                    if s < SEM_MIN:
                        break
                    path, text, _ = rows[idx]
                    if path not in best and ok_path(path):
                        best[path] = (s, text)
                for r, (path, (s, text)) in enumerate(sorted(best.items(), key=lambda kv: -kv[1][0])):
                    e = ranks.setdefault(path, {"chunk": text})
                    e["meaning"], e["score"] = r, s
                    if "words" not in e:
                        e["chunk"] = text
        except Exception:
            semantic = False

    def fused(e):       # reciprocal rank fusion
        return sum(1.0 / (60 + e[k]) for k in ("words", "meaning") if k in e)

    out = []
    for path, e in sorted(ranks.items(), key=lambda kv: -fused(kv[1]))[:limit]:
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            continue
        out.append({"path": path, "modified": time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime)),
                    "matched": "+".join(k for k in ("words", "meaning") if k in e),
                    "snippet": _snippet(e.get("chunk", ""), terms)})
    return {"ready": True, "results": out, "semantic": semantic}


def _path_filter(conn, folder, days):
    prefix = ""
    if folder:
        f = pathlib.Path(os.path.expanduser(folder))
        if not f.is_absolute():
            f = root() / f
        prefix = str(f.resolve()).rstrip("/") + "/"
    since = time.time() - int(days) * 86400 if days else 0
    mt = dict(conn.execute("SELECT path, mtime FROM files")) if since else {}

    def ok(path):
        if prefix and not path.startswith(prefix):
            return False
        if since and mt.get(path, 0) < since:
            return False
        return True
    return ok


# ---------------------------------------------------------------------------
# what Settings shows
# ---------------------------------------------------------------------------
def status() -> dict:
    out = {"enabled": enabled(), "ocr": ocr_enabled(), "files": 0, "with_text": 0,
           "vectors": 0, "chunks": 0, "last_run": None, "running": False,
           "model": model_ready()}
    conn = _connect(create=False)
    if conn is None:
        return out
    try:
        out["files"] = conn.execute("SELECT count(*) FROM files").fetchone()[0]
        out["with_text"] = conn.execute(
            "SELECT count(DISTINCT path) FROM chunks WHERE text != ''").fetchone()[0]
        out["chunks"] = conn.execute(
            "SELECT count(*) FROM chunks WHERE n < ?", (MAX_VEC_CHUNKS,)).fetchone()[0]
        out["vectors"] = conn.execute("SELECT count(*) FROM chunks WHERE vec IS NOT NULL").fetchone()[0]
        lr, running = _meta(conn, "last_run"), _meta(conn, "running")
        out["last_run"] = float(lr) if lr else None
        out["running"] = bool(running) and time.time() - float(running) < 6 * 3600
    except (sqlite3.Error, ValueError):
        pass
    finally:
        conn.close()
    return out


# ---------------------------------------------------------------------------
# in the background, inside the person's own assistant
# ---------------------------------------------------------------------------
def _lower_priority():
    """This thread only: nice 19 and idle I/O (Linux priorities are per thread)."""
    try:
        tid = threading.get_native_id()
        os.setpriority(os.PRIO_PROCESS, tid, 19)
    except Exception:
        pass
    try:
        import ctypes
        libc = ctypes.CDLL(None, use_errno=True)
        IOPRIO_WHO_PROCESS, IOPRIO_CLASS_IDLE = 1, 3
        libc.syscall(251, IOPRIO_WHO_PROCESS, threading.get_native_id(),
                     IOPRIO_CLASS_IDLE << 13)        # ioprio_set on x86_64
    except Exception:
        pass


def _loop():
    _lower_priority()
    time.sleep(FIRST_WAIT)
    last = 0.0
    while True:
        try:
            req = _request_path()
            asked = req.read_text().strip() if req.exists() else ""
            if asked:
                req.unlink(missing_ok=True)
                if asked == "rebuild":
                    forget()
            if not enabled():
                if db_path().exists():
                    forget()
            elif asked or time.time() - last >= EVERY:
                last = time.time()
                print(f"file index: {run_once()}", flush=True)
        except Exception as e:
            print(f"file index failed: {e}", flush=True)
        time.sleep(POLL)


def start():
    threading.Thread(target=_loop, daemon=True, name="fileindex").start()


def probe() -> list:
    """Does the real model understand? Problems, or [] — run on a machine:
        python3 /opt/osprime/agent/fileindex.py probe"""
    cases = [("rental agreement for the shop", "قرارداد اجاره مغازه با آقای کریمی",
              "دستور پخت کیک شکلاتی با گردو"),
             ("دستور پخت کیک", "Chocolate cake recipe with walnuts",
              "Lease contract for the warehouse"),
             ("electricity bill", "قبض برق ماه اسفند پرداخت شد",
              "عکس‌های سفر شمال")]
    bad = []
    if not model_ready():
        return [f"the model is not answering at {EMBED_URL} (systemctl status osprime-embed)"]
    for q, right, wrong in cases:
        v = embed([f"query: {q}", f"passage: {right}", f"passage: {wrong}"])
        if not v:
            return ["the model answered with no vectors"]
        good = sum(a * b for a, b in zip(v[0], v[1]))
        poor = sum(a * b for a, b in zip(v[0], v[2]))
        print(f"  {q!r}: right {good:.3f}, wrong {poor:.3f}")
        if good <= poor:
            bad.append(f"{q!r} matched the wrong text")
        elif good < SEM_MIN:
            bad.append(f"{q!r}: the right text scored {good:.3f}, under SEM_MIN {SEM_MIN}")
    return bad


if __name__ == "__main__":
    import sys
    if sys.argv[1:2] == ["probe"]:
        problems = probe()
        print("\n".join(problems) if problems else "the meaning model works")
        sys.exit(1 if problems else 0)
    if sys.argv[1:2] == ["run"]:
        print(run_once())
    elif sys.argv[1:2] == ["search"]:
        print(json.dumps(search(" ".join(sys.argv[2:])), ensure_ascii=False, indent=2))
    else:
        print(json.dumps(status(), indent=2))
