#!/usr/bin/env bash
# The small model that lets file search understand meaning (agent/fileindex.py).
#
# multilingual-e5-small, ~130 MB, Persian and English. Served by llama-server
# in embedding mode on 127.0.0.1:8093, on the PROCESSOR only (-ngl 0): the
# graphics card belongs to the main model and to vision (agent/engines.py),
# and turning a paragraph into numbers does not need it.
#
# Run as the osprime service account by osprime-embed.service. If the model
# is not on the disk yet (a machine installed before 1 October) it is
# downloaded here, checked against its sha256, and only then used. With no
# network this exits; systemd tries again later, and file search keeps
# working by words in the meantime.
#
#     bash /opt/osprime/shell/osprime-embed.sh      run it by hand to see why it fails
set -u

MODELS="${OSPRIME_MODELS:-/var/lib/osprime/models}"
FILE="$MODELS/embed-multilingual-e5-small-q8_0.gguf"
URL="${OSPRIME_EMBED_MODEL_URL:-https://huggingface.co/keisuke-miyako/multilingual-e5-small-gguf-q8_0/resolve/main/multilingual-e5-small-Q8_0.gguf}"
SHA256="0d5a5a0b0ad84faad6357a6145e769b0661f0efbf53acf74598afc34dab454f4"
PORT="${OSPRIME_EMBED_PORT:-8093}"
THREADS="${OSPRIME_EMBED_THREADS:-2}"

if [ ! -s "$FILE" ]; then
    echo "embedding model missing; downloading (about 130 MB) ..." >&2
    mkdir -p "$MODELS"
    curl -fL --retry 3 --continue-at - -o "$FILE.part" "$URL" || {
        echo "download failed; file search works by words until it succeeds." >&2
        exit 1; }
    got="$(sha256sum "$FILE.part" | cut -d' ' -f1)"
    if [ "$got" != "$SHA256" ]; then
        echo "the download does not match its checksum ($got); not used." >&2
        rm -f "$FILE.part"
        exit 1
    fi
    mv "$FILE.part" "$FILE"
fi

BIN="$(command -v llama-server || command -v llama-cpp-server || true)"
[ -n "$BIN" ] || { echo "FATAL: no llama-server in PATH." >&2; exit 1; }

# --embedding (older builds: --embeddings), mean pooling as e5 was trained,
# a 512-token window (e5's own limit), nothing on the graphics card.
EMB=--embedding
"$BIN" --help 2>&1 | grep -q -- '--embedding\b' || EMB=--embeddings
ARGS=(-m "$FILE" --host 127.0.0.1 --port "$PORT" "$EMB" --pooling mean
      -c 512 -b 512 -ub 512 -t "$THREADS" -ngl 0)
exec "$BIN" "${ARGS[@]}"
