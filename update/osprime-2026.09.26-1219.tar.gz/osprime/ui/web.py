#!/usr/bin/env python3
"""OSprime web UI: stdlib-only HTTP server that serves an RTL chat page
and bridges it to the agent daemon's Unix socket.

Run:  python3 ui/web.py   →  open http://localhost:8080
"""

import http.server
import json
import os
import pathlib
import socket
import sys
import threading
import time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "agent"))
import i18n
import webguard
import proactive
import qr
import remote as remote_access
import settings_page
import system_tools
import updater
import voice
import eyes
import people


sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "agent"))
import paths as _paths  # noqa: E402
SECRETS_PATH = _paths.secrets()


def _plain(msg: str) -> str:
    """Strip the ERROR: marker before showing a message to a person.

    The prefix exists so the assistant cannot mistake a failure for a
    success. It means nothing to the user reading a settings window.
    """
    return msg[6:].strip() if msg.startswith("ERROR:") else msg


def _read_settings() -> dict:
    """One read, from the same place the assistant reads."""
    out = json.loads(system_tools.get_settings())
    t = system_tools.get_time()
    try:
        # "automatic_sync", not "auto_sync". There were two get_time()
        # functions in system_tools for months — Python kept the second and
        # silently discarded the first, and this line was reading the dead
        # one's key name. .get(..., False) turned that into a permanent
        # "off": the clock's automatic-sync switch in Settings showed off
        # even with NTP running. No error, no log, just a wrong answer.
        out["auto_time"] = bool(json.loads(t)["automatic_sync"])
    except (json.JSONDecodeError, KeyError):
        out["auto_time"] = False
    net = system_tools.network_status()
    try:
        out["network"] = ", ".join(n["name"] for n in json.loads(net))
    except json.JSONDecodeError:
        # _plain, not the raw string: "ERROR: could not read network
        # status" is a sentence for a log, not for a label in a window.
        out["network"] = _plain(net)
    out["has_api_key"] = "ANTHROPIC_API_KEY" in _read_secrets()
    return out


def _overview() -> dict:
    """Everything the "This machine" page shows, in one request.

    Six separate fetches for one page is six chances for one of them to
    fail quietly and leave a card reading "unknown" with no reason. This
    assembles them here, where a failure can be caught and named.

    Nothing in here touches the agent. This page has to render on a machine
    whose model will not load — that is precisely when someone opens it.
    """
    out = {"version": _version()}
    try:
        out.update(json.loads(system_tools.system_summary()))
    except Exception:
        pass
    try:
        out.update(json.loads(system_tools.model_status()))
    except Exception:
        # model_status returns a plain ERROR string when the hardware
        # profile cannot be read. The page copes with the keys missing.
        pass
    try:
        out["network"] = ", ".join(
            n["name"] for n in json.loads(system_tools.network_status()))
    except Exception:
        out["network"] = ""
    # Administrators only: updates, the model, eyes (docs/ACCOUNTS.md,
    # phase 2). Without a login yet, the one account has those rights.
    try:
        out["is_admin"] = people.is_admin() if people.enabled() else True
    except Exception:
        out["is_admin"] = True
    # These two were first added to the wrong function (the settings
    # reader), so Settings → Home never showed Disk or Python libraries —
    # found in the encrypted VM, 26 September. tests/test_overview.py.
    try:
        import disk
        out["disk_encryption"] = disk.status()
    except Exception:
        pass
    try:
        import pyenv
        out["python"] = pyenv.status()
    except Exception:
        pass
    return out


def _memory_db():
    """Read the assistant's memory without going through the assistant.

    Its own connection to the same SQLite file, not a call into the agent.
    The Control Panel has to work when the agent is dead, and "what has this
    thing remembered about me" is a question a person is entitled to an
    answer to whether or not the model will load. SQLite in WAL mode is
    built for exactly this — one writer, other readers.
    """
    import memory as memory_mod
    path = os.environ.get("OSPRIME_MEMORY_DB", "/var/lib/osprime/memory.db")
    return memory_mod.Memory(path)


def _memory_list() -> dict:
    try:
        mem = _memory_db()
        return {"ok": True, "count": mem.count(), "memories": mem.all(200)}
    except Exception as e:
        return {"ok": False, "count": 0, "memories": [], "message": str(e)}


def _storage() -> dict:
    out = {}
    try:
        out["usage"] = json.loads(system_tools.disk_usage())
    except Exception:
        out["usage"] = None
    try:
        out["drives"] = json.loads(system_tools.list_drives())
    except Exception:
        out["drives"] = []
    return out


def _read_secrets() -> dict:
    out = {}
    try:
        for line in SECRETS_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except Exception:
        pass
    return out


def _apply_setting(key: str, value) -> dict:
    """Every branch calls the same function the assistant would call, so the
    two interfaces cannot disagree about what a setting means."""
    try:
        if key == "wallpaper":
            msg = system_tools.set_wallpaper(str(value))
        elif key == "language":
            msg = system_tools.set_language(str(value))
        elif key == "timezone":
            msg = system_tools.set_timezone(str(value))
        elif key == "time":
            msg = system_tools.set_time(str(value))
        elif key == "auto_time":
            msg = system_tools.set_auto_time(bool(value))
        elif key == "volume":
            msg = system_tools.set_volume(value)
        elif key == "scale":
            msg = system_tools.set_display(scale=str(value))
        elif key == "text_size":
            msg = system_tools.set_text_size(value)
        elif key == "resolution":
            msg = system_tools.set_display(resolution=str(value))
        elif key == "desktop":
            system_tools._write_env("OSPRIME_DESKTOP",
                                    "yes" if value else "no")
            msg = ("desktop on — log out and back in to see it"
                   if value else "desktop off — log out and back in")
        elif key == "companion":
            msg = system_tools.set_companion(bool(value))
        elif key == "proactive":
            msg = system_tools.set_proactive(bool(value))
        elif key in ("allow_camera", "allow_microphone"):
            msg = system_tools.set_capture(
                "camera" if key == "allow_camera" else "microphone",
                bool(value))
        elif key == "confirm_level":
            msg = system_tools.set_confirm_level(str(value))
        elif key == "cloud_mode":
            if str(value) not in ("off", "ask", "auto"):
                return {"ok": False, "message": "unknown cloud mode"}
            system_tools._write_env("OSPRIME_CLOUD_MODE", str(value))
            msg = "cloud mode saved — restart the assistant to apply"
        elif key == "api_key":
            v = str(value or "").strip()
            if not v:
                return {"ok": False, "message": "no key given"}
            SECRETS_PATH.parent.mkdir(parents=True, exist_ok=True)
            lines = [l for l in (SECRETS_PATH.read_text(encoding="utf-8").splitlines()
                                 if SECRETS_PATH.exists() else [])
                     if not l.startswith("ANTHROPIC_API_KEY=")]
            lines.append(f"ANTHROPIC_API_KEY={v}")
            SECRETS_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
            SECRETS_PATH.chmod(0o600)
            msg = "key saved on this machine"
        else:
            return {"ok": False, "message": f"unknown setting: {key}"}
    except Exception as e:
        return {"ok": False, "message": str(e)}

    # system_tools marks every failure with an ERROR: prefix, which replaces
    # the previous guesswork of matching phrases inside the message.
    return {"ok": not msg.startswith("ERROR:"), "message": _plain(msg)}


def _version() -> str:
    for p in (pathlib.Path(__file__).resolve().parent.parent / "VERSION",
              pathlib.Path("/opt/osprime/VERSION")):
        try:
            return p.read_text(encoding="utf-8").strip()
        except Exception:
            continue
    return "dev"

import paths  # noqa: E402  — agent/paths.py, docs/ACCOUNTS.md
SOCKET_PATH = paths.socket_path()
PROFILE_PATH = paths.profile()
PORT = int(os.environ.get("OSPRIME_WEB_PORT", "8080"))

_sessions = {}
_lock = threading.Lock()

# Which paired device owns each conversation; None for the computer itself.
# Checked on /api/chat, /api/confirm and /api/end, so a phone can neither
# join a conversation started at the computer nor answer a question that
# was asked there. The session ids are random UUIDs and not guessable — this
# is the check that does not depend on that.
_session_owner = {}
_owner_lock = threading.Lock()

# Approvals asked for by a paired device that may not approve its own
# requests. They wait here for someone at the computer. Agreed with Ehsan on
# 23 September: by default a phone can ask for anything, but a dangerous
# action is approved at the machine it happens on.
#   (session, confirm id) -> {text, detail, device, at}
_pending = {}
_pending_lock = threading.Lock()
PENDING_SECONDS = 300      # matches the agent's own wait in confirm()


def _claim_session(sid: str, owner):
    """Record who owns a conversation; False if it belongs to someone else."""
    with _owner_lock:
        current = _session_owner.setdefault(sid, owner)
    return current == owner


def _pending_list() -> list:
    now = time.time()
    with _pending_lock:
        for key in [k for k, v in _pending.items()
                    if now - v["at"] > PENDING_SECONDS]:
            _pending.pop(key, None)
        return [{"session": s, "id": i, **v} for (s, i), v in _pending.items()]

# A conversation nobody has spoken in for this long is over. The number is
# generous on purpose: someone who walks away mid-thought and comes back
# after lunch should find their conversation, not a blank window.
IDLE_TIMEOUT = 30 * 60


def get_session(sid: str):
    """One persistent daemon connection per browser session (keeps history)."""
    with _lock:
        if sid not in _sessions:
            sk = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sk.connect(SOCKET_PATH)
            _sessions[sid] = {"sock": sk, "f": sk.makefile("rwb"),
                              "lock": threading.Lock(), "seen": time.time()}
        _sessions[sid]["seen"] = time.time()
        return _sessions[sid]


def end_session(sid: str) -> bool:
    """Close one conversation.

    Closing the socket is what tells the agent the conversation is over, and
    the agent's own end-of-conversation work — reading the exchange and
    keeping the few durable facts in it — runs at exactly that moment.
    Nothing ever closed these, so that step had effectively never run
    outside a service restart: the assistant was not learning anything from
    talking to anyone.
    """
    with _lock:
        sess = _sessions.pop(sid, None)
    with _owner_lock:
        _session_owner.pop(sid, None)
    if not sess:
        return False
    for closer in (sess["f"].close, sess["sock"].close):
        try:
            closer()
        except Exception:
            pass
    return True


def _reap_idle_sessions():
    """Close conversations that have gone quiet, forever, in the background.

    The browser says goodbye when it can, but a window that is killed, a
    machine that sleeps, or a tab that crashes says nothing at all. Without
    this the sockets accumulate one per chat window opened, for as long as
    the service runs.
    """
    while True:
        time.sleep(60)
        cutoff = time.time() - IDLE_TIMEOUT
        for sid in [s for s, v in list(_sessions.items())
                    if v.get("seen", 0) < cutoff]:
            if end_session(sid):
                print(f"conversation {sid[:8]} ended after being idle")


def session_send(sess, obj):
    with sess["lock"]:
        sess["f"].write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
        sess["f"].flush()


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    # ---- who may ask --------------------------------------------------------
    # Every request is checked before any handler runs. The rules, and why
    # each exists, are in webguard.py; this is only the wiring.
    def end_headers(self):
        for name, value in webguard.SECURITY_HEADERS:
            self.send_header(name, value)
        super().end_headers()

    # False on the loopback listener, True on the one remote.py opens on the
    # local network. A separate listener rather than a check of the client's
    # address: a request that arrived on the network port can never be
    # mistaken for one from this machine, whatever it claims about itself.
    remote = False
    device = None          # the paired device making this request, if remote

    def _refuse(self, why: str, code: int = 403, message: str = "") -> bool:
        # Logged, because a refusal nobody can see is indistinguishable from
        # a broken page — and the first time this fires on a real machine it
        # will be either an attack or a bug in these rules, and both need to
        # be found.
        where = f" from {self.client_address[0]}" if self.remote else ""
        print(f"refused {self.command} {self.path}{where}: {why}", flush=True)
        self._json({"error": "forbidden", "message": message or why}, code)
        return True

    def _guarded(self) -> bool:
        """True if the request was refused and answered here."""
        if not self.remote:
            why = webguard.check(self.command, self.path, self.headers, PORT)
            return self._refuse(why) if why else False

        # ---- the remote listener -------------------------------------------
        ip = self.client_address[0]
        why = remote_access.allowed_client(ip)
        if why:
            return self._refuse(why)
        ours = {f"{a}:{remote_access.PORT}"
                for a in remote_access.lan_addresses()}
        why = webguard.check(self.command, self.path, self.headers,
                             remote_access.PORT, ours=ours)
        if why:
            return self._refuse(why)
        # The pairing page is the one thing reachable without a key — it is
        # how a key is obtained. It does nothing unless a pairing window was
        # opened on the computer in the last two minutes.
        if self.path.split("?", 1)[0] == "/pair":
            return False
        self.device = remote_access.authenticate(
            self.headers.get("Cookie", ""), ip)
        if not self.device:
            if self.command == "GET" and not self.path.startswith("/api/"):
                self._html(_NOT_PAIRED, 401)
                return True
            return self._refuse("not paired", 401,
                                "This device is not paired with the computer.")
        if not remote_access.path_allowed(self.command, self.path):
            return self._refuse(
                "local only", 403,
                "This can only be changed on the computer itself.")
        return False

    def _html(self, page: str, code: int = 200, cookie: str = ""):
        data = page.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(data)

    # No CORS preflight is ever answered: nothing on another origin is meant
    # to call this, so the correct answer to "may I?" is no. The other
    # methods have no handlers at all and are refused the same way rather
    # than falling through to http.server's default page.
    def _no(self):
        self.send_response(403)
        self.send_header("Content-Length", "0")
        self.end_headers()

    do_OPTIONS = do_PUT = do_DELETE = do_PATCH = _no

    def _json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # Pictures the assistant refers to are shown in the chat, which means the
    # page has to be able to fetch them. Deliberately narrow: images only,
    # inside the user's own home directory, resolved before it is checked so
    # a path full of ".." cannot walk out of it.
    _IMAGE_TYPES = {".png": "image/png", ".jpg": "image/jpeg",
                    ".jpeg": "image/jpeg", ".gif": "image/gif",
                    ".webp": "image/webp", ".bmp": "image/bmp"}

    def _serve_file(self):
        import urllib.parse
        raw = urllib.parse.parse_qs(self.path.split("?", 1)[1]).get("path", [""])[0]
        try:
            p = pathlib.Path(raw).resolve()
            home = paths.home().resolve()
            # The home folder, plus the two places backgrounds live.
            #
            # Restricting this to home was right when the only images were
            # the user's own. The wallpaper chooser also shows designs
            # drawn into /var/lib/osprime and photographs shipped in
            # /usr/share/osprime, and neither is under home — so their
            # thumbnails came back 404 and the chooser showed empty boxes.
            # Still an allowlist, not a free file server.
            allowed = [home,
                       pathlib.Path("/var/lib/osprime/wallpapers"),
                       pathlib.Path("/usr/share/osprime/wallpapers")]
            ctype = self._IMAGE_TYPES.get(p.suffix.lower())
            inside = any(root in p.parents for root in allowed)
            if ctype is None or not p.is_file() or not inside:
                self._json({"error": "not available"}, 404)
                return
            data = p.read_bytes()
        except Exception:
            self._json({"error": "not available"}, 404)
            return
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self._guarded():
            return
        if self.path.split("?", 1)[0] == "/":
            # Locale is resolved per request, so changing it in settings takes
            # effect on reload instead of needing a service restart.
            code = i18n.lang()
            # The version is shown in the header on purpose: a stale service
            # left running from an older install is otherwise indistinguishable
            # from a fresh one, and costs an hour of chasing the wrong build.
            data = (PAGE.replace("{{LANG}}", code)
                        .replace("{{DIR}}", "rtl" if i18n.is_rtl(code) else "ltr")
                        .replace("{{VERSION}}", _version())).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif self.path.split("?", 1)[0] == "/settings":
            code = i18n.lang()
            data = (settings_page.PAGE.replace("{{LANG}}", code)
                    .replace("{{DIR}}", "rtl" if i18n.is_rtl(code) else "ltr")
                    .replace("{{VERSION}}", _version())).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif self.path.startswith("/api/file?"):
            self._serve_file()
        elif self.path == "/api/settings":
            self._json(_read_settings())
        elif self.path == "/api/display":
            raw = system_tools.get_display()
            try:
                self._json({"screens": json.loads(raw)})
            except json.JSONDecodeError:
                self._json({"screens": [], "message": _plain(raw)})
        elif self.path == "/api/wifi/scan":
            raw = system_tools.list_wifi()
            try:
                self._json({"networks": json.loads(raw)})
            except json.JSONDecodeError:
                self._json({"networks": [], "message": _plain(raw)})
        elif self.path == "/api/overview":
            self._json(_overview())
        elif self.path == "/api/people":
            self._json(people.status())
        elif self.path == "/api/eyes":
            self._json(eyes.status())
        elif self.path == "/api/memory":
            self._json(_memory_list())
        elif self.path == "/api/storage":
            self._json(_storage())
        elif self.path == "/api/backgrounds":
            try:
                self._json(json.loads(system_tools.list_backgrounds()))
            except Exception as e:
                self._json({"designs": [], "shipped": [], "mine": [],
                            "can_draw": False, "shipped_note": str(e)})
        elif self.path == "/api/capture":
            # Polled by the panel indicator, so it must be cheap and must
            # never raise: a failure here would make the badge disappear,
            # which reads as "nothing is watching".
            try:
                self._json(json.loads(system_tools.capture_state()))
            except Exception as e:
                self._json({"camera": {"in_use": False, "by": []},
                            "microphone": {"in_use": False, "by": []},
                            "allowed": {"camera": True, "microphone": True},
                            "message": str(e)})
        elif self.path == "/api/devices":
            try:
                self._json(json.loads(system_tools.list_capture_devices()))
            except Exception as e:
                self._json({"cameras": [], "microphones": [],
                            "notes": [str(e)]})
        elif self.path == "/api/apps":
            try:
                self._json({"apps": json.loads(system_tools.list_apps())})
            except Exception as e:
                self._json({"apps": [], "message": str(e)})
        elif self.path == "/api/backups":
            self._json({"backups": list(reversed(updater.status()["backups"]))})
        elif self.path == "/api/profile":
            self._json({"exists": PROFILE_PATH.exists()})
        elif self.path == "/api/update/check":
            # Deliberately not routed through the assistant. Asked to install an
            # update the model invented `sudo /path/to/update/install.sh`, and
            # the fix for that behaviour lives inside the update it refuses to
            # install. Keeping a system's own update path behind a 1.5B model's
            # tool choice is a design error; this is the way out of it.
            self._json(updater.check())
        elif self.path == "/api/voice/status":
            self._json(voice.status())
        elif self.path.split("?", 1)[0] == "/pair":
            if not self.remote:
                self._json({"error": "not found"}, 404)
            else:
                self._html(_pair_page())
        elif self.path == "/api/remote/whoami":
            self._json({"remote": self.remote, "device": self.device})
        elif self.path == "/api/remote":
            # Only ever reached on the loopback listener: remote.path_allowed
            # does not list it, so a phone cannot see who else is paired.
            self._json({"enabled": remote_access.enabled(),
                        "port": remote_access.PORT,
                        "addresses": [f"http://{a}:{remote_access.PORT}"
                                      for a in remote_access.lan_addresses()],
                        "devices": remote_access.devices(),
                        "pairing": remote_access.pairing_open()})
        elif self.path == "/api/approvals":
            self._json({"items": _pending_list()})
        elif self.path == "/api/notifications":
            try:
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.connect(SOCKET_PATH)
                sf = s.makefile("rwb")
                sf.write(b'{"type": "poll_notifications"}\n'); sf.flush()
                resp = json.loads(sf.readline())
                s.close()
                self._json(resp)
            except Exception as e:
                self._json({"items": [], "error": str(e)})
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        # Before the body is read, not after. A refused request should cost
        # us nothing, and should never reach a line that parses it.
        if self._guarded():
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            length = -1
        # A ceiling on what a request may make us read. A recording for
        # speech-to-text is the largest legitimate body; anything bigger is
        # a request to fill this process's memory.
        if length < 0 or length > 32 * 1024 * 1024:
            self._refuse("body too large", 413)
            return
        raw = self.rfile.read(length)

        if self.path == "/api/stt":
            # Checked here, before a single byte is looked at. This is what
            # makes the switch honest: "off" refuses the recording, it does
            # not accept it and throw the transcript away.
            try:
                allowed = json.loads(
                    system_tools.capture_state())["allowed"]["microphone"]
            except Exception:
                allowed = True
            if not allowed:
                self._json({"ok": False,
                            "error": "the microphone is switched off in the "
                                     "Control Panel"})
                return
            suffix = "." + (self.headers.get("X-Audio-Ext") or "webm").lstrip(".")
            lang = self.headers.get("X-Audio-Lang") or "auto"
            try:
                text = voice.transcribe(raw, suffix, lang)
            except Exception as e:
                text = f"ERROR: {e}"
            if text.startswith("ERROR:"):
                self._json({"ok": False, "error": text[6:].strip()})
            else:
                self._json({"ok": True, "text": text})
            return

        if self.path == "/api/tts":
            try:
                payload = json.loads(raw)
                wav = voice.synthesize(payload.get("text", ""))
            except Exception:
                wav = b""
            if not wav:
                self.send_response(503)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(wav)))
            self.end_headers()
            self.wfile.write(wav)
            return

        # Tolerate an empty body. Endpoints that take no arguments were
        # failing here before reaching their handler, because this parsed
        # every remaining POST as JSON unconditionally.
        try:
            body = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            body = {}

        if self.path == "/api/confirm":
            sid, cid = str(body.get("session", "")), str(body.get("id", ""))
            if self.device:
                # A phone may answer only its own questions, and only if the
                # computer has given it that right. Otherwise the question is
                # waiting on the computer and this request is refused, even
                # if the page was edited to show a button it should not.
                with _owner_lock:
                    owner = _session_owner.get(sid)
                if owner != self.device["id"]:
                    self._refuse("confirm for another session")
                    return
                if not self.device.get("can_approve"):
                    self._refuse("device may not approve", 403,
                                 "Approve this on the computer itself.")
                    return
            with _pending_lock:
                _pending.pop((sid, cid), None)
            try:
                sess = get_session(sid)
                session_send(sess, {"type": "confirm_response",
                                    "id": cid, "approved": bool(body.get("approved"))})
                self._json({"ok": True})
            except Exception as e:
                self._json({"ok": False, "error": str(e)})
            return
        if self.path == "/api/settings":
            key = str(body.get("key", ""))
            if self.device and key not in remote_access.REMOTE_SETTING_KEYS:
                self._refuse(f"setting {key} is local only", 403,
                             "This can only be changed on the computer itself.")
                return
            self._json(_apply_setting(key, body.get("value")))
            return

        if self.path == "/api/wifi/connect":
            msg = system_tools.connect_wifi(body.get("ssid", ""),
                                            body.get("password", ""))
            self._json({"ok": not msg.startswith("ERROR:"),
                        "message": _plain(msg)})
            return

        if self.path == "/api/wifi/forget":
            msg = system_tools.forget_wifi(body.get("ssid", ""))
            self._json({"ok": not msg.startswith("ERROR:"),
                        "message": _plain(msg)})
            return

        if self.path == "/api/update/install":
            # restart=False deliberately. Restarting the services is part of an
            # update, but osprime-web is one of them — doing it inline kills
            # this very connection before the reply is written, and the browser
            # reports "Failed to fetch" for an update that actually succeeded.
            try:
                result = updater.update(restart=False)
                ok = updater.succeeded(result)
            except Exception as e:
                result, ok = f"update failed: {e}", False
            self._json({"ok": ok, "message": result,
                        "version": updater.current_version()})
            if ok:
                # Answer first, restart a moment later.
                threading.Timer(1.0, updater.restart_services).start()
            return

        if self.path == "/api/browse":
            # POST rather than GET: a folder path in a query string ends up
            # in logs and in the browser's history, and this one is the
            # user's own directory names.
            try:
                self._json(json.loads(system_tools.browse_pictures(
                    str(body.get("folder", "")))))
            except Exception as e:
                # Every key the page reads, so a failure here shows a
                # message rather than an empty dialog.
                self._json({"path": "", "label": "", "parent": "",
                            "folders": [], "images": [],
                            "note": f"could not open that folder: {e}"})
            return

        if self.path.startswith("/api/apps/"):
            # The panel and the assistant reach the same functions. The
            # difference is only who asked — and both are confirmed by the
            # person before anything is installed or removed, the panel by
            # its own dialog and the assistant by the permission gate.
            what = self.path.rsplit("/", 1)[-1]
            app_id = str(body.get("app_id", "")).strip()
            try:
                if what == "search":
                    raw = system_tools.search_apps(str(body.get("query", "")))
                    try:
                        self._json(json.loads(raw))
                    except json.JSONDecodeError:
                        self._json({"results": [], "note": _plain(raw)})
                elif what == "install":
                    r = system_tools.install_app(
                        app_id, "yes" if body.get("everyone") else "no")
                    self._json({"ok": not r.startswith("ERROR"),
                                "message": _plain(r)})
                elif what == "uninstall":
                    r = system_tools.uninstall_app(app_id)
                    self._json({"ok": not r.startswith("ERROR"),
                                "message": _plain(r)})
                elif what == "info":
                    self._json(json.loads(system_tools.app_info(app_id)))
                else:
                    self._json({"ok": False, "message": "unknown request"})
            except Exception as e:
                self._json({"ok": False, "results": [], "message": str(e)})
            return

        if self.path == "/api/memory/forget":
            try:
                mem = _memory_db()
                if body.get("all"):
                    n = mem.forget_all()
                    self._json({"ok": True,
                                "message": f"forgot {n} things" if n
                                else "there was nothing to forget"})
                else:
                    ok = mem.forget(body.get("id"))
                    self._json({"ok": ok, "message": "forgotten" if ok
                                else "that memory is already gone"})
            except Exception as e:
                self._json({"ok": False, "message": str(e)})
            return

        if self.path.startswith("/api/people/"):
            # docs/ACCOUNTS.md, phase 2. Administrators confirm every change
            # with their own password (sudo -S), which people.py never stores
            # and never logs.
            what = self.path.rsplit("/", 1)[-1]
            pw = str(body.get("admin_password", ""))
            name = str(body.get("name", "")).strip()
            if what == "self-password":
                r = people.change_own_password(str(body.get("old", "")),
                                               str(body.get("new", "")))
            elif what == "add":
                r = people.add(pw, name, str(body.get("full", "")).strip(),
                               str(body.get("password", "")), bool(body.get("admin")))
            elif what == "reset":
                r = people.reset_password(pw, name, str(body.get("password", "")))
            elif what == "admin":
                r = people.set_admin(pw, name, bool(body.get("admin")))
            elif what == "remove":
                r = people.remove(pw, name)
            elif what == "archives":
                r = people.archives(pw)
            elif what == "purge":
                r = people.purge(pw, str(body.get("archive", "")))
            else:
                r = {"ok": False, "message": "unknown request"}
            self._json(r)
            return

        if self.path in ("/api/eyes/add", "/api/eyes/remove", "/api/eyes/switch"):
            # The page has already asked, with the download size in the
            # question. The script runs in the background; the page polls
            # GET /api/eyes for progress.
            self._json(eyes.start(self.path.rsplit("/", 1)[-1]))
            return

        if self.path == "/api/rollback":
            # Answer first, restart after — the same lesson as /api/update.
            # Rolling back restarts osprime-web, which is the server writing
            # this reply.
            try:
                result = updater.restore(restart=False)
                ok = result.startswith("restored")
            except Exception as e:
                result, ok = f"rollback failed: {e}", False
            self._json({"ok": ok, "message": _plain(result)})
            if ok:
                threading.Timer(1.0, updater.restart_services).start()
            return

        if self.path == "/api/end":
            # The window is closing. Sent with sendBeacon so it still
            # arrives while the page is being torn down.
            sid = str(body.get("session", ""))
            if self.device:
                with _owner_lock:
                    if _session_owner.get(sid) != self.device["id"]:
                        self._refuse("end another session")
                        return
            self._json({"ok": end_session(sid)})
            return

        if self.path == "/api/open":
            # A link clicked in the chat must open a browser WINDOW, not
            # navigate this one. The chat is a kiosk window with no address
            # bar and no back button: letting it follow a link would replace
            # the assistant with a web page and leave no way back.
            url = str(body.get("url", "")).strip()
            if not url.startswith(("http://", "https://")):
                self._json({"ok": False, "message": "not a web address"})
                return
            try:
                import desktop
                self._json({"ok": True, "message": desktop.open_url(url)})
            except Exception as e:
                self._json({"ok": False, "message": str(e)})
            return

        # ---- remote access -------------------------------------------------
        if self.path.split("?", 1)[0] == "/pair":
            if not self.remote:
                self._json({"error": "not found"}, 404)
                return
            cookie, dev = remote_access.complete_pairing(
                self.client_address[0], str(body.get("name", "")),
                nonce=str(body.get("k", "")), code=str(body.get("code", "")))
            if not cookie:
                self._json({"ok": False, "message": dev}, 403)
                return
            # HttpOnly: no script on any page can read the key. SameSite
            # Strict: no other site can make the phone send it. No Secure
            # flag, because this is plain HTTP on a home network — the limit
            # docs/SECURITY.md states out loud rather than hides.
            data = json.dumps({"ok": True, "device": dev}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.send_header(
                "Set-Cookie",
                f"{remote_access.COOKIE}={cookie}; Path=/; HttpOnly; "
                "SameSite=Strict; Max-Age=31536000")
            self.end_headers()
            self.wfile.write(data)
            return
        if self.path == "/api/remote/enable":
            on = bool(body.get("on"))
            if not remote_access.set_enabled(on):
                self._json({"ok": False, "message": "Could not save the setting."})
                return
            msg = start_remote() if on else stop_remote()
            self._json({"ok": not msg.startswith("ERROR"), "message": _plain(msg)})
            return
        if self.path == "/api/remote/pair":
            r = remote_access.start_pairing()
            if r.get("ok"):
                r["svg"] = qr.svg(r["url"], scale=6)
            self._json(r)
            return
        if self.path == "/api/remote/pair/cancel":
            remote_access.cancel_pairing()
            self._json({"ok": True})
            return
        if self.path == "/api/remote/device":
            dev_id = str(body.get("id", ""))
            if body.get("remove"):
                ok = remote_access.remove_device(dev_id)
            else:
                ok = remote_access.set_can_approve(dev_id,
                                                   bool(body.get("can_approve")))
            self._json({"ok": ok, "devices": remote_access.devices()})
            return

        if self.path == "/api/proactive/dismiss":
            # Handled here, not sent to the agent: a refusal is a fact on
            # disk, and it must stick even if the agent is restarting at the
            # moment the user clicks — which is exactly when an update has
            # just made it say something they did not want.
            kind = str(body.get("kind", ""))
            restore = bool(body.get("restore"))
            ok = (proactive.restore(kind) if restore
                  else proactive.dismiss(kind))
            self._json({"ok": bool(ok),
                        "dismissed": proactive.dismissed()})
            return

        if self.path == "/api/onboard":
            PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
            PROFILE_PATH.write_text(
                json.dumps(body, ensure_ascii=False, indent=2), encoding="utf-8")
            self._json({"ok": True})
        elif self.path == "/api/chat":
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.end_headers()

            def emit(obj):
                self.wfile.write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
                self.wfile.flush()

            try:
                sid = str(body["session"])
                owner = self.device["id"] if self.device else None
                if not _claim_session(sid, owner):
                    emit({"type": "error", "text": "This conversation belongs "
                          "to another device."})
                    return
                sess = get_session(sid)
                f = sess["f"]
                session_send(sess, {"type": "user_message", "text": body["text"]})
                for line in f:
                    msg = json.loads(line)
                    # A question from a device that may not approve goes to
                    # the computer instead. The phone is told where it went;
                    # the agent keeps waiting, and after five minutes treats
                    # silence as no — the same as a person pressing Deny.
                    if (msg.get("type") == "confirm" and self.device
                            and not self.device.get("can_approve")):
                        with _pending_lock:
                            _pending[(sid, str(msg.get("id")))] = {
                                "text": msg.get("text", ""),
                                "detail": msg.get("detail", ""),
                                "device": self.device.get("name", "a device"),
                                "at": time.time()}
                        try:
                            import companion
                            companion.attention(True)
                        except Exception:
                            pass
                        emit({"type": "confirm_elsewhere",
                              "text": msg.get("text", ""),
                              "detail": msg.get("detail", "")})
                        continue
                    emit(msg)
                    if msg.get("type") in ("assistant", "error"):
                        return
                emit({"type": "error", "text": "Lost connection to the agent"})
            except BrokenPipeError:
                pass
            except Exception as e:
                try:
                    emit({"type": "error", "text": str(e)})
                except Exception:
                    pass
        else:
            self._json({"error": "not found"}, 404)


PAGE = r"""<!DOCTYPE html>
<html lang="{{LANG}}" dir="{{DIR}}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OSprime</title>
<style>
  :root { --bg:#0d1117; --panel:#161b22; --accent:#58a6ff; --text:#e6edf3; --dim:#8b949e; }
  * { box-sizing:border-box; margin:0; }
  body { background:var(--bg); color:var(--text); height:100vh; display:flex; flex-direction:column;
         font-family:"Segoe UI", Vazirmatn, Tahoma, sans-serif; }
  header { padding:14px 22px; background:var(--panel); border-bottom:1px solid #21262d;
           display:flex; align-items:center; gap:10px; }
  header .logo { font-size:20px; font-weight:700; color:var(--accent); }
  header .sub { color:var(--dim); font-size:13px; }
  #chat { flex:1; overflow-y:auto; padding:20px; display:flex; flex-direction:column; gap:10px; }
  .msg { max-width:75%; padding:10px 14px; border-radius:14px; line-height:1.9; white-space:pre-wrap; }
  .user { background:#1f6feb; align-self:flex-start; border-bottom-right-radius:4px; }
  .bot  { background:var(--panel); align-self:flex-end; border-bottom-left-radius:4px; border:1px solid #21262d; }
  /* A file path has no spaces to break at, so a long one ran straight off
     the right edge and took the sentence around it with it: "There are 3
     pictures in /home/os" was all that could be read. */
  .msg, .tool { overflow-wrap:anywhere; word-break:break-word; }
  .link { color:var(--accent); text-decoration:underline; cursor:pointer; }
  .link:hover { text-decoration:none; }
  .img  { padding:8px; }
  .img img { max-width:420px; max-height:340px; width:auto; height:auto;
             display:block; border-radius:8px; cursor:zoom-in; }
  .img .cap { color:var(--dim); font-size:12px; margin-top:6px;
              direction:ltr; text-align:left; }
  .tool { align-self:flex-end; color:var(--dim); font-size:12px; direction:ltr; text-align:left;
          background:#161b2280; border:1px dashed #30363d; border-radius:8px; padding:4px 10px;
          font-family:Consolas, monospace; }
  .badge { font-size:11px; color:var(--dim); margin-top:4px; }
  form { display:flex; gap:10px; padding:14px 20px; background:var(--panel); border-top:1px solid #21262d; }
  input { flex:1; background:var(--bg); color:var(--text); border:1px solid #30363d; border-radius:10px;
          padding:12px 16px; font-size:15px; font-family:inherit; outline:none; }
  input:focus { border-color:var(--accent); }
  button { background:var(--accent); color:#0d1117; border:0; border-radius:10px; padding:0 22px;
           font-size:15px; font-weight:700; cursor:pointer; font-family:inherit; }
  button:disabled { opacity:.5; }
  .typing { color:var(--dim); align-self:flex-end; font-size:13px; }
  .confirm { align-self:flex-end; background:#2d1a1a; border:1px solid #a14; border-radius:12px;
             padding:12px 14px; max-width:75%; }
  .confirm .q { color:#ffb3b3; margin-bottom:6px; }
  .confirm .cmd { direction:ltr; text-align:left; font-family:Consolas,monospace; font-size:13px;
                  background:#0d1117; border-radius:6px; padding:6px 10px; margin-bottom:10px;
                  white-space:pre-wrap; word-break:break-all; }
  .confirm .btns { display:flex; gap:8px; }
  .confirm button { padding:6px 16px; border-radius:8px; border:0; cursor:pointer; font-family:inherit; font-weight:700; }
  .confirm .yes { background:#238636; color:#fff; }
  .confirm .no  { background:#30363d; color:var(--text); }
  .iconbtn { background:var(--bg); color:var(--text); border:1px solid #30363d; border-radius:10px;
             padding:0 14px; font-size:18px; cursor:pointer; }
  .iconbtn.on { background:#a12d2d; border-color:#e05555; animation:pulse 1.2s infinite; }
  .iconbtn.speak-on { background:var(--accent); color:#0d1117; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.55} }
  /* Chat settings. Only what belongs to the conversation lives here —
     everything about the machine is in the Control Panel. A chat window
     that can also repartition your disk is a chat window nobody trusts. */
  .hdrbtn { background:transparent; border:0; color:#8b949e; font-size:13px;
            cursor:pointer; font-family:inherit; padding:4px 8px;
            border-radius:6px; }
  .hdrbtn:hover { background:#21262d; color:var(--text); }
  #chatset { display:none; position:absolute; top:52px; inset-inline-end:16px;
             width:290px; background:#161b22; border:1px solid #30363d;
             border-radius:12px; padding:12px 14px; z-index:20;
             box-shadow:0 10px 30px rgba(0,0,0,.45); }
  #chatset.on { display:block; }
  #chatset h3 { margin:0 0 10px; font-size:13px; color:#8b949e;
                font-weight:600; }
  #chatset .r { display:flex; align-items:center; gap:10px; padding:7px 0;
                border-top:1px solid #21262d; font-size:13px; }
  #chatset .r:first-of-type { border-top:0; }
  #chatset .r span { flex:1; }
  #chatset select { background:#0d1117; color:var(--text);
                    border:1px solid #30363d; border-radius:6px;
                    padding:5px 7px; font-size:12px; font-family:inherit; }
  #chatset .full { display:block; width:100%; text-align:center;
                   margin-top:10px; padding:8px; border-radius:8px;
                   border:1px solid #30363d; color:var(--text);
                   text-decoration:none; font-size:13px; }
  #chatset .full:hover { border-color:#2d6cdf; }
</style>
</head>
<body>
<header><span class="logo">OSprime</span><span class="sub">the operating system that thinks &nbsp;·&nbsp; v{{VERSION}}</span>
<button type="button" class="hdrbtn" id="chatsetbtn" style="margin-left:auto">Chat settings</button>
<span id="upd" style="display:none;margin-left:14px;font-size:13px;align-items:center;gap:10px">
<span id="updtxt"></span>
<button type="button" id="updbtn" style="border:0;border-radius:6px;padding:5px 14px;background:#2d6cdf;color:#fff;cursor:pointer;font-size:13px">Install</button>
</span></header>
<div id="chatset">
  <h3>This conversation</h3>
  <div class="r"><span>Who answers</span>
    <select id="cs_cloud">
      <option value="off">This computer only</option>
      <option value="ask">Cloud when I ask</option>
      <option value="auto">Cloud when needed</option>
    </select></div>
  <div class="r"><span>Check with me before</span>
    <select id="cs_confirm">
      <option value="everything">anything</option>
      <option value="moderate">changing things</option>
      <option value="dangerous">risky things</option>
      <option value="nothing">never ask</option>
    </select></div>
  <div class="r"><span>Language</span>
    <select id="cs_lang">
      <option value="en">English</option>
      <option value="fa">فارسی</option>
    </select></div>
  <div class="r"><span>Microphone</span>
    <button type="button" class="hdrbtn" id="cs_mic"
            style="border:1px solid #30363d">…</button></div>
  <div class="r"><span>Start a new conversation</span>
    <button type="button" class="hdrbtn" id="cs_clear"
            style="border:1px solid #30363d">Clear</button></div>
  <a class="full" href="/settings">All settings — Control Panel</a>
</div>
<div id="chat"></div>
<form id="f" onsubmit="return false">
<button type="button" id="mic" class="iconbtn" title="Record voice" style="display:none">🎤</button>
<button type="button" id="spk" class="iconbtn" title="Read answers aloud" style="display:none">🔈</button>
<input id="inp" autocomplete="off" placeholder="Ask your computer anything..." autofocus>
<button id="btn">Send</button></form>
<script>
// crypto.randomUUID() exists only in a "secure context" — HTTPS, or
// localhost. The computer's own window is localhost, so it always worked
// there. A paired phone reaches this page as http://192.168.x.x, where the
// function is undefined: this line threw, the whole script stopped, and the
// form fell back to submitting itself as a page load, which showed the phone
// {"error": "not found"}. getRandomValues is available everywhere, so the
// id is built from that when it has to be.
function newId() {
  try { if (crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
  const b = crypto.getRandomValues(new Uint8Array(16));
  b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b, x => x.toString(16).padStart(2, "0")).join("");
  return h.slice(0, 8) + "-" + h.slice(8, 12) + "-" + h.slice(12, 16) + "-" +
         h.slice(16, 20) + "-" + h.slice(20);
}
const chat = document.getElementById("chat"), inp = document.getElementById("inp"),
      btn = document.getElementById("btn"), sid = newId();
let onboarding = null;
const OB_QUESTIONS = [
  ["name", "What's your name?"],
  ["language", "Preferred language? (en/fa)"],
  ["skill", "Technical level? (beginner/intermediate/expert)"],
  ["usage", "What do you mostly use this computer for?"],
  ["autonomy", "Ask permission before changing the system? (yes/no)"],
];

function add(cls, text) {
  const d = document.createElement("div");
  d.className = "msg " + cls; d.textContent = text;
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight; return d;
}

// Turn web addresses in an answer into something you can click.
//
// Built out of DOM nodes, never innerHTML: the text comes from a language
// model, and a model that can be asked to repeat what a web page said can
// be asked to repeat a <script> tag along with it.
//
// Clicking asks the server to open a browser window instead of following
// the link here, because "here" is a window with no way back.
const URL_RE = /(https?:\/\/[^\s<>"'()\[\]]+)/g;
function linkify(el, text) {
  el.textContent = "";
  let last = 0, m;
  URL_RE.lastIndex = 0;
  while ((m = URL_RE.exec(text)) !== null) {
    if (m.index > last) el.appendChild(document.createTextNode(text.slice(last, m.index)));
    const raw = m[1].replace(/[.,;:)\]]+$/, "");
    const a = document.createElement("a");
    a.href = "#"; a.className = "link"; a.textContent = raw;
    a.title = "Open in a browser window";
    // Says so when it fails. Clicking a link and having nothing at all
    // happen is the single most confusing thing an interface can do, and
    // it is exactly what happened while the browser was being launched
    // without the flags it needs.
    a.onclick = async ev => {
      ev.preventDefault();
      a.textContent = raw + "  (opening…)";
      try {
        const r = await fetch("/api/open", { method: "POST",
          body: JSON.stringify({ url: raw }) }).then(r => r.json());
        a.textContent = raw;
        if (!r.ok) add("bot", "⚠ Could not open it: " + (r.message || "unknown reason"));
      } catch (e) {
        a.textContent = raw;
        add("bot", "⚠ Could not open it: " + e);
      }
    };
    el.appendChild(a);
    last = m.index + raw.length;
  }
  if (last < text.length) el.appendChild(document.createTextNode(text.slice(last)));
}
function addTool(e) {
  const d = document.createElement("div");
  d.className = "tool"; d.textContent = "⚙ " + e.name + ": " + e.detail;
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight;
}
// A picture the assistant found or made. The path came from a file that was
// checked to exist before it was sent, so a broken image here means the
// server refused it, not that the assistant made the path up.
function addImage(path) {
  const d = document.createElement("div");
  d.className = "msg bot img";
  const img = document.createElement("img");
  img.src = "/api/file?path=" + encodeURIComponent(path);
  img.alt = path;
  img.onclick = () => window.open(img.src, "_blank");
  const cap = document.createElement("div");
  cap.className = "cap"; cap.textContent = path.split("/").pop();
  d.appendChild(img); d.appendChild(cap);
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight;
}

// Tell the server the conversation is over when the window goes away, so
// the assistant does its end-of-conversation thinking — reading what was
// said and keeping the handful of durable facts in it. sendBeacon is used
// because a normal fetch is cancelled when the page unloads.
//
// pagehide fires where beforeunload does not, including when a window is
// closed on a phone or put to sleep.
function endSession() {
  try {
    navigator.sendBeacon("/api/end", JSON.stringify({ session: sid }));
  } catch (e) { /* the idle sweep on the server catches this case */ }
}
window.addEventListener("pagehide", endSession);
window.addEventListener("beforeunload", endSession);

// ---- chat settings ----------------------------------------------------
// Only the conversation's own settings. Everything about the machine moved
// to the Control Panel: a chat window that could also repartition a disk
// was a chat window with no honest boundary, and the settings it held were
// unreachable the moment the assistant was the thing that was broken.
const cset = document.getElementById("chatset");

document.getElementById("chatsetbtn").onclick = async ev => {
  ev.stopPropagation();
  const opening = !cset.classList.contains("on");
  cset.classList.toggle("on", opening);
  if (!opening) return;
  // Read on open, not on page load. These can be changed from the Control
  // Panel or by asking, and a value cached at startup would quietly be a
  // lie by the time anyone looked at it.
  try {
    const s = await fetch("/api/settings").then(r => r.json());
    document.getElementById("cs_cloud").value = s.cloud_mode || "off";
    if (s.confirm_level) document.getElementById("cs_confirm").value = s.confirm_level;
    if (s.language) document.getElementById("cs_lang").value = s.language;
  } catch (e) { /* the selects keep their current values */ }
  refreshMicButton();
};

// ---- the microphone switch, from the chat -----------------------------
// Ehsan asked for this here as well as in the Control Panel, and he was
// right: this is the one people will actually reach for. The panel switch
// is the one that has to keep working when the assistant does not.
//
// Turning it off hides the record button too. Leaving a button that
// refuses when pressed would technically be honest and would still feel
// broken.
let micAllowed = true;
// Whether speech-to-text is installed at all. Two separate conditions, and
// the record button needs BOTH.
//
// The first version let the switch set display = "" directly, which made
// the button appear on a machine with no whisper.cpp — so pressing it
// answered "whisper.cpp is not installed", a button that existed only
// because a toggle revealed it. One place decides whether that button is
// visible now, and it looks at both facts.
let sttReady = false;

function showMicButton() {
  const rec = document.getElementById("mic");
  if (!rec) return;
  rec.style.display = (sttReady && micAllowed && navigator.mediaDevices)
    ? "" : "none";
}

async function refreshMicButton() {
  try {
    const c = await fetch("/api/capture").then(r => r.json());
    micAllowed = c.allowed.microphone !== false;
  } catch (e) { /* leave it as it was */ }
  const b = document.getElementById("cs_mic");
  if (b) {
    // The switch says what it is, and says when it cannot do anything.
    b.textContent = !sttReady ? "not installed"
                  : micAllowed ? "On" : "Off";
    b.disabled = !sttReady;
  }
  showMicButton();
}

document.getElementById("cs_mic").onclick = async () => {
  if (!sttReady) return;
  const want = !micAllowed;
  await saveChatSetting("allow_microphone", want);
  micAllowed = want;
  document.getElementById("cs_mic").textContent = want ? "On" : "Off";
  showMicButton();
  if (!want) add("bot", "The microphone is off. OSprime will not open it.");
};

document.addEventListener("click", ev => {
  if (!cset.contains(ev.target)) cset.classList.remove("on");
});

async function saveChatSetting(key, value) {
  try {
    const r = await fetch("/api/settings", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ key, value })
    }).then(r => r.json());
    if (!r.ok) add("bot", "⚠ " + (r.message || "Could not save that."));
  } catch (e) { add("bot", "⚠ Could not save that: " + e); }
}

document.getElementById("cs_cloud").onchange   = e => saveChatSetting("cloud_mode", e.target.value);
document.getElementById("cs_confirm").onchange = e => saveChatSetting("confirm_level", e.target.value);
document.getElementById("cs_lang").onchange    = e => saveChatSetting("language", e.target.value);

document.getElementById("cs_clear").onclick = () => {
  // Ends the conversation properly rather than just blanking the screen:
  // the server closes the socket, which is what makes the assistant keep
  // what it learned. Wiping the transcript without that would throw the
  // conversation away instead of finishing it.
  endSession();
  chat.innerHTML = "";
  cset.classList.remove("on");
  location.reload();
};

async function init() {
  const r = await fetch("/api/profile").then(r => r.json());
  if (!r.exists) {
    onboarding = { step: 0, answers: {} };
    add("bot", "Hello! I'm OSprime — your operating system.\nA few quick questions so I know you.");
    add("bot", OB_QUESTIONS[0][1]);
  } else {
    add("bot", "Hi — ask your computer anything.");
  }
}

async function send(text) {
  add("user", text);
  if (onboarding) {
    onboarding.answers[OB_QUESTIONS[onboarding.step][0]] = text;
    onboarding.step++;
    if (onboarding.step < OB_QUESTIONS.length) {
      add("bot", OB_QUESTIONS[onboarding.step][1]);
    } else {
      await fetch("/api/onboard", { method: "POST", body: JSON.stringify(onboarding.answers) });
      add("bot", "Thanks " + (onboarding.answers.name || "") + "! I'm at your service now.");
      onboarding = null;
    }
    return;
  }
  btn.disabled = true;
  let t = add("typing", "Thinking..."), bubble = null;
  const clearT = () => { if (t) { t.remove(); t = null; } };
  try {
    const resp = await fetch("/api/chat", { method: "POST",
      body: JSON.stringify({ session: sid, text }) });
    const reader = resp.body.getReader(), dec = new TextDecoder();
    let buf = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line) continue;
        const m = JSON.parse(line);
        if (m.type === "delta") {
          clearT();
          if (!bubble) bubble = add("bot", "");
          bubble.textContent += m.text;
          chat.scrollTop = chat.scrollHeight;
        } else if (m.type === "tool_use") {
          clearT(); addTool(m); bubble = null;
        } else if (m.type === "image") {
          clearT(); addImage(m.path); bubble = null;
        } else if (m.type === "assistant") {
          clearT();
          if (!bubble) bubble = add("bot", m.text);
          // Streaming appends plain text; the links go in once at the end,
          // when the whole address is known. Half a URL is not a link.
          linkify(bubble, m.text || bubble.textContent);
          const b = document.createElement("div"); b.className = "badge";
          b.textContent = m.backend === "claude" ? "\u2601 Claude" : "\u2302 Local model";
          bubble.appendChild(b);
          speak(m.text);
        } else if (m.type === "confirm") {
          clearT(); bubble = null; renderConfirm(m);
        } else if (m.type === "confirm_elsewhere") {
          // This phone may not approve its own requests; the question is
          // waiting on the computer. Said plainly, including what happens
          // if nobody answers, so the silence that follows is not a mystery.
          clearT(); bubble = null;
          add("bot", "🔒 This needs approval on the computer itself: " +
              m.text + "\n\nIt is waiting there for five minutes. If nobody " +
              "approves it, it will not happen.");
        } else if (m.type === "error") {
          clearT(); add("bot", "⚠ " + m.text);
        }
      }
    }
  } catch (e) { clearT(); add("bot", "\u26a0 Connection error: " + e); }
  btn.disabled = false; inp.focus();
}

document.getElementById("f").addEventListener("submit", ev => {
  ev.preventDefault();
  const text = inp.value.trim();
  if (text) { inp.value = ""; send(text); }
});
// ---- voice ----------------------------------------------------------
const mic = document.getElementById("mic"), spk = document.getElementById("spk");
let recorder = null, chunks = [], speakOn = false;

async function initVoice() {
  let st = {};
  try { st = await fetch("/api/voice/status").then(r => r.json()); } catch (e) { return; }
  // Two conditions, not one: speech-to-text has to be installed AND the
  // microphone has to be switched on. Checking only the first put the
  // record button back on screen every time the page loaded, however the
  // switch was set — a setting that only holds until you reload is not a
  // setting.
  sttReady = !!st.stt;
  if (st.tts) spk.style.display = "";
  // refreshMicButton reads the switch and applies both conditions.
  await refreshMicButton();
}

spk.onclick = () => {
  speakOn = !speakOn;
  spk.classList.toggle("speak-on", speakOn);
  spk.textContent = speakOn ? "🔊" : "🔈";
};

async function speak(text) {
  if (!speakOn || !text) return;
  try {
    const r = await fetch("/api/tts", { method: "POST", body: JSON.stringify({ text }) });
    if (!r.ok) return;
    const blob = await r.blob();
    new Audio(URL.createObjectURL(blob)).play();
  } catch (e) {}
}

mic.onclick = async () => {
  if (recorder && recorder.state === "recording") { recorder.stop(); return; }
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
  catch (e) { add("bot", "\u26a0 Microphone access denied."); return; }
  chunks = [];
  recorder = new MediaRecorder(stream);
  recorder.ondataavailable = e => chunks.push(e.data);
  recorder.onstop = async () => {
    stream.getTracks().forEach(t => t.stop());
    mic.classList.remove("on"); mic.textContent = "🎤";
    const blob = new Blob(chunks, { type: recorder.mimeType || "audio/webm" });
    const ext = (recorder.mimeType || "audio/webm").includes("ogg") ? "ogg" : "webm";
    const note = add("typing", "Transcribing...");
    try {
      const r = await fetch("/api/stt", { method: "POST",
        headers: { "X-Audio-Ext": ext }, body: blob }).then(r => r.json());
      note.remove();
      if (r.ok && r.text) { inp.value = r.text; send(r.text); inp.value = ""; }
      else add("bot", "⚠ " + (r.error || "No speech detected"));
    } catch (e) { note.remove(); add("bot", "\u26a0 Transcription error: " + e); }
  };
  recorder.start();
  mic.classList.add("on"); mic.textContent = "⏹";
};

// `session` and `from` are set only for a request that a paired phone made
// and that has to be approved here, at the computer. The answer goes to the
// phone's conversation, not this window's.
function renderConfirm(m, session, from) {
  const d = document.createElement("div");
  d.className = "confirm";
  const q = document.createElement("div"); q.className = "q";
  q.textContent = (from ? "📱 " + from + " asks: " : "🔒 ") + m.text;
  const cmd = document.createElement("div"); cmd.className = "cmd"; cmd.textContent = m.detail || "";
  const btns = document.createElement("div"); btns.className = "btns";
  const yes = document.createElement("button"); yes.className = "yes"; yes.textContent = "Allow";
  const no = document.createElement("button"); no.className = "no"; no.textContent = "Deny";
  const answer = (approved) => {
    yes.disabled = no.disabled = true;
    yes.style.opacity = no.style.opacity = .5;
    fetch("/api/confirm", { method: "POST",
      body: JSON.stringify({ session: session || sid, id: m.id, approved }) });
    q.textContent = (approved ? "\u2713 Allowed" : "\u2715 Denied") + " — " + m.text;
  };
  yes.onclick = () => answer(true); no.onclick = () => answer(false);
  btns.append(yes, no); d.append(q); if (m.detail) d.append(cmd); d.append(btns);
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight;
}

// Questions a paired phone asked that wait for someone at the computer.
// Polled like notifications. On a phone the request is refused by the
// server (remote.py does not list it), which switches the polling off there.
const shownApprovals = new Set();
let approvalsOff = false;
async function pollApprovals() {
  if (approvalsOff) return;
  try {
    const r = await fetch("/api/approvals");
    if (r.status === 401 || r.status === 403) { approvalsOff = true; return; }
    const j = await r.json();
    (j.items || []).forEach(a => {
      const key = a.session + "/" + a.id;
      if (shownApprovals.has(key)) return;
      shownApprovals.add(key);
      renderConfirm({ id: a.id, text: a.text, detail: a.detail },
                    a.session, a.device);
    });
  } catch (e) {}
}
setInterval(pollApprovals, 3000);

// "Don't tell me this again", and it means it.
//
// Quiet and small on purpose: the point is that a refusal is available, not
// that it is urged. Built from DOM nodes rather than innerHTML for the same
// reason as linkify — everything near a model's output is treated as
// untrusted text.
function addRefusal(el, kind) {
  const row = document.createElement("div");
  row.style.cssText = "margin-top:8px";
  const b = document.createElement("span");
  b.className = "link";
  b.style.fontSize = "12px";
  b.textContent = "Don't tell me this again";
  b.onclick = async () => {
    b.onclick = null;
    let ok = false;
    try {
      ok = (await (await fetch("/api/proactive/dismiss", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({kind})
      })).json()).ok;
    } catch (e) {}
    // Say which way it went. A button that silently does nothing is how
    // someone ends up clicking it three times and still being interrupted.
    b.className = "";
    b.style.color = "var(--dim)";
    b.textContent = ok
      ? "Won't mention this again. You can turn it back on in Settings → Assistant."
      : "Could not save that — Settings → Assistant can switch it off entirely.";
  };
  row.appendChild(b);
  el.appendChild(row);
}

async function pollNotifications() {
  try {
    const r = await fetch("/api/notifications").then(r => r.json());
    (r.items || []).forEach(n => {
      if (n.kind === "message" || n.text) {
        const el = add("bot", n.text);
        // Rule 4: a refusal has to be possible, or it can never be
        // permanent. Only on messages the machine raised by itself — a
        // scheduled task the user set up has no "stop telling me" to
        // offer, because they can change or delete the schedule.
        if (n.proactive) addRefusal(el, n.proactive);
      } else {
        const icon = n.status === "done" ? "✅" : "⚠";
        add("bot", `${icon} Background task "${n.label}" ${n.status === "done" ? "finished" : "failed"} (code ${n.code}).`);
      }
    });
  } catch (e) {}
}
setInterval(pollNotifications, 3000);
initVoice();
init();
// --- updates -------------------------------------------------------------
// Independent of the assistant on purpose. This must keep working on the day
// the model is having a bad day, because the fix for that day arrives here.
(async () => {
  const bar = document.getElementById("upd");
  const txt = document.getElementById("updtxt");
  const btn = document.getElementById("updbtn");
  let info = null;
  try { info = await (await fetch("/api/update/check")).json(); } catch (e) { return; }
  if (!info || !info.available) return;
  txt.textContent = "Version " + info.latest + " is available";
  bar.style.display = "flex";
  btn.onclick = async () => {
    btn.disabled = true;
    txt.textContent = "Installing " + info.latest + "…";
    btn.textContent = "…";
    let r = null;
    try { r = await (await fetch("/api/update/install", {method:"POST"})).json(); }
    catch (e) { r = null; }   // the service may have restarted underneath us
    if (r && !r.ok) {
      txt.textContent = r.message || "Update failed";
      btn.textContent = "Retry"; btn.disabled = false;
      return;
    }
    // Either it reported success, or the connection dropped mid-restart.
    // Both look the same from here, so wait for the service to answer again
    // and reload once it does, rather than guessing.
    txt.textContent = "Installed — restarting";
    for (let i = 0; i < 30; i++) {
      await new Promise(s => setTimeout(s, 1000));
      try { await fetch("/api/update/check", {cache: "no-store"});
            location.reload(); return; } catch (e) {}
    }
    txt.textContent = "Installed — reopen this window";
    btn.style.display = "none";
  };
})();
</script>
</body>
</html>"""


# ---- the two pages a phone sees before it is paired ------------------------
# Small, self-contained, readable on a phone. No external resources: the
# phone is on a home network that may have no internet at all.
_PHONE_HEAD = """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OSprime</title><style>
body{font-family:system-ui,sans-serif;background:#0d1117;color:#e6edf3;
     margin:0;padding:28px 22px;line-height:1.6}
h1{color:#58a6ff;font-size:22px;margin:0 0 6px}
p{color:#8b949e;margin:0 0 18px}
label{display:block;margin:14px 0 6px;font-size:14px}
input{width:100%;box-sizing:border-box;padding:12px;border-radius:10px;
      border:1px solid #30363d;background:#161b22;color:#e6edf3;font-size:18px}
button{margin-top:22px;width:100%;padding:14px;border:0;border-radius:10px;
       background:#1f6feb;color:#fff;font-size:17px}
.err{color:#f0883e;margin-top:14px;min-height:1.4em}
</style></head><body>"""

_NOT_PAIRED = _PHONE_HEAD + """
<h1>OSprime</h1>
<p>This device is not paired with the computer yet.</p>
<p>On the computer, open <b>Settings → Network → Other devices</b> and choose
<b>Pair a device</b>. Then scan the code it shows with this phone's camera —
or <a href="/pair" style="color:#58a6ff">type the six-digit code here</a>.</p>
</body></html>"""


def _pair_page() -> str:
    open_now = remote_access.pairing_open()
    return _PHONE_HEAD + """
<h1>Pair with OSprime</h1>
<p id="lede"></p>
<div id="codebox"><label for="code">Six-digit code shown on the computer</label>
<input id="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6"></div>
<label for="name">A name for this device</label>
<input id="name" value="Phone" maxlength="40">
<button id="go">Pair</button>
<div class="err" id="err"></div>
<script>
const k = new URLSearchParams(location.search).get("k") || "";
const OPEN = """ + ("true" if open_now else "false") + """;
document.getElementById("lede").textContent = !OPEN
  ? "No pairing is in progress. On the computer, open Settings → Network → " +
    "Other devices and choose Pair a device — then try again within two minutes."
  : k ? "Give this device a name so you can recognise it in the computer's list."
      : "Enter the code shown on the computer's screen.";
if (k) document.getElementById("codebox").style.display = "none";
// The key is in the address only until pairing is done; take it out of the
// history so it is not sitting in the phone's list of visited pages.
if (k) history.replaceState(null, "", "/pair");
document.getElementById("go").onclick = async () => {
  const err = document.getElementById("err");
  err.textContent = "";
  let r;
  try {
    r = await (await fetch("/pair", {method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({k, code: document.getElementById("code").value,
                            name: document.getElementById("name").value})})).json();
  } catch (e) { err.textContent = "Could not reach the computer."; return; }
  if (r.ok) location.href = "/";
  else err.textContent = r.message || "Pairing failed.";
};
</script></body></html>"""


class RemoteHandler(Handler):
    """The same pages and API, reached from another device.

    Every request through here is authenticated by remote.py and limited to
    remote.path_allowed() before any handler runs — see Handler._guarded.
    """
    remote = True


_remote_server = None
_remote_lock = threading.Lock()


def start_remote() -> str:
    """Open the listener on the local network. Only while switched on.

    Its own port (remote.PORT), not the chat's. The loopback listener stays
    exactly as it was, so switching this on changes nothing about how the
    computer's own windows are trusted.
    """
    global _remote_server
    with _remote_lock:
        if _remote_server:
            return "already listening"
        try:
            srv = http.server.ThreadingHTTPServer(
                ("0.0.0.0", remote_access.PORT), RemoteHandler)
        except OSError as e:
            return f"ERROR: could not open port {remote_access.PORT}: {e}"
        _remote_server = srv
        threading.Thread(target=srv.serve_forever, daemon=True).start()
    print(f"remote access on port {remote_access.PORT}", flush=True)
    return "Other devices on this network can now pair."


def stop_remote() -> str:
    global _remote_server
    with _remote_lock:
        srv, _remote_server = _remote_server, None
    if srv:
        srv.shutdown()
        srv.server_close()
        print("remote access closed", flush=True)
    remote_access.cancel_pairing()
    return "Other devices can no longer connect."


def main():
    # Loopback only. This was "0.0.0.0" — every network interface — with no
    # authentication on anything, so anyone on the same Wi-Fi could drive the
    # machine, including turning off its confirmations. See SECURITY.md, #1.
    #
    # Deliberately not a setting. Access from other devices is a separate
    # listener with its own port and its own authentication (start_remote),
    # so this one never has to decide whether a request is local.
    server = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    threading.Thread(target=_reap_idle_sessions, daemon=True).start()
    if remote_access.enabled():
        print(start_remote(), flush=True)
    print(f"OSprime web UI on http://localhost:{PORT}")
    server.serve_forever()


if __name__ == "__main__":
    main()
