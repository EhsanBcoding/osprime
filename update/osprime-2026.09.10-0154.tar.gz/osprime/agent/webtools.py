"""OSprime web tools: search and page fetch. Stdlib only, no API key.

Searching used to be one request to DuckDuckGo's HTML endpoint, parsed by
looking for `class="result__a"`. Both halves of that were fragile and both
broke. The endpoint now answers a plain request with nothing, and the class
name is markup that a search engine is free to change any week.

The symptom was the worst kind: `web_search` returned "no results found"
for everything, so the assistant told the user "I couldn't find any results
for Anyma syren on YouTube" — a confident, specific, wrong answer about a
track that has millions of plays. A broken search is indistinguishable from
an empty one unless the code says which it is.

So: several engines, tried in order, and a parser that does not depend on
one engine's class names. If every engine fails, that is reported as search
being unavailable — not as the thing not existing.
"""

import html as htmllib
import re
import urllib.error
import urllib.parse
import urllib.request

# A real browser's User-Agent. The old one announced itself as OSprime,
# which is honest and gets refused.
UA = {
    "User-Agent": ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/128.0 Safari/537.36"),
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "en-US,en;q=0.9",
}

# Tried in order. Independent indexes first: they are the least likely to
# refuse a request that does not look like a browser session.
#
# Only endpoints that are known to exist. While writing this list I typed a
# fourth one from memory — a Brave front-end on a workers.dev domain — which
# does not exist and never did. That is the same invention this whole guard
# exists to prevent, and it happens to whoever is typing. Anything added
# here has to be a URL somebody has actually loaded.
ENGINES = [
    ("Mojeek",      "https://www.mojeek.com/search?q={q}"),
    ("DuckDuckGo",  "https://lite.duckduckgo.com/lite/?q={q}"),
    ("DuckDuckGo",  "https://html.duckduckgo.com/html/?q={q}"),
    ("Bing",        "https://www.bing.com/search?q={q}&format=rss"),
]

# Links that are the engine's own furniture, not results.
_JUNK = re.compile(
    r"(?:^|\.)(?:duckduckgo|mojeek|bing|google|microsoft|msn|yandex)\.",
    re.I)
_JUNK_PATH = re.compile(
    r"/(?:about|privacy|settings|preferences|help|login|signin|ads?|"
    r"support|terms|legal|feedback)\b", re.I)


def _http_get(url: str, timeout: int = 15) -> str:
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
    return raw.decode("utf-8", "replace")


def _real_url(href: str) -> str:
    """Engines wrap results in redirects: /l/?uddg=<real>, /url?q=<real>."""
    parsed = urllib.parse.urlparse(href)
    q = urllib.parse.parse_qs(parsed.query)
    for key in ("uddg", "u", "url", "q"):
        val = q.get(key, [""])[0]
        if val.startswith(("http://", "https://")):
            return val
    if href.startswith("//"):
        return "https:" + href
    return href


def parse_search_results(page: str, max_results: int = 6) -> str:
    """Pull results out of any engine's HTML.

    Deliberately generic: every link with visible text, minus the engine's
    own pages, keeping the first few distinct destinations. Depending on one
    engine's CSS class is what left this returning nothing at all.
    """
    page = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", page)

    # RSS, when an engine offers it — far more stable than HTML.
    items = re.findall(r"<item>(.*?)</item>", page, re.S | re.I)
    if items:
        out = []
        for item in items[:max_results]:
            t = re.search(r"<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>",
                          item, re.S | re.I)
            u = re.search(r"<link>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</link>",
                          item, re.S | re.I)
            if t and u:
                out.append(f"- {htmllib.unescape(t.group(1)).strip()}\n"
                           f"  {htmllib.unescape(u.group(1)).strip()}")
        if out:
            return "\n".join(out)

    # Search engines put result titles in headings and their own furniture
    # everywhere else. Looking at headings first is what stops a Mojeek
    # newsletter link — buttondown.email/Mojeek, which no host filter would
    # catch — coming back as the top result for a song.
    headings = "\n".join(re.findall(r"(?is)<h[1-4]\b[^>]*>.*?</h[1-4]>", page))
    for source in (headings, page):
        found = _links(source)
        if found:
            return "\n".join(found[:max_results])
    return ""


def _links(page: str) -> list:
    results, seen = [], set()
    for m in re.finditer(r'<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
                         page, re.S | re.I):
        href = _real_url(htmllib.unescape(m.group(1)))
        if not href.startswith(("http://", "https://")):
            continue
        host = urllib.parse.urlparse(href).netloc
        if _JUNK.search(host) or _JUNK_PATH.search(
                urllib.parse.urlparse(href).path):
            continue
        title = htmllib.unescape(re.sub(r"<[^>]+>", " ", m.group(2)))
        title = " ".join(title.split())
        if len(title) < 4 or href in seen:
            continue
        seen.add(href)
        results.append(f"- {title}\n  {href}")
    return results


def web_search(query: str) -> str:
    query = (query or "").strip()
    if not query:
        return "ERROR: nothing to search for."
    q = urllib.parse.quote_plus(query)
    tried = []
    for name, template in ENGINES:
        try:
            page = _http_get(template.format(q=q))
        except Exception as e:
            tried.append(f"{name} ({type(e).__name__})")
            continue
        found = parse_search_results(page)
        if found:
            return f"Search results for '{query}' (via {name}):\n{found}"
        tried.append(f"{name} (no results)")

    # The distinction that matters. "Nothing exists" and "I could not ask"
    # are different answers, and only one of them is honest here.
    return ("ERROR: web search is not working on this machine right now — "
            f"none of the engines could be reached or read ({', '.join(tried)}). "
            "Tell the user that search is unavailable. Do NOT tell them the "
            "thing they asked for does not exist, and do not invent a link.")


def html_to_text(page: str, limit: int = 8000) -> str:
    page = re.sub(r"(?s)<(script|style|nav|footer|header)[^>]*>.*?</\1>", " ", page)
    page = re.sub(r"(?s)<[^>]+>", " ", page)
    page = htmllib.unescape(page)
    page = re.sub(r"[ \t]+", " ", page)
    page = re.sub(r"\n\s*\n+", "\n", page)
    return page.strip()[:limit]


def fetch_url(url: str) -> str:
    if not url.startswith(("http://", "https://")):
        return "ERROR: only http(s) URLs are supported"
    try:
        return html_to_text(_http_get(url, timeout=25))
    except Exception as e:
        return f"ERROR: could not read {url}: {type(e).__name__}: {e}"
