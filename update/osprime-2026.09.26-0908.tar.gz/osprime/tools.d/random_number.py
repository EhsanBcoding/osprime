"""OSprime plugin: pick a random number.

Exists because the model asked for it by name. Asked to "randomly pick a
number", the local model called a tool called random_number — which did not
exist — and the raw call was shown to the user. run_shell could have done
it, but a small model guesses the obvious name first, and when the obvious
name costs a few dozen tokens in one group, having it be real is cheaper
than teaching the model not to guess.

`secrets`, not `random`: nothing here is security-sensitive, but a person
asking a computer to pick fairly is entitled to a fair pick, and there is no
cost to the better source.
"""
import secrets

TOOL = {
    "name": "random_number",
    "description": "Pick a random whole number between min and max "
                   "(inclusive). Also for dice, coin flips and choosing "
                   "between options.",
    "input_schema": {
        "type": "object",
        "properties": {"min": {"type": "integer"}, "max": {"type": "integer"}},
    },
}


def run(args):
    try:
        lo = int(args.get("min", 1))
        hi = int(args.get("max", 100))
    except (TypeError, ValueError):
        return "ERROR: min and max must be whole numbers."
    if lo > hi:
        lo, hi = hi, lo
    if hi - lo > 10 ** 12:
        return "ERROR: that range is too large."
    return str(lo + secrets.randbelow(hi - lo + 1))
