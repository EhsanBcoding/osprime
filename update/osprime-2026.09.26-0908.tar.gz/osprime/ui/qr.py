"""A small QR code encoder, written from the specification (ISO/IEC 18004).

Why this exists instead of a library: nothing on the OSprime image can make
a QR code — there is no qrencode and no Python qrcode module — and adding a
system package would make the update that ships remote access run a full
`pacman -Syu` on every machine that installs it, which is a heavy price for
drawing one square. The job is narrow: encode a short web address so a
phone can scan it. So this does exactly that and nothing more:

  * byte mode only (a URL is bytes);
  * error correction level M (recovers ~15% damage — enough for a screen);
  * versions 1 to 10 (up to 213 bytes; a pairing address is about 60);
  * all eight masks, chosen by the standard penalty rules;
  * output as SVG, so it is sharp at any size and needs no image file.

How it was verified, 23 September:

  * module-for-module identical to the `qrcode` reference library in 480
    codes — versions 1 to 10, all eight masks;
  * decoded by ZXing (the decoder family most phone cameras use) in 960 of
    960 codes, and in 300 of 300 addresses shaped like a real pairing link.

OpenCV's detector failed on about 3% of the same images — including images
from the reference library itself — so it is the wrong instrument for this
test, and a reason a phone's own camera app is what the pairing screen
asks people to use.
"""

# --- per-version tables for error correction level M -----------------------
# (ec codewords per block, number of blocks), versions 1..10.
_EC_M = {1: (10, 1), 2: (16, 1), 3: (26, 1), 4: (18, 2), 5: (24, 2),
         6: (16, 4), 7: (18, 4), 8: (22, 4), 9: (22, 5), 10: (26, 5)}

# Total codewords (data + ec) per version.
_TOTAL = {1: 26, 2: 44, 3: 70, 4: 100, 5: 134, 6: 172, 7: 196, 8: 242,
          9: 292, 10: 346}

# Alignment pattern centres per version.
_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30],
          6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46],
          10: [6, 28, 50]}

_EC_LEVEL_BITS_M = 0b00


def _data_capacity(version: int) -> int:
    ec, blocks = _EC_M[version]
    return _TOTAL[version] - ec * blocks


# --- GF(256) and Reed-Solomon ------------------------------------------------
_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _gf_mul(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return _EXP[_LOG[a] + _LOG[b]]


def _rs_generator(degree: int) -> list:
    """Coefficients of prod(x - a^i) for i < degree, highest power first,
    leading 1 omitted."""
    poly = [1]
    for i in range(degree):
        nxt = [0] * (len(poly) + 1)
        for j, c in enumerate(poly):
            nxt[j] ^= c
            nxt[j + 1] ^= _gf_mul(c, _EXP[i])
        poly = nxt
    return poly[1:]


def _rs_remainder(data: list, degree: int) -> list:
    gen = _rs_generator(degree)
    rem = [0] * degree
    for b in data:
        factor = b ^ rem[0]
        rem = rem[1:] + [0]
        for i, g in enumerate(gen):
            rem[i] ^= _gf_mul(g, factor)
    return rem


# --- data codewords ------------------------------------------------------------
def _codewords(payload: bytes, version: int) -> list:
    bits = []

    def put(value, length):
        for i in range(length - 1, -1, -1):
            bits.append((value >> i) & 1)

    put(0b0100, 4)                                    # byte mode
    put(len(payload), 8 if version <= 9 else 16)
    for b in payload:
        put(b, 8)
    cap_bits = _data_capacity(version) * 8
    put(0, min(4, cap_bits - len(bits)))              # terminator
    while len(bits) % 8:
        bits.append(0)
    pad = [0xEC, 0x11]
    i = 0
    while len(bits) < cap_bits:
        put(pad[i % 2], 8)
        i += 1
    data = [int("".join(map(str, bits[i:i + 8])), 2)
            for i in range(0, len(bits), 8)]

    # Split into blocks; the later blocks are one codeword longer when the
    # total does not divide evenly.
    ec_len, n_blocks = _EC_M[version]
    total = _TOTAL[version]
    short_len = total // n_blocks
    n_short = n_blocks - total % n_blocks
    blocks, ecs, k = [], [], 0
    for i in range(n_blocks):
        dlen = short_len - ec_len + (0 if i < n_short else 1)
        blk = data[k:k + dlen]
        k += dlen
        blocks.append(blk)
        ecs.append(_rs_remainder(blk, ec_len))

    out = []
    for i in range(max(len(b) for b in blocks)):
        for b in blocks:
            if i < len(b):
                out.append(b[i])
    for i in range(ec_len):
        for e in ecs:
            out.append(e[i])
    return out


# --- the matrix ------------------------------------------------------------------
class _Matrix:
    def __init__(self, version: int):
        self.v = version
        self.size = 17 + 4 * version
        n = self.size
        self.m = [[0] * n for _ in range(n)]
        self.fn = [[False] * n for _ in range(n)]

    def setf(self, x, y, dark):
        self.m[y][x] = 1 if dark else 0
        self.fn[y][x] = True

    def draw_function_patterns(self):
        n = self.size
        for i in range(n):                       # timing
            self.setf(6, i, i % 2 == 0)
            self.setf(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (n - 4, 3), (3, n - 4)):   # finders
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < n and 0 <= y < n:
                        d = max(abs(dx), abs(dy))
                        self.setf(x, y, d not in (2, 4))
        pos = _ALIGN[self.v]
        for i, a in enumerate(pos):              # alignment
            for j, b in enumerate(pos):
                if (i == 0 and j == 0) or (i == 0 and j == len(pos) - 1) \
                        or (i == len(pos) - 1 and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.setf(a + dx, b + dy, max(abs(dx), abs(dy)) != 1)
        self.draw_format(0)                      # reserve, real bits later
        if self.v >= 7:
            rem = self.v
            for _ in range(12):
                rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
            bits = self.v << 12 | rem
            for i in range(18):
                bit = (bits >> i) & 1
                a, b = n - 11 + i % 3, i // 3
                self.setf(a, b, bit)
                self.setf(b, a, bit)

    def draw_format(self, mask):
        data = _EC_LEVEL_BITS_M << 3 | mask
        rem = data
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = (data << 10 | rem) ^ 0x5412
        n = self.size
        bit = lambda i: (bits >> i) & 1
        for i in range(6):
            self.setf(8, i, bit(i))
        self.setf(8, 7, bit(6))
        self.setf(8, 8, bit(7))
        self.setf(7, 8, bit(8))
        for i in range(9, 15):
            self.setf(14 - i, 8, bit(i))
        for i in range(8):
            self.setf(n - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self.setf(8, n - 15 + i, bit(i))
        self.setf(8, n - 8, True)                # the dark module

    def draw_codewords(self, cw):
        n = self.size
        i = 0
        right = n - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(n):
                for j in range(2):
                    x = right - j
                    upward = ((right + 1) & 2) == 0
                    y = n - 1 - vert if upward else vert
                    if not self.fn[y][x] and i < len(cw) * 8:
                        self.m[y][x] = (cw[i >> 3] >> (7 - (i & 7))) & 1
                        i += 1
            right -= 2

    def apply_mask(self, mask):
        n = self.size
        for y in range(n):
            for x in range(n):
                if self.fn[y][x]:
                    continue
                if mask == 0:
                    inv = (x + y) % 2 == 0
                elif mask == 1:
                    inv = y % 2 == 0
                elif mask == 2:
                    inv = x % 3 == 0
                elif mask == 3:
                    inv = (x + y) % 3 == 0
                elif mask == 4:
                    inv = (x // 3 + y // 2) % 2 == 0
                elif mask == 5:
                    inv = x * y % 2 + x * y % 3 == 0
                elif mask == 6:
                    inv = (x * y % 2 + x * y % 3) % 2 == 0
                else:
                    inv = ((x + y) % 2 + x * y % 3) % 2 == 0
                if inv:
                    self.m[y][x] ^= 1

    def penalty(self) -> int:
        """The four standard penalty rules. Only used to choose among masks
        that are all valid, so a small difference from another encoder's
        scoring changes which valid code is drawn, never whether it scans."""
        n, m = self.size, self.m
        score = 0
        lines = [row for row in m] + [[m[y][x] for y in range(n)]
                                      for x in range(n)]
        for line in lines:                       # rule 1: runs of 5+
            run, prev = 0, None
            for c in line:
                if c == prev:
                    run += 1
                else:
                    if run >= 5:
                        score += run - 2
                    run, prev = 1, c
            if run >= 5:
                score += run - 2
        for y in range(n - 1):                   # rule 2: 2x2 blocks
            for x in range(n - 1):
                c = m[y][x]
                if c == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    score += 3
        pats = ([1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0],
                [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1])
        for line in lines:                       # rule 3: finder-alikes
            for i in range(len(line) - 10):
                if line[i:i + 11] in pats:
                    score += 40
        dark = sum(map(sum, m))                  # rule 4: balance
        k = abs(dark * 20 - n * n * 10) // (n * n)
        score += k * 10
        return score


def matrix(text: str, mask: int = None, version: int = None) -> list:
    """The QR code for `text` as rows of 0/1, without the quiet zone."""
    payload = text.encode("utf-8")
    if version is None:
        for v in range(1, 11):
            head = 4 + (8 if v <= 9 else 16)
            if head + len(payload) * 8 <= _data_capacity(v) * 8:
                version = v
                break
        else:
            raise ValueError("too long for a QR code this encoder makes "
                             f"({len(payload)} bytes; at most 213)")
    cw = _codewords(payload, version)
    best = None
    for msk in ([mask] if mask is not None else range(8)):
        q = _Matrix(version)
        q.draw_function_patterns()
        q.draw_codewords(cw)
        q.apply_mask(msk)
        q.draw_format(msk)
        if mask is not None:
            return q.m
        p = q.penalty()
        if best is None or p < best[0]:
            best = (p, q.m)
    return best[1]


def selftest() -> list:
    """Two codes, pinned to output that was checked module-for-module
    against the reference library on 23 September. Called by release.sh.

    A QR code that is almost right does not scan, and nothing else in the
    build would notice: the page would still show a square full of dots.
    """
    import hashlib
    pinned = {"http://192.168.1.20:8081/pair?k=abcdefghijklmnopqrstuv":
              (33, "a9952314b52d756f"),
              "OSprime": (21, "24ac06c771ddc693")}
    bad = []
    for text, (size, digest) in pinned.items():
        try:
            m = matrix(text)
        except Exception as e:
            bad.append(f"qr: {text[:20]}… raised {e}")
            continue
        got = hashlib.sha256("".join("".join(map(str, r)) for r in m)
                             .encode()).hexdigest()[:16]
        if len(m) != size or got != digest:
            bad.append(f"qr: {text[:20]}… no longer matches the verified code")
    return bad


def svg(text: str, scale: int = 8, quiet: int = 4) -> str:
    """An SVG drawing of the code, black on white, with the quiet zone the
    specification requires — a code drawn edge-to-edge on a dark page does
    not scan, and this page is dark."""
    m = matrix(text)
    n = len(m) + 2 * quiet
    parts = []
    for y, row in enumerate(m):
        for x, c in enumerate(row):
            if c:
                parts.append(f"M{x + quiet},{y + quiet}h1v1h-1z")
    px = n * scale
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{px}" '
            f'height="{px}" viewBox="0 0 {n} {n}" shape-rendering="crispEdges">'
            f'<rect width="{n}" height="{n}" fill="#fff"/>'
            f'<path d="{"".join(parts)}" fill="#000"/></svg>')
