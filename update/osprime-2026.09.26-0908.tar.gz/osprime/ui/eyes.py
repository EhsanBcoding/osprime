"""Settings → Home → "Add eyes" / "Remove eyes", and "Switch model".

docs/MODELS.md, steps 4 and 7. The switch runs osprime-profile.sh --install,
which installs the model hardware.recommend() picks — on an 8 GB card,
Qwen3.5 9B — after proving it loads and calls a tool.

Runs shell/osprime-add-vision.sh through its argument-free sudo rule and
reports progress to the page. Adding eyes downloads gigabytes and takes
minutes, so it runs in the background: the page starts it, then polls
status() until it is done. One run at a time.

Nothing here decides anything. Which model, where it runs, and whether it
really sees are all decided by the script and agent/hardware.py; this file
only starts it, watches it and says what happened.
"""

import os
import pathlib
import subprocess
import threading
import time

SCRIPT = "/opt/osprime/shell/osprime-add-vision.sh"
PROFILER = "/opt/osprime/shell/osprime-profile.sh"
LOG = pathlib.Path(os.environ.get("OSPRIME_EYES_LOG",
                                  "/var/lib/osprime/add-vision.log"))

_lock = threading.Lock()
_run = {"proc": None, "action": None, "started": 0.0, "download_mb": 0,
        "code": None}


def _command(action: str) -> list:
    # Exactly the lines in OSPRIME_EYES — nothing a caller can vary.
    if action == "switch":
        cmd = ["/usr/bin/bash", PROFILER, "--install"]
    else:
        cmd = ["/usr/bin/bash", SCRIPT] + (["--remove"] if action == "remove" else [])
    return cmd if os.geteuid() == 0 else ["sudo", "-n"] + cmd


def start(action: str) -> dict:
    if action not in ("add", "remove", "switch"):
        return {"ok": False, "message": "unknown request"}
    with _lock:
        p = _run["proc"]
        if p is not None and p.poll() is None:
            return {"ok": False, "message": "already working on it"}
        plan = {}
        if action == "switch":
            plan = switch_plan()
            if not plan.get("better"):
                return {"ok": False, "message": "this computer is already "
                        "running the model that suits it"}
            if not plan.get("enough_disk", True):
                return {"ok": False, "message":
                        f"not enough free disk space — it needs about "
                        f"{plan['download_mb'] + 1000} MB"}
        if action == "add":
            import hardware
            plan = hardware.vision_plan()
            if not plan.get("tier"):
                return {"ok": False, "message": plan.get("why_not") or
                        "this machine cannot run a model that can see"}
            if not plan.get("enough_disk", True):
                return {"ok": False, "message":
                        f"not enough free disk space — it needs about "
                        f"{plan['download_mb'] + 500} MB"}
        try:
            LOG.parent.mkdir(parents=True, exist_ok=True)
            out = open(LOG, "w", encoding="utf-8")
            _run["proc"] = subprocess.Popen(
                _command(action), stdout=out, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, start_new_session=True)
            out.close()
        except Exception as e:
            return {"ok": False, "message": f"could not start: {e}"}
        _run.update(action=action, started=time.time(), code=None, restarted=False,
                    download_mb=plan.get("download_mb", 0))
    return {"ok": True, "message": "started"}


def switch_plan() -> dict:
    """What "Switch model" would install, and how much it would download."""
    import hardware
    rec = hardware.recommend()
    now = hardware.installed()
    need = 0
    for i, f in enumerate(rec["files"]):
        if not (hardware.MODELS_DIR / f).is_file():
            if f == rec.get("mmproj_local"):
                need += rec.get("mmproj_mb", 0)
            else:
                need += rec.get("model_mb", rec["disk_mb"]) if i == 0 else 0
    p = hardware.profile()
    return {"better": rec["tier"] != now.get("tier"), "tier": rec["tier"],
            "label": rec["label"], "why": rec.get("why", ""),
            "download_mb": need,
            "enough_disk": p["disk_free_mb"] >= need + 1000}


def _downloaded_mb() -> int:
    """How much of the download is on disk so far, from the .part files."""
    try:
        import hardware
        return int(sum(f.stat().st_size for f in
                       hardware.MODELS_DIR.glob("*.part")) / 1024 / 1024)
    except Exception:
        return 0


def _tail(n: int = 8) -> list:
    try:
        lines = LOG.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    # curl's progress meter writes carriage returns; keep only the last state.
    return [l.rsplit("\r", 1)[-1] for l in lines if l.strip()][-n:]


def status() -> dict:
    import hardware
    out = {"plan": {}, "running": False}
    try:
        out["plan"] = hardware.vision_plan()
    except Exception as e:
        out["plan"] = {"why_not": f"could not read this machine: {e}"}
    try:
        out["switch"] = switch_plan()
    except Exception:
        out["switch"] = {}
    p = _run["proc"]
    if p is None:
        return out
    code = p.poll()
    out.update(action=_run["action"], running=code is None,
               seconds=int(time.time() - _run["started"]), log=_tail())
    if code is None and _run["download_mb"]:
        done = _downloaded_mb()
        out["progress"] = min(99, int(100 * done / max(1, _run["download_mb"])))
        out["downloaded_mb"] = done
    if code is not None:
        out["ok"] = code == 0
        if code == 0 and not _run.get("restarted"):
            # The scripts restart the system-wide agent, which does not run
            # once people have accounts. The person's own is restarted here,
            # once, so it learns about the new model or its eyes.
            _run["restarted"] = True
            if pathlib.Path("/etc/osprime/accounts").exists() and os.geteuid() != 0:
                subprocess.run(["systemctl", "--user", "try-restart", "osprime-agent"],
                               capture_output=True)
        if code != 0 and any("a password is required" in l for l in out["log"]):
            out["log"].append("The sudo rule for this is missing — install the "
                              "latest update, which adds it.")
    return out


def selftest() -> list:
    """The command line must be exactly what the sudo rule names."""
    bad = []
    sudoers = pathlib.Path(__file__).resolve().parent.parent / "shell/osprime-sudoers"
    try:
        text = sudoers.read_text(encoding="utf-8")
    except OSError:
        return ["eyes: cannot read shell/osprime-sudoers"]
    for action in ("add", "remove", "switch"):
        line = " ".join(_command(action)[-2 if action == "add" else -3:])
        if line not in text:
            bad.append(f"eyes: '{line}' is not in the sudo rules")
    return bad
