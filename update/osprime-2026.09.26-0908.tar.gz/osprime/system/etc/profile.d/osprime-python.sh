# OSprime's own Python environment first, for the person at the terminal —
# the same one the assistant uses (docs/PYTHON.md). So "run this in your
# terminal" runs it with the libraries the assistant installed.
# Only when it exists; a machine without it is left exactly as it was.
_osprime_py="$HOME/.local/share/osprime/python/bin"
if [ -x "$_osprime_py/python" ]; then
    case ":$PATH:" in
        *":$_osprime_py:"*) ;;
        *) PATH="$_osprime_py:$PATH"; export PATH ;;
    esac
fi
unset _osprime_py
