#!/usr/bin/env bash
# Change how the encrypted disk unlocks at start. docs/ENCRYPTION.md.
#
#   sudo bash /opt/osprime/shell/osprime-disk-unlock.sh tpm        TPM only (login password)
#   sudo bash /opt/osprime/shell/osprime-disk-unlock.sh tpm-pin    TPM + a PIN at start
#   sudo bash /opt/osprime/shell/osprime-disk-unlock.sh password   the disk password every start
#
# From a terminal, deliberately: it needs the disk password or the recovery
# key (systemd-cryptenroll asks for it), so it is not a Settings button that
# anyone at an unlocked screen could press. The password and the recovery
# key are never removed — only the TPM way in is added, changed or taken
# away.
set -u
R="${OSPRIME_DISK_ROOT:-}"
MODE="${1:-}"
MAPPER=osprime-root
CRYPTTAB="$R/etc/crypttab.initramfs"
STATE="$R/etc/osprime/disk.json"

case "$MODE" in tpm|tpm-pin|password) ;; *)
    echo "Usage: sudo bash $0 tpm|tpm-pin|password"; exit 2 ;; esac
if [ "$(id -u)" -ne 0 ] && [ -z "${OSPRIME_DISK_TEST:-}" ]; then
    echo "Run it with sudo."; exit 1
fi
[ -f "$CRYPTTAB" ] || { echo "This disk is not encrypted (no $CRYPTTAB)."; exit 1; }

DEV="${OSPRIME_DISK_DEV:-$(cryptsetup status "$MAPPER" 2>/dev/null | awk '/device:/{print $2}')}"
[ -n "$DEV" ] || { echo "Could not find the encrypted disk behind $MAPPER."; exit 1; }
if [ "$MODE" != password ] && [ -z "${OSPRIME_DISK_TEST:-}" ] && [ ! -e /dev/tpmrm0 ]; then
    echo "This computer has no TPM 2.0 — only 'password' is possible."; exit 1
fi

echo "> changing how $DEV unlocks to: $MODE"
echo "  You will be asked for the disk password or the recovery key."
case "$MODE" in
    tpm)      systemd-cryptenroll --wipe-slot=tpm2 --tpm2-device=auto --tpm2-pcrs=7 "$DEV" ;;
    tpm-pin)  systemd-cryptenroll --wipe-slot=tpm2 --tpm2-device=auto --tpm2-pcrs=7 \
                  --tpm2-with-pin=yes "$DEV" ;;
    password) systemd-cryptenroll --wipe-slot=tpm2 "$DEV" ;;
esac || { echo "Nothing was changed."; exit 1; }

# The initramfs has to be told whether to ask the TPM.
opt=luks; [ "$MODE" = password ] || opt=tpm2-device=auto
sed -i -E "s/^($MAPPER[[:space:]]+[^[:space:]]+[[:space:]]+[^[:space:]]+[[:space:]]+).*/\1$opt/" "$CRYPTTAB"
printf '{"encrypted": true, "unlock": "%s", "mapper": "%s"}\n' "$MODE" "$MAPPER" > "$STATE"
echo "> rebuilding the startup image"
mkinitcpio -P >/dev/null || { echo "mkinitcpio failed — do not restart until this is fixed:"; mkinitcpio -P; exit 1; }
echo "Done. It takes effect at the next start."
