#!/usr/bin/env bash
# Start the companion — the round presence that floats on the desktop.
#
# Same shape as osprime-desktop.sh, and for the same reason: autostart gets
# one thing to call, and the checks live somewhere a person can read them.
#
# Every failure here is survivable. Without the companion the chat is still
# on the Super key, in the desktop right-click menu and in labwc's own menu,
# so the worst case is a missing button, never a session that will not come
# up. Nothing below is allowed to exit non-zero into autostart.

HERE="$(cd "$(dirname "$0")" && pwd)"
LOG=/tmp/osprime-companion.log

fail() {
    echo "$(date +%H:%M:%S) not starting: $1" >> "$LOG"
    exit 0          # 0 on purpose — autostart must not treat this as fatal
}

# The machine's defaults, then the person's own on top (docs/ACCOUNTS.md).
# On a machine without a login yet the second file does not exist.
for _env in /etc/osprime/desktop.env "$HOME/.config/osprime/desktop.env"; do
    [ -r "$_env" ] && [ "$(id -un)" != osprime -o "$_env" = /etc/osprime/desktop.env ] && . "$_env"
done
unset _env
[ "${OSPRIME_COMPANION:-yes}" = "no" ] && fail "switched off in Settings"

command -v python3 >/dev/null || fail "python3 missing"

# Without gtk-layer-shell a GTK window is an ordinary window: it would land
# in the middle of the screen with a titlebar on it, which is worse than
# nothing at all. Check before starting, not after.
# cairo is in here too, not only gi: the companion draws itself rather than
# loading an image, so a missing python-cairo is a traceback in a log nobody
# reads and a button that never appears.
python3 - <<'PY' 2>>"$LOG" || fail "gtk-layer-shell, python-gobject or python-cairo missing"
import cairo
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("GtkLayerShell", "0.1")
from gi.repository import Gtk, GtkLayerShell
PY

# Only one. Restarting the session — or flipping the switch in Settings —
# must not leave two companions stacked on the same corner.
pkill -f "osprime-companion.py" 2>/dev/null
sleep 0.2

exec python3 "$HERE/osprime-companion.py" >>"$LOG" 2>&1
