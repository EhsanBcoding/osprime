#!/usr/bin/env bash
# Round 3 of docs/MODELS.md: Qwen3.5-9B with eyes vs today's model vs a coder.
#
#   bash /opt/osprime/shell/osprime-measure-round3.sh
#
# Run as the osprime user, in a terminal — it asks twice before doing
# anything: once before downloading ~11 GB, once before stopping the chat
# engine for 10-20 minutes. The main engine always comes back. The result
# opens in the text editor.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
if [ "$(id -u)" -eq 0 ]; then
    echo "Run this as your normal user, not with sudo — it runs model-written"
    echo "test programs, and those never run as root. It asks for sudo itself"
    echo "only to stop and restart the chat engine."
    exit 1
fi
python3 "$HERE/osprime-measure-round3.py"
OUT="${HOME:-/tmp}/osprime-model-round3.txt"
if [ -f "$OUT" ] && [ -n "${WAYLAND_DISPLAY:-}" ] && command -v mousepad >/dev/null; then
    mousepad "$OUT" >/dev/null 2>&1 &
fi
