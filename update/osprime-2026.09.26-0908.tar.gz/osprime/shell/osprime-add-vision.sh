#!/usr/bin/env bash
# Give OSprime eyes without changing the model it talks with.
#
#   sudo bash /opt/osprime/shell/osprime-add-vision.sh           the one this machine suits
#   sudo bash /opt/osprime/shell/osprime-add-vision.sh vision-large     Qwen2.5-VL 7B
#   sudo bash /opt/osprime/shell/osprime-add-vision.sh vision-medium    Qwen2.5-VL 3B
#   sudo bash /opt/osprime/shell/osprime-add-vision.sh --remove   take the eyes away
#
# With no argument it is what Settings → "Add eyes" runs, through a sudo
# rule that allows exactly that and --remove — no argument a caller could
# choose. hardware.vision_choice() picks the model from the hardware.
#
# docs/MODELS.md, step 2. The main model stays exactly as it is. The vision
# model is installed BESIDE it, and for each photo agent/engines.py lends it
# the graphics card for a few seconds and takes it back.
#
# Uses what is already on the disk: a machine that ran the vision model as
# its main model still has it, and nothing is downloaded twice. Before
# 24 September the projector was saved as "mmproj-F16.gguf" — the same
# name every vision model publishes, so it cannot be told from the file
# name which model it belongs to. Such a file is used only after it has
# PROVED itself below; a wrong one is replaced by a download, never trusted.
#
# Proof, not a label: the model is started on a spare port, on the
# processor so the conversation keeps its card, and shown a small picture
# that is plainly one colour. If it names the colour, it sees. Only then is
# /etc/osprime/vision.env written. A failure at any point changes nothing.
set -u

HERE="$(cd "$(dirname "$0")" && pwd)"
AGENT="$(cd "$HERE/../agent" && pwd)"
MODELS="${OSPRIME_MODELS:-/var/lib/osprime/models}"
PROBE_PORT="${OSPRIME_PROBE_PORT:-8092}"
VISION_ENV="${OSPRIME_VISION_ENV:-/etc/osprime/vision.env}"
TIER="${1:-}"
py() { PYTHONPATH="$AGENT" python3 "$@"; }

if [ "$(id -u)" -ne 0 ] && [ -z "${OSPRIME_ADD_VISION_TEST:-}" ]; then
    echo "This installs a model and writes /etc/osprime/vision.env — run it with sudo."
    exit 1
fi

restart_agent() {   # the agent caches "can this machine see"
    [ -n "${OSPRIME_ADD_VISION_TEST:-}" ] && return 0
    systemctl daemon-reload 2>/dev/null
    systemctl try-restart osprime-agent 2>/dev/null || true   # only if running
}

if [ "$TIER" = "--remove" ]; then
    # Only the setting. The model files stay, so adding eyes back later
    # costs no download. Starting the main engine stops vision if it is
    # somehow running (Conflicts=).
    rm -f "$VISION_ENV"
    [ -z "${OSPRIME_ADD_VISION_TEST:-}" ] && systemctl start osprime-model 2>/dev/null
    restart_agent
    echo "Removed. The assistant no longer sees; the model files are still in"
    echo "$MODELS, so adding it back needs no download."
    exit 0
fi

# A talking model with its own eyes (Qwen3.5 9B) needs no second one — it
# would only add a swap to every photo.
if [ "$(py -c "import hardware; i = hardware.installed(); print('yes' if i['sees'] and i['tier'] not in hardware.VISION_TIERS else '')")" = yes ]; then
    echo "The model OSprime talks with already sees on its own. Nothing to add."
    exit 0
fi

if [ -z "$TIER" ]; then
    TIER="$(py -c "import hardware; print(hardware.vision_choice() or '')")"
    [ -n "$TIER" ] || { py -c "import hardware; print(hardware.vision_plan().get('why_not', 'This machine cannot run a vision model.'))"; exit 1; }
fi
case "$TIER" in
    vision-large|vision-medium) ;;
    *) echo "Usage: sudo bash $0 [vision-large|vision-medium|--remove]"; exit 2 ;;
esac

field() { py -c "import hardware; r = hardware.spec_for('$TIER'); print($1)"; }
LABEL="$(field "r['label']")"
MODEL_FILE="$(field "r['files'][0]")"
MODEL_URL="$(field "r['urls'][0]")"
PROJ_LOCAL="$(field "r['mmproj_local']")"
PROJ_URL="$(field "r['urls'][-1]")"
PROJ_LEGACY="$(field "r['mmproj']")"
MODEL="$MODELS/$MODEL_FILE"

BIN="$(command -v llama-server || command -v llama-cpp-server || true)"
[ -n "$BIN" ] || { echo "No llama-server on this machine — nothing was changed."; exit 1; }

fetch() {   # fetch <url> <dest>
    [ -s "$2" ] && { echo "  already have $(basename "$2")"; return 0; }
    echo "  downloading $(basename "$2")"
    mkdir -p "$(dirname "$2")"
    curl -fL --retry 3 --continue-at - -o "$2.part" "$1" && mv "$2.part" "$2"
}

# A small, plainly red picture, made here so the proof needs nothing else.
PICTURE="$(mktemp --suffix=.png)"
py -c "
import struct, zlib, sys
w = h = 224
row = b'\x00' + bytes([220, 20, 20]) * w
raw = zlib.compress(row * h)
def chunk(t, d):
    return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d))
png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
       + chunk(b'IDAT', raw) + chunk(b'IEND', b''))
open(sys.argv[1], 'wb').write(png)
" "$PICTURE"
PROBE_PID=""
cleanup() { [ -n "$PROBE_PID" ] && kill "$PROBE_PID" 2>/dev/null; rm -f "$PICTURE"; }
trap cleanup EXIT

sees() {   # sees <projector> — 0 if the model names the colour of the picture
    local proj="$1"
    echo "> checking $(basename "$proj") with $LABEL (on the processor, ~a minute)"
    "$BIN" -m "$MODEL" --mmproj "$proj" --host 127.0.0.1 --port "$PROBE_PORT" \
           --ctx-size 2048 --n-gpu-layers 0 >/tmp/osprime-vision-probe.log 2>&1 &
    PROBE_PID=$!
    local answer="" ok=1
    for _ in $(seq 1 180); do
        sleep 1
        kill -0 "$PROBE_PID" 2>/dev/null || break
        curl -fsS --max-time 2 "http://127.0.0.1:$PROBE_PORT/health" >/dev/null 2>&1 || continue
        answer="$(OSPRIME_VISION_PROBE_URL="http://127.0.0.1:$PROBE_PORT/v1" py -c "
import os, sys, local
try:
    print(local._ask_image(os.environ['OSPRIME_VISION_PROBE_URL'],
                           open(sys.argv[1], 'rb').read(), 'image/png',
                           'What colour is this picture? Answer with one word.', 300))
except Exception as e:
    print('ERROR:', e)
" "$PICTURE")"
        break
    done
    kill "$PROBE_PID" 2>/dev/null; wait "$PROBE_PID" 2>/dev/null; PROBE_PID=""
    echo "  it said: ${answer:-nothing}"
    case "$(printf '%s' "$answer" | tr '[:upper:]' '[:lower:]')" in
        *red*|*قرمز*) ok=0 ;;
    esac
    [ "$ok" -eq 0 ] || tail -5 /tmp/osprime-vision-probe.log
    return "$ok"
}

echo "> $LABEL"
fetch "$MODEL_URL" "$MODEL" || { echo "Download failed — nothing was changed."; exit 1; }

CHOSEN=""
for cand in "$MODELS/$PROJ_LOCAL" "$MODELS/$PROJ_LEGACY"; do
    [ -s "$cand" ] || continue
    if sees "$cand"; then CHOSEN="$cand"; break; fi
    echo "  that projector does not belong to this model — not using it"
done
if [ -z "$CHOSEN" ]; then
    rm -f "$MODELS/$PROJ_LOCAL"          # proved wrong above, or absent
    fetch "$PROJ_URL" "$MODELS/$PROJ_LOCAL" || { echo "Download failed — nothing was changed."; exit 1; }
    sees "$MODELS/$PROJ_LOCAL" && CHOSEN="$MODELS/$PROJ_LOCAL"
fi
if [ -z "$CHOSEN" ]; then
    echo
    echo "$LABEL did not see the picture. Nothing was changed; the"
    echo "conversation model is exactly as it was."
    exit 1
fi
# Settle on the tier's own name, so the ambiguous one is never needed again.
if [ "$CHOSEN" != "$MODELS/$PROJ_LOCAL" ]; then
    cp -f "$CHOSEN" "$MODELS/$PROJ_LOCAL" && CHOSEN="$MODELS/$PROJ_LOCAL"
fi

py -c "import hardware; print(hardware.write_vision_env('$TIER', '$MODEL', '$CHOSEN'))" \
    | tee /tmp/osprime-add-vision.out
grep -q '^ERROR' /tmp/osprime-add-vision.out && exit 1

restart_agent
echo
echo "Done. Ask OSprime to take a photo, or to look at a picture."
echo "The first look after a restart takes longer while the model is read"
echo "from disk; after that, a few seconds."
