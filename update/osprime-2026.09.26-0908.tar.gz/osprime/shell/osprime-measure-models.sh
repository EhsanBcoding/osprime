#!/usr/bin/env bash
# Where can a vision model live on this machine? docs/MODELS.md, step 0.
#
#   bash /opt/osprime/shell/osprime-measure-models.sh
#
# Takes several minutes and keeps the laptop busy — the fans will come on.
# Changes nothing: every test engine is started on its own port and shut
# down again, and the chat keeps working (slower) throughout. The result
# opens in the text editor so it can be read and copied.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
echo "This takes several minutes. The chat keeps working, only slower."
python3 "$HERE/osprime-measure-models.py"
OUT="${HOME:-/tmp}/osprime-model-measure.txt"
if [ -f "$OUT" ] && [ -n "${WAYLAND_DISPLAY:-}" ] && command -v mousepad >/dev/null; then
    mousepad "$OUT" >/dev/null 2>&1 &
fi
