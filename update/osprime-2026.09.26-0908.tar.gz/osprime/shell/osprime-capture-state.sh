#!/usr/bin/env bash
# Is the camera or the microphone open right now?
#
# Printed for waybar, which polls this and shows nothing when the text is
# empty. So the badge appears exactly while a device is in use and vanishes
# when it is not — it is not a notification that fades while the camera
# keeps running.
#
# It reports ANY program using a device, not only OSprime. That is the
# whole point: a badge that stayed dark during a video call would teach
# people that no badge means nothing is watching, which is worse than
# having no badge at all.
#
# Failure prints nothing rather than an error. A broken indicator must not
# put a permanent warning on a machine where nothing is wrong — but it also
# must not be the reason the panel dies, which is why every path here ends
# in valid JSON.

URL="${OSPRIME_URL:-http://localhost:8080}/api/capture"

state="$(curl -s --max-time 2 "$URL" 2>/dev/null)"
[ -z "$state" ] && { echo '{"text":"","tooltip":"","class":"idle"}'; exit 0; }

printf '%s' "$state" | python3 -c '
import json, sys
try:
    d = json.load(sys.stdin)
except Exception:
    print(json.dumps({"text": "", "tooltip": "", "class": "idle"}))
    sys.exit(0)

cam, mic = d.get("camera", {}), d.get("microphone", {})
parts, who = [], []
if cam.get("in_use"):
    parts.append(" Camera")          # video icon
    who += cam.get("by", [])
if mic.get("in_use"):
    parts.append(" Microphone")      # microphone icon
    who += mic.get("by", [])

if not parts:
    print(json.dumps({"text": "", "tooltip": "", "class": "idle"}))
    sys.exit(0)

# Naming the program is the difference between a warning and information.
# "Something is using your camera" makes people anxious; "Chromium is using
# your camera" tells them whether to care.
tip = " and ".join(parts).replace(" ", "").replace(" ", "")
if who:
    tip += " in use by " + ", ".join(sorted(set(who)))
else:
    tip += " in use"
print(json.dumps({"text": " ".join(parts), "tooltip": tip, "class": "live"}))
' 2>/dev/null || echo '{"text":"","tooltip":"","class":"idle"}'
