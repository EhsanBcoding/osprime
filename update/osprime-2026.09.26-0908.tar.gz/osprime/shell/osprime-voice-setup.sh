#!/usr/bin/env bash
# Set up speech-to-text: fetch a Whisper model and prove it works.
#
# The engine itself is a package — `whisper-cpp` in Arch's extra repo, whose
# binary is `whisper-cli`. This script only deals with the model, which is a
# few hundred megabytes and cannot ship in an update.
#
# Written the same way osprime-profile.sh downloads a language model, and
# for the same reasons: resume rather than restart, write to .part and
# rename only on success, and PROVE the thing works before telling anyone
# it is ready. A model file that exists and cannot be loaded is worse than
# no model, because the failure then happens to the user mid-sentence.
#
#   bash osprime-voice-setup.sh          # pick a size for this machine
#   bash osprime-voice-setup.sh small    # or name one
#
# Text-to-speech is a separate matter: piper is AUR-only, so OSprime cannot
# install it from the official repositories and the assistant stays
# text-out-only for now. Said here so the next person does not go looking.
set -u

MODELS="${OSPRIME_MODELS:-/var/lib/osprime/models}"
BASE="https://huggingface.co/ggerganov/whisper.cpp/resolve/main"

BIN="$(command -v whisper-cli || command -v whisper || true)"
if [ -z "$BIN" ]; then
    echo "Speech-to-text needs the whisper-cpp package:"
    echo "  sudo pacman -Syu --needed whisper-cpp"
    exit 1
fi

# Which model.
#
# The .en models are English-only and would be the wrong default here: the
# person who uses this machine speaks Persian. Multilingual it is, and the
# smallest multilingual model that is any good at Persian is 'small'.
WANT="${1:-}"
if [ -z "$WANT" ]; then
    FREE_MB=$(df -Pm "$(dirname "$MODELS")" 2>/dev/null | awk 'NR==2{print $4}')
    RAM_MB=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo 2>/dev/null)
    if [ "${FREE_MB:-0}" -gt 2000 ] && [ "${RAM_MB:-0}" -gt 3500 ]; then
        WANT=small
    else
        WANT=base
    fi
    echo "> choosing '$WANT' for this machine (${FREE_MB:-?} MB free, ${RAM_MB:-?} MB RAM)"
fi

case "$WANT" in
    tiny|base|small|medium) NAME="ggml-$WANT.bin" ;;
    *) echo "Unknown size '$WANT'. Use tiny, base, small or medium."; exit 1 ;;
esac

mkdir -p "$MODELS" 2>/dev/null || {
    echo "Cannot write to $MODELS. Run this with sudo, or as the osprime user."
    exit 1; }

DEST="$MODELS/$NAME"
if [ -s "$DEST" ]; then
    echo "> already have $NAME"
else
    echo "> downloading $NAME (this is a few hundred megabytes)"
    curl -fL --retry 3 --continue-at - -o "$DEST.part" "$BASE/$NAME" || {
        echo "Download failed — nothing was changed."; rm -f "$DEST.part"; exit 1; }
    mv "$DEST.part" "$DEST"
fi

# Prove it. A one-second silent wav is enough to make whisper load the
# model and exit; if the file is truncated or corrupt this is where we find
# out, not the first time somebody speaks into it.
echo "> checking the model actually loads"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
if command -v ffmpeg >/dev/null 2>&1; then
    ffmpeg -f lavfi -i anullsrc=r=16000:cl=mono -t 1 -c:a pcm_s16le \
           "$TMP/silence.wav" >/dev/null 2>&1
fi
if [ -s "$TMP/silence.wav" ]; then
    if "$BIN" -m "$DEST" -f "$TMP/silence.wav" -nt >"$TMP/log" 2>&1; then
        echo "> speech-to-text is ready"
    else
        echo "The model downloaded but whisper could not load it:"
        tail -5 "$TMP/log" | sed 's/^/    /'
        echo "The file was left in place so you can inspect it: $DEST"
        exit 1
    fi
else
    # Not a failure: ffmpeg is how the web UI converts recordings anyway,
    # so if it is missing that is the thing to say, and the model is fine.
    echo "> model in place. ffmpeg is missing, so recordings cannot be"
    echo "  converted yet: sudo pacman -Syu --needed ffmpeg"
fi

echo
echo "Restart the assistant to pick it up:"
echo "  sudo systemctl restart osprime-agent osprime-web"
