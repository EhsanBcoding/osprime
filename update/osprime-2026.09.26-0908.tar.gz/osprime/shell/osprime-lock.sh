#!/usr/bin/env bash
# Lock the screen now — from the menu, or Super+L. docs/ACCOUNTS.md.
#
# Only where people have their own accounts: the single osprime account of
# a machine without a login has no password anyone uses, and a lock there
# would be a prompt nobody can answer.
if [ -e /etc/osprime/accounts ] && [ "$(id -un)" != osprime ] && command -v gtklock >/dev/null; then
    exec gtklock -d
fi
command -v notify-send >/dev/null && \
    notify-send "OSprime" "This computer has no login yet, so there is nothing to lock it with. Settings → set up a login."
exit 0
