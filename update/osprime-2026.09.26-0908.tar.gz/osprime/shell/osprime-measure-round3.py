#!/usr/bin/env python3
"""docs/MODELS.md, step 6, round 3: one newer model, or a coder beside the old?

Three candidates, each measured alone on the graphics card, under the same
conditions:

  * Qwen2.5 7B          — today's main model; the baseline
  * Qwen3.5-9B + eyes   — could replace the main model AND the vision swap
  * Qwen2.5-Coder 7B    — the coder specialist the plan started from

For each: does this llama.cpp load it at all, card memory at 16k context,
tokens per second, ten tool calls through the same code path the assistant
uses (agent/local.py), three Persian questions from the 24 September log,
one photo where the model has eyes, and five small programs, each checked
by running its own tests. The decision rule in docs/MODELS.md is applied
at the end, as written there before any number existed.

What it changes, and asks about first:
  * DOWNLOADS the two new models (~11 GB) into /var/lib/osprime/models.
    They stay there, so whichever wins is not downloaded twice. Delete them
    by hand if neither does.
  * STOPS the main engine for the whole measurement — each candidate needs
    the card to itself — and ALWAYS starts it again, in a `finally`.

Model-written test programs run in a temporary folder, with a time limit,
no network where the system allows it (unshare), and never as root.
The result goes to ~/osprime-model-round3.txt.
"""

import base64
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "agent"))

MODELS = pathlib.Path(os.environ.get("OSPRIME_MODELS", "/var/lib/osprime/models"))
MAIN = os.environ.get("OSPRIME_MAIN_URL", "http://127.0.0.1:8087")
PORT = int(os.environ.get("OSPRIME_MEASURE_PORT", "8094"))
URL = f"http://127.0.0.1:{PORT}"
BIN = shutil.which("llama-server") or shutil.which("llama-cpp-server")
LOAD_LIMIT = 300
HF = "https://huggingface.co"

# (key, label, files [(local name, url, MB)], projector local name or None, extra flags)
CANDIDATES = [
    ("main", "Qwen2.5 7B (today)",
     [("qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf", None, 0)], None, []),
    ("q35", "Qwen3.5-9B + eyes",
     [("Qwen3.5-9B-Q4_K_M.gguf",
       f"{HF}/unsloth/Qwen3.5-9B-GGUF/resolve/main/Qwen3.5-9B-Q4_K_M.gguf", 5417),
      ("qwen3.5-9b.mmproj-F16.gguf",
       f"{HF}/unsloth/Qwen3.5-9B-GGUF/resolve/main/mmproj-F16.gguf", 876)],
     "qwen3.5-9b.mmproj-F16.gguf",
     # Thinking is off by default on the small Qwen3.5 models; said anyway,
     # so a template change upstream cannot turn it on unnoticed.
     ["--chat-template-kwargs", '{"enable_thinking":false}']),
    ("coder", "Qwen2.5-Coder 7B",
     [("qwen2.5-coder-7b-instruct-q4_k_m.gguf",
       f"{HF}/Qwen/Qwen2.5-Coder-7B-Instruct-GGUF/resolve/main/"
       "qwen2.5-coder-7b-instruct-q4_k_m.gguf", 4466)], None, []),
]

# ---- tool calls: ten requests, the tool each should reach ------------------
TOOLS = [
    {"name": "get_time", "description": "The current date and time on this computer.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "system_info", "description": "This computer's processor, memory, disk and graphics.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "weather", "description": "Current weather for a city.",
     "input_schema": {"type": "object", "properties": {"city": {"type": "string"}},
                      "required": ["city"]}},
    {"name": "write_file", "description": "Create or overwrite a text file.",
     "input_schema": {"type": "object", "properties": {
         "path": {"type": "string"}, "content": {"type": "string"}},
         "required": ["path", "content"]}},
    {"name": "open_app", "description": "Open an installed application by name.",
     "input_schema": {"type": "object", "properties": {"name": {"type": "string"}},
                      "required": ["name"]}},
    {"name": "random_number", "description": "A random whole number between min and max.",
     "input_schema": {"type": "object", "properties": {
         "min": {"type": "integer"}, "max": {"type": "integer"}}}},
]
TOOL_ASKS = [
    ("What time is it?", "get_time"),
    ("ساعت چنده؟", "get_time"),
    ("How much memory does this computer have?", "system_info"),
    ("سلام میشه اطلاعات سیستم رو بهم بگی", "system_info"),
    ("What's the weather in Tehran right now?", "weather"),
    ("هوا امروز در لوس انجلس چطوره ؟", "weather"),
    ("Make a file notes.txt on the desktop that says buy milk", "write_file"),
    ("یه فایل متنی بساز به اسم خرید و بنویس نان", "write_file"),
    ("Open the calculator", "open_app"),
    ("یک عدد تصادفی بین ۱ تا ۱۰۰ بده", "random_number"),
]

PERSIAN = [
    "کرنل سیستم عامل چیه؟ خیلی کوتاه توضیح بده.",
    "برای رفتن به سر کار دوچرخه بهتره یا پیاده روی؟ یک جمله.",
    "یک پیام کوتاه و مودبانه بنویس که جلسه‌ی فردا را یک ساعت عقب بیندازیم.",
]

# ---- five programs, each with tests that decide pass or fail ---------------
TASKS = [
    ("is_palindrome",
     "Write a Python function is_palindrome(s) that returns True if s reads "
     "the same forwards and backwards, ignoring case, spaces and punctuation.",
     "assert is_palindrome('A man, a plan, a canal: Panama')\n"
     "assert not is_palindrome('hello')\nassert is_palindrome('')\n"
     "assert is_palindrome('No lemon, no melon')\n"),
    ("parse_duration",
     "Write a Python function parse_duration(s) that turns strings like "
     "'1h30m', '45s', '2h5s' or '10m15s' into a total number of seconds (int). "
     "Raise ValueError for anything else, including an empty string.",
     "assert parse_duration('1h30m') == 5400\nassert parse_duration('45s') == 45\n"
     "assert parse_duration('2h5s') == 7205\nassert parse_duration('10m15s') == 615\n"
     "for bad in ('', 'abc', '5x', 'h'):\n"
     "    try:\n        parse_duration(bad)\n    except ValueError:\n        pass\n"
     "    else:\n        raise AssertionError(bad)\n"),
    ("merge_intervals",
     "Write a Python function merge_intervals(intervals) that takes a list of "
     "[start, end] pairs in any order and returns the overlapping ones merged, "
     "sorted by start. Touching intervals like [1,2] and [2,3] merge.",
     "assert merge_intervals([[1,3],[2,6],[8,10],[15,18]]) == [[1,6],[8,10],[15,18]]\n"
     "assert merge_intervals([[5,6],[1,2],[2,3]]) == [[1,3],[5,6]]\n"
     "assert merge_intervals([]) == []\nassert merge_intervals([[1,10],[2,3]]) == [[1,10]]\n"),
    ("roman_to_int",
     "Write a Python function roman_to_int(s) that converts a Roman numeral "
     "string (I, V, X, L, C, D, M, with subtractive forms like IV and CM) to an int.",
     "assert roman_to_int('III') == 3\nassert roman_to_int('LVIII') == 58\n"
     "assert roman_to_int('MCMXCIV') == 1994\nassert roman_to_int('IX') == 9\n"),
    ("top_words",
     "Write a Python function top_words(text, n) that returns the n most "
     "common words in text as a list of (word, count) tuples, most common "
     "first. Words are lowercased and split on anything that is not a letter "
     "or digit. Ties are broken alphabetically.",
     "assert top_words('b a b c a b', 2) == [('b', 3), ('a', 2)]\n"
     "assert top_words('Hello, hello! World.', 1) == [('hello', 2)]\n"
     "assert top_words('x y z', 2) == [('x', 1), ('y', 1)]\n"
     "assert top_words('', 3) == []\n"),
]

out_lines = []


def say(line=""):
    print(line, flush=True)
    out_lines.append(line)


def http(url, body=None, timeout=10):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, json.loads(r.read() or b"{}")


def ask(question):
    """A yes from a person at a terminal. The test suite answers for itself."""
    preset = os.environ.get("OSPRIME_MEASURE_YES", "").lower()
    if preset in ("y", "yes"):
        return True
    if not sys.stdin.isatty():
        say("   no one to ask (not run from a terminal) — stopping here.")
        return False
    try:
        return input(f"   {question} [y/N] ").strip().lower() in ("y", "yes")
    except EOFError:
        return False


def nvidia_used_gb():
    if not shutil.which("nvidia-smi"):
        return None
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=memory.used",
                              "--format=csv,noheader,nounits"],
                             capture_output=True, text=True, timeout=10).stdout
        return int(out.strip().splitlines()[0]) / 1024
    except Exception:
        return None


def help_text():
    try:
        h = subprocess.run([BIN, "--help"], capture_output=True, text=True, timeout=20)
        return h.stdout + h.stderr
    except Exception:
        return ""


def engine_version():
    try:
        r = subprocess.run([BIN, "--version"], capture_output=True, text=True, timeout=20)
        text = (r.stdout + r.stderr).strip().splitlines()
        return next((l for l in text if "version" in l.lower()), text[0] if text else "?")
    except Exception:
        return "?"


def cuda_device():
    try:
        r = subprocess.run([BIN, "--list-devices"], capture_output=True, text=True, timeout=60)
        for line in (r.stdout + r.stderr).splitlines():
            m = re.match(r"\s*(CUDA\d+)\s*:", line)
            if m:
                return m.group(1)
    except Exception:
        pass
    return None


def main_up(timeout=0):
    t0 = time.time()
    while True:
        try:
            if http(f"{MAIN}/health", timeout=2)[0] == 200:
                return True
        except Exception:
            pass
        if time.time() - t0 >= timeout:
            return False
        time.sleep(1)


# ---------------------------------------------------------------------------
# downloads
# ---------------------------------------------------------------------------
def missing_downloads():
    need = []
    for _, label, files, _, _ in CANDIDATES:
        for name, url, mb in files:
            if url and not (MODELS / name).is_file():
                need.append((label, name, url, mb))
    return need


def download(name, url):
    dest = MODELS / name
    part = dest.with_name(dest.name + ".part")
    say(f"   downloading {name} …")
    r = subprocess.run(["curl", "-fL", "--retry", "3", "--continue-at", "-",
                        "-o", str(part), url])
    if r.returncode != 0 or not part.is_file():
        say(f"   download failed: {name}")
        return False
    part.rename(dest)
    return True


# ---------------------------------------------------------------------------
# one engine
# ---------------------------------------------------------------------------
def start(model, proj, flags, ctx):
    log = pathlib.Path(tempfile.gettempdir()) / f"osprime-round3-{PORT}.log"
    cmd = [BIN, "-m", str(model), "--host", "127.0.0.1", "--port", str(PORT),
           "--ctx-size", str(ctx)] + (["--mmproj", str(proj)] if proj else []) + flags
    t0 = time.time()
    proc = subprocess.Popen(cmd, stdout=open(log, "w"), stderr=subprocess.STDOUT)
    while time.time() - t0 < LOAD_LIMIT:
        if proc.poll() is not None:
            text = log.read_text(errors="replace")
            why = "exited while loading"
            if re.search(r"unknown (model )?architecture|unsupported model", text, re.I):
                why = "this llama.cpp is too old for this model's architecture"
            elif re.search(r"out of memory|failed to allocate|OOM", text, re.I):
                why = "does not fit on the card"
            return proc, None, why
        try:
            if http(f"{URL}/health", timeout=2)[0] == 200:
                return proc, time.time() - t0, ""
        except Exception:
            pass
        time.sleep(1)
    return proc, None, f"did not finish loading in {LOAD_LIMIT}s"


def stop(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(20)
        except subprocess.TimeoutExpired:
            proc.kill()
    time.sleep(2)


def chat(messages, max_tokens=400, timeout=180):
    t0 = time.time()
    _, r = http(f"{URL}/v1/chat/completions",
                {"model": "local", "messages": messages, "temperature": 0,
                 "max_tokens": max_tokens}, timeout=timeout)
    return r["choices"][0]["message"].get("content") or "", time.time() - t0, r


def speed():
    try:
        _, r = http(f"{URL}/completion", {"prompt": "Write a short paragraph about the sea.",
                                          "n_predict": 128, "cache_prompt": False},
                    timeout=180)
        return r.get("timings", {}).get("predicted_per_second")
    except Exception:
        return None


def tool_calls():
    """Through agent/local.py — the route the assistant itself takes."""
    os.environ["OSPRIME_LOCAL_URL"] = f"{URL}/v1"
    import local
    local._ENDPOINT_CACHE["url"] = None
    local.ENDPOINTS[0] = f"{URL}/v1"
    hits, detail = 0, []
    for q, want in TOOL_ASKS:
        try:
            _, calls = local.chat([{"role": "user", "content": q}],
                                  "You are OSprime, the assistant on this computer. "
                                  "Use a tool when one fits.", TOOLS)
            got = [c.get("name") for c in calls]
        except Exception as e:
            got = [f"error: {type(e).__name__}"]
        ok = want in got
        hits += ok
        detail.append(f"{'ok ' if ok else 'NO '} {q[:40]:40} → {', '.join(got) or 'no call'}")
    return hits, detail


def photo_question():
    home = pathlib.Path(os.path.expanduser("~"))
    for folder in (home / "Pictures" / "Camera", home / "Pictures"):
        pics = sorted([p for p in folder.glob("*")
                       if p.suffix.lower() in (".jpg", ".jpeg", ".png")],
                      key=lambda p: p.stat().st_mtime, reverse=True)
        if pics:
            return pics[0]
    return None


def look(photo):
    import local
    data, mime = local._shrunk(photo, 1280)
    b64 = base64.b64encode(data).decode()
    try:
        text, took, _ = chat([
            {"role": "system", "content": local.VISION_SYSTEM},
            {"role": "user", "content": [
                {"type": "text", "text": "What colour is the clothing of the person in this photo?"},
                {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}}]}],
            max_tokens=400)
        return text.strip(), took
    except Exception as e:
        return f"error: {type(e).__name__}", None


# ---------------------------------------------------------------------------
# programs: judged by their own tests
# ---------------------------------------------------------------------------
def extract_code(text):
    blocks = re.findall(r"```(?:python|py)?\s*\n(.*?)```", text, re.S)
    if blocks:
        return max(blocks, key=len)
    return text


def _isolation():
    """No network for model-written code, where the system allows it."""
    if shutil.which("unshare"):
        try:
            if subprocess.run(["unshare", "-rn", "true"], capture_output=True,
                              timeout=5).returncode == 0:
                return ["unshare", "-rn"]
        except Exception:
            pass
    return []


def run_tests(code, tests, isolate):
    if os.geteuid() == 0:
        return False, "refused: never runs model-written code as root"
    with tempfile.TemporaryDirectory(prefix="osprime-round3-") as d:
        f = pathlib.Path(d) / "t.py"
        f.write_text(code + "\n\n" + tests + "\nprint('PASSED')\n", encoding="utf-8")
        try:
            r = subprocess.run(isolate + [sys.executable, "-I", str(f)], cwd=d,
                               capture_output=True, text=True, timeout=15,
                               env={"PATH": "/usr/bin:/bin", "HOME": d})
        except subprocess.TimeoutExpired:
            return False, "timed out"
        if "PASSED" in r.stdout:
            return True, ""
        last = (r.stderr.strip().splitlines() or ["no output"])[-1]
        return False, last[:120]


def programs(isolate):
    passed, secs, detail = 0, 0.0, []
    for name, prompt, tests in TASKS:
        try:
            text, took, _ = chat([
                {"role": "system", "content": "You write correct, simple Python. "
                 "Reply with only the code, in one ```python block."},
                {"role": "user", "content": prompt}], max_tokens=1200)
        except Exception as e:
            detail.append(f"NO  {name}: {type(e).__name__}")
            continue
        secs += took
        ok, why = run_tests(extract_code(text), tests, isolate)
        passed += ok
        detail.append(f"{'ok ' if ok else 'NO '} {name} ({took:.0f}s){'' if ok else ' — ' + why}")
    return passed, secs, detail


# ---------------------------------------------------------------------------
def measure(cand, cuda, has_kwargs, isolate, photo):
    key, label, files, proj_name, extra = cand
    model = MODELS / files[0][0]
    proj = MODELS / proj_name if proj_name else None
    r = {"key": key, "label": label}
    if not model.is_file() or (proj and not proj.is_file()):
        r["error"] = "not on disk"
        return r
    flags = ["--n-gpu-layers", "99", "--jinja"] + (["--device", cuda] if cuda else [])
    if extra and extra[0] == "--chat-template-kwargs" and not has_kwargs:
        extra = []
    say(f"\n{label}")
    for ctx in (16384, 8192):
        proc, load, why = start(model, proj, flags + extra, ctx)
        if not why:
            break
        stop(proc)
        say(f"   {ctx} context: {why}")
        if "too old" in why:
            r["error"] = why
            return r
    if why:
        r["error"] = why
        return r
    r.update(ctx=ctx, load=load)
    try:
        r["vram"] = nvidia_used_gb()
        r["tps"] = speed()
        say(f"   loaded in {load:.0f}s at {ctx} context"
            + (f", card {r['vram']:.1f} GB" if r["vram"] else "")
            + (f", {r['tps']:.1f} tokens/s" if r["tps"] else ""))
        r["tools"], r["tool_detail"] = tool_calls()
        say(f"   tool calls: {r['tools']}/10")
        r["persian"] = []
        for q in PERSIAN:
            try:
                text, _, _ = chat([{"role": "user", "content": q}], max_tokens=200)
            except Exception as e:
                text = f"error: {type(e).__name__}"
            r["persian"].append((q, text.strip()))
        if proj and photo:
            r["photo"], r["photo_s"] = look(photo)
            say(f"   photo: {r['photo_s'] and round(r['photo_s'], 1)}s")
        r["passed"], r["code_s"], r["code_detail"] = programs(isolate)
        say(f"   programs: {r['passed']}/5 passed")
    finally:
        stop(proc)
    return r


def verdict(rows):
    by = {r["key"]: r for r in rows}
    q, coder, main = by.get("q35", {}), by.get("coder", {}), by.get("main", {})
    say("\nTHE RULE (docs/MODELS.md, written before these numbers)")
    checks = [
        ("loads on this llama.cpp", "error" not in q),
        ("fits WITH its eyes at 16k context", q.get("ctx") == 16384),
        ("tool calls ≥ 9/10", (q.get("tools") or 0) >= 9),
        ("≥ 30 tokens/s", (q.get("tps") or 0) >= 30),
        ("programs ≥ the coder's",
         (q.get("passed") or 0) >= (coder.get("passed") or 0)),
    ]
    for what, ok in checks:
        say(f"   {'yes' if ok else 'NO '}  Qwen3.5-9B {what}")
    if all(ok for _, ok in checks):
        say("   → Qwen3.5-9B becomes the main model, with its own eyes. "
            "No vision swap, no coder specialist.")
    elif (coder.get("passed") or 0) > (main.get("passed") or 0):
        say("   → Main model stays. Qwen2.5-Coder 7B is added as a specialist "
            "(it passed more programs than the main model).")
    else:
        say("   → Main model stays, and no coder specialist: it did not pass "
            "more programs than the main model does on its own.")


def main():
    say(f"OSprime model measurement, round 3 — {time.strftime('%Y-%m-%d %H:%M')}")
    say("docs/MODELS.md, step 6.")
    if not BIN:
        say("No llama-server on this machine.")
        return
    say(f"llama.cpp: {engine_version()}")
    cuda = cuda_device()
    say(f"graphics card for llama.cpp: {cuda or 'none found — measuring anyway, it will be slow'}")

    need = missing_downloads()
    if need:
        total = sum(mb for *_, mb in need)
        # The override exists for the test suite, whose sandbox is small.
        free = float(os.environ.get("OSPRIME_MEASURE_FREE_MB") or
                     shutil.disk_usage(MODELS).free / 1024 / 1024)
        say(f"\nTo download: {', '.join(n for _, n, _, _ in need)}")
        say(f"   about {total / 1024:.1f} GB; {free / 1024:.0f} GB free on disk. "
            "On a metered connection, that costs money.")
        if free < total + 2048:
            say("   not enough free disk space — stopping.")
            return
        if not os.access(MODELS, os.W_OK):
            say(f"   {MODELS} is not writable by this user — install the latest "
                "update (it makes it the assistant's own folder) and run this again.")
            return
        if not ask("Download them now?"):
            say("   nothing downloaded.")
            return
        for _, name, url, _ in need:
            if not download(name, url):
                return

    say("\nEach model needs the graphics card to itself, so the chat stops "
        "for the whole measurement — about 10-20 minutes.")
    if not ask("Stop the main engine now and measure?"):
        say("   nothing was stopped.")
        return
    photo = photo_question()
    isolate = _isolation()
    say("Model-written programs run " + ("without network (unshare)." if isolate
        else "WITH network available — unshare is not permitted here."))
    has_kwargs = "--chat-template-kwargs" in help_text()
    rows = []
    if subprocess.run(["sudo", "systemctl", "stop", "osprime-model"]).returncode != 0:
        say("   could not stop the main engine — stopping here.")
        return
    try:
        time.sleep(3)
        for cand in CANDIDATES:
            rows.append(measure(cand, cuda, has_kwargs, isolate, photo))
    finally:
        # Whatever happened above, the chat comes back.
        subprocess.run(["sudo", "systemctl", "restart", "osprime-model"])
        back = main_up(timeout=240)
        say("\nmain engine " + ("is running again." if back else
            "did NOT come back within 4 minutes — run: sudo systemctl restart osprime-model"))

    say("\nRESULTS")
    say(f"{'model':22} {'context':>7} {'card':>6} {'tok/s':>6} {'tools':>6} "
        f"{'programs':>9} {'photo':>6}")
    for r in rows:
        if "error" in r:
            say(f"{r['label']:22} {r['error']}")
            continue
        say(f"{r['label']:22} {r['ctx']:>7} "
            f"{(str(round(r['vram'], 1)) + 'G') if r.get('vram') else '-':>6} "
            f"{(str(round(r['tps'], 1))) if r.get('tps') else '-':>6} "
            f"{str(r['tools']) + '/10':>6} {str(r['passed']) + '/5':>9} "
            f"{(str(round(r['photo_s'], 1)) + 's') if r.get('photo_s') else '-':>6}")
    verdict(rows)
    for r in rows:
        if "error" in r:
            continue
        say(f"\n--- {r['label']}")
        say("tool calls:")
        for line in r["tool_detail"]:
            say("   " + line)
        say("programs:")
        for line in r["code_detail"]:
            say("   " + line)
        if r.get("photo"):
            say(f"photo: {r['photo'][:200]}")
        say("Persian (for Ehsan to judge):")
        for q, a in r["persian"]:
            say(f"   Q: {q}")
            say(f"   A: {a[:400]}")


if __name__ == "__main__":
    try:
        main()
    finally:
        dest = pathlib.Path(os.path.expanduser("~")) / "osprime-model-round3.txt"
        dest.write_text("\n".join(out_lines) + "\n", encoding="utf-8")
        print(f"\nSaved to {dest}")
