#!/usr/bin/env bash
# Switching a machine to logins — shared by osprime-migrate-accounts.sh (a
# machine that had the single osprime account) and the installer (a new
# machine). docs/ACCOUNTS.md. Sourced, not run.
#
#   osprime_enable_login NAME HOME [KEEP]
#
# KEEP is where the migration keeps what it replaced, for --revert; the
# installer passes nothing, as there is nothing to go back to.
#
# One copy on purpose: this project has twice had two copies of the same
# setup drift apart (service units, labwc config).

R="${OSPRIME_MIGRATE_ROOT:-${R:-}}"
FLAG="${FLAG:-$R/etc/osprime/accounts}"
AUTOLOGIN="${AUTOLOGIN:-$R/etc/systemd/system/getty@tty1.service.d/autologin.conf}"
GREETD="${GREETD:-$R/etc/greetd}"

# Commands that change the real system go through these, so the tests can
# replace them.
sysctl_()  { [ -n "${OSPRIME_MIGRATE_TEST:-}" ] && { echo "systemctl $*" >> "$R/log"; return 0; }; systemctl "$@"; }
usermod_() { [ -n "${OSPRIME_MIGRATE_TEST:-}" ] && { echo "usermod $*" >> "$R/log"; return 0; }; usermod "$@"; }

osprime_enable_login() {
    local name="$1" home_="$2" keep="${3:-}" default_
    mkdir -p "$GREETD"
    [ -n "$keep" ] && [ -f "$GREETD/config.toml" ] && cp -f "$GREETD/config.toml" "$keep/greetd-config.toml"
    printf '%s\n' \
        "# Written by osprime-accounts-lib.sh (docs/ACCOUNTS.md)." \
        "[terminal]" "vt = 1" "" "[default_session]" \
        "# ReGreet, the graphical login screen, in the cage kiosk compositor." \
        'command = "cage -s -- regreet"' 'user = "greeter"' > "$GREETD/config.toml"
    # ReGreet keeps its state and log here and runs as the greeter user.
    if getent passwd greeter >/dev/null; then
        install -d -o greeter -g greeter "$R/var/lib/regreet" "$R/var/log/regreet" 2>/dev/null || true
    fi
    # labwc also installs its own plain session; if it is picked by mistake,
    # the person still gets OSprime's configuration.
    mkdir -p "$home_/.config"
    [ -d "$home_/.config/labwc" ] || cp -a "$R/opt/osprime/shell/labwc" "$home_/.config/labwc" 2>/dev/null
    chown -R "$name:$name" "$home_/.config" 2>/dev/null || true
    if [ -n "$keep" ]; then [ -f "$AUTOLOGIN" ] && mv -f "$AUTOLOGIN" "$keep/autologin.conf"; else rm -f "$AUTOLOGIN"; fi
    printf '%s\n%s\n' "$name" "$(date -Iseconds)" > "$FLAG"
    chmod 644 "$FLAG"
    sysctl_ disable getty@tty1.service
    sysctl_ enable greetd.service
    # greetd is a display manager, and display managers start with
    # graphical.target. OSprime booted to multi-user.target — the desktop came
    # from the tty1 autologin — so on the laptop, 25 September, greetd was
    # enabled and never started: a black screen on tty1. The old default is
    # kept for --revert.
    default_="$(sysctl_ get-default 2>/dev/null)"
    [ -n "$keep" ] && [ -n "$default_" ] && echo "$default_" > "$keep/default.target"
    sysctl_ set-default graphical.target
    # Nobody logs in as the service account any more; --revert unlocks it.
    usermod_ -L osprime
    # …and is not offered on the login screen: ReGreet lists accounts that
    # have a login shell. 25 September: it was listed, asked for a password,
    # and no password could ever work. --revert gives it bash back.
    usermod_ -s /usr/bin/nologin osprime
}
