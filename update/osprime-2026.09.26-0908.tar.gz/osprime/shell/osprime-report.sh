#!/usr/bin/env bash
# What the assistant was offered and what it used, turn by turn.
#
#   bash /opt/osprime/shell/osprime-report.sh        the last 60 turns
#   bash /opt/osprime/shell/osprime-report.sh 200    the last 200
#
# Reads /var/lib/osprime/tool-groups.log (see docs/TOOL_BUDGET.md) and opens
# the result in the text editor rather than printing it. Two reasons, both
# found the first time anyone read this log: a terminal does not join Persian
# letters or write them right to left, so every Persian request came out as a
# row of punctuation; and text in the terminal could not be copied to send to
# anyone. The editor does both. With no screen to open it on, it prints.
#
# The marks:
#   !!  the model used a tool this turn's group did not offer — the grouping
#       guessed wrong (the tool still ran)
#   --  no tool used. Right for a greeting or a question; wrong if the
#       request plainly needed one
set -u
N="${1:-60}"
LOG=/var/lib/osprime/tool-groups.log
OUT="${HOME:-/tmp}/osprime-tool-report.txt"

[ -r "$LOG" ] || { echo "No log yet at $LOG (or it cannot be read)."; exit 1; }

python3 - "$LOG" "$N" > "$OUT" <<'PY'
import json, sys
path, n = sys.argv[1], int(sys.argv[2])
rows = []
for line in open(path, encoding="utf-8"):
    try:
        rows.append(json.loads(line))
    except ValueError:
        pass
miss = sum(1 for r in rows if r.get("not_offered"))
none = sum(1 for r in rows if not r.get("called"))
print(f"{len(rows)} turns in the log — tool outside its group: {miss} — "
      f"no tool used: {none}")
print(f"Showing the last {min(n, len(rows))}.\n")
for r in rows[-n:]:
    flag = "!!" if r.get("not_offered") else ("--" if not r.get("called") else "  ")
    print(f'{flag} {r.get("at", "")[5:16]}  asked: {r.get("q", "")}')
    print(f'      groups: {", ".join(r.get("groups", []))}')
    print(f'      used:   {", ".join(r.get("called", [])) or "nothing"}'
          + (f'   (not offered: {", ".join(r["not_offered"])})'
             if r.get("not_offered") else ""))
    print()
PY

if [ -n "${WAYLAND_DISPLAY:-}" ] && command -v mousepad >/dev/null; then
    mousepad "$OUT" >/dev/null 2>&1 &
    echo "Opened in the text editor: $OUT"
else
    cat "$OUT"
fi
