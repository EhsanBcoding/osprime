#!/usr/bin/env bash
# The Python libraries people ask the assistant for first. docs/PYTHON.md.
#
#   sudo bash /opt/osprime/shell/osprime-python-setup.sh
#
# New installs get these from the ISO. A machine installed before that runs
# this once — by a person, with a password: pacman is deliberately not in
# the assistant's sudo rules, and an update never runs it.
#
# `pacman -S --needed`, never with -y: refreshing the package list without
# upgrading everything is how an Arch system ends up half-upgraded. If the
# list is too old to find a file, this says so and stops.
set -u
PKGS="python-matplotlib python-numpy python-pillow python-pandas python-requests python-openpyxl"

if [ "$(id -u)" -ne 0 ] && [ -z "${OSPRIME_PYSETUP_TEST:-}" ]; then
    echo "This installs system packages — run it with sudo."
    exit 1
fi

# Every name checked against the repositories first, not trusted from here.
FOUND=""; MISSING=""
for p in $PKGS; do
    if pacman -Si "$p" >/dev/null 2>&1; then FOUND="$FOUND $p"; else MISSING="$MISSING $p"; fi
done
[ -n "$MISSING" ] && echo "Not in the repositories, skipped:$MISSING"
[ -n "$FOUND" ] || { echo "Nothing to install."; exit 1; }

echo "> installing:$FOUND"
# shellcheck disable=SC2086
if ! pacman -S --needed $FOUND; then
    echo
    echo "pacman could not install them. If it said a file was not found,"
    echo "the package list is out of date. Update the whole system first,"
    echo "then run this again:"
    echo "    sudo pacman -Syu"
    exit 1
fi
echo
echo "Done. The assistant sees them from its next conversation."
