#!/usr/bin/env python3
"""The OSprime desktop: icons on the background, and the right-click menu.

Wayland has no desktop. A compositor manages windows and does nothing else,
so "the desktop" — the surface that holds your files and answers a
right-click — is a program somebody has to write. We tried the obvious
candidate first: pcmanfm-qt --desktop painted the background black, showed
no icons, and swallowed the right-click menu we already had. So this is ours.

It is a layer-shell surface pinned to the BOTTOM layer, which puts it above
the wallpaper (swaybg owns BACKGROUND) and below every real window. On it:

  - the contents of ~/Desktop, as icons you double-click to open
  - the menu that appears when you right-click the background

Design rules, learned from the failures that came before this file:

  * Nothing here may take the session down. Every optional feature is
    wrapped, and if this program dies the user loses icons, not their
    computer — labwc keeps running and its own menu comes back.
  * The background is drawn by swaybg, not by us. We are transparent. That
    keeps the wallpaper setting in Settings working exactly as it did,
    instead of Settings appearing to do nothing because our window was on
    top of the colour it just changed.
  * Deleting means the trash, never rm.
"""

import json
import os
import pathlib
import shlex
import subprocess
import sys
import time

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("GtkLayerShell", "0.1")
from gi.repository import Gtk, Gdk, GdkPixbuf, Gio, GLib, GtkLayerShell  # noqa: E402

HOME = pathlib.Path.home()
DESKTOP_DIR = HOME / "Desktop"
STATE = HOME / ".config" / "osprime" / "desktop.json"
SHELL = pathlib.Path(__file__).resolve().parent

ICON_SIZES = [("Small icons", 32), ("Medium icons", 48),
              ("Large icons", 64), ("Extra large icons", 96)]
SORTS = [("Name", "name"), ("Date modified", "date"),
         ("Type", "type"), ("Size", "size")]

CSS = b"""
#desktop { background-color: transparent; }
#desktop iconview {
    background-color: transparent;
    color: #ffffff;
    padding: 14px;
    /* The wallpaper can be beige as easily as petrol blue, and white text
       on beige is unreadable. The shadow is what keeps a filename legible
       on any background without knowing which one is set. */
    text-shadow: 0 1px 3px rgba(0,0,0,0.9);
}
#desktop iconview:selected,
#desktop iconview .cell:selected {
    background-color: rgba(56,139,253,0.55);
    border-radius: 6px;
}
"""


# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------

def log(msg):
    try:
        with open("/tmp/osprime-desktop.log", "a") as f:
            f.write(f"{time.strftime('%H:%M:%S')} {msg}\n")
    except Exception:
        pass


def spawn(argv):
    """Launch and forget. Never let a failed launch reach the user as a
    traceback — the desktop must survive anything it starts."""
    try:
        subprocess.Popen(argv, start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        log(f"spawn {argv}: {e}")


def sh(script):
    spawn(["bash", "-c", script])


def load_state():
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_state(state):
    try:
        STATE.parent.mkdir(parents=True, exist_ok=True)
        STATE.write_text(json.dumps(state, indent=2), encoding="utf-8")
    except Exception as e:
        log(f"save_state: {e}")


# --------------------------------------------------------------------------

class Desktop:
    def __init__(self):
        self.state = load_state()
        self.icon_size = int(self.state.get("icon_size", 64))
        self.sort = self.state.get("sort", "name")
        self.show_icons = bool(self.state.get("show_icons", True))
        self.paths = []          # row index -> pathlib.Path
        self._reload_id = 0

        try:
            DESKTOP_DIR.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            log(f"mkdir Desktop: {e}")

        self._build_window()
        self._watch()
        self.reload()

    # -- window ------------------------------------------------------------

    def _build_window(self):
        win = Gtk.Window()
        win.set_name("desktop")

        # Layer shell has to be initialised before the window is realised,
        # or the surface is created as an ordinary toplevel and ends up in
        # the middle of the screen with a titlebar.
        GtkLayerShell.init_for_window(win)
        GtkLayerShell.set_layer(win, GtkLayerShell.Layer.BOTTOM)
        for edge in (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.BOTTOM,
                     GtkLayerShell.Edge.LEFT, GtkLayerShell.Edge.RIGHT):
            GtkLayerShell.set_anchor(win, edge, True)
        # -1 means "ignore other panels' exclusive zones": we want the full
        # screen and the panel drawn over us, not a rectangle shrunk by it.
        GtkLayerShell.set_exclusive_zone(win, -1)
        # ON_DEMAND rather than NONE: without keyboard focus the popup menu
        # cannot be driven from the keyboard. Older gtk-layer-shell has only
        # the boolean, and losing keyboard navigation is not worth failing to
        # start over.
        try:
            GtkLayerShell.set_keyboard_mode(
                win, GtkLayerShell.KeyboardMode.ON_DEMAND)
        except Exception:
            try:
                GtkLayerShell.set_keyboard_interactivity(win, False)
            except Exception as e:
                log(f"keyboard mode: {e}")
        GtkLayerShell.set_namespace(win, "osprime-desktop")

        # Transparent, so swaybg's colour shows through and Settings keeps
        # owning the wallpaper. If the visual is unavailable we would render
        # black over the wallpaper, which is worse than no desktop at all —
        # so fall back to painting the saved colour ourselves.
        screen = win.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            win.set_visual(visual)
            win.set_app_paintable(True)
        else:
            log("no RGBA visual; painting the wallpaper colour instead")
            self._paint_fallback_colour()

        store = Gtk.ListStore(GdkPixbuf.Pixbuf, str)
        view = Gtk.IconView.new_with_model(store)
        view.set_pixbuf_column(0)
        view.set_text_column(1)
        view.set_selection_mode(Gtk.SelectionMode.MULTIPLE)
        view.set_activate_on_single_click(False)
        view.set_column_spacing(6)
        view.set_row_spacing(6)
        view.connect("item-activated", self.on_activate)
        view.connect("button-press-event", self.on_button)

        # The IconView only covers the rows it has. Right-clicking far below
        # the last icon has to still open the menu, so the event box behind
        # it catches what the view does not.
        box = Gtk.EventBox()
        box.add(view)
        box.connect("button-press-event", self.on_background_button)

        win.add(box)
        win.connect("destroy", Gtk.main_quit)

        provider = Gtk.CssProvider()
        provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(
            screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        self.win, self.view, self.store = win, view, store
        win.show_all()

    def _paint_fallback_colour(self):
        colour = "#12232E"
        try:
            sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "agent"))
            import paths
            colour = paths.read_desktop_env().get("OSPRIME_WALLPAPER", colour).strip('"') or colour
        except Exception:
            pass
        css = Gtk.CssProvider()
        css.load_from_data(f"#desktop {{ background-color: {colour}; }}".encode())
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), css,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    # -- contents ----------------------------------------------------------

    def _watch(self):
        """Adding a file in Files should make it appear here, without the
        user learning that Refresh exists."""
        try:
            mon = Gio.File.new_for_path(str(DESKTOP_DIR)).monitor_directory(
                Gio.FileMonitorFlags.WATCH_MOVES, None)
            mon.connect("changed", lambda *a: self.schedule_reload())
            self._monitor = mon          # keep a reference or it is collected
        except Exception as e:
            log(f"monitor: {e}")

    def schedule_reload(self):
        """Copying twenty files fires twenty events. Coalesce them."""
        if self._reload_id:
            GLib.source_remove(self._reload_id)
        self._reload_id = GLib.timeout_add(400, self._reload_now)

    def _reload_now(self):
        self._reload_id = 0
        self.reload()
        return False

    def _entries(self):
        try:
            items = [p for p in DESKTOP_DIR.iterdir() if not p.name.startswith(".")]
        except Exception as e:
            log(f"read Desktop: {e}")
            return []

        def key(p):
            try:
                st = p.stat()
            except Exception:
                return (0, p.name.lower())
            if self.sort == "date":
                return (not p.is_dir(), -st.st_mtime)
            if self.sort == "size":
                return (not p.is_dir(), -st.st_size)
            if self.sort == "type":
                return (not p.is_dir(), p.suffix.lower(), p.name.lower())
            return (not p.is_dir(), p.name.lower())

        return sorted(items, key=key)

    def _icon_for(self, path):
        size = self.icon_size
        # A picture of the picture is worth more than a generic image icon,
        # and this is the one place a person immediately notices the
        # difference. Guarded by size: a 40MB scan must not stall the
        # desktop while it loads.
        try:
            if path.is_file() and path.stat().st_size < 20 * 1024 * 1024:
                if path.suffix.lower() in (".png", ".jpg", ".jpeg", ".gif",
                                           ".bmp", ".webp"):
                    return GdkPixbuf.Pixbuf.new_from_file_at_size(
                        str(path), size, size)
        except Exception:
            pass

        theme = Gtk.IconTheme.get_default()
        try:
            info = Gio.File.new_for_path(str(path)).query_info(
                "standard::icon", Gio.FileQueryInfoFlags.NONE, None)
            gicon = info.get_icon()
            found = theme.lookup_by_gicon(gicon, size,
                                          Gtk.IconLookupFlags.FORCE_SIZE)
            if found:
                return found.load_icon()
        except Exception:
            pass
        for name in ("text-x-generic", "application-x-executable", "folder"):
            try:
                return theme.load_icon(name, size, Gtk.IconLookupFlags.FORCE_SIZE)
            except Exception:
                continue
        return None

    def _label_for(self, path):
        if path.suffix == ".desktop":
            try:
                app = Gio.DesktopAppInfo.new_from_filename(str(path))
                if app:
                    return app.get_display_name()
            except Exception:
                pass
        return path.name

    def reload(self):
        self.store.clear()
        self.paths = []
        if not self.show_icons:
            return
        for path in self._entries():
            pixbuf = self._icon_for(path)
            self.store.append([pixbuf, self._label_for(path)])
            self.paths.append(path)
        # Room for the icon plus a filename that wraps to two lines.
        self.view.set_item_width(self.icon_size + 42)

    # -- opening -----------------------------------------------------------

    def open_path(self, path):
        if path.suffix == ".desktop":
            try:
                app = Gio.DesktopAppInfo.new_from_filename(str(path))
                if app:
                    app.launch([], None)
                    return
            except Exception as e:
                log(f"desktop file {path}: {e}")
        if path.is_dir():
            spawn(["thunar", str(path)])
            return
        # gio first, xdg-open second. Neither is guaranteed on a minimal
        # system, and a double-click that does nothing is the single most
        # frustrating thing a desktop can do.
        sh(f"gio open {shlex.quote(str(path))} "
           f"|| xdg-open {shlex.quote(str(path))} "
           f"|| thunar {shlex.quote(str(path.parent))}")

    def on_activate(self, view, tree_path):
        i = tree_path.get_indices()[0]
        if 0 <= i < len(self.paths):
            self.open_path(self.paths[i])

    def selected_paths(self):
        out = []
        for tp in self.view.get_selected_items():
            i = tp.get_indices()[0]
            if 0 <= i < len(self.paths):
                out.append(self.paths[i])
        return out

    # -- input -------------------------------------------------------------

    def on_button(self, view, event):
        if event.button != 3:
            return False
        tp = view.get_path_at_pos(int(event.x), int(event.y))
        if tp is None:
            self.view.unselect_all()
            self.background_menu(event)
        else:
            if tp not in view.get_selected_items():
                view.unselect_all()
                view.select_path(tp)
            self.item_menu(event)
        return True

    def on_background_button(self, box, event):
        if event.button == 3:
            self.view.unselect_all()
            self.background_menu(event)
            return True
        if event.button == 1:
            self.view.unselect_all()
        return False

    # -- menus -------------------------------------------------------------

    @staticmethod
    def _item(menu, label, handler=None, submenu=None):
        it = Gtk.MenuItem(label=label)
        if submenu is not None:
            it.set_submenu(submenu)
        elif handler is not None:
            it.connect("activate", lambda *_: handler())
        else:
            it.set_sensitive(False)
        menu.append(it)
        return it

    @staticmethod
    def _sep(menu):
        menu.append(Gtk.SeparatorMenuItem())

    def _popup(self, menu, event):
        menu.show_all()
        menu.popup_at_pointer(event)

    def background_menu(self, event):
        m = Gtk.Menu()

        view = Gtk.Menu()
        first = None
        for label, size in ICON_SIZES:
            it = (Gtk.RadioMenuItem.new_with_label_from_widget(first, label)
                  if first else Gtk.RadioMenuItem.new_with_label([], label))
            first = first or it
            it.set_active(size == self.icon_size)
            it.connect("toggled", self._set_icon_size, size)
            view.append(it)
        view.append(Gtk.SeparatorMenuItem())
        show = Gtk.CheckMenuItem(label="Show desktop icons")
        show.set_active(self.show_icons)
        show.connect("toggled", self._toggle_icons)
        view.append(show)
        self._item(m, "View", submenu=view)

        srt = Gtk.Menu()
        first = None
        for label, key in SORTS:
            it = (Gtk.RadioMenuItem.new_with_label_from_widget(first, label)
                  if first else Gtk.RadioMenuItem.new_with_label([], label))
            first = first or it
            it.set_active(key == self.sort)
            it.connect("toggled", self._set_sort, key)
            srt.append(it)
        self._item(m, "Sort by", submenu=srt)

        self._item(m, "Refresh", self.reload)
        self._sep(m)

        new = Gtk.Menu()
        self._item(new, "Folder", self.new_folder)
        self._item(new, "Text document", self.new_text_file)
        self._item(m, "New", submenu=new)
        self._sep(m)

        self._item(m, "Display settings",
                   lambda: sh(f"bash {SHELL}/osprime-settings.sh display"))
        self._item(m, "Personalize",
                   lambda: sh(f"bash {SHELL}/osprime-settings.sh appearance"))
        self._sep(m)
        self._item(m, "Open chat", lambda: sh(f"bash {SHELL}/osprime-toggle.sh"))
        self._item(m, "Open terminal", lambda: spawn(["foot"]))
        self._sep(m)

        more = Gtk.Menu()
        self._item(more, "Apps", lambda: sh(f"bash {SHELL}/osprime-apps.sh"))
        self._item(more, "Files", lambda: spawn(["thunar", str(HOME)]))
        self._item(more, "All settings",
                   lambda: sh(f"bash {SHELL}/osprime-settings.sh"))
        self._item(more, "Take a screenshot",
                   lambda: sh(f"bash {SHELL}/osprime-screenshot.sh area"))
        more.append(Gtk.SeparatorMenuItem())
        self._item(more, "Open Desktop folder",
                   lambda: spawn(["thunar", str(DESKTOP_DIR)]))
        self._item(m, "More options", submenu=more)

        self._popup(m, event)

    def item_menu(self, event):
        paths = self.selected_paths()
        if not paths:
            return
        m = Gtk.Menu()
        one = paths[0] if len(paths) == 1 else None

        self._item(m, "Open", lambda: [self.open_path(p) for p in paths])
        if one and one.is_dir():
            self._item(m, "Open in terminal",
                       lambda: spawn(["foot", "-D", str(one)]))
        self._sep(m)
        if one:
            self._item(m, "Rename", lambda: self.rename(one))
            self._item(m, "Copy path", lambda: self.copy_path(one))
        self._item(m, f"Move to trash ({len(paths)})" if len(paths) > 1
                   else "Move to trash", lambda: self.trash(paths))
        if one:
            self._sep(m)
            self._item(m, "Properties", lambda: self.properties(one))
        self._popup(m, event)

    # -- view preferences --------------------------------------------------

    def _set_icon_size(self, item, size):
        if item.get_active() and size != self.icon_size:
            self.icon_size = size
            self.state["icon_size"] = size
            save_state(self.state)
            self.reload()

    def _set_sort(self, item, key):
        if item.get_active() and key != self.sort:
            self.sort = key
            self.state["sort"] = key
            save_state(self.state)
            self.reload()

    def _toggle_icons(self, item):
        self.show_icons = item.get_active()
        self.state["show_icons"] = self.show_icons
        save_state(self.state)
        self.reload()

    # -- file operations ---------------------------------------------------

    def _ask(self, title, prompt, initial=""):
        """A plain dialog. It is a real toplevel, not part of the layer
        surface, so it gets keyboard focus the ordinary way."""
        d = Gtk.Dialog(title=title, modal=True)
        d.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                      "OK", Gtk.ResponseType.OK)
        d.set_default_response(Gtk.ResponseType.OK)
        entry = Gtk.Entry()
        entry.set_text(initial)
        entry.set_activates_default(True)
        box = d.get_content_area()
        box.set_spacing(8)
        box.set_border_width(14)
        box.add(Gtk.Label(label=prompt, xalign=0))
        box.add(entry)
        d.show_all()
        answer = entry.get_text().strip() if d.run() == Gtk.ResponseType.OK else ""
        d.destroy()
        return answer

    def _tell(self, message):
        d = Gtk.MessageDialog(modal=True, message_type=Gtk.MessageType.INFO,
                              buttons=Gtk.ButtonsType.OK, text=message)
        d.run()
        d.destroy()

    def _unique(self, name):
        dest = DESKTOP_DIR / name
        if not dest.exists():
            return dest
        stem, suffix, n = dest.stem, dest.suffix, 2
        while dest.exists():
            dest = DESKTOP_DIR / f"{stem} ({n}){suffix}"
            n += 1
        return dest

    def new_folder(self):
        name = self._ask("New folder", "Name for the new folder:", "New folder")
        if not name:
            return
        try:
            self._unique(name).mkdir()
        except Exception as e:
            self._tell(f"Could not create the folder: {e}")
        self.reload()

    def new_text_file(self):
        name = self._ask("New text document", "Name for the new file:",
                         "New document.txt")
        if not name:
            return
        try:
            self._unique(name).touch()
        except Exception as e:
            self._tell(f"Could not create the file: {e}")
        self.reload()

    def rename(self, path):
        name = self._ask("Rename", f"New name for “{path.name}”:", path.name)
        if not name or name == path.name:
            return
        try:
            path.rename(path.with_name(name))
        except Exception as e:
            self._tell(f"Could not rename it: {e}")
        self.reload()

    def trash(self, paths):
        """The trash, not rm. A desktop that deletes permanently on a
        right-click is a desktop that loses somebody's work."""
        failed = []
        for p in paths:
            try:
                Gio.File.new_for_path(str(p)).trash(None)
            except Exception as e:
                log(f"trash {p}: {e}")
                failed.append(p.name)
        if failed:
            self._tell("Could not move to trash: " + ", ".join(failed))
        self.reload()

    def copy_path(self, path):
        clip = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        clip.set_text(str(path), -1)
        clip.store()

    def properties(self, path):
        try:
            st = path.stat()
            size = st.st_size
            for unit in ("B", "KB", "MB", "GB"):
                if size < 1024 or unit == "GB":
                    human = f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
                    break
                size /= 1024
            kind = "Folder" if path.is_dir() else (path.suffix[1:].upper() + " file"
                                                  if path.suffix else "File")
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime))
            self._tell(f"{path.name}\n\n{kind}\n{human}\nModified {when}\n\n{path}")
        except Exception as e:
            self._tell(f"Could not read it: {e}")


def main():
    if not os.environ.get("WAYLAND_DISPLAY"):
        log("no WAYLAND_DISPLAY — not starting")
        return 1
    try:
        Desktop()
        Gtk.main()
    except Exception:
        # The whole traceback, not the message. Every bug in this project so
        # far was silent first and obvious second, and the gap between the
        # two was always a missing log line.
        import traceback
        log("fatal:\n" + traceback.format_exc())
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
