#!/usr/bin/env python3
"""docs/MODELS.md, step 0: where should a vision model live on this machine?

Round one (24 September) found: the Intel GPU is invisible to this llama.cpp
build, the vision 7B does not fit on the NVIDIA card beside a main engine,
and on the CPU it took 151 seconds to describe one photo. Round two tests
the three things that could change that:

  1. SMALLER IMAGES. The photo was sent full size. Qwen2.5-VL spends about
     one token per 28x28 pixels, so 1920x1080 is ~2,600 tokens and 768 px is
     ~420. Every layout is tested with both, and the token count the engine
     reports is printed, so the saving is shown rather than assumed.
  2. HYBRID. The vision model's "eye" (the projector, ~1.3 GB) on the NVIDIA
     card and its language part on the CPU — which only fits once the main
     engine is the text 7B, because that frees the ~1.3 GB the vision main
     model's own projector was holding.
  3. SWAP. Only one model on the NVIDIA card at a time: stop the main engine,
     load vision, describe, stop it, bring the main engine back. This is the
     one test that interrupts the chat, so it asks first, and the main engine
     is ALWAYS started again — in a `finally`, whatever happens in between.

Nothing is written, installed or downloaded. The result goes to
~/osprime-model-measure.txt.
"""

import base64
import json
import mimetypes
import os
import pathlib
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request

MODELS = pathlib.Path(os.environ.get("OSPRIME_MODELS", "/var/lib/osprime/models"))
MAIN = os.environ.get("OSPRIME_MAIN_URL", "http://127.0.0.1:8087")
MODEL_ENV = pathlib.Path(os.environ.get("OSPRIME_MODEL_ENV", "/etc/osprime/model.env"))
PORT = int(os.environ.get("OSPRIME_MEASURE_PORT", "8093"))
BIN = shutil.which("llama-server") or shutil.which("llama-cpp-server")
LOAD_LIMIT = 300
DESCRIBE_LIMIT = 300
SMALL_SIDE = 768

VISION = [  # (label, model file, projector names to try, in order)
    ("Qwen2.5-VL 3B", "Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf",
     ["vision-medium.mmproj-F16.gguf", "mmproj-F16.gguf"]),
    ("Qwen2.5-VL 7B", "Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf",
     ["vision-large.mmproj-F16.gguf", "mmproj-F16.gguf"]),
]
TEXT_7B = "qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf"

out_lines = []


def say(line=""):
    print(line, flush=True)
    out_lines.append(line)


def http(url, body=None, timeout=10):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, json.loads(r.read() or b"{}")


def ram_free_gb():
    for line in open("/proc/meminfo"):
        if line.startswith("MemAvailable:"):
            return int(line.split()[1]) / 1024 / 1024
    return 0.0


def nvidia_used_gb():
    if not shutil.which("nvidia-smi"):
        return None
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=memory.used",
                              "--format=csv,noheader,nounits"],
                             capture_output=True, text=True, timeout=10).stdout
        return int(out.strip().splitlines()[0]) / 1024
    except Exception:
        return None


def help_has(flag):
    try:
        h = subprocess.run([BIN, "--help"], capture_output=True, text=True,
                           timeout=20)
        return flag in (h.stdout + h.stderr)
    except Exception:
        return False


def devices():
    """What llama.cpp itself can see. Its answer, not ours."""
    if not help_has("--list-devices"):
        return None
    r = subprocess.run([BIN, "--list-devices"], capture_output=True, text=True,
                       timeout=60)
    found = []
    for line in (r.stdout + r.stderr).splitlines():
        m = re.match(r"\s*([A-Za-z]+\d+)\s*:\s*(.+)", line)
        if m and not m.group(1).lower().startswith("available"):
            found.append((m.group(1), m.group(2).strip()))
    return found


def main_tier():
    try:
        for line in MODEL_ENV.read_text().splitlines():
            if line.startswith("OSPRIME_MODEL_TIER="):
                return line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    return "unknown"


def main_speed():
    """Tokens per second from the main engine, as it reports them."""
    try:
        _, r = http(f"{MAIN}/completion",
                    {"prompt": "Write two sentences about the sea.",
                     "n_predict": 48, "cache_prompt": False}, timeout=120)
        return r.get("timings", {}).get("predicted_per_second")
    except Exception:
        return None


def main_up(timeout=0):
    t0 = time.time()
    while True:
        try:
            if http(f"{MAIN}/health", timeout=2)[0] == 200:
                return True
        except Exception:
            pass
        if time.time() - t0 >= timeout:
            return False
        time.sleep(1)


def test_images():
    """The newest photo, and a copy no larger than SMALL_SIDE on its long side."""
    home = pathlib.Path(os.path.expanduser("~"))
    photo = None
    for folder in (home / "Pictures" / "Camera", home / "Pictures"):
        pics = sorted([p for p in folder.glob("*")
                       if p.suffix.lower() in (".jpg", ".jpeg", ".png")],
                      key=lambda p: p.stat().st_mtime, reverse=True)
        if pics:
            photo = pics[0]
            break
    tool = shutil.which("magick") or shutil.which("convert")
    if photo is None and tool:
        photo = pathlib.Path("/tmp/osprime-measure.png")
        subprocess.run([tool, "-size", "1920x1080", "xc:skyblue", "-fill", "red",
                        "-draw", "circle 960,540 960,300", str(photo)],
                       capture_output=True)
    if photo is None or not photo.exists():
        return []
    images = [("full", photo)]
    if tool:
        small = pathlib.Path(f"/tmp/osprime-measure-{SMALL_SIDE}.jpg")
        # "768x768>" only ever shrinks: a photo already smaller is left alone.
        subprocess.run([tool, str(photo), "-resize",
                        f"{SMALL_SIDE}x{SMALL_SIDE}>", "-quality", "90",
                        str(small)], capture_output=True)
        if small.exists():
            images.append((f"{SMALL_SIDE}px", small))
    return images


def start(model, proj, flags, ctx=4096):
    log = pathlib.Path(f"/tmp/osprime-measure-{PORT}.log")
    cmd = [BIN, "-m", str(model), "--host", "127.0.0.1", "--port", str(PORT),
           "--ctx-size", str(ctx)] + (["--mmproj", str(proj)] if proj else []) + flags
    t0 = time.time()
    proc = subprocess.Popen(cmd, stdout=open(log, "w"), stderr=subprocess.STDOUT)
    while time.time() - t0 < LOAD_LIMIT:
        if proc.poll() is not None:
            text = log.read_text(errors="replace")
            why = "exited while loading"
            if re.search(r"mismatch|n_embd", text):
                why = "the projector file does not belong to this model"
            elif re.search(r"out of memory|failed to allocate|OOM", text, re.I):
                why = "does not fit in memory"
            return proc, None, why, log
        try:
            if http(f"http://127.0.0.1:{PORT}/health", timeout=2)[0] == 200:
                return proc, time.time() - t0, "", log
        except Exception:
            pass
        time.sleep(1)
    return proc, None, f"did not finish loading in {LOAD_LIMIT}s", log


def stop(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(20)
        except subprocess.TimeoutExpired:
            proc.kill()
    time.sleep(2)


def describe(image, watch_main=True):
    mime = mimetypes.guess_type(str(image))[0] or "image/jpeg"
    b64 = base64.b64encode(image.read_bytes()).decode()
    body = {"model": "local", "temperature": 0, "max_tokens": 96,
            "messages": [{"role": "user", "content": [
                {"type": "text", "text": "Describe this photo in two sentences."},
                {"type": "image_url",
                 "image_url": {"url": f"data:{mime};base64,{b64}"}}]}]}
    main_during = {}
    th = threading.Thread(target=lambda: main_during.update(v=main_speed()))
    t1 = time.time()
    if watch_main:
        th.start()
    try:
        _, r = http(f"http://127.0.0.1:{PORT}/v1/chat/completions", body,
                    timeout=DESCRIBE_LIMIT)
        answer = r["choices"][0]["message"]["content"].strip()
        tokens = r.get("timings", {}).get("prompt_n")
        err = ""
    except Exception as e:
        answer, tokens, err = "", None, f"could not describe ({type(e).__name__})"
    took = time.time() - t1
    if watch_main:
        th.join(120)
    return {"describe": None if err else took, "tokens": tokens,
            "answer": answer, "error": err, "main": main_during.get("v")}


def projector_device(log):
    """Where the engine put the vision projector, from its own log line."""
    try:
        text = log.read_text(errors="replace")
    except OSError:
        return "?"
    for line in text.splitlines():
        low = line.lower()
        if "clip" in low or "mtmd" in low:
            if "cuda" in low:
                return "NVIDIA"
            if "vulkan" in low:
                return "Vulkan"
    return "CPU?"


def measure_place(label, model, proj, place, flags, images, rows):
    size_gb = (model.stat().st_size + proj.stat().st_size) / 1024 ** 3
    if place not in ("NVIDIA", "swap") and ram_free_gb() < size_gb + 1.5:
        rows.append((label, place, "-", {"error": f"skipped — needs "
                     f"{size_gb + 1.5:.1f} GB free RAM, {ram_free_gb():.1f} free"}))
        return
    say(f"testing {label} — {place} …")
    proc, load, why, log = start(model, proj, flags)
    try:
        if why:
            rows.append((label, place, "-", {"error": why}))
            say("   " + why)
            return
        ram, nv = ram_free_gb(), nvidia_used_gb()
        eye = projector_device(log) if place == "hybrid" else ""
        for size, image in images:
            r = describe(image, watch_main=(place != "swap"))
            r.update(load=load, ram=ram, nv=nv, eye=eye)
            rows.append((label, place, size, r))
            say(f"   {size}: " + (r["error"] or
                f"load {load:.0f}s, describe {r['describe']:.0f}s, "
                f"image = {r['tokens'] or '?'} tokens"))
    finally:
        stop(proc)


def swap_round(label, model, proj, cuda, images, rows):
    """Layout C. Stops the main engine; always brings it back."""
    say()
    say("SWAP TEST — this stops the chat for a minute or two.")
    # OSPRIME_MEASURE_SWAP=yes answers for the person — only the test suite
    # sets it. Anyone else is asked, at a terminal, every time.
    ok = os.environ.get("OSPRIME_MEASURE_SWAP", "").lower()
    if ok not in ("y", "yes"):
        if not sys.stdin.isatty():
            say("   skipped: not run from a terminal, so there is no one to ask.")
            return None
        try:
            ok = input("   Stop the main engine now and measure? [y/N] ").strip().lower()
        except EOFError:
            ok = ""
    if ok not in ("y", "yes"):
        say("   skipped at your request.")
        return None
    text7b = MODELS / TEXT_7B
    result = {}
    stopped = subprocess.run(["sudo", "systemctl", "stop", "osprime-model"]).returncode == 0
    if not stopped:
        say("   could not stop the main engine — skipped.")
        return None
    try:
        time.sleep(3)
        measure_place(label, model, proj, "swap",
                      ["--n-gpu-layers", "99", "--device", cuda], images, rows)
        if text7b.is_file():
            say("   timing the way back: loading the text 7B onto NVIDIA …")
            proc, load, why, _ = start(text7b, None,
                                       ["--n-gpu-layers", "99", "--device", cuda],
                                       ctx=16384)
            stop(proc)
            result["main_back"] = None if why else load
            say("   " + (why or f"main 7B back on the card in {load:.0f}s"))
    finally:
        # Whatever happened above, the chat comes back. restart, not start:
        # it is the one allowed without a password, and it also clears a
        # half-started state.
        subprocess.run(["sudo", "systemctl", "restart", "osprime-model"])
        back = main_up(timeout=180)
        say("   main engine " + ("is running again." if back else
            "did NOT come back within 3 minutes — run: "
            "sudo systemctl restart osprime-model"))
    return result


def main():
    say(f"OSprime model measurement, round 2 — {time.strftime('%Y-%m-%d %H:%M')}")
    say("docs/MODELS.md, step 0. Nothing on this machine was changed.")
    say()
    if not BIN:
        say("No llama-server on this machine. Nothing to measure.")
        return
    images = test_images()
    if not images:
        say("No photo to test with, and ImageMagick could not make one.")
        return
    say(f"Test photo: {images[0][1]}"
        + ("" if len(images) > 1 else "  (no ImageMagick — full size only)"))
    tier = main_tier()
    say(f"Main engine model: {tier}")
    if tier.startswith("vision"):
        say("  NOTE: the main engine is still the vision model. The hybrid and "
            "swap numbers only mean what they should once it is the text 7B: "
            "sudo bash /opt/osprime/shell/osprime-profile.sh large")
    base = main_speed()
    say(f"Main engine now: {f'{base:.1f} tokens/s' if base else 'not answering'}"
        f" | RAM free {ram_free_gb():.1f} GB"
        + (f" | NVIDIA in use {nvidia_used_gb():.1f} GB" if nvidia_used_gb() is not None else ""))
    say()

    devs = devices()
    places, cuda = [], None
    if devs is None:
        say("This llama.cpp build cannot list its devices; testing the CPU only.")
    else:
        say("Devices llama.cpp can see: "
            + (", ".join(f"{d} ({n})" for d, n in devs) or "none besides the CPU"))
        cuda = next((d for d, n in devs if d.upper().startswith("CUDA")), None)
        if cuda:
            # Everything on the card beside the main engine — expected not to
            # fit a 7B, measured anyway because "expected" is not a number.
            places.append(("NVIDIA", ["--n-gpu-layers", "99", "--device", cuda]))
            # The eye on the card, the language on the CPU: no layers
            # offloaded, but the device is allowed, so the projector goes
            # there. Confirmed from the engine's own log, not assumed.
            places.append(("hybrid", ["--n-gpu-layers", "0", "--device", cuda]))
        intel = [(d, n) for d, n in devs if "intel" in n.lower()]
        for d, n in intel[:1]:
            places.append(("Intel GPU", ["--n-gpu-layers", "99", "--device", d]))
        if not intel:
            say("  No Intel GPU in that list — this build has no Vulkan backend.")
    cpu = ["--n-gpu-layers", "0"] + (["--device", "none"] if devs is not None else [])
    places.append(("CPU", cpu))
    say()

    rows, swap = [], None
    for label, fname, projs in VISION:
        model = MODELS / fname
        if not model.is_file():
            say(f"{label}: not on disk — skipped")
            continue
        proj = next((MODELS / p for p in projs if (MODELS / p).is_file()), None)
        if not proj:
            say(f"{label}: no projector file on disk — skipped")
            continue
        for place, flags in places:
            measure_place(label, model, proj, place, flags, images, rows)
        if cuda and swap is None:
            swap = swap_round(label, model, proj, cuda, images, rows) or {}

    say()
    say("RESULTS")
    say(f"{'model':14} {'where':9} {'image':6} {'tokens':>6} {'load':>5} "
        f"{'describe':>8} {'RAM left':>8} {'NVIDIA':>6} {'main t/s':>8}  eye")
    for label, place, size, r in rows:
        if r.get("describe") is None:
            say(f"{label:14} {place:9} {size:6} {r.get('error', '')}")
            continue
        nv = f"{r['nv']:.1f}G" if r.get("nv") is not None else "-"
        mn = f"{r['main']:.1f}" if r.get("main") else "-"
        say(f"{label:14} {place:9} {size:6} {str(r.get('tokens') or '?'):>6} "
            f"{r['load']:4.0f}s {r['describe']:7.0f}s {r['ram']:7.1f}G {nv:>6} "
            f"{mn:>8}  {r.get('eye', '')}")
    say(f"(main engine alone: {f'{base:.1f}' if base else '-'} tokens/s)")
    if swap and swap.get("main_back") is not None:
        say(f"(swap: bringing the main 7B back onto the card took "
            f"{swap['main_back']:.0f}s — add it to every swap row's total, "
            f"with the vision load time)")
    say()
    say("What each one said about the photo:")
    for label, place, size, r in rows:
        if r.get("answer"):
            say(f"  {label}, {place}, {size}: {r['answer'][:150]}")
    say()
    say("The rule agreed in docs/MODELS.md: the fastest layout where describing "
        "a photo takes under about 20 seconds in total, the main engine does "
        "not slow down, and at least 4 GB of RAM stays free.")


if __name__ == "__main__":
    try:
        main()
    finally:
        dest = pathlib.Path(os.path.expanduser("~")) / "osprime-model-measure.txt"
        dest.write_text("\n".join(out_lines) + "\n", encoding="utf-8")
        print(f"\nSaved to {dest}")
