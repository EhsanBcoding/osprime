---json
{
  "name": "find-files",
  "title": "Look at files on this computer",
  "type": "system",
  "teachable": true,
  "triggers": [
    "what files are", "can you see the files", "show me my files",
    "look in my folder", "what is on my desktop", "find a file",
    "list the files", "where is my file", "open my usb", "what is on the usb",
    "check my downloads", "look at my documents"
  ],
  "tools": ["list_files", "read_file", "list_drives", "mount_drive", "open_app"],
  "packages": [],
  "sources": []
}
---

## Do it

You CAN read this machine's files. `list_files` and `read_file` work. Refusing
is wrong — if a path fails, the path was wrong, not the ability.

1. Use the home path given in THIS MACHINE above. Never build a path from the
   user's name: the account is not called after them.
2. Paths are case-sensitive. `Desktop`, `Documents`, `Downloads` and
   `Pictures` all begin with a capital letter.
3. If a folder is not found, call `list_files` on the home directory and look
   at what is actually there instead of guessing a second time.
4. For a USB stick or memory card, call `list_drives` first. It reports where
   each device is reachable, or that it is not yet open. If it has no
   location, call `mount_drive` with the device name and then list that path.
5. Report what you found. If a folder is empty, say it is empty — that is an
   answer, not a failure.

## Teach it

1. Open **Apps → Files**.
2. The sidebar shows the home folder and, under **Devices**, anything
   plugged in. A USB stick appears there once connected.
3. Clicking a device opens it; there is no need to know a device name.
4. The path bar at the top shows exactly where you are, which is the same
   text used when asking about a folder here.

## Check

Report only what a tool actually returned. If `list_files` returned an error,
say the folder could not be found and what you tried — do not describe files
that were never listed.

## Common mistakes

- Building a path from the person's name instead of the account name.
- Lowercasing a folder name: `desktop` is not `Desktop`.
- Answering "I cannot access your files" when `list_files` is available.
- Guessing at a USB path instead of calling `list_drives`.
- Giving up after one wrong path rather than listing the home folder.
