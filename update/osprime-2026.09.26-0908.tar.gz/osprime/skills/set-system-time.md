---json
{
  "name": "set-system-time",
  "title": "Set the clock",
  "type": "system",
  "teachable": true,
  "triggers": [
    "the clock is wrong", "set the time", "change the date",
    "wrong timezone", "the time is off", "fix the clock",
    "set my timezone", "change the timezone", "set the clock automatically", "sync the clock"],
  "tools": ["set_time", "set_timezone", "set_auto_time", "get_time"],
  "packages": [],
  "sources": []
}
---

## Do it

1. Read the current state with `get_time`.
2. If the machine has a network connection, prefer `set_auto_time(true)` —
   an automatically synchronised clock will not drift again.
3. If the timezone is wrong, `set_timezone` with an IANA name such as
   `Europe/Berlin` or `Asia/Tehran`. Ask the user for their city if it is not
   obvious; do not guess from language.
4. Only if automatic time is unavailable or the user asks for a specific
   value, use `set_time` with `YYYY-MM-DD HH:MM`.

Setting the time manually turns automatic sync off, so a manual value would
otherwise be overwritten on the next connection.

## Teach it

The user can do this themselves in Settings.

1. Open **Apps → Settings**, or click **Settings** in the chat header.
2. Go to the **Date and time** section.
3. **Set automatically** covers almost every case — leave it on unless the
   machine has no network.
4. **Time zone** takes a name like `Europe/Berlin`, not a city on its own.
5. **Set manually** is only needed on a machine that is never online.

## Check

Call `get_time` and confirm the reported time and timezone are what the user
asked for. On a machine with a network, also confirm `automatic_sync` is true —
if it is false the clock will drift again within days and the user will be
back with the same problem.

## Common mistakes

- Guessing a timezone from the interface language. A Persian speaker may well
  be in Berlin. Ask.
- Setting a manual time on a connected machine, which sync then overwrites.
- Offering a city name such as `Tehran` where an IANA zone `Asia/Tehran` is
  required.
