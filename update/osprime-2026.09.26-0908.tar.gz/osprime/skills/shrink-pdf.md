---json
{
  "name": "shrink-pdf",
  "title": "Make a PDF small enough to send",
  "type": "shared",
  "teachable": true,
  "triggers": [
    "pdf is too big", "compress a pdf", "reduce pdf size",
    "shrink this pdf", "email attachment too large", "make this pdf smaller"
  ],
  "tools": ["compress_pdf", "list_files", "list_drives", "open_app"],
  "packages": ["ghostscript"],
  "sources": [
    {"what": "Ghostscript pdfwrite parameters", "licence": "AGPL-3.0",
     "note": "invoked as a program, not linked — no obligation on OSprime"}
  ]
}
---

## Do it

Use `compress_pdf`. Do not write a ghostscript command yourself — quoting,
flags and paths are exactly what goes wrong, and the tool has them right.

1. Find the file's **full path**, beginning with `/`. If the user said "this
   PDF" without naming one, call `list_files` on their Desktop or Downloads
   rather than guessing a filename. For a memory stick, `list_drives` first.
2. Call `compress_pdf` with that full path. Nothing else is needed —
   `ebook` quality is the default and is right almost every time.
3. Report the sizes it gives back, in the plain units it returns.

Only change quality if the first result is not enough: `screen` is smaller
but visibly degrades scans, `printer` keeps more detail for printing.

If the tool says the file is already about as small as it goes, pass that on
rather than trying again with another setting.

## Teach it

The user wants to do this themselves next time.

1. Ask what they are trying to get under — most email limits are 25 MB, many
   upload forms are 10 MB. The target decides the setting.
2. Show them the command once, with their own file in it. A command they have
   seen work on their own file is remembered; a generic example is not.
3. Explain only the part that changes: `-dPDFSETTINGS` is the quality dial,
   and `/ebook` is the setting to reach for first.
4. Point out the output filename is separate on purpose, so a bad result
   never costs them the original.
5. Have them run it on a second file unaided, and check the result.

## Check

The output file exists, is smaller than the input, and still opens. Open it
with `open_app` and ask the user to confirm it is still readable — a PDF that
is small and unreadable has not solved their problem.

Report the before and after sizes. "12 MB → 2.4 MB" is the answer to the
question they actually asked.

## Common mistakes

- Writing a ghostscript command by hand instead of using `compress_pdf`.
- Using a bare filename. Paths must start with `/`; the shell is not sitting
  in the folder the file is in.
- Repeating an identical command after it failed, instead of finding the
  real path first.
- Reaching for `screen` quality first because it is smallest; scanned text
  becomes unreadable.
- Reporting success without checking the file still opens.
