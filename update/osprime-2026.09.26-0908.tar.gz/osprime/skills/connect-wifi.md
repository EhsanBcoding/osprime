---json
{
  "name": "connect-wifi",
  "title": "Get this computer onto Wi-Fi",
  "type": "system",
  "teachable": true,
  "triggers": [
    "connect to wifi", "connect to the internet", "no internet",
    "join a wifi network", "wifi password", "get online", "internet not working",
    "connect me to", "find wifi networks", "why am i offline",
    "forget this network", "turn wifi on", "turn wifi off",
    "forget the wifi", "forget this network", "am i online", "internet is not working"],
  "tools": ["list_wifi", "connect_wifi", "forget_wifi", "wifi_radio",
            "network_status"],
  "packages": ["networkmanager:nmcli"],
  "sources": []
}
---

## Do it

You CAN do this. There are tools for every part of it, and "I cannot connect
you to Wi-Fi" is never the right answer on this machine.

1. Call `network_status` first. If it is already online, say so and stop —
   people ask to connect when something else is broken surprisingly often.
2. Call `list_wifi`. It rescans, so a network that has just appeared will be
   there. If the radio is off, it says so; turn it on with `wifi_radio`
   rather than reporting failure.
3. If the user named a network, match it case-insensitively against what came
   back. If they did not, show the names and signal strengths and ask which.
   Do not pick for them.
4. Call `connect_wifi` with the exact name from the scan — not the name the
   user typed, which may differ in case or spacing.
5. If it is a network this machine has joined before, no password is needed.
   `connect_wifi` handles that; do not ask for a password you do not need.
6. If it fails for a wrong password, say exactly that and offer to try again.
   Never report a connection that did not happen.

## Teach it

1. The network name is called an **SSID**. It is the name that appears on the
   router, or on a card the café gives you.
2. Ask OSprime "what wifi networks are there" — this scans and lists them,
   strongest first. Signal strength matters more than people expect: a weak
   network that connects will still be unusable.
3. Say "connect to <name>" and give the password when asked. It is stored, so
   this only happens once per network.
4. To check it worked, ask "am I online". That tests the connection rather
   than trusting the icon.
5. If a network has changed its password, ask to **forget** it first —
   otherwise the machine keeps trying the old one and it looks like the
   password is wrong when it is the saved one that is wrong.

## Check

Call `network_status` after connecting. It is the only proof. A connection
that was requested is not a connection that happened, and the difference is
invisible from the tool that requested it.

Report the network name it is actually on.

## Common mistakes

- Saying Wi-Fi cannot be managed from here. It can.
- Asking for a password for a network already saved on this machine.
- Using the user's spelling of the network name instead of the scanned one.
- Reporting success without calling `network_status`.
- Forgetting to check whether the radio is switched off — the scan returns
  nothing and it looks like there are no networks in range.
- Suggesting the user edit configuration files. Nobody should ever need to.
