#!/usr/bin/env python3
"""OSprime first-boot onboarding: runs once, interviews the user,
writes the profile the agent uses to personalize itself."""

import json
import os
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "ui"))
import i18n

PROFILE_PATH = pathlib.Path(os.environ.get("OSPRIME_PROFILE", "/etc/osprime/profile.json"))

QUESTIONS = [
    ("name",     "ob_name"),
    ("language", "ob_lang"),
    ("skill",    "ob_skill"),
    ("usage",    "ob_usage"),
    ("autonomy", "ob_autonomy"),
    # Whether the assistant may speak first. Asked once, here, and never
    # again — see docs/COMPANION.md. This is the only moment the user is
    # already in a conversation with the machine, so the question costs no
    # interruption; anywhere else it would be the very thing it is asking
    # permission for.
    ("speak",    "ob_speak"),
]

DEFAULTS = {"language": "en", "autonomy": "yes", "speak": "no"}

ENV_PATH = pathlib.Path(os.environ.get("OSPRIME_DESKTOP_ENV",
                                       "/etc/osprime/desktop.env"))

# Both languages, because the question is asked in both. Anything that is
# not clearly a yes is a no: silence is the safe failure for this setting,
# and a typo must not turn the machine talkative.
_YES = {"y", "yes", "بله", "اره", "آره", "بلی"}


def _save_speak(answer: str):
    """Write the answer where Settings and proactive.py both read it.

    Not into profile.json: that file describes the user, and this is a
    setting about the machine's behaviour. Keeping it in desktop.env means
    the switch in Settings -> Assistant and the answer given here are the
    same value, so they cannot show different things.
    """
    on = "yes" if answer.strip().lower() in _YES else "no"
    try:
        ENV_PATH.parent.mkdir(parents=True, exist_ok=True)
        lines = (ENV_PATH.read_text(encoding="utf-8").splitlines()
                 if ENV_PATH.exists() else [])
        for i, line in enumerate(lines):
            if line.strip().startswith("OSPRIME_PROACTIVE="):
                lines[i] = f"OSPRIME_PROACTIVE={on}"
                break
        else:
            lines.append(f"OSPRIME_PROACTIVE={on}")
        ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except Exception:
        # The default is off, and a failure here leaves it off. Onboarding
        # must not end in a traceback over a setting the user can change in
        # Settings in ten seconds.
        pass



def fix_text(s: str) -> str:
    """Recover Persian text mangled by a non-UTF-8 locale (surrogate escapes)."""
    try:
        return s.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    except Exception:
        return s.encode("utf-8", "replace").decode("utf-8")

def main():
    if PROFILE_PATH.exists():
        print(i18n.t("ob_done"))
        return
    os.system("clear")
    print(i18n.t("ob_hello"))
    print(i18n.t("ob_intro") + "\n")
    profile = {}
    for key, qkey in QUESTIONS:
        ans = fix_text(input("  " + i18n.t(qkey)).strip())
        profile[key] = ans or DEFAULTS.get(key, "")
    _save_speak(profile.pop("speak", "no"))
    PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
    PROFILE_PATH.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n" + i18n.t("ob_thanks").format(name=profile["name"]))


if __name__ == "__main__":
    main()
