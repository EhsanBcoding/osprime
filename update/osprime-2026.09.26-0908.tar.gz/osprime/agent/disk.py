"""Is this computer's disk encrypted, and how does it unlock? docs/ENCRYPTION.md.

Read without root: the root filesystem's source from findmnt, and
/etc/osprime/disk.json, which the installer writes and
osprime-disk-unlock.sh keeps current. The LUKS header itself needs root to
read, and Settings must work without it.
"""
import json
import os
import pathlib
import subprocess

STATE = pathlib.Path(os.environ.get("OSPRIME_DISK_STATE", "/etc/osprime/disk.json"))

WORDS = {
    "tpm": "unlocks with the TPM — only the login password at start",
    "tpm-pin": "unlocks with the TPM and a PIN at start",
    "password": "asks for the disk password at every start",
}


def _root_source() -> str:
    try:
        return subprocess.run(["findmnt", "-no", "SOURCE", "/"], capture_output=True,
                              text=True, timeout=5).stdout.strip()
    except Exception:
        return ""


def status() -> dict:
    src = _root_source()
    try:
        state = json.loads(STATE.read_text(encoding="utf-8"))
    except Exception:
        state = {}
    encrypted = src.startswith("/dev/mapper/") or bool(state.get("encrypted"))
    mode = state.get("unlock", "") if encrypted else ""
    if not encrypted:
        text = "Not encrypted"
        note = ("A stolen disk can be read. Encryption is chosen when OSprime is "
                "installed.")
    else:
        text = "Encrypted — " + WORDS.get(mode, "unlock method unknown")
        note = ("Keep the recovery key from the installation somewhere safe. "
                "To change how it unlocks: sudo bash "
                "/opt/osprime/shell/osprime-disk-unlock.sh tpm|tpm-pin|password")
        if mode == "tpm":
            note = ("Protects the disk if it is taken out; not yet against tampering "
                    "with the startup files (that needs Secure Boot, coming). " + note)
    return {"encrypted": encrypted, "unlock": mode, "text": text, "note": note}
