"""OSprime backend router — local-first.

The rule: the local model handles everything it can, including tools.
The cloud is an optional escalation the user opts into, never a
requirement. With no network, nothing here changes behaviour.

This is a deliberate inversion of the earlier design, which sent every
tool-using request to Claude and left an offline machine with a
toolless chatbot.
"""

import os
import socket

import local

CLAUDE_MODEL = os.environ.get("OSPRIME_CLAUDE_MODEL", "claude-sonnet-5")

# How the cloud may be used:
#   "off"    never (fully local; the default)
#   "ask"    only when the user explicitly asks for it
#   "auto"   automatically when local is unavailable
CLOUD_MODE = os.environ.get("OSPRIME_CLOUD_MODE", "off")

# Explicit user request for the big model, in either language.
_CLOUD_HINTS = ("با کلاد", "مدل ابری", "مدل بزرگ", "از اینترنت بپرس",
                "use claude", "cloud model", "big model", "ask online")

# Neutral connectivity check. Deliberately NOT api.anthropic.com: an
# offline-by-design OS should not phone a vendor to learn it is offline.
PROBE_HOST = os.environ.get("OSPRIME_PROBE_HOST", "1.1.1.1")
PROBE_PORT = int(os.environ.get("OSPRIME_PROBE_PORT", "53"))


def has_internet(timeout: float = 1.5) -> bool:
    try:
        socket.create_connection((PROBE_HOST, PROBE_PORT), timeout=timeout).close()
        return True
    except OSError:
        return False


def local_available() -> bool:
    return local.available()


def cloud_available() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY")) and has_internet()


def wants_cloud(message: str) -> bool:
    low = (message or "").lower()
    return any(h in low for h in _CLOUD_HINTS)


def pick_backend(message: str = "") -> str:
    """Return 'local' or 'claude'. Local wins unless it cannot serve."""
    if local_available():
        if CLOUD_MODE == "ask" and wants_cloud(message) and cloud_available():
            return "claude"
        return "local"

    # The local engine is down. Only "auto" may leave the machine on its own.
    #
    # This used to read `if CLOUD_MODE in ("ask", "auto")`, which made "ask"
    # behave exactly like "auto" the moment the local model stopped — so a
    # user who chose "only when I ask" had their conversation sent to a
    # company they had not asked to involve, at the one moment they were
    # least likely to notice, because the machine was already misbehaving.
    #
    # "Only when I ask" has to mean only when they ask. An engine that is
    # down is our problem to report, not a reason to reinterpret a setting
    # the user chose deliberately.
    if CLOUD_MODE == "auto" and cloud_available():
        return "claude"
    if CLOUD_MODE == "ask" and wants_cloud(message) and cloud_available():
        return "claude"

    if CLOUD_MODE == "ask" and cloud_available():
        raise RuntimeError(
            "The local model engine is not running, so I cannot answer on "
            "this machine. You have the cloud model set to 'only when I "
            "ask' — say so and I will use it for this. Or check the engine "
            "with: systemctl status osprime-model")
    raise RuntimeError(
        "The local model engine is not running. Check it with: "
        "systemctl status osprime-model")
