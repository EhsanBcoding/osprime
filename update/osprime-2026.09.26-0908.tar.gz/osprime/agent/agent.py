#!/usr/bin/env python3
"""osprime-agent: the always-on AI daemon at the heart of OSprime.

Listens on a Unix socket. Each client sends JSON lines:
    {"type": "user_message", "text": "..."}
and receives JSON lines back:
    {"type": "assistant", "text": "..."}
    {"type": "tool_use", "name": "...", "detail": "..."}   (progress info)
    {"type": "confirm", "text": "..."}                     (dangerous command)
    {"type": "error", "text": "..."}

Requires: pip install anthropic   (for the Claude backend)
"""

import datetime
import inspect
import json
import os
import pathlib
import queue
import re
import shutil
import socket
import subprocess
import threading
import time
import traceback
import uuid

import companion
import desktop
import hardware
import jobs
import local
import memory as memory_mod
import permissions
import plugins as plugins_mod
import proactive
import router
import skills as skills_mod
import system_tools
import toolgroups
import updater
import webtools

# Where the person's things are: agent/paths.py (docs/ACCOUNTS.md). On a
# machine still running as the single `osprime` account these are exactly
# the paths that used to be written here.
import paths  # noqa: E402
SOCKET_PATH = paths.socket_path()
PROFILE_PATH = paths.profile()
MEMORY_PATH = paths.memory_json()
MEMORY_DB = paths.memory_db()
MEM = memory_mod.Memory(MEMORY_DB)
if MEM.count() == 0:
    memory_mod.migrate_json(MEM, MEMORY_PATH)
PLUGIN_DIR = pathlib.Path(os.environ.get(
    "OSPRIME_PLUGINS",
    str(pathlib.Path(__file__).resolve().parent.parent / "tools.d")))
MAX_TURNS = 20  # max tool-use rounds per request

DANGEROUS = ("rm -rf /", "mkfs", "dd if=", ":(){", "> /dev/sd", "chmod -R 777 /")

TOOLS = [
    {
        "name": "run_shell",
        "description": "Run a shell command on this machine and return stdout/stderr.",
        "input_schema": {
            "type": "object",
            "properties": {"command": {"type": "string"}},
            "required": ["command"],
        },
    },
    {
        "name": "read_file",
        "description": "Read a text file from the filesystem.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "save_chat",
        "description": "Save this whole conversation, word for word, as a "
                       "text file. Use for 'save this chat', 'export this "
                       "conversation', 'make a file of our chat'. Never write "
                       "the conversation out yourself.",
        "input_schema": {"type": "object", "properties": {
            "name": {"type": "string",
                     "description": "File name the user asked for, if any, e.g. 'test 4'."},
            "folder": {"type": "string",
                       "description": "Desktop, Documents or Downloads, if the "
                                      "user named one. Default Documents."}}},
    },
    {
        "name": "remember",
        "description": "Save one important, durable fact about the user or system to "
                       "long-term memory (preferences, habits, names, recurring tasks). "
                       "Use it whenever the user shares something worth remembering.",
        "input_schema": {
            "type": "object",
            "properties": {"fact": {"type": "string"}},
            "required": ["fact"],
        },
    },
    {
        "name": "write_file",
        "description": "Write text content to a file (creates parent dirs).",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
            "required": ["path", "content"],
        },
    },
    {
        "name": "web_search",
        "description": "Search the web (DuckDuckGo). Returns titles and URLs.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "fetch_url",
        "description": "Fetch a web page and return its readable text content.",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
            "required": ["url"],
        },
    },
    {
        "name": "open_app",
        # "or any installed command" was in this description, and it was
        # true, and it was the hole: see docs/SECURITY.md #4. The model reads
        # this text as a list of what it may do, so it has to say what the
        # tool is for AND what it is not for.
        "description": "Open an installed application on the user's screen: "
                       "browser, files, editor, video, image, terminal, "
                       "calculator, or anything from the Apps menu or the Apps "
                       "page (e.g. gimp). args are only files or web addresses "
                       "to open with it. Not for running commands — that is "
                       "run_shell.",
        "input_schema": {
            "type": "object",
            "properties": {"app": {"type": "string"},
                           "args": {"type": "array", "items": {"type": "string"}}},
            "required": ["app"],
        },
    },
    {
        "name": "open_url",
        "description": "Put a web page on the user's screen in a browser "
                       "window. Use this after web_search to open the result "
                       "you are recommending — do not print a link and ask "
                       "them to click it. url must be one a search actually "
                       "returned.",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
            "required": ["url"],
        },
    },
    {
        "name": "list_windows",
        "description": "List currently open application windows.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "close_app",
        "description": "Close an application window by its app name.",
        "input_schema": {
            "type": "object",
            "properties": {"app": {"type": "string"}},
            "required": ["app"],
        },
    },
    {
        "name": "schedule_task",
        "description": "Schedule a recurring daily task at a given time. Use when the "
                       "user says things like 'every morning', 'each day at 8', etc. "
                       "time is 24h HH:MM. prompt is what OSprime should do then.",
        "input_schema": {
            "type": "object",
            "properties": {"time": {"type": "string"},
                           "prompt": {"type": "string"},
                           "label": {"type": "string"}},
            "required": ["time", "prompt"],
        },
    },
    {
        "name": "run_job",
        "description": "Run a LONG-running shell command in the background and "
                       "return a job id immediately. Use for builds, downloads, "
                       "clones, or anything that takes more than ~30s. The user is "
                       "notified automatically when it finishes.",
        "input_schema": {
            "type": "object",
            "properties": {"command": {"type": "string"},
                           "label": {"type": "string"}},
            "required": ["command"],
        },
    },
    {
        "name": "job_status",
        "description": "Check a background job by id (status, exit code, output).",
        "input_schema": {
            "type": "object",
            "properties": {"id": {"type": "string"}},
            "required": ["id"],
        },
    },
    {
        "name": "list_jobs",
        "description": "List all background jobs and their statuses.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "self_update",
        "description": "Download and install the latest version of OSprime. Use "
                       "this whenever the user asks to update, upgrade, install "
                       "the new version, or says yes to an offered update. You "
                       "CAN do this — it is not something to refuse or delegate. "
                       "The package is verified and a backup is kept, so it is "
                       "safe and reversible.",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
        },
    },
    {
        "name": "update_status",
        "description": "Show the installed OSprime version and available backups.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "rollback_update",
        "description": "Roll OSprime back to a previous version (latest backup by default).",
        "input_schema": {
            "type": "object",
            "properties": {"name": {"type": "string"}},
        },
    },
    {
        "name": "model_status",
        "description": "Which model is answering, whether it is running on "
                       "the processor or the graphics card, this machine's "
                       "CPU/memory/GPU, whether a better model would "
                       "fit, and which model (if any) it uses to see "
                       "pictures. Use for 'what model are you', 'can you see', 'are you using "
                       "the GPU', 'why are you slow', 'what hardware is "
                       "this'.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "system_info",
        "description": "Snapshot of disk, memory, CPU and uptime.",
        "input_schema": {"type": "object", "properties": {}},
    },
    # --- system control -----------------------------------------------
    # Named operations rather than shell strings. A small model can pick a
    # name and fill one field reliably; it cannot recall timedatectl syntax.
    {
        "name": "set_time",
        "description": "Set the system clock. Use when the time or date is wrong. "
                       "datetime must be 'YYYY-MM-DD HH:MM'.",
        "input_schema": {
            "type": "object",
            "properties": {"datetime": {"type": "string"}},
            "required": ["datetime"],
        },
    },
    {
        "name": "get_time",
        "description": "What this computer currently thinks the time, date "
                       "and timezone are, and whether it syncs automatically. "
                       "Call this before changing the clock, and again "
                       "afterwards to confirm the change actually took.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "set_timezone",
        "description": "Set the timezone, e.g. 'Europe/Berlin' or 'Asia/Tehran'.",
        "input_schema": {
            "type": "object",
            "properties": {"zone": {"type": "string"}},
            "required": ["zone"],
        },
    },
    {
        "name": "set_auto_time",
        "description": "Turn automatic clock synchronisation on or off.",
        "input_schema": {
            "type": "object",
            "properties": {"enabled": {"type": "boolean"}},
            "required": ["enabled"],
        },
    },
    {
        "name": "list_wifi",
        "description": "Scan for nearby Wi-Fi networks.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "connect_wifi",
        "description": "Join a Wi-Fi network by name.",
        "input_schema": {
            "type": "object",
            "properties": {"ssid": {"type": "string"},
                           "password": {"type": "string"}},
            "required": ["ssid"],
        },
    },
    {
        "name": "network_status",
        "description": "Report whether this machine is online and how.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "forget_wifi",
        "description": "Forget a saved Wi-Fi network, so its stored password "
                       "is no longer used. Needed when a network's password "
                       "has changed — otherwise the old one keeps being tried "
                       "and it looks like the new one is wrong.",
        "input_schema": {
            "type": "object",
            "properties": {"ssid": {"type": "string"}},
            "required": ["ssid"],
        },
    },
    {
        "name": "wifi_radio",
        "description": "Turn the Wi-Fi radio on or off. If a scan finds no "
                       "networks at all, check this before telling the user "
                       "there are none in range.",
        "input_schema": {
            "type": "object",
            "properties": {"on": {"type": "boolean"}},
            "required": ["on"],
        },
    },
    {
        "name": "set_wallpaper",
        "description": "Set the desktop background. One argument, three "
                       "kinds: a colour (#12232E, petrol, beige, navy, "
                       "grey, black), one of the built-in designs, or the "
                       "path to a picture. Call list_backgrounds first if "
                       "you do not know the design names — never guess one.",
        "input_schema": {
            "type": "object",
            "properties": {"color": {"type": "string"}},
            "required": ["color"],
        },
    },
    {
        "name": "list_backgrounds",
        "description": "The backgrounds that can be chosen: the built-in "
                       "designs, any photographs installed with the system, "
                       "and the user's own pictures.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "set_language",
        "description": "Set the interface language by two-letter code, e.g. en or fa.",
        "input_schema": {
            "type": "object",
            "properties": {"code": {"type": "string"}},
            "required": ["code"],
        },
    },
    {
        "name": "set_volume",
        "description": "Set the output volume, 0 to 100.",
        "input_schema": {
            "type": "object",
            "properties": {"percent": {"type": "integer"}},
            "required": ["percent"],
        },
    },
    {
        "name": "get_settings",
        "description": "Read the current settings — language, background, "
                       "timezone, cloud mode.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "check_update",
        "description": "Check whether a newer version of OSprime is available. "
                       "Does not install anything.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "take_screenshot",
        "description": "Take a picture of the screen and save it. Set area to "
                       "true to let the user drag a selection first. This is "
                       "the only screenshot tool that works here — scrot, "
                       "import and gnome-screenshot are X11 and do not exist.",
        "input_schema": {
            "type": "object",
            "properties": {"area": {"type": "boolean"}},
        },
    },
    {
        "name": "get_display",
        "description": "Report the screen's resolution and scale. Use this "
                       "instead of xrandr or xdpyinfo, which are X11 tools "
                       "and are not present.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "set_display",
        "description": "Change how large everything appears, or the screen "
                       "resolution. Use when the user says things are too "
                       "small or too large. Prefer scale (1.25 or 1.5) over "
                       "lowering the resolution, which only makes it blurry.",
        "input_schema": {
            "type": "object",
            "properties": {"scale": {"type": "string"},
                           "resolution": {"type": "string"}},
        },
    },
    {
        "name": "compress_pdf",
        "description": "Make a PDF file smaller. Use this whenever a PDF is "
                       "too large to email, upload or send. Give the full "
                       "path to the file. Quality is optional: screen, ebook "
                       "(default), printer or prepress. Never build a "
                       "ghostscript command by hand — use this.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"},
                           "quality": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "list_drives",
        "description": "List storage devices, including USB sticks and memory "
                       "cards, and where each one is currently available. Use "
                       "this whenever the user mentions a USB stick, a memory "
                       "card, an external drive, or files that are not on this "
                       "computer.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "mount_drive",
        "description": "Make a storage device's files reachable. Give the "
                       "device name from list_drives, such as /dev/sdb1.",
        "input_schema": {
            "type": "object",
            "properties": {"device": {"type": "string"}},
            "required": ["device"],
        },
    },
    {
        "name": "list_files",
        "description": "Exact contents and count of a folder. folder: a path "
                       "or a word like Desktop, Pictures, Downloads, "
                       "Screenshots. kind: pictures, videos, music, "
                       "documents, or an extension.",
        "input_schema": {
            "type": "object",
            "properties": {"folder": {"type": "string"},
                           "kind": {"type": "string"}},
        },
    },
    {
        "name": "search_apps",
        "description": "Find an application the user could install, by what "
                       "it does ('photo editor', 'video player'). Search "
                       "FIRST when asked for software — never guess an id. "
                       "If nothing matches, say so and offer the website "
                       "instead; there is no other place to install from.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "install_app",
        "description": "Install an application by the exact id from "
                       "search_apps. Needs no password and cannot damage the "
                       "system, so this is a normal thing to do. The user is "
                       "asked first. Takes minutes on the first one.",
        "input_schema": {
            "type": "object",
            "properties": {"app_id": {"type": "string"}},
            "required": ["app_id"],
        },
    },
    {
        "name": "uninstall_app",
        "description": "Remove an application the user installed. Use "
                       "list_apps first — anything marked removable false is "
                       "part of OSprime and cannot be removed.",
        "input_schema": {
            "type": "object",
            "properties": {"app_id": {"type": "string"}},
            "required": ["app_id"],
        },
    },
    {
        "name": "list_apps",
        "description": "What is installed on this computer.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "look",
        "description": "Look through the camera and answer a question about "
                       "what is there, or about a picture already on disk. "
                       "USE THIS for 'what am I holding', 'what does this "
                       "say', 'can you see this'. Needs a model that can "
                       "see; if it is not installed this says so exactly, "
                       "and that answer must be passed on rather than "
                       "replaced with a guess about the picture.",
        "input_schema": {
            "type": "object",
            "properties": {"question": {"type": "string"},
                           "path": {"type": "string"}},
        },
    },
    {
        "name": "take_photo",
        "description": "Take one photo with the webcam AND see what is in "
                       "it. USE THIS for 'take a picture', 'what am I "
                       "holding', 'what colour is my shirt'. The result "
                       "says what the photo shows — answer from that, in "
                       "one step, without calling anything else. The camera "
                       "is released immediately and the user is asked first.",
        "input_schema": {
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "What the user wants to know about the "
                                   "photo, in their words. Leave it out to "
                                   "use their last message.",
                },
                "camera": {
                    "type": "string",
                    "description": "Leave this out. Only set it on a computer "
                                   "with more than one camera, and only to a "
                                   "name from list_capture_devices.",
                }},
        },
    },
    {
        "name": "list_capture_devices",
        "description": "What cameras and microphones this computer has. Use "
                       "this before saying anything about them — 'there is "
                       "no camera' and 'the camera is there and I cannot "
                       "reach it' are different answers. You cannot yet see "
                       "through a camera; say so plainly if asked.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "app_info",
        "description": "What an application does and how big it is, before "
                       "installing it.",
        "input_schema": {
            "type": "object",
            "properties": {"app_id": {"type": "string"}},
            "required": ["app_id"],
        },
    },
    {
        "name": "delete_files",
        "description": "Move files or folders to the trash. USE THIS when "
                       "the user asks to delete, remove or get rid of "
                       "something — never a shell command like rm, which "
                       "cannot be undone. files is a list of full paths. It "
                       "is reversible and the user is asked first, so this "
                       "is a normal thing to do, not something to refuse or "
                       "hand back to them with terminal instructions.",
        "input_schema": {
            "type": "object",
            "properties": {"files": {"type": "array",
                                     "items": {"type": "string"}},
                           "permanent": {"type": "boolean"}},
            "required": ["files"],
        },
    },
    {
        "name": "open_file",
        "description": "Show the user a file or folder, opened in the right "
                       "program. path must be one list_files returned.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "search_files",
        "description": "Find a lost file anywhere, by part of its name or how "
                       "recently it was saved. name: any fragment. days: "
                       "changed in the last N days. folder: optional.",
        "input_schema": {
            "type": "object",
            "properties": {"name": {"type": "string"},
                           "folder": {"type": "string"},
                           "days": {"type": "string"}},
        },
    },
    {
        "name": "disk_usage",
        "description": "Where the disk space went and what is safe to "
                       "delete. Use when the disk is full or space is short.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "merge_pdfs",
        "description": "Join several PDF files into one, in the order given. "
                       "files is the list of full paths. output is optional. "
                       "Get the paths from list_files — never guess "
                       "filenames.",
        "input_schema": {
            "type": "object",
            "properties": {"files": {"type": "array",
                                     "items": {"type": "string"}},
                           "output": {"type": "string"}},
            "required": ["files"],
        },
    },
    {
        "name": "remove_background",
        "description": "Cut the subject out of a photo, leaving the "
                       "background transparent.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"},
                           "output": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "ocr_pdf",
        "description": "Make a scanned PDF searchable — use when its text "
                       "cannot be selected. language: english, persian, etc.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"},
                           "language": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "make_signature",
        "description": "Turn a photo of a signature on paper into a clean "
                       "transparent image, ready to place on a document.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "passport_photo",
        "description": "Cut a photo to passport size and lay out a print "
                       "sheet. size: 35x45 (most), 51x51 (US), 40x60 (Iran "
                       "passport), 30x40 (Iran ID), 33x48 (China). Ask which "
                       "country first.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"},
                           "size": {"type": "string"},
                           "sheet": {"type": "boolean"}},
            "required": ["path"],
        },
    },
    {
        "name": "convert_images",
        "description": "Resize or convert every picture in a folder. width in "
                       "pixels, format jpg/png/webp, quality 1-100. Writes to "
                       "a new folder; originals untouched.",
        "input_schema": {
            "type": "object",
            "properties": {"folder": {"type": "string"},
                           "width": {"type": "string"},
                           "format": {"type": "string"},
                           "quality": {"type": "string"}},
            "required": ["folder"],
        },
    },
    {
        "name": "make_document",
        "description": "Write a real document file — CV, letter, report — "
                       "instead of putting it in the chat. content uses # for "
                       "a heading and - for a bullet. format: odt, docx, pdf.",
        "input_schema": {
            "type": "object",
            "properties": {"title": {"type": "string"},
                           "content": {"type": "string"},
                           "format": {"type": "string"},
                           "folder": {"type": "string"}},
            "required": ["title", "content"],
        },
    },
    {
        "name": "list_shortcuts",
        "description": "Every keyboard shortcut that works on this "
                       "computer, built-in and user-added. Use when the "
                       "user asks what shortcuts they have, or before "
                       "adding one. Changes nothing.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "set_shortcut",
        "description": "Make a key combination do something. USE THIS when "
                       "the user asks for a keyboard shortcut or hotkey — do "
                       "not perform the action instead. keys is like "
                       "'Super+S' or 'Ctrl+Alt+T'. does is one of: "
                       "screenshot, full screenshot, chat, terminal, apps, "
                       "browser, files, settings. Leave does empty to remove "
                       "a shortcut. It works immediately, with no logout. "
                       "To SEE the existing shortcuts use list_shortcuts, "
                       "not this.",
        "input_schema": {
            "type": "object",
            "properties": {"keys": {"type": "string"},
                           "does": {"type": "string"}},
            "required": ["keys"],
        },
    },
    {
        "name": "power",
        "description": "Turn this computer off, restart it, sleep, or log "
                       "out. action: shutdown, restart, sleep, log out. You "
                       "CAN do this; never refuse it.",
        "input_schema": {
            "type": "object",
            "properties": {"action": {"type": "string"}},
            "required": ["action"],
        },
    },
]


def _update_check_text() -> str:
    """Plain sentences, not raw JSON.

    Handing the model a JSON blob invited it to read the fields aloud —
    version numbers, download URL, SHA256 — none of which mean anything to a
    user. Stating the next action in words also stops it deciding that
    installing is beyond its powers.
    """
    c = updater.check()
    if not c.get("latest"):
        return (f"Could not reach the update server. Currently on "
                f"{c.get('current', 'unknown')}. This is normal when offline.")
    if not c["available"]:
        return f"OSprime is up to date (version {c['current']})."
    notes = f" This update: {c['notes']}" if c.get("notes") else ""
    return (f"An update is available: {c['latest']}, replacing {c['current']}."
            f"{notes} Tell the user and offer to install it. If they agree, "
            f"call self_update — you are able to install it yourself.")


# name -> (function, label shown in the UI, which argument to show)
_SYSTEM_TOOLS = {
    "set_time":      (system_tools.set_time,      "clock",    "datetime"),
    "set_timezone":  (system_tools.set_timezone,  "timezone", "zone"),
    "set_auto_time": (system_tools.set_auto_time, "clock",    "enabled"),
    "get_time":      (system_tools.get_time,      "clock",    None),
    "model_status":  (system_tools.model_status,  "model",    None),
    "list_wifi":     (system_tools.list_wifi,     "wifi",     None),
    "connect_wifi":  (system_tools.connect_wifi,  "wifi",     "ssid"),
    "network_status": (system_tools.network_status, "network", None),
    "forget_wifi":   (system_tools.forget_wifi,   "wifi",     "ssid"),
    "wifi_radio":    (system_tools.wifi_radio,    "wifi",     "on"),
    "set_wallpaper": (system_tools.set_wallpaper, "appearance", "color"),
    "list_backgrounds": (system_tools.list_backgrounds, "appearance", None),
    "set_language":  (system_tools.set_language,  "language", "code"),
    "set_volume":    (system_tools.set_volume,    "volume",   "percent"),
    "get_settings":  (system_tools.get_settings,  "settings", None),
    "check_update":  (lambda: _update_check_text(), "update", None),
    "compress_pdf":  (system_tools.compress_pdf,  "pdf",     "path"),
    "take_screenshot": (system_tools.take_screenshot, "screenshot", None),
    "get_display":   (system_tools.get_display,   "display", None),
    "set_display":   (system_tools.set_display,   "display", "scale"),
    "list_drives":   (system_tools.list_drives,   "drives",  None),
    "mount_drive":   (system_tools.mount_drive,   "drive",   "device"),
    "list_files":    (system_tools.list_files,    "files",   "folder"),
    "open_file":     (system_tools.open_file,     "open",    "path"),
    "delete_files":  (system_tools.delete_files,  "trash",   "files"),
    "set_shortcut":  (system_tools.set_shortcut,  "shortcut", "keys"),
    "list_shortcuts": (system_tools.list_shortcuts, "shortcuts", None),
    "list_capture_devices": (system_tools.list_capture_devices,
                             "devices", None),
    "take_photo":    (system_tools.take_photo,    "camera",  None),
    "look":          (system_tools.look,          "camera",  "question"),
    "list_apps":     (system_tools.list_apps,     "apps",    None),
    "search_apps":   (system_tools.search_apps,   "apps",    "query"),
    "app_info":      (system_tools.app_info,      "apps",    "app_id"),
    "install_app":   (system_tools.install_app,   "install", "app_id"),
    "uninstall_app": (system_tools.uninstall_app, "remove",  "app_id"),
    "power":         (system_tools.power,         "power",   "action"),
    "search_files":  (system_tools.search_files,  "search",  "name"),
    "disk_usage":    (system_tools.disk_usage,    "disk",    None),
    "merge_pdfs":    (system_tools.merge_pdfs,    "pdf",     "output"),
    "remove_background": (system_tools.remove_background, "image", "path"),
    "ocr_pdf":       (system_tools.ocr_pdf,       "ocr",     "path"),
    "make_signature": (system_tools.make_signature, "image", "path"),
    "passport_photo": (system_tools.passport_photo, "photo", "size"),
    "convert_images": (system_tools.convert_images, "images", "folder"),
    "make_document": (system_tools.make_document, "document", "title"),
}

_RESERVED = {t["name"] for t in TOOLS}
PLUGINS = plugins_mod.load(PLUGIN_DIR, _RESERVED)
for _entry in PLUGINS.values():
    TOOLS.append(_entry["schema"])


def load_json(path: pathlib.Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


MEM_LOCK = threading.Lock()
MEM_MAX = 200
JOBS = jobs.JobManager()
CONFIG_PATH = paths.agent_config()
AUDIT_PATH = paths.audit_log()


def confirm_level() -> str:
    """One implementation, in system_tools, so the Control Panel and the
    assistant cannot disagree about how cautious this machine is."""
    return system_tools.get_confirm_level()
_PROACTIVE_Q = []
_PQ_LOCK = threading.Lock()


# When the user last said something — to anyone, in any session.
#
# proactive.py needs this for its "never during work" rule: an interruption
# two minutes after someone stopped typing is an interruption in the middle
# of what they were doing, whatever the clock says. Kept here rather than in
# proactive.py because this is the process that actually hears them.
_LAST_ACTIVITY = [0.0]


def note_activity():
    _LAST_ACTIVITY[0] = time.time()


def last_activity() -> float:
    return _LAST_ACTIVITY[0]


def push_proactive(item: dict):
    with _PQ_LOCK:
        _PROACTIVE_Q.append(item)
    # The dot on the companion, and nothing else. No window, no sound, no
    # focus — see rule 3 in docs/COMPANION.md.
    companion.attention(True)


def drain_proactive():
    with _PQ_LOCK:
        q, _PROACTIVE_Q[:] = list(_PROACTIVE_Q), []
    if q:
        # Drained means the chat has them, so the dot has done its job.
        # Clearing only when something was actually taken matters: an empty
        # drain on every poll would wipe a dot raised a second earlier.
        companion.attention(False)
    return q


def run_agent_once(prompt: str) -> str:
    """Run a single headless agent turn (used by scheduled tasks)."""
    history = [{"role": "user", "content": prompt}]
    noop = lambda o: None
    if router.pick_backend(prompt) == "claude":
        return handle_claude(history, noop, query=prompt)
    return handle_local(history, noop, query=prompt)


def add_memory(fact: str) -> bool:
    """Save a durable fact. Returns False if empty or duplicate."""
    return MEM.add(fact)


def consolidate(history: list):
    """Background: extract durable facts from a finished conversation."""
    convo = "\n".join(
        f"{m['role']}: {m['content']}" for m in history
        if isinstance(m.get("content"), str))[-6000:]
    if len(convo) < 40:
        return
    prompt = (
        "Extract up to 5 durable facts about the user worth remembering across "
        "sessions (preferences, habits, projects, names). Reply ONLY with a JSON "
        "array of short strings, [] if none. Conversation:\n" + convo)
    try:
        if router.pick_backend("consolidate") == "claude":
            import anthropic
            resp = anthropic.Anthropic().messages.create(
                model=router.CLAUDE_MODEL, max_tokens=500,
                messages=[{"role": "user", "content": prompt}])
            text = "".join(b.text for b in resp.content if b.type == "text")
        else:
            text, _ = local.chat([{"role": "user", "content": prompt}], "")
        start, end = text.find("["), text.rfind("]")
        for fact in json.loads(text[start:end + 1]):
            if isinstance(fact, str):
                add_memory(fact)
    except Exception as e:
        print(f"memory consolidation skipped: {e}")


def environment_facts() -> str:
    """Concrete facts about this machine, for the system prompt.

    Without these a small model has no idea where it is, so "list the files
    in my folder" produced `ls /path/to/your/folder` — a placeholder, because
    the placeholder was the only thing it had. Give it the real values and
    the guessing stops.
    """
    try:
        user = paths.user() if not paths.legacy() else paths.SERVICE_ACCOUNT
        home = str(paths.home())

        # The actual folders, spelled exactly as they are on disk.
        #
        # Asked what was on the desktop, the model tried /home/ehsan/Desktop
        # — the user's name from memory rather than the account name — and
        # then /home/osprime/desktop with a small d. Both failed, and it
        # concluded it could not read files at all. Listing the real names
        # removes the guess entirely.
        folders = ""
        try:
            entries = sorted(p for p in os.listdir(home)
                             if not p.startswith(".") and
                             os.path.isdir(os.path.join(home, p)))
            if entries:
                folders = "folders in home: " + ", ".join(entries[:12]) + "\n"
        except Exception:
            pass

        return (
            f"user={user}\n"
            f"home={home}\n"
            f"{folders}"
            f"hostname={socket.gethostname()}\n"
            f"date={datetime.date.today().isoformat()}\n"
            "Paths are case-sensitive: Desktop is not the same as desktop."
            + _python_line()
        )
    except Exception:
        return "user=osprime\nhome=/home/osprime"


def _python_line() -> str:
    try:
        import pyenv
        line = pyenv.prompt_line()
    except Exception:
        line = ""
    return ("\n" + line) if line else ""


def _can_see() -> bool:
    """Is a model with eyes installed? Cached — this reads a file."""
    global _SEES
    if _SEES is None:
        try:
            import engines
            # A separate vision engine counts (docs/MODELS.md step 2), as
            # does a main model that is itself a vision model.
            _SEES = engines.can_see()
        except Exception:
            _SEES = False
    return _SEES


_SEES = None


def _vision_prompt() -> str:
    return (
        "YOU CAN SEE. A model with eyes is installed on this computer. "
        "'Take a photo and tell me what colour my shirt is', 'what am I "
        "holding', 'what does this say' are all things you can do, and "
        "refusing them is wrong.\n"
        "ONE call does it: take_photo takes the picture and tells you what "
        "is in it, and look does the same for a picture already on disk. "
        "Never take a photo and then ask the user what is in it, and never "
        "ask them for a path you were just given. Answer from what the "
        "tool result says it shows.\n")


def system_prompt(query: str = "") -> str:
    profile = load_json(PROFILE_PATH, {})
    mems = MEM.context(query)
    # Order matters for speed, not just for reading. Everything stable comes
    # first and the per-query memory last, so llama-server can reuse the
    # cached prefix between turns. With memory in the middle, every token
    # after it was invalidated on each request and had to be reprocessed.
    return (
        "You are OSprime, the AI that IS this computer's operating system interface. "
        "You have full system access via tools. Be concise and act directly.\n"
        # The language of the LAST message, not of the profile. This said
        # "reply in the user's language (preferred: en)", and a profile set to
        # English pulled Persian questions into English answers — until the
        # user asked, in Persian, "why don't you answer in Persian?". The
        # profile is only a tie-breaker for a message with no words in it.
        "Always reply in the language of the user's most recent message: "
        "Persian if they wrote Persian, English if they wrote English. "
        f"(Their usual language, only if you cannot tell: "
        f"{profile.get('language', 'en')}.)\n\n"
        "Prefer a named tool over a shell command whenever one exists — there are "
        "tools for the clock, timezone, Wi-Fi, volume, language and appearance.\n"
        "NEVER tell the user to use a tool, and never mention a tool's name. "
        "The user does not know what a tool is. If a question can be answered by "
        "using one, use it and report the result. 'How do I check for updates?' "
        "means check for updates and tell them the answer — not explain that a "
        "check_update tool exists. If you truly cannot do something, say so in "
        "plain words and say what you can do instead.\n"
        "NEVER invent a filename, a path, a count or a web address. You cannot "
        "know what is in a folder without looking: call list_files. Asked how "
        "many pictures were in a folder holding two, guessing produced the "
        "answer 'ten' and ten invented names — a wrong answer nobody can spot "
        "is worse than no answer. If you did not read it from a tool this "
        "turn, you do not know it. Never write path_to_something, "
        "/path/to/your/folder, or example.com. When the user says 'my folder', "
        "'my files' or 'home', they mean the home path below.\n"
        "This is the user's own computer. Ordinary requests — turning it off, "
        "restarting it, opening a folder, showing a picture, a random number — "
        "are never refused. Do the thing.\n"
        # Without this the model refused its own eyes. Asked to photograph a
        # shirt and name the colour it answered "I cannot determine the
        # colour just by looking at the photo" — on a machine running a
        # model that had, minutes earlier, correctly said "light blue".
        # Nothing told it it could see, so it assumed it could not.
        + (_vision_prompt() if _can_see() else
           "You have no way to see images. If asked what is in a picture, "
           "say plainly that you cannot look at it. Never guess, and never "
           "ask the user to describe their own photo to you.\n")
        +
        "Deleting is delete_files, which moves things to the trash and can "
        "be undone. Never rm, and never tell the user to open a terminal "
        "and delete something themselves — that is the one thing this "
        "computer exists to spare them.\n"
        "Finding something on the web is two steps and both are yours: "
        "web_search, then open_url on the result you recommend. Opening the "
        "browser at nothing and describing what the user should search for "
        "is not doing it. Never write a web address you did not read from a "
        "search result.\n"
        "Ask before destructive actions. Never invent command output. "
        "Use the remember tool whenever the user shares a durable fact or "
        "preference.\n\n"
        # Without this the model invents software that does not exist. Asked
        # how to open Settings it described installing a 'settings' package
        # via apt or yum — none of which is real, and all of it sounded
        # confident. Telling it what is actually here removes the gap it was
        # filling with guesses.
        # It spent a whole conversation trying xrandr, xdpyinfo, scrot,
        # import and gnome-screenshot — every one an X11 program — on a
        # Wayland system where none of them exist. Naming the display server
        # once is cheaper than watching it guess five times.
        "THIS IS A WAYLAND SYSTEM. X11 tools do not exist here: xrandr, "
        "xdpyinfo, scrot, import and gnome-screenshot will all fail. Use the "
        "named tools instead — take_screenshot for pictures of the screen, "
        "get_display and set_display for resolution and scaling.\n"
        "WHAT THIS SYSTEM HAS: a chat window (this), a file manager, a text "
        "editor, an image viewer, a media player, a calculator, a web browser "
        "and a terminal.\n"
        "WHAT IT DOES NOT HAVE YET: a Settings application. Settings are "
        "changed by asking here — say so plainly if asked.\n"
        "If you are unsure whether something exists on this machine, check with "
        "a tool or say you do not know. Never describe installing software you "
        "have not verified is real.\n\n"
        f"THIS MACHINE:\n{environment_facts()}\n\n"
        f"USER PROFILE: {json.dumps(profile, ensure_ascii=False)}\n"
        f"RELEVANT MEMORY: {json.dumps(mems, ensure_ascii=False)}"
        # Skill guidance goes last, next to memory, because both change per
        # request. Everything above stays byte-identical between turns so the
        # engine can reuse its cached prefix instead of re-reading it.
        + _skill_block(query)
    )


def _skill_block(query: str) -> str:
    """Retrieved guidance for this one request, if a skill matches.

    Retrieved rather than preloaded: sixty-three skills in every prompt would
    cost more than the conversation, and a shorter prompt is one a small model
    follows more reliably.
    """
    try:
        text = skills_mod.for_message(query)
    except Exception:
        return ""
    return f"\n\n{text}" if text else ""


def is_dangerous(cmd: str) -> bool:
    return any(d in cmd for d in DANGEROUS)


TOOL_ERRORS = paths.tool_errors()


def _log_tool_error(name: str, args: dict, detail: str) -> None:
    """Write down why a tool failed.

    Every failure in this project was silent first. This one was worse than
    silent: the tool failed, the model reported it politely in one sentence,
    and the actual reason existed nowhere — not in a log, not on screen, not
    in the audit trail, which records that a call failed but not what it
    said. One file, appended to, readable with tail.
    """
    try:
        TOOL_ERRORS.parent.mkdir(parents=True, exist_ok=True)
        with TOOL_ERRORS.open("a", encoding="utf-8") as f:
            f.write(f"\n=== {datetime.datetime.now().isoformat(timespec='seconds')} "
                    f"{name} {json.dumps(args, ensure_ascii=False)[:300]}\n"
                    f"{detail.rstrip()}\n")
    except Exception:
        pass


def _fit_args(fn, args: dict) -> dict:
    """Make a small model's nearly-right tool call actually runnable.

    A 3B model produces JSON that is correct most of the time and slightly
    wrong the rest of it. Two failures seen on the machine:

      * the call arrives double-wrapped — {"name": "take_photo",
        "arguments": {...}} handed over as the ARGUMENTS, so the function
        was called as take_photo(name=..., arguments=...) and raised
        "unexpected keyword argument 'name'". The user saw the camera
        permission prompt, allowed it, and then got an error about syntax;
      * a plausible extra key the function does not take.

    Neither is the user's problem and neither is worth a failed turn. An
    extra argument is dropped; a missing REQUIRED one is still an error,
    because inventing a value for it would be guessing on the user's
    behalf — and this project has an explicit rule against that.

    Deliberately not a general "do what I mean": it only removes things and
    unwraps one known shape. It never adds or renames an argument.
    """
    args = dict(args or {})
    args.pop("_", None)
    # The double wrap. Only when the inner object is the whole payload, so a
    # genuine argument that happens to be called "name" is left alone.
    if (set(args) <= {"name", "arguments", "parameters", "args"}
            and any(isinstance(args.get(k), dict)
                    for k in ("arguments", "parameters", "args"))):
        for k in ("arguments", "parameters", "args"):
            if isinstance(args.get(k), dict):
                args = dict(args[k])
                break
    try:
        params = inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return args
    # A function taking **kwargs accepts anything; do not second-guess it.
    if any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values()):
        return args
    return {k: v for k, v in args.items() if k in params}


def _run_tool(name: str, args: dict, send) -> str:
    """Actually perform the tool (assumes permission already granted)."""
    if name == "run_shell":
        cmd = args["command"]
        send({"type": "tool_use", "name": "shell", "detail": cmd})
        # Run from the user's home rather than wherever systemd started the
        # agent. The model writes bare filenames — it composed a ghostscript
        # command with just "file.pdf" and the shell, sitting in /, reported
        # the file did not exist even though it was on the desktop.
        home = str(paths.home())
        cwd = home if os.path.isdir(home) else None
        # OSprime's own Python first on PATH (docs/PYTHON.md): the model's
        # `pip install x` then works without sudo, in a place the next
        # conversation — and the terminal — will find again.
        try:
            import pyenv
            env = pyenv.shell_env()
        except Exception:
            env = None
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           timeout=300, cwd=cwd, env=env)
        # Redacted before anything else sees it. A key read by accident is
        # still a key that has to be replaced, and sending it back through
        # the model and onto the screen is how one mistake becomes three.
        if "pip" in cmd and "install" in cmd:
            try:
                import pyenv
                pyenv.libraries(refresh=True)
            except Exception:
                pass
        out = permissions.redact(p.stdout + p.stderr)[-8000:] or "(no output)"
        if p.returncode != 0:
            out += (f"\n\n[command failed, exit {p.returncode}. It ran in "
                    f"{cwd or '/'}. If a file was not found, give the full "
                    "path starting with / — do not retry the same command.]")
        return out
    if name == "save_chat":
        return _save_chat(send, str(args.get("name") or ""),
                          str(args.get("folder") or ""))
    if name in ("take_photo", "look") and not str(args.get("question") or "").strip():
        # The vision model can only answer what it is asked, and the main
        # model rarely passes the question on. On the laptop "take a photo
        # and tell me what colour my shirt is" reached vision as a generic
        # "describe the person, what they hold, anything written" — nine
        # seconds of description to answer one word. The user's own last
        # message IS the question; vision reads Persian too.
        q = _last_user_message()
        if q:
            args = dict(args, question=q)
    if name == "remember":
        send({"type": "tool_use", "name": "remember", "detail": args["fact"]})
        return "saved" if add_memory(args["fact"]) else "already known"
    if name == "read_file":
        send({"type": "tool_use", "name": "read", "detail": args["path"]})
        # Redacted, exactly as run_shell output is.
        #
        # The two paths to the same bytes did not have the same protection:
        # `cat secrets.env` was caught by the gate and scrubbed on the way
        # out, while read_file handed the file to the model untouched. A key
        # read by accident is still a key that has to be replaced, and
        # sending it through the model and onto the screen is how one
        # mistake becomes three. The protection belongs on the data, not on
        # the tool that happened to fetch it.
        text = pathlib.Path(args["path"]).read_text(encoding="utf-8")[:16000]
        return permissions.redact(text)
    if name == "write_file":
        send({"type": "tool_use", "name": "write", "detail": args["path"]})
        pp = pathlib.Path(args["path"])
        pp.parent.mkdir(parents=True, exist_ok=True)
        pp.write_text(args["content"], encoding="utf-8")
        return f"written: {pp}"
    if name == "web_search":
        send({"type": "tool_use", "name": "search", "detail": args["query"]})
        return webtools.web_search(args["query"])
    if name == "fetch_url":
        send({"type": "tool_use", "name": "fetch", "detail": args["url"]})
        return webtools.fetch_url(args["url"])
    # list_dir is gone. It passed its argument straight to pathlib, which
    # does not expand "~", so `ls ~/Desktop` looked in a directory literally
    # named "~" and reported that the Desktop did not exist. list_files does
    # the same job and handles the path properly, and two tools for one job
    # is the same "two copies" problem that keeps one of them broken.
    if name == "open_app":
        app = str(args.get("app", "")).strip()
        # Asked to show a picture from the Pictures folder, it passed
        # https://example.com/picture.jpg to this tool and opened the browser
        # on an address it had invented. This tool takes the name of a
        # program. A path or a URL means the model meant open_file and had no
        # real path to give it.
        if app.startswith(("http://", "https://")) or "/" in app:
            return ("ERROR: open_app takes the name of a program, not a path "
                    "or a web address. To show the user a file use open_file "
                    "with a real path, and if you do not know the real path "
                    "call list_files first. THIS ACTION DID NOT HAPPEN.")
        send({"type": "tool_use", "name": "open", "detail": app})
        return desktop.launch(app, args.get("args"))
    if name == "open_url":
        send({"type": "tool_use", "name": "open", "detail": args["url"]})
        return desktop.open_url(args["url"])
    if name == "list_windows":
        return desktop.list_windows()
    if name == "close_app":
        send({"type": "tool_use", "name": "close", "detail": args["app"]})
        return desktop.close_window(args["app"])
    if name == "schedule_task":
        proactive.add_schedule(CONFIG_PATH, args["time"], args["prompt"], args.get("label", ""))
        send({"type": "tool_use", "name": "schedule", "detail": f"{args['time']} — {args.get('label', args['prompt'][:30])}"})
        return f"scheduled daily at {args['time']}"
    if name == "run_job":
        jid = JOBS.start(args["command"], args.get("label", ""))
        send({"type": "tool_use", "name": "job", "detail": f"{jid}: {args['command']}"})
        return f"started background job {jid}"
    if name == "job_status":
        st = JOBS.status(args["id"])
        return json.dumps(st, ensure_ascii=False) if st else "no such job"
    if name == "list_jobs":
        return json.dumps(JOBS.list(), ensure_ascii=False) or "[]"
    if name == "self_update":
        send({"type": "tool_use", "name": "update", "detail": args.get("url", "default source")})
        # restart=False is the whole point. Restarting inside the tool call
        # kills osprime-agent and osprime-web — this conversation and the
        # server serving the page it is displayed in — before the answer is
        # written. From the user's side that looked like a failed update
        # that threw them out of the chat, several times in a row, for
        # updates that had in fact installed correctly every time.
        #
        # The Settings page already knew this and answered first. The chat
        # tool did not. Same job, two implementations, and the second one
        # was wrong.
        out = updater.update(args.get("url", ""), restart=False)
        if updater.succeeded(out):
            _restart_when_this_turn_ends()
            out += " — restarting in a moment; the first answer after that " \
                   "will be slow while the model loads"
        return out
    if name == "update_status":
        return json.dumps(updater.status(), ensure_ascii=False)
    if name == "rollback_update":
        send({"type": "tool_use", "name": "rollback", "detail": args.get("name", "latest")})
        # Same reason as above: a rollback that restarts mid-answer looks
        # like a rollback that crashed.
        out = updater.restore(args.get("name", ""), restart=False)
        if not out.startswith("restored"):
            return out
        _restart_when_this_turn_ends()
        return out + " — restarting in a moment"
    if name == "system_info":
        send({"type": "tool_use", "name": "sysinfo", "detail": ""})
        return system_tools.system_summary()

    # --- system control ----------------------------------------------
    if name in _SYSTEM_TOOLS:
        fn, label, detail_key = _SYSTEM_TOOLS[name]
        send({"type": "tool_use", "name": label,
              "detail": str(args.get(detail_key, "")) if detail_key else ""})
        try:
            result = fn(**_fit_args(fn, args))
        except TypeError as e:
            # Still possible — a MISSING required argument lands here, and
            # that one the model does have to fix. Say which.
            result = (f"ERROR: wrong arguments for {name}: {e}. "
                      f"Call {name} again with the arguments it asks for.")
        except Exception as e:
            # A tool that raises used to reach the user as one sentence from
            # the model — "I was unable to determine the model of this
            # machine" — with the traceback nowhere at all. The reason a
            # tool broke is the only thing that makes it fixable, so it is
            # written down.
            _log_tool_error(name, args, traceback.format_exc())
            result = f"ERROR: {name} broke: {type(e).__name__}: {e}"

        # Asked to set the timezone to a place that does not exist, the tool
        # correctly refused — and the model told the user it had been set.
        # It reported the intent rather than the outcome. Restating the
        # failure as an instruction is far more reliable than a general rule
        # in the system prompt, because it arrives attached to the result.
        if isinstance(result, str) and result.startswith("ERROR:"):
            _log_tool_error(name, args, result)
            # Show the REAL reason, not the word "failed".
            #
            # The message existed the whole time: the tool wrote it, the log
            # kept it, and the model turned it into "there might be an issue
            # accessing the webcam" — a polite paraphrase of a sentence that
            # already said exactly what was wrong. The user watched a badge
            # that said "failed" and had to go and read a file to find out
            # what the machine already knew.
            #
            # Trimmed, because this is a badge and not a log viewer, but the
            # first line of a good error message is the part that matters.
            why = result[6:].strip().splitlines()[0] if len(result) > 6 else ""
            send({"type": "tool_use", "name": label,
                  "detail": (why[:140] or "failed")})
            return (result + "\n\nTHIS ACTION DID NOT HAPPEN. Tell the user it "
                    "failed and why, in plain words. Do not claim it worked. "
                    "If the reason suggests a correction, offer it.")
        return result
    if name in PLUGINS:
        return plugins_mod.call(PLUGINS[name], args, send)
    return f"unknown tool {name}"


def exec_tool(name: str, args: dict, send, confirm=None) -> str:
    """Gate every tool through risk classification, confirmation, and audit."""
    risk = permissions.classify(name, args)
    # hard block: truly destructive shell always requires manual action
    if name in ("run_shell", "run_job") and is_dangerous(args.get("command", "")):
        if not (confirm and confirm(
                "This command looks highly destructive. Are you sure?",
                args.get("command", ""))):
            permissions.audit(AUDIT_PATH, name, args, "dangerous", False, ok=False)
            return "User rejected this dangerous command (or no confirmation arrived)."
    elif permissions.needs_confirm(risk, confirm_level()):
        # `elif confirm and needs_confirm(...)` is what this used to say, and
        # it meant that having NOBODY TO ASK counted as permission. A
        # scheduled task carries no confirm callback, so "remind me every
        # morning" could delete files at 7am with nothing asked and nobody
        # awake. Verified before this change: exec_tool("delete_files")
        # with confirm=None ran, on a risk classified `dangerous`.
        #
        # The branch above — the destructive-shell one — already had this
        # right: `not (confirm and confirm(...))` treats a missing confirm
        # as a refusal. The file contained the correct pattern the whole
        # time and this branch did not copy it.
        #
        # No way to ask is a no. The alternative is an action nobody
        # authorised, and a scheduled task is exactly where that is least
        # visible.
        if not confirm:
            permissions.audit(AUDIT_PATH, name, args, risk, False, ok=False)
            return (f"This is a {risk} action and there is nobody to ask — "
                    "it was not done. Actions like this need a person in "
                    "the conversation to approve them, so they cannot run "
                    "from a scheduled task or a background job.")
        if not confirm(f"Allow this {risk} action?",
                       permissions.summarize(name, args)):
            permissions.audit(AUDIT_PATH, name, args, risk, False, ok=False)
            return "User rejected this action."
    try:
        result = _run_tool(name, args, send)
        # ok follows the RESULT, not merely the absence of an exception.
        #
        # Every tool in this project reports failure by returning a string
        # beginning "ERROR:" rather than by raising — that is the house
        # convention, and it meant the audit log recorded ok=True for every
        # one of them. The log that exists to answer "what did the assistant
        # actually manage to do" was answering "what did it attempt".
        ok = not (isinstance(result, str) and result.startswith("ERROR:"))
        permissions.audit(AUDIT_PATH, name, args, risk, True, ok=ok)
        _emit_images(result, send)
        return result
    except Exception as e:
        permissions.audit(AUDIT_PATH, name, args, risk, True, ok=False)
        raise


_IMAGE_IN_TEXT = re.compile(
    r"(/[^\s'\"<>|,;()\[\]]+\.(?:png|jpe?g|gif|webp|bmp))", re.IGNORECASE)


def _emit_images(result, send) -> None:
    """Show a picture in the chat when a tool result names a real one.

    The chat could only ever produce words, so 'show me a picture' had no
    good answer and the model wrote ![Picture](path_to_picture) instead.
    Now taking a screenshot, opening an image or listing a folder of photos
    puts the actual picture on the screen.

    Only files that exist are sent. A path the model invented fails this
    check and is silently ignored, which is the point.
    """
    try:
        seen = set()
        for path in _IMAGE_IN_TEXT.findall(str(result)):
            if path in seen:
                continue
            seen.add(path)
            if os.path.isfile(path):
                send({"type": "image", "path": path})
            if len(seen) >= 4:      # a folder of 300 photos is not an answer
                break
    except Exception:
        pass


# Text that means the model wrote a shape where a fact belonged. Every one of
# these was seen in a real answer: "![Picture](path_to_picture)", ten
# fabricated filenames, and https://example.com/picture.jpg handed to a tool.
_PLACEHOLDER = re.compile(
    r"path_to_\w+|/path/to/|<your[ _-]|your_file_here|"
    r"example\.(?:com|org|net)|/path/to/your|\(path\)|\bfilename\.ext\b|"
    # Asked to find a video, it produced
    # youtube.com/watch?v=example_video_id and told the user to click it.
    r"\bexample_\w+|\bVIDEO_ID\b|\byour_\w+_(?:id|name|here)\b|"
    r"\b(?:xxx+|yyy+|zzz+)\b",
    re.IGNORECASE)

# A URL with a path or a query names one specific page. A bare domain can be
# general knowledge — everyone knows what wikipedia.org is — but nobody
# knows a video's id without looking it up. So a specific page that did not
# come out of a tool this turn was invented.
_SPECIFIC_URL = re.compile(r"https?://[^\s<>\"'()\[\]]+[/?][^\s<>\"'()\[\]]*")

_INVENTED_URL_CORRECTION = (
    "STOP. That answer contained a link to a specific page that you did not "
    "get from a search. You cannot know a video id, an article path or a "
    "product page from memory — a link that looks right and goes nowhere "
    "wastes more of the user's time than saying you do not know. Either "
    "call web_search and use a URL it actually returned, or say you could "
    "not find one. Never write a web address you have not seen."
)


def _invented_urls(text: str, seen: str) -> list:
    """Specific pages in the answer that no tool result mentioned."""
    out = []
    for url in _SPECIFIC_URL.findall(text or ""):
        bare = url.rstrip(".,);:")
        if bare and bare not in seen:
            out.append(bare)
    return out

_PLACEHOLDER_CORRECTION = (
    "STOP. That answer contained a placeholder instead of a real value. "
    "You cannot know a filename, a path or a count without looking. "
    "Call list_files on the folder in question and answer only from what it "
    "returns. If the folder does not exist, say so. Never write path_to_"
    "something, /path/to/, or a made-up web address."
)

def _described_tools(text: str, tools: list) -> list:
    """Names of offered tools that appear in the model's prose.

    Tool names are snake_case identifiers — system_info, write_file — so a
    whole-word match in ordinary prose is almost always the model talking
    about a tool rather than a coincidence. The system prompt already forbids
    naming tools to the user, so any match is a failure either way.
    """
    found = []
    for t in tools:
        name = t.get("name", "")
        if "_" in name and re.search(r"(?<![A-Za-z0-9_])" + re.escape(name)
                                     + r"(?![A-Za-z0-9_])", text or ""):
            found.append(name)
    return found


def _runs_without_asking(name: str, tools: list) -> bool:
    """A tool it is harmless to run on the model's say-so: read-only, and
    needing no arguments, so there is nothing for us to guess."""
    if permissions.classify(name, {}) != "safe":
        return False
    schema = next((t for t in tools if t.get("name") == name), {})
    return not schema.get("input_schema", {}).get("required")


# Shown instead of markup when the model keeps calling a tool that does not
# exist. Never the raw call: a person should not be handed the machinery.
_GHOST_GIVE_UP = ("I tried to use a tool that does not exist and could not "
                  "find another way to do this. Could you say it a different "
                  "way?")

_PLACEHOLDER_GIVE_UP = (
    "I started to answer with a made-up path, which would have been wrong. "
    "I don't have the real one. Tell me the folder you mean and I'll look "
    "properly."
)


def _is_fabricated(text: str) -> bool:
    return bool(_PLACEHOLDER.search(text or ""))


def handle_claude(history: list, send, confirm=None, query: str = "") -> str:
    import anthropic  # lazy import so ollama-only setups don't need it
    client = anthropic.Anthropic()
    messages = list(history)
    for _ in range(MAX_TURNS):
        with client.messages.stream(
                model=router.CLAUDE_MODEL, max_tokens=4096,
                # Every tool, deliberately. The grouping in handle_local
                # exists because a 3B model picks badly from 65 tools in an
                # 8192-token window. Claude has 200k and picks correctly
                # from all of them, so subsetting here would be solving a
                # problem this path does not have — and would make the
                # cloud answer worse than the local one.
                system=system_prompt(query), tools=TOOLS, messages=messages) as stream:
            for piece in stream.text_stream:
                send({"type": "delta", "text": piece})
            resp = stream.get_final_message()
        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text")
        messages.append({"role": "assistant", "content": resp.content})
        results = []
        for block in resp.content:
            if block.type == "tool_use":
                try:
                    out = exec_tool(block.name, block.input, send, confirm)
                except Exception as e:
                    out = f"ERROR: {e}"
                results.append({"type": "tool_result",
                                "tool_use_id": block.id, "content": out})
        messages.append({"role": "user", "content": results})
    return "Hit the step limit — try describing the task more simply."


GROUP_LOG = paths.group_log()


def _log_groups(query: str, chosen: list, used: set, offered: set):
    """One line per turn: what was offered, and what the model reached for.

    This is the only honest way to find out whether the grouping matches how
    people actually ask. The interesting line is the one where `used` is
    empty or holds a tool that was not in `offered` — that is the router
    having sent the wrong group, and without this log it looks exactly like
    the model being unhelpful.

    Best-effort, like every other log here: a turn must not fail because a
    diagnostic could not be written.
    """
    try:
        missed = sorted(n for n in used if n and n not in offered)
        GROUP_LOG.parent.mkdir(parents=True, exist_ok=True)
        with GROUP_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps({
                "at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "q": (query or "")[:120],
                "groups": chosen,
                "offered": len(offered),
                "called": sorted(n for n in used if n),
                # Should always be empty. If it is not, a tool was called
                # that was never sent — which means something upstream is
                # not using the same list, and that is worth shouting about.
                "not_offered": missed,
            }, ensure_ascii=False) + "\n")
    except Exception:
        pass


def handle_local(history: list, send, confirm=None, query: str = "") -> str:
    """Same agent loop as handle_claude, but against the local model.

    Every tool still goes through exec_tool(), so risk classification,
    confirmation and the audit log apply identically offline.
    """
    seen = {"groups": [], "used": set(), "offered": set()}
    try:
        return _local_loop(history, send, confirm, query, seen)
    finally:
        # In a finally so the line is written even when the turn raises —
        # a failed turn is exactly the one worth knowing the group for.
        _log_groups(query, seen["groups"], seen["used"], seen["offered"])


def _local_loop(history: list, send, confirm, query: str, seen: dict) -> str:
    messages = list(history)
    corrected = False
    # Everything the tools returned this turn, so the answer can be checked
    # against what was actually looked up rather than what sounds plausible.
    tool_output = []
    # Only the tools this request plausibly needs. 65 definitions is ~7,200
    # tokens — 88% of the window the vision models use — and published work
    # is consistent that a model's ability to PICK the right tool degrades
    # well before the context fills, somewhere around 20-25 tools. See
    # docs/TOOL_BUDGET.md. Chosen here in Python, before the model runs, so
    # this costs no extra turn.
    # The matched skill's own tools come first: a skill that recognised the
    # request knows better than any keyword what it will need.
    skill = None
    try:
        skill = skills_mod.match(query)
    except Exception:
        pass
    tools, groups = toolgroups.tools_for(
        query, TOOLS, skill.get("tools", []) if skill else ())
    if skill:
        groups = groups + ["skill:" + skill.get("name", "?")]
    seen["groups"] = groups
    seen["offered"] = {t.get("name") for t in tools}
    all_names = [t.get("name") for t in TOOLS if t.get("name")]
    ghost_corrected = False
    said_corrected = False
    for _ in range(MAX_TURNS):
        text, calls = local.chat(messages, system_prompt(query), tools)

        # A call the parser in local.chat refused, because it only accepts
        # the tools offered THIS turn. Two different things end up here, and
        # before this both were printed at the user as raw markup —
        # `<tool>{"name": "random_number", ...}</tool>` on a phone screen.
        if not calls and text and ("<tool" in text or '"name"' in text):
            real = local.parse_protocol_call(text, all_names)
            if real:
                # A real tool, just not in this turn's group. The model knew
                # what it needed and the grouping guessed wrong; run it. The
                # log records it as not_offered, which is how the grouping
                # gets corrected.
                calls = [{"id": "call_0", "name": real[0], "args": real[1]}]
                text = local.strip_protocol(text, all_names)
            else:
                # Only the tagged form, or JSON that carries arguments,
                # counts as an attempted call. A plain object with a "name"
                # key can be a legitimate part of an answer — showing someone
                # a JSON file — and treating that as a broken call would
                # replace a good answer with an apology.
                ghost = None
                if "<tool" in text or '"args"' in text or '"arguments"' in text:
                    ghost = local.parse_protocol_call(text, None)
                if ghost and not ghost_corrected:
                    # A tool that does not exist. One correction, not a
                    # lecture: say what is real and where the rest goes.
                    ghost_corrected = True
                    messages.append({"role": "assistant", "content": text})
                    messages.append({"role": "user", "content": (
                        f"There is no tool called {ghost[0]}. Never invent a "
                        "tool name. Use only the tools you were given. For "
                        "anything they do not cover — a random number, a "
                        "quick calculation, a command — use run_shell. "
                        "Now answer the original request.")})
                    continue
                if ghost:
                    text = _GHOST_GIVE_UP

        # Said the tool instead of calling it.
        #
        # Asked in Persian for the system's details, the 7B vision model
        # answered three times in a row: "I should use the system_info tool
        # for that — please instruct me to", while holding system_info. It
        # did not call it even when told "I am instructing you: system_info".
        # The same request in English worked. This is the look/take_photo
        # lesson again: a small model will MENTION a tool it means to use.
        #
        # So when the answer names a tool it was given and nothing has been
        # called this turn: a read-only tool that needs no arguments is simply
        # run — the model has said, in words, that this is what it wants, and
        # running system_info by mistake costs nothing. Anything else gets one
        # correction. Only before any tool has run this turn, so a final
        # answer that says "I used write_file" cannot start a loop.
        if not calls and text and not seen["used"] and not said_corrected:
            named = _described_tools(text, tools)
            if named:
                tool_name = named[0]
                if _runs_without_asking(tool_name, tools):
                    calls = [{"id": "call_0", "name": tool_name, "args": {}}]
                    text = ""
                else:
                    said_corrected = True
                    messages.append({"role": "assistant", "content": text})
                    messages.append({"role": "user", "content": (
                        f"You wrote about {tool_name} instead of calling it. "
                        "Do not describe a tool and do not ask for "
                        "permission — the user already asked. Reply with "
                        "only the call line, then answer after the result.")})
                    continue

        seen["used"].update(c.get("name") for c in (calls or []))

        if not calls:
            # nothing left to do — stream a clean final answer to the UI.
            # Checked before it is sent, never after: a fabricated answer the
            # user has already read cannot be taken back.
            problem = ""
            if text and _is_fabricated(text):
                problem = _PLACEHOLDER_CORRECTION
            elif text:
                fake = _invented_urls(text, "\n".join(tool_output))
                if fake:
                    problem = (_INVENTED_URL_CORRECTION
                               + "\nThe invented link was: " + fake[0])
            if problem:
                if corrected:
                    send({"type": "delta", "text": _PLACEHOLDER_GIVE_UP})
                    return _PLACEHOLDER_GIVE_UP
                corrected = True
                messages.append({"role": "assistant", "content": text})
                messages.append({"role": "user", "content": problem})
                continue
            if text:
                send({"type": "delta", "text": text})
                return text
            return local.chat_stream(messages, system_prompt(query),
                                     lambda p: send({"type": "delta", "text": p}))

        messages.append({
            "role": "assistant",
            "content": text or "",
            "tool_calls": [{
                "id": c["id"], "type": "function",
                "function": {"name": c["name"],
                             "arguments": json.dumps(c["args"], ensure_ascii=False)},
            } for c in calls],
        })
        for c in calls:
            try:
                out = exec_tool(c["name"], c["args"], send, confirm)
            except Exception as e:
                out = f"ERROR: {e}"
            tool_output.append(str(out))
            messages.append({"role": "tool", "tool_call_id": c["id"],
                             "name": c["name"], "content": str(out)[:8000]})
    return "Hit the step limit — try describing the task more simply."


# The conversation being answered on this thread. save_chat reads it.
#
# Each chat window is one connection, served by one thread, so the history
# that thread holds IS the conversation — every message the user sent and
# every answer they were shown, exactly as they saw them. Asked to "make a
# text file of this chat", the model called write_file and typed the
# conversation out from memory; the file it made had none of the chat in
# it. A 7B cannot reproduce twenty turns verbatim, and should not be asked
# to. The record already exists; this is how a tool gets to it.
_CONVERSATION = threading.local()


def _last_user_message() -> str:
    for m in reversed(getattr(_CONVERSATION, "history", None) or []):
        if m.get("role") == "user" and isinstance(m.get("content"), str):
            return m["content"].strip()[:500]
    return ""


def _save_chat(send, name: str = "", folder_name: str = "") -> str:
    history = getattr(_CONVERSATION, "history", None)
    turns = [m for m in (history or [])
             if m.get("role") in ("user", "assistant")
             and isinstance(m.get("content"), str) and m["content"].strip()]
    # The request to save is itself the last user message; a transcript
    # that ends with "save this chat" is still the chat, so it stays.
    if len(turns) < 2:
        return "ERROR: there is nothing in this conversation to save yet."
    home = system_tools._user_home()
    # 25 September: "name it test 4 and put it on the Desktop" was saved as
    # "OSprime chat …" in Documents, and the model then had to explain why.
    # Three folders by name only — never a path, so this cannot be pointed
    # anywhere else — and a name stripped to something a file can be called.
    places = {"desktop": "Desktop", "documents": "Documents", "downloads": "Downloads"}
    folder = home / places.get(folder_name.strip().lower().strip("~/"), "Documents")
    stem = re.sub(r"[^\w \-().]+", "", name.strip())[:80].strip(" .")
    if stem.lower().endswith(".txt"):
        stem = stem[:-4]
    try:
        folder.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y-%m-%d %H-%M")
        base = stem or f"OSprime chat {stamp}"
        path = folder / f"{base}.txt"
        n = 2
        while path.exists():        # never overwrites
            path = folder / f"{base} ({n}).txt"
            n += 1
        lines = [f"OSprime conversation — {time.strftime('%Y-%m-%d %H:%M')}", ""]
        for m in turns:
            who = "You" if m["role"] == "user" else "OSprime"
            lines += [f"{who}:", m["content"].strip(), ""]
        path.write_text("\n".join(lines), encoding="utf-8")
    except OSError as e:
        return f"ERROR: could not save the conversation: {e}"
    send({"type": "tool_use", "name": "save", "detail": str(path)})
    return (f"Saved {len(turns)} messages to {path}. Tell the user where "
            "the file is.")


def handle_client(conn: socket.socket):
    history = []
    _CONVERSATION.history = history
    f = conn.makefile("rwb")
    send_lock = threading.Lock()
    pending = {}            # confirm id -> {"event":..., "approved":...}
    work_q = queue.Queue()

    def send(obj):
        with send_lock:
            f.write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
            f.flush()

    def confirm(prompt, detail=""):
        cid = uuid.uuid4().hex[:8]
        ev = threading.Event()
        pending[cid] = {"event": ev, "approved": False}
        send({"type": "confirm", "id": cid, "text": prompt, "detail": detail})
        ev.wait(timeout=300)
        return pending.pop(cid, {}).get("approved", False)

    def reader():
        try:
            for line in f:
                msg = json.loads(line)
                t = msg.get("type")
                if t == "confirm_response":
                    slot = pending.get(msg.get("id"))
                    if slot:
                        slot["approved"] = bool(msg.get("approved"))
                        slot["event"].set()
                elif t == "poll_notifications":
                    send({"type": "notifications",
                          "items": JOBS.drain_notifications() + drain_proactive()})
                elif t == "user_message":
                    work_q.put(msg["text"])
        except (ConnectionError, json.JSONDecodeError, ValueError):
            pass
        finally:
            work_q.put(None)   # sentinel: stop worker

    threading.Thread(target=reader, daemon=True).start()

    while True:
        text = work_q.get()
        if text is None:
            break
        history.append({"role": "user", "content": text})
        note_activity()
        # The companion shows "working" for the whole turn, including the
        # tool calls. Before today a long answer gave no sign that anything
        # was happening unless the chat window was open and in front.
        companion.working()
        try:
            backend = router.pick_backend(text)
            if backend == "claude":
                answer = handle_claude(history, send, confirm, query=text)
            else:
                answer = handle_local(history, send, confirm, query=text)
            history.append({"role": "assistant", "content": answer})
            send({"type": "assistant", "text": answer, "backend": backend})
        except Exception as e:
            send({"type": "error", "text": str(e)})
        finally:
            # In a finally, not after the except: a turn that fails still
            # ends, and a companion left spinning on a failure would be
            # claiming the machine is busy with work that is already over.
            companion.done()
            # Again at the end, not only at the start. A five-minute answer
            # would otherwise leave the quiet window already expired at the
            # exact moment the user starts reading it.
            note_activity()
        # An update or a rollback asked for a restart. It waits until here,
        # with the answer already delivered, because restarting this service
        # is restarting the thing that would have said so.
        _run_pending_restart()

    conn.close()
    if len(history) >= 2:
        threading.Thread(target=consolidate, args=(history,), daemon=True).start()


_RESTART_PENDING = threading.Event()


def _restart_when_this_turn_ends():
    """Ask for a restart without taking one now."""
    _RESTART_PENDING.set()


def _run_pending_restart():
    """Restart the services, a moment after the user has been answered.

    The delay is not superstition. `send` has written the answer to the
    socket, but the web server still has to read it and push it to the
    page; restarting osprime-web in that window drops the reply on the
    floor and the chat goes blank — which is exactly the failure this is
    here to stop. A second is far longer than that hand-off needs.
    """
    if not _RESTART_PENDING.is_set():
        return
    _RESTART_PENDING.clear()

    def go():
        time.sleep(1.0)
        try:
            updater.restart_services()
        except Exception as e:
            # This process is about to be replaced, so there is nobody left
            # to tell. The journal is the only place this can land.
            print(f"restart after update failed: {e}", flush=True)

    threading.Thread(target=go, daemon=True).start()


def check_privileges() -> list:
    """Can the agent still do its job as an ordinary user?

    The services used to run as root, so everything was writable and every
    sudo call was a no-op. Moving to the osprime user turns each of those
    assumptions into a permission that either exists or does not — and a
    missing one fails as EACCES buried inside a tool, which is this
    project's worst failure mode.

    So they are checked once, out loud, at startup. Problems are returned
    rather than raised: a machine with a broken audit log should still talk
    to its owner, and tell them what is wrong.
    """
    problems = []
    for path in (MEMORY_DB.parent, AUDIT_PATH.parent, CONFIG_PATH.parent,
                 TOOL_ERRORS.parent):
        try:
            path.mkdir(parents=True, exist_ok=True)
            probe = path / ".osprime-write-test"
            probe.write_text("x", encoding="utf-8")
            probe.unlink()
        except Exception as e:
            problems.append(f"cannot write {path}: {type(e).__name__}")

    # The sudo rules the tools depend on. `sudo -nl <cmd>` asks about that
    # exact command, which is the only question worth asking — a probe with
    # a different command answers about a different permission.
    if os.geteuid() != 0 and shutil.which("sudo"):
        for label, cmd in (
                ("set the clock", ["/usr/bin/timedatectl", "set-ntp", "true"]),
                ("manage Wi-Fi", ["/usr/bin/nmcli"]),
                ("turn the computer off", ["/usr/bin/systemctl", "poweroff"]),
                ("install updates", ["/usr/bin/python3",
                                     "/opt/osprime/agent/updater.py",
                                     "--install"])):
            r = subprocess.run(["sudo", "-nl"] + cmd,
                               capture_output=True, text=True)
            if r.returncode != 0:
                problems.append(f"not allowed to {label}")
    return problems


def prefix_budget() -> dict:
    """How much of the model's context the fixed prefix eats.

    This exists because of a failure that produced no error anywhere. Adding
    fourteen tools with careful descriptions pushed the system prompt plus
    the tool definitions past the 4096-token context. llama-server did not
    complain; it truncated. What fell off the end was the tool list, so the
    model genuinely had no tools and said so politely: "I don't have the
    capability to shut down the computer." Every layer behaved correctly and
    the machine quietly lost half its abilities.

    Three tokens per character is deliberately pessimistic for JSON, which
    is dense with punctuation. An estimate that errs towards "too big" is
    the right kind of wrong here.
    """
    # The WORST TURN, not the whole tool list.
    #
    # Since the grouping went in, no turn sends all 65 tools — so measuring
    # all 65 would fail a build that is fine. But measuring the average, or
    # one group, would pass a build that breaks on the one question somebody
    # actually asks. toolgroups.worst_case() returns the largest combination
    # of groups that can be sent together, which is the number that has to
    # fit.
    try:
        skill_sets = [s.get("tools", []) for s in skills_mod.load()]
    except Exception:
        skill_sets = []
    worst_chars, worst_groups = toolgroups.worst_case(TOOLS, skill_sets)
    chars = worst_chars + len(system_prompt(""))
    tokens = chars // 3
    ctx = 4096
    try:
        for line in pathlib.Path("/etc/osprime/model.env").read_text(
                encoding="utf-8").splitlines():
            if line.strip().startswith("MODEL_CTX="):
                ctx = int(line.split("=", 1)[1].strip().strip('"'))
    except Exception:
        ctx = int(os.environ.get("MODEL_CTX", "8192"))
    return {"tools": len(TOOLS),
            "worst_groups": list(worst_groups),
            "worst_tools": len(toolgroups.CORE) + sum(
                len(toolgroups.GROUPS.get(g, [])) for g in worst_groups),
            "ungrouped": toolgroups.ungrouped(TOOLS),
            "prefix_tokens": tokens, "context": ctx,
            "share": round(tokens / ctx, 2),
            # Half the window is the line. Past it there is not enough room
            # left for the conversation and the tool results it produces.
            "ok": tokens < ctx * 0.5}


def warm_up():
    """Read the system prompt into the engine before anyone asks anything.

    The wait before the first answer was fifteen to twenty seconds, and
    almost none of it was writing the reply. It was reading the question:
    the system prompt and the tool definitions come to roughly two thousand
    tokens, they are identical on every request, and the engine was reading
    them from scratch each time a session started.

    Sending them once at startup puts them in the engine's cache while the
    user is still looking at the desktop. --cache-reuse then keeps them
    there, so the first real question only has to process the handful of
    words the user actually typed.

    Costs one request nobody sees. Fails silently on purpose — a machine
    with no engine running must still boot to a working desktop, and this
    is an optimisation, not a dependency.
    """
    for attempt in range(30):
        try:
            if local.available():
                break
        except Exception:
            pass
        time.sleep(2)
    else:
        return
    b = prefix_budget()
    if not b["ok"]:
        print(f"WARNING: {b['tools']} tools and the system prompt come to "
              f"~{b['prefix_tokens']} tokens against a context of "
              f"{b['context']} ({int(b['share'] * 100)}%). The engine will "
              "truncate, and what it drops is the tool list — the assistant "
              "will politely deny abilities it has. Raise MODEL_CTX in "
              "/etc/osprime/model.env or shorten the tool descriptions.")
    else:
        print(f"prefix: ~{b['prefix_tokens']} tokens of {b['context']} "
              f"({int(b['share'] * 100)}%)")
    try:
        # The same prefix a real turn sends, so the cache that gets filled
        # is the one that will be hit. An empty query keeps the per-request
        # tail (memory, skills) out of it, which is the part that changes.
        local.chat([{"role": "user", "content": "hello"}],
                   system_prompt(""), TOOLS)
        print("warm-up done: the system prompt is cached")
    except Exception as e:
        print(f"warm-up skipped: {e}")


def _recover_then_warm_up():
    """A vision engine left holding the graphics card — an agent killed in
    the middle of a photo — gets the card taken back before anything else.
    systemd usually does this already (docs/MODELS.md); this is the rest."""
    try:
        import engines
        engines.recover()
    except Exception as e:
        print(f"engine recovery skipped: {e}")
    try:
        import pyenv
        err = pyenv.ensure()
        print("python environment: " + (f"not created — {err}" if err
              else str(pyenv.root())), flush=True)
    except Exception as e:
        print(f"python environment skipped: {e}")
    warm_up()


def main():
    sock_dir = pathlib.Path(SOCKET_PATH).parent
    sock_dir.mkdir(parents=True, exist_ok=True)
    if os.path.exists(SOCKET_PATH):
        os.unlink(SOCKET_PATH)
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(SOCKET_PATH)
    os.chmod(SOCKET_PATH, 0o660)
    server.listen(8)
    # A state file left behind by an agent that was killed mid-turn — by an
    # update, or a crash — would have the companion spinning for a turn that
    # no longer exists. Starting clean is one line and costs nothing.
    companion.reset()
    proactive.ProactiveMonitor(
        notify=push_proactive, run_agent=run_agent_once,
        config_path=CONFIG_PATH, last_activity=last_activity).start()
    for problem in check_privileges():
        print(f"WARNING: {problem}")
        _log_tool_error("startup", {}, f"privilege check: {problem}")
    threading.Thread(target=_recover_then_warm_up, daemon=True).start()
    print(f"osprime-agent listening as uid {os.geteuid()} on {SOCKET_PATH}")
    while True:
        conn, _ = server.accept()
        threading.Thread(target=handle_client, args=(conn,), daemon=True).start()


if __name__ == "__main__":
    main()
