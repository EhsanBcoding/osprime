"""OSprime desktop control: let the agent launch and manage real GUI windows
on the Wayland session (labwc + wlr protocols).

Uses wlrctl when available for window listing/closing; falls back to plain
process management so the tools still work in a bare session.
"""

import os
import pathlib
import re
import shutil
import signal
import subprocess
import time

def _browser_script():
    """The one place the browser's flags live.

    Chromium needs --no-sandbox, --test-type and a Wayland platform to start
    without a full session, and it needs a stale SingletonLock cleared —
    installing copies a home directory whose hostname was archiso, and
    chromium refuses to start when the lock names another machine.
    osprime-browser.sh has all of that. This module was launching bare
    `chromium` instead, so every page the assistant opened failed exactly
    the way the script's own comment says the menu entry used to fail.
    """
    p = pathlib.Path(__file__).resolve().parent.parent / "shell" / "osprime-browser.sh"
    return ["bash", str(p)] if p.is_file() else None


# friendly name -> list of candidate commands (first installed one wins)
APPS = {
    # osprime-browser.sh is put at the front of the browser entries below,
    # because the script's path depends on where OSprime is installed. The
    # bare-chromium commands stay as a last resort.
    "browser":  [["chromium", "--ozone-platform=wayland", "--new-window"],
                 ["chromium-browser", "--ozone-platform=wayland", "--new-window"],
                 ["google-chrome", "--ozone-platform=wayland", "--new-window"],
                 ["firefox"]],
    "chromium": [["chromium"], ["chromium-browser"]],
    "firefox":  [["firefox"]],
    "terminal": [["foot"], ["xterm"], ["gnome-terminal"]],
    "files":    [["thunar"], ["nautilus"], ["pcmanfm"]],
    "editor":   [["mousepad"], ["gnome-text-editor"], ["gedit"], ["nano"]],
    "video":    [["mpv"], ["vlc"]],
    "image":    [["imv"], ["eog"], ["feh"]],
    "calculator": [["gnome-calculator"], ["galculator"]],
}

if _browser_script():
    APPS["browser"].insert(0, _browser_script())
    APPS["chromium"].insert(0, _browser_script())

_launched = {}   # name -> Popen


def _env():
    """The environment a graphical program needs to reach the screen.

    This used to guess: WAYLAND_DISPLAY=wayland-0 and
    XDG_RUNTIME_DIR=/run/user/<our own uid>. The agent runs as root, so that
    was /run/user/0 — a directory that does not exist. Every window this
    module opened therefore died the instant it started, while launch()
    cheerfully reported a pid. Asked to open a video, the assistant said
    "opened in the browser" and nothing appeared.

    system_tools already solved this by finding the compositor's socket.
    One implementation, imported rather than repeated, because two copies of
    this logic is how the first one stayed wrong.
    """
    try:
        import system_tools
        return system_tools._wayland_env()
    except Exception:
        e = os.environ.copy()
        e.setdefault("WAYLAND_DISPLAY", "wayland-0")
        e.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
        return e


def _desktop_user():
    """Who is logged in at the screen.

    Taken from the compositor's own runtime directory — /run/user/1000
    means uid 1000 — because that is the session the window will appear in,
    whatever user the agent happens to be.
    """
    try:
        import pwd
        run = _env().get("XDG_RUNTIME_DIR", "")
        uid = int(os.path.basename(run)) if run.startswith("/run/user/") else -1
        if uid >= 0:
            return pwd.getpwuid(uid)
    except Exception:
        pass
    try:
        import pwd
        return pwd.getpwnam("osprime")
    except Exception:
        return None


def _drop_privileges(pw):
    """Become the logged-in user before exec.

    Graphical programs must not run as root. The immediate symptom was a
    browser that would not start at all: its launch script appends to a log
    in /tmp, the file belonged to the user, and Linux stops root writing to
    another user's file inside a sticky directory — so the redirect failed
    and the script died before it could exec chromium.

    The quieter damage was worse. HOME was pointed at the user's home so
    the browser would find their profile, which meant root was creating
    root-owned files inside it; the user's own browser would have started
    failing later, for no visible reason.

    initgroups matters as much as setuid: video, render, input and seat are
    supplementary groups, and without them the program has no display.
    """
    def fn():
        os.initgroups(pw.pw_name, pw.pw_gid)
        os.setgid(pw.pw_gid)
        os.setuid(pw.pw_uid)
    return fn


def resolve(app: str):
    """The argv for one of the names in APPS, or None.

    Only APPS. This used to fall back to `[[app]]` — "any installed
    command" — which made open_app a second way to run anything on the
    machine: open_app("python3", ["-c", "..."]) was classified safe and
    never asked, while the same thing through run_shell was gated. An
    outside review found it; see docs/SECURITY.md, #4. Other applications
    are found by find_app() below, through the system's own definition of
    what an application is.
    """
    candidates = APPS.get(app)
    if not candidates:
        return None
    path = _env().get("PATH")
    for argv in candidates:
        exe = shutil.which(argv[0], path=path)
        if exe:
            return [exe] + argv[1:]
    return None


# --------------------------------------------------------------------------
# What counts as an application.
#
# Three sources, and deliberately nothing else:
#
#   1. the friendly names in APPS ("browser", "files", …);
#   2. applications installed from Flathub — the ones on the Apps page;
#   3. anything with a .desktop entry in a directory ROOT owns. That is the
#      standard Linux definition of "an application", and it is exactly the
#      list the Apps menu is built from.
#
# What is left out is bare executables: python3, bash, sh, curl, rm. Those
# are not applications, they are the shell's tools, and the shell has its
# own tool with its own gate.
#
# Why "a directory root owns": ~/.local/share/applications is also a
# standard place for .desktop files, and it is writable by the agent, which
# runs as the same user as the desktop. A .desktop file there with
# Exec=python3 -c … would put the hole straight back. So those are not
# trusted. The complete fix for "the agent can change its own user's files"
# is the agent not BEING the desktop user, which is the multi-user work in
# docs/SECURITY.md, not something this function can solve.
# --------------------------------------------------------------------------
TRUSTED_DESKTOP_DIRS = (
    "/usr/share/applications",
    "/usr/local/share/applications",
    "/var/lib/flatpak/exports/share/applications",
)

# A terminal's positional arguments are a COMMAND, not a file: `foot
# python3` runs python3, no dash required. So a terminal opens with no
# arguments at all, and running something in it is run_shell's job.
TERMINALS = {"terminal", "foot", "xterm", "gnome-terminal", "kgx",
             "konsole", "alacritty", "kitty", "footclient"}

MAX_ARGS = 20


def _desktop_entries() -> dict:
    """name -> path of the .desktop file, from trusted directories only."""
    found = {}
    for d in TRUSTED_DESKTOP_DIRS:
        base = pathlib.Path(d)
        if not base.is_dir():
            continue
        for f in sorted(base.glob("*.desktop")):
            try:
                fields = {}
                in_entry = False
                for line in f.read_text(encoding="utf-8",
                                        errors="replace").splitlines():
                    line = line.strip()
                    if line.startswith("["):
                        in_entry = line == "[Desktop Entry]"
                        continue
                    if in_entry and "=" in line:
                        k, v = line.split("=", 1)
                        fields.setdefault(k.strip(), v.strip())
            except OSError:
                continue
            # Helpers, settings panels and MIME handlers mark themselves
            # hidden. They are not things a person means by "open".
            if fields.get("Type", "Application") != "Application":
                continue
            if fields.get("NoDisplay", "").lower() == "true" or \
               fields.get("Hidden", "").lower() == "true":
                continue
            for key in (f.stem, fields.get("Name", "")):
                if key:
                    found.setdefault(key.lower(), str(f))
    return found


def _flatpak_apps() -> dict:
    """name -> flatpak application id, for what is installed from Flathub.

    Asked of flatpak itself rather than read from files, because flatpak's
    own list is the authority on what is installed and a file can be left
    behind by something that was removed.
    """
    try:
        import system_tools
        if not shutil.which("flatpak"):
            return {}
        code, out, _ = system_tools._flatpak(
            ["list", "--app", "--columns=application,name"], timeout=30)
        if code != 0:
            return {}
        found = {}
        for app_id, name in system_tools._rows(out, 2):
            if not app_id:
                continue
            for key in (app_id, name, app_id.rsplit(".", 1)[-1]):
                if key:
                    found.setdefault(key.lower(), app_id)
        return found
    except Exception:
        return {}


def find_app(app: str):
    """(argv, label) for a real application, or (None, reason).

    Order matters only for speed: APPS needs no lookup, the .desktop scan
    reads a few hundred small files, and flatpak is a subprocess.
    """
    name = (app or "").strip()
    key = name.lower()
    if not key:
        return None, "no application was named"

    argv = resolve(key)
    if argv:
        return argv, key

    entries = _desktop_entries()
    if key in entries:
        # `gio launch` rather than parsing Exec= ourselves. It applies the
        # field codes (%f, %u …) exactly as the menu would, so a file handed
        # over can only ever arrive where the application declared it takes
        # a file — never as a command.
        if shutil.which("gio", path=_env().get("PATH")):
            return ["gio", "launch", entries[key]], name
        if shutil.which("gtk-launch", path=_env().get("PATH")):
            return ["gtk-launch", pathlib.Path(entries[key]).name], name

    flat = _flatpak_apps()
    if key in flat:
        return ["flatpak", "run", flat[key]], name

    return None, "not an installed application"


def _is_terminal(app: str, argv: list) -> bool:
    """A terminal by name, by executable, or by what it calls itself.

    The last test is for Flathub terminals — org.gnome.Console and the like
    — whose ids are not in TERMINALS and whose positional arguments may also
    be commands. Matching "terminal" and "console" anywhere is broad on
    purpose: a false positive costs an app opening without a file, and a
    false negative is a shell.
    """
    ident = " ".join([app] + [str(a) for a in argv]).lower()
    if app.lower() in TERMINALS:
        return True
    if any(pathlib.Path(str(a)).name in TERMINALS for a in argv):
        return True
    return any(w in ident for w in ("terminal", "console", "konsole"))


def _safe_args(app: str, argv: list, args) -> tuple:
    """(clean_args, error). Arguments are things to OPEN, never options.

    A path or a web address is what an application is handed when you open
    something with it. Anything starting with "-" is an option, and options
    are where "open GIMP" turns into "run this": --command=sh, -e, --exec.
    None are accepted.
    """
    if not args:
        return [], ""
    if not isinstance(args, (list, tuple)):
        args = [args]
    if len(args) > MAX_ARGS:
        return None, f"too many things to open at once (at most {MAX_ARGS})"
    if _is_terminal(app, argv):
        return None, ("a terminal opens empty. To run a command, use "
                      "run_shell — it asks the user first when it should.")
    clean = []
    for a in args:
        a = str(a)
        if not a.strip() or "\x00" in a or "\n" in a:
            return None, "an empty or malformed argument"
        if a.lstrip().startswith("-"):
            return None, (f"'{a}' is an option, not a file or web address. "
                          "open_app only opens things; it does not pass "
                          "options to programs")
        scheme = re.match(r"^([a-zA-Z][a-zA-Z0-9+.-]*):", a)
        if scheme and scheme.group(1).lower() not in ("http", "https", "file"):
            return None, (f"'{a}' is not a file or a web address "
                          "(only http, https and file are opened)")
        clean.append(a)
    return clean, ""


def launch(app: str, args=None) -> str:
    argv, label = find_app(app)
    if not argv:
        avail = ", ".join(sorted(APPS))
        return (f"ERROR: '{app}' is {label}. open_app opens applications — "
                f"the built-in ones ({avail}), anything installed from the "
                "Apps page, or anything in the Apps menu. To see what is "
                "installed call list_apps. To run a command, that is "
                "run_shell, not open_app. THIS ACTION DID NOT HAPPEN.")
    extra, why = _safe_args(app, argv, args)
    if extra is None:
        return f"ERROR: {why}. THIS ACTION DID NOT HAPPEN."
    argv = argv + extra
    env = _env()
    demote = None
    pw = _desktop_user()
    if os.geteuid() == 0 and pw is not None and pw.pw_uid != 0:
        demote = _drop_privileges(pw)
        env["HOME"] = pw.pw_dir
        env["USER"] = env["LOGNAME"] = pw.pw_name

    try:
        # stderr is kept, not discarded. A window that fails to open says
        # why on stderr, and throwing that away is what made this look like
        # a working launch for weeks.
        p = subprocess.Popen(argv, env=env, stdout=subprocess.DEVNULL,
                             stderr=subprocess.PIPE, start_new_session=True,
                             preexec_fn=demote)
    except Exception as e:
        return f"ERROR: could not start {app}: {e}"

    # A pid is not a window, so wait a moment and look. But an exit is not a
    # failure either: chromium, handed a URL while another window already
    # owns the profile, passes the address to that window and exits 0. The
    # first version of this check called that a failure, so the assistant
    # reported "there is still an issue opening the browser" five times in a
    # row while the page was opening perfectly well each time.
    #
    # The exit CODE is the thing that distinguishes them.
    time.sleep(1.5)
    code = p.poll()
    if code is None:
        _launched[app] = p
        return f"{app} is open on screen (pid {p.pid})"
    if code == 0:
        return (f"{app} is open on screen — the page was handed to a window "
                "that was already running.")
    try:
        err = (p.stderr.read() or b"").decode("utf-8", "replace")
    except Exception:
        err = ""
    tail = " ".join(err.split())[-300:]
    return (f"ERROR: {app} exited straight away with code {code}. "
            f"{tail or 'It gave no reason.'} THIS DID NOT OPEN — do not tell "
            "the user it did.")


def _wlrctl(*args):
    if not shutil.which("wlrctl"):
        return None
    try:
        r = subprocess.run(["wlrctl", *args], env=_env(), capture_output=True,
                           text=True, timeout=10)
        return (r.stdout + r.stderr).strip()
    except Exception:
        return None


def list_windows() -> str:
    out = _wlrctl("window", "list")
    if out:
        return out or "(no windows)"
    alive = [f"{n} (pid {p.pid})" for n, p in _launched.items() if p.poll() is None]
    return "\n".join(alive) or "(no windows launched by OSprime)"


def close_window(app: str) -> str:
    out = _wlrctl("window", "close", f"app_id:{app}")
    if out is not None:
        return f"closed {app}"
    p = _launched.get(app)
    if p and p.poll() is None:
        os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        return f"closed {app}"
    return f"no running window for {app}"


def open_url(url: str) -> str:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    # "browser" first: that entry is the script with the flags chromium
    # needs. Going straight to "chromium" got the bare command.
    for browser in ("browser", "chromium", "firefox"):
        if resolve(browser):
            return launch(browser, [url])
    return "ERROR: no browser is installed."
