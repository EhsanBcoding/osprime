"""Who has the graphics card right now. docs/MODELS.md, step 2.

OSprime talks through one main model — the text 7B — and reaches specialist
models through tools. On the reference laptop (8 GB NVIDIA) two 7B models do
not fit on the card together, and measuring on 24 September settled how to
share it: swap. To look at a photo, stop the main engine, start the vision
engine, describe, and bring the main engine back — about 6 to 10 seconds in
all, against 26 to 154 seconds for the alternatives. (Round 2 in MODELS.md.)

This module is the only place that knows that. Everything else asks it:

    with engines.main_engine():   # talking to the main model
        ...
    with engines.gpu_slot() as vision_url:   # a specialist needs the card
        ...

`main_engine` is shared — any number of conversations at once. `gpu_slot` is
exclusive — it waits for them to finish their current request, takes the
card, and while it holds it every new request waits instead of failing. It
is the scheduler the 24 September discussion asked to keep separate from
the agent: on a card big enough for both, `gpu_slot` would simply not stop
anything, and nothing that calls it would change.

THE ONE RULE: the main engine always comes back. In a `finally`, whatever
happened in between. And because a `finally` cannot run in a process that
has died, systemd enforces it too: the two services declare Conflicts= on
each other, and the agent's unit Wants= the main engine — so if the agent
crashes in the middle of a swap, systemd restarts it, which starts the main
engine, which stops vision. The measurement script's test for this is in
tests/test_measure_models.sh; this module's is tests/test_engines.py.
"""

import contextlib
import json
import os
import pathlib
import subprocess
import threading
import time
import urllib.request

VISION_ENV = pathlib.Path(os.environ.get("OSPRIME_VISION_ENV",
                                         "/etc/osprime/vision.env"))
MAIN_UNIT = "osprime-model"
VISION_UNIT = "osprime-vision"
MAIN_HEALTH = os.environ.get("OSPRIME_MAIN_HEALTH", "http://127.0.0.1:8087/health")
START_LIMIT = int(os.environ.get("OSPRIME_ENGINE_START_LIMIT", "240"))
WAIT_LIMIT = 600     # how long a conversation waits for the card, at most
# One line per look, so Settings can say when the last one was and how it
# went. A vision engine that fails is otherwise invisible until someone
# asks about a photo and gets an apology.
LOG = pathlib.Path(os.environ.get("OSPRIME_ENGINES_LOG",
                                  "/var/lib/osprime/engines.log"))
LOG_KEEP = 200


# --------------------------------------------------------------------------
# configuration
# --------------------------------------------------------------------------
def _read_env(path: pathlib.Path) -> dict:
    out = {}
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"')
    except OSError:
        pass
    return out


def vision_config():
    """The separate vision engine, if one is installed and its files exist.

    Checked against the files, not just the settings: a vision.env pointing
    at a deleted model would otherwise make every photo request stop the
    main engine to start something that cannot load.
    """
    cfg = _read_env(VISION_ENV)
    model = pathlib.Path(cfg.get("MODEL_PATH", ""))
    proj = pathlib.Path(cfg.get("MODEL_MMPROJ", ""))
    if not (cfg and model.is_file() and proj.is_file()):
        return None
    port = cfg.get("MODEL_PORT", "8088")
    try:
        max_px = int(cfg.get("OSPRIME_VISION_MAX_PX", "1280"))
    except ValueError:
        max_px = 1280
    return {"model": str(model), "mmproj": str(proj),
            "url": f"http://127.0.0.1:{port}",
            "tier": cfg.get("OSPRIME_VISION_TIER", ""),
            "label": cfg.get("OSPRIME_VISION_LABEL", model.name),
            "mode": cfg.get("OSPRIME_VISION_MODE", "swap"),
            "gpu": cfg.get("OSPRIME_GPU_LAYERS", "0") not in ("", "0"),
            "max_px": max_px}


def main_sees() -> bool:
    """The old arrangement: the main model is itself a vision model."""
    try:
        import hardware
        return bool(hardware.installed().get("sees"))
    except Exception:
        return False


def can_see() -> bool:
    return vision_config() is not None or main_sees()


# --------------------------------------------------------------------------
# the lock: many readers (conversations), one writer (a specialist)
# --------------------------------------------------------------------------
class _Slot:
    """A readers/writer lock that prefers the writer.

    Writer-preferring so a photo request is not starved by a stream of chat
    requests. Never taken re-entrantly by the code in this project: it is
    held only around a single HTTP request (local._post, chat_stream) or a
    single swap, so a nested acquire — which would deadlock behind a waiting
    writer — cannot happen.
    """

    def __init__(self):
        self._c = threading.Condition()
        self._readers = 0
        self._writer = False
        self._waiting_writers = 0

    def acquire_read(self, timeout=WAIT_LIMIT):
        end = time.time() + timeout
        with self._c:
            while self._writer or self._waiting_writers:
                left = end - time.time()
                if left <= 0:
                    raise TimeoutError("the graphics card is busy")
                self._c.wait(left)
            self._readers += 1

    def release_read(self):
        with self._c:
            self._readers -= 1
            if self._readers == 0:
                self._c.notify_all()

    def acquire_write(self, timeout=WAIT_LIMIT):
        end = time.time() + timeout
        with self._c:
            self._waiting_writers += 1
            try:
                while self._writer or self._readers:
                    left = end - time.time()
                    if left <= 0:
                        raise TimeoutError("the graphics card is busy")
                    self._c.wait(left)
                self._writer = True
            finally:
                self._waiting_writers -= 1

    def release_write(self):
        with self._c:
            self._writer = False
            self._c.notify_all()

    @property
    def swapped(self) -> bool:
        return self._writer


SLOT = _Slot()


@contextlib.contextmanager
def main_engine():
    """Around one request to the main engine. Waits out a swap."""
    SLOT.acquire_read()
    try:
        yield
    finally:
        SLOT.release_read()


# --------------------------------------------------------------------------
# the swap
# --------------------------------------------------------------------------
def _systemctl(*args) -> bool:
    """Start one of the two engine units, by exact name.

    `sudo -n`: the agent runs as the unprivileged osprime user, and the sudo
    rules name exactly `systemctl start osprime-model` and `systemctl start
    osprime-vision` — nothing wider. -n so a missing rule fails at once
    instead of waiting for a password nobody will type.
    """
    cmd = ["systemctl", *args]
    if os.geteuid() != 0:
        cmd = ["sudo", "-n"] + cmd
    try:
        return subprocess.run(cmd, capture_output=True, timeout=120).returncode == 0
    except Exception:
        return False


def _healthy(url: str, limit: int) -> bool:
    end = time.time() + limit
    while time.time() < end:
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                if r.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(1)
    return False


def _bring_main_back() -> bool:
    """Start the main engine — which, by Conflicts=, stops vision."""
    _systemctl("start", MAIN_UNIT)
    ok = _healthy(MAIN_HEALTH, START_LIMIT)
    if not ok:
        # Once more, with restart: it also clears a unit stuck half-started.
        _systemctl("restart", MAIN_UNIT)
        ok = _healthy(MAIN_HEALTH, START_LIMIT)
    print("engines: main engine " + ("back" if ok else "DID NOT COME BACK"),
          flush=True)
    return ok


def _log(entry: dict):
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        lines = []
        if LOG.is_file():
            lines = LOG.read_text(encoding="utf-8").splitlines()[-(LOG_KEEP - 1):]
        lines.append(json.dumps(entry))
        LOG.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except Exception:
        pass     # a log that cannot be written must never cost the photo


def last_look():
    """The most recent look, as logged: when, ok, and how long each part took."""
    try:
        for line in reversed(LOG.read_text(encoding="utf-8").splitlines()):
            if line.strip():
                return json.loads(line)
    except Exception:
        pass
    return None


@contextlib.contextmanager
def gpu_slot():
    """Take the card for the vision engine; always give it back.

    Yields the vision engine's base URL. Raises RuntimeError when vision
    could not be started — AFTER the main engine is back, so the caller can
    report the failure to a user whose conversation still works.
    """
    cfg = vision_config()
    if cfg is None:
        raise RuntimeError("no separate vision engine is installed")
    SLOT.acquire_write()
    entry = {"at": time.strftime("%Y-%m-%dT%H:%M:%S"), "ok": False,
             "vision": cfg["label"]}
    t0 = time.time()
    try:
        # Conflicts= makes this one command stop the main engine first.
        started = _systemctl("start", VISION_UNIT)
        if not started or not _healthy(f"{cfg['url']}/health", START_LIMIT):
            raise RuntimeError("the vision engine did not start")
        entry["load_s"] = round(time.time() - t0, 1)
        print(f"engines: vision on the card after {entry['load_s']:.0f}s",
              flush=True)
        t1 = time.time()
        yield cfg["url"]
        entry["answer_s"] = round(time.time() - t1, 1)
        entry["ok"] = True
    except BaseException as e:
        entry["error"] = str(e)[:200] or type(e).__name__
        raise
    finally:
        try:
            t2 = time.time()
            back = _bring_main_back()
            entry["back_s"] = round(time.time() - t2, 1)
            entry["main_back"] = back
            entry["total_s"] = round(time.time() - t0, 1)
            _log(entry)
        finally:
            SLOT.release_write()


def recover():
    """At agent start: if vision was left holding the card, take it back.

    systemd already does this in the usual case — restarting the agent pulls
    in the main engine, which by Conflicts= stops vision. This covers the
    unusual one: the agent restarted but the main engine was not pulled in.
    """
    try:
        active = subprocess.run(["systemctl", "is-active", VISION_UNIT],
                                capture_output=True, text=True, timeout=10
                                ).stdout.strip() == "active"
    except Exception:
        return
    if active:
        print("engines: vision was left running — bringing the main engine back",
              flush=True)
        _bring_main_back()


def status() -> dict:
    cfg = vision_config()
    return {"vision": cfg["label"] if cfg else None,
            "mode": cfg["mode"] if cfg else None,
            "main_sees": main_sees(),
            "swapped_now": SLOT.swapped,
            "last_look": last_look()}
