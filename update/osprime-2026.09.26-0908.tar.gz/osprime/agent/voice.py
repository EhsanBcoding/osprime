"""OSprime voice: local speech-to-text (whisper.cpp) and text-to-speech (piper).

Both engines are optional — if the binaries or models are missing, the
functions report it cleanly and the UI simply hides the voice controls.
No cloud services are used.
"""

import os
import pathlib
import shutil
import subprocess
import tempfile

MODELS_DIR = pathlib.Path(os.environ.get("OSPRIME_MODELS", "/var/lib/osprime/models"))

# whisper.cpp ships different binary names across versions
WHISPER_BINS = ("whisper-cli", "whisper", "main", "whisper.cpp")
PIPER_BINS = ("piper", "piper-tts")


def _which(names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return None


def _find_model(patterns):
    if not MODELS_DIR.is_dir():
        return None
    for pat in patterns:
        hits = sorted(MODELS_DIR.glob(pat))
        if hits:
            return hits[0]
    return None


def stt_available() -> bool:
    return bool(_which(WHISPER_BINS) and _find_model(("ggml-*.bin", "*.bin")))


def tts_available() -> bool:
    return bool(_which(PIPER_BINS) and _find_model(("*.onnx",)))


def status() -> dict:
    """What works, and — when something does not — which half is missing.

    "Voice is unavailable" is not an answer anyone can act on. The engine
    and the model are two separate things that go missing for two separate
    reasons, and the fix is different for each: one is a package, the other
    is a download. So say which.
    """
    binary = _which(WHISPER_BINS)
    model = _find_model(("ggml-*.bin", "*.bin"))
    if binary and model:
        why = ""
    elif not binary and not model:
        why = ("speech-to-text is not set up: install the whisper-cpp "
               "package, then run osprime-voice-setup.sh")
    elif not binary:
        why = ("the speech model is here but the engine is not: "
               "sudo pacman -Syu --needed whisper-cpp")
    else:
        why = (f"whisper is installed but there is no model in "
               f"{MODELS_DIR}: run osprime-voice-setup.sh")

    return {
        "stt": bool(binary and model), "tts": tts_available(),
        "whisper": binary, "piper": _which(PIPER_BINS),
        "models_dir": str(MODELS_DIR),
        "stt_why": why,
        # piper is AUR-only, so OSprime cannot install it from the official
        # repositories. Not a bug and not a to-do: a stated limit.
        "tts_why": "" if tts_available() else
                   "reading answers aloud needs piper, which Arch only "
                   "packages in the AUR, so OSprime does not install it",
    }


def _to_wav16k(src: str, dst: str) -> bool:
    """Convert any browser-recorded audio to 16 kHz mono WAV (whisper needs it)."""
    ff = shutil.which("ffmpeg")
    if not ff:
        return False
    r = subprocess.run([ff, "-y", "-i", src, "-ar", "16000", "-ac", "1", dst],
                       capture_output=True, timeout=120)
    return r.returncode == 0 and os.path.getsize(dst) > 0


def transcribe(audio_bytes: bytes, suffix: str = ".webm", lang: str = "auto") -> str:
    """Return recognized text, or a string starting with 'ERROR:' on failure."""
    binary = _which(WHISPER_BINS)
    model = _find_model(("ggml-*.bin", "*.bin"))
    if not binary:
        return "ERROR: whisper.cpp is not installed"
    if not model:
        return f"ERROR: no whisper model found in {MODELS_DIR}"

    with tempfile.TemporaryDirectory() as td:
        raw = os.path.join(td, "in" + suffix)
        wav = os.path.join(td, "in.wav")
        with open(raw, "wb") as f:
            f.write(audio_bytes)
        if not _to_wav16k(raw, wav):
            if suffix.lower() == ".wav":
                shutil.copy(raw, wav)   # maybe already fine
            else:
                return "ERROR: ffmpeg is required to convert recorded audio"
        cmd = [binary, "-m", str(model), "-f", wav, "-nt", "-otxt", "-of",
               os.path.join(td, "out")]
        if lang and lang != "auto":
            cmd += ["-l", lang]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        except Exception as e:
            return f"ERROR: whisper failed: {e}"
        out_txt = pathlib.Path(td, "out.txt")
        if out_txt.exists():
            text = out_txt.read_text(encoding="utf-8", errors="replace").strip()
        else:
            text = (r.stdout or "").strip()
        if not text:
            return "ERROR: nothing recognized"
        return text


def synthesize(text: str) -> bytes:
    """Return WAV audio bytes for the text, or b'' if TTS is unavailable."""
    binary = _which(PIPER_BINS)
    model = _find_model(("*.onnx",))
    if not binary or not model or not text.strip():
        return b""
    with tempfile.TemporaryDirectory() as td:
        out = os.path.join(td, "out.wav")
        try:
            subprocess.run([binary, "--model", str(model), "--output_file", out],
                           input=text.encode("utf-8"), capture_output=True, timeout=180)
        except Exception:
            return b""
        p = pathlib.Path(out)
        return p.read_bytes() if p.exists() else b""
