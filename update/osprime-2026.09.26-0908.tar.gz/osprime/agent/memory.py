"""OSprime long-term memory: SQLite + FTS5 full-text search.

Stores durable facts and retrieves the most relevant ones for a given query,
so the model gets a small, focused set of memories instead of the whole list.
Stdlib only (sqlite3 ships with Python)."""

import datetime
import json
import pathlib
import re
import sqlite3
import threading

CAP = 5000  # keep at most this many memories (oldest pruned)


class Memory:
    def __init__(self, db_path):
        self.db_path = str(db_path)
        pathlib.Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init()

    def _conn(self):
        c = getattr(self._local, "c", None)
        if c is None:
            c = sqlite3.connect(self.db_path, timeout=5.0)
            c.execute("PRAGMA journal_mode=WAL")
            self._local.c = c
        return c

    def _init(self):
        c = self._conn()
        c.execute("CREATE TABLE IF NOT EXISTS memories "
                  "(id INTEGER PRIMARY KEY, fact TEXT UNIQUE, ts TEXT)")
        c.execute("CREATE VIRTUAL TABLE IF NOT EXISTS mem_fts USING fts5(fact)")
        c.commit()

    def add(self, fact: str) -> bool:
        fact = (fact or "").strip()
        if not fact:
            return False
        c = self._conn()
        try:
            cur = c.execute("INSERT INTO memories(fact, ts) VALUES(?, ?)",
                            (fact, datetime.date.today().isoformat()))
            c.execute("INSERT INTO mem_fts(rowid, fact) VALUES(?, ?)",
                      (cur.lastrowid, fact))
            c.commit()
        except sqlite3.IntegrityError:
            return False  # UNIQUE -> duplicate
        self._prune()
        return True

    def _prune(self):
        c = self._conn()
        n = c.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        if n > CAP:
            ids = [r[0] for r in c.execute(
                "SELECT id FROM memories ORDER BY id ASC LIMIT ?", (n - CAP,))]
            c.executemany("DELETE FROM memories WHERE id=?", [(i,) for i in ids])
            c.executemany("DELETE FROM mem_fts WHERE rowid=?", [(i,) for i in ids])
            c.commit()

    def recent(self, limit: int = 8):
        rows = self._conn().execute(
            "SELECT fact, ts FROM memories ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [{"fact": r[0], "t": r[1]} for r in rows]

    def search(self, query: str, limit: int = 8):
        toks = [t for t in re.findall(r"\w+", query or "", re.UNICODE)
                if len(t) >= 2][:12]
        if not toks:
            return []
        match = " OR ".join('"' + t.replace('"', '') + '"' for t in toks)
        try:
            rows = self._conn().execute(
                "SELECT m.fact, m.ts FROM mem_fts f "
                "JOIN memories m ON m.id = f.rowid "
                "WHERE mem_fts MATCH ? ORDER BY rank LIMIT ?",
                (match, limit)).fetchall()
        except sqlite3.OperationalError:
            return []
        return [{"fact": r[0], "t": r[1]} for r in rows]

    def count(self) -> int:
        return self._conn().execute("SELECT COUNT(*) FROM memories").fetchone()[0]

    # ---- what the user can see and undo --------------------------------
    #
    # recent() and search() return facts without their ids, which is right
    # for building a prompt and useless for anything the user acts on: you
    # cannot delete a row you cannot name. These three exist so the Control
    # Panel can show what the assistant has kept about someone and let them
    # take it back. A product that remembers you and gives you no way to
    # see or erase what it remembers is not one we want to ship.

    def all(self, limit: int = 200, offset: int = 0):
        rows = self._conn().execute(
            "SELECT id, fact, ts FROM memories ORDER BY id DESC "
            "LIMIT ? OFFSET ?", (limit, offset)).fetchall()
        return [{"id": r[0], "fact": r[1], "t": r[2]} for r in rows]

    def forget(self, mem_id: int) -> bool:
        """Delete one memory. Returns whether there was one to delete."""
        try:
            mem_id = int(mem_id)
        except (TypeError, ValueError):
            return False
        c = self._conn()
        cur = c.execute("DELETE FROM memories WHERE id=?", (mem_id,))
        # The search index is a separate table. Deleting from one and not
        # the other leaves a fact that is gone from the list and still
        # findable — the worst possible outcome for a delete button.
        c.execute("DELETE FROM mem_fts WHERE rowid=?", (mem_id,))
        c.commit()
        return cur.rowcount > 0

    def forget_all(self) -> int:
        """Delete every memory. Returns how many there were."""
        c = self._conn()
        n = self.count()
        c.execute("DELETE FROM memories")
        c.execute("DELETE FROM mem_fts")
        c.commit()
        return n

    def context(self, query: str = "", recent_n: int = 6, search_n: int = 6):
        """Recent + query-relevant memories, deduped, for the system prompt."""
        seen, out = set(), []
        for m in self.search(query, search_n) + self.recent(recent_n):
            if m["fact"] not in seen:
                seen.add(m["fact"])
                out.append(m)
        return out


def migrate_json(mem: "Memory", json_path) -> int:
    """One-time import of an old memory.json list. Returns count imported."""
    p = pathlib.Path(json_path)
    if not p.exists():
        return 0
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return 0
    n = 0
    for item in data:
        fact = item.get("fact") if isinstance(item, dict) else str(item)
        if fact and mem.add(fact):
            n += 1
    return n
