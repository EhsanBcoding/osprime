"""What the companion shows.

`shell/osprime-companion.py` draws a circle on the desktop in one of three
states. This is the other half: the agent says what is happening, and the
companion reads it.

A file rather than a socket, and read on a timer rather than pushed. The
reasons are all the same one — neither side may depend on the other being
alive:

  * the companion must keep working when the agent is stopped, restarted by
    an update, or has crashed. A missing file means idle, which is the
    correct answer for a machine whose assistant is not running;
  * the agent must not block, retry or log because a button is not there.
    Every function here swallows its own errors and returns None.

The two processes run as different users — the agent as root, the companion
as `osprime` — so the file is written world-readable on purpose.

States are exactly the three in docs/COMPANION.md: idle, working, attention.
Adding a fourth means changing the drawing, so it is a design decision, not
an import away.
"""

import json
import os
import pathlib
import tempfile
import time

import paths  # noqa: E402  — docs/ACCOUNTS.md
STATE_FILE = paths.companion_state()

_STATES = ("idle", "working", "attention")


def _read() -> dict:
    try:
        raw = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _write(state: str, attention: bool):
    """Replace the file atomically.

    A half-written file is read as no file at all, which puts the companion
    back to idle — a state it then keeps until the next write. Writing to a
    temporary name and renaming means the reader only ever sees a whole
    file, so a poll landing mid-write is not a stuck spinner.
    """
    if state not in _STATES:
        state = "idle"
    payload = json.dumps({"state": state,
                          "attention": bool(attention),
                          "at": time.time()})
    try:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=str(STATE_FILE.parent),
                                   prefix=".companion-")
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(payload)
        os.chmod(tmp, 0o644)      # the companion is a different user
        os.replace(tmp, STATE_FILE)
    except Exception:
        # Deliberately silent. A companion that cannot be told what is
        # happening shows idle; an agent that cannot tell it still answers.
        pass


def working():
    """A turn the user asked for has started."""
    _write("working", _read().get("attention", False))


def done():
    """That turn has finished. Whatever was waiting is still waiting."""
    _write("idle", _read().get("attention", False))


def attention(on: bool = True):
    """Something is waiting for the user — or has just been read.

    This is the whole of the notification. No window, no sound, no focus:
    the companion grows a dot and the user comes to it when they choose.
    Rule 3 of docs/COMPANION.md, and the line between this and Clippy.
    """
    cur = _read().get("state", "idle")
    _write(cur, on)


def reset():
    """Back to nothing. Called when the agent starts, because a state file
    left behind by a process that was killed mid-turn would otherwise have
    the companion spinning for a turn that no longer exists."""
    _write("idle", False)
