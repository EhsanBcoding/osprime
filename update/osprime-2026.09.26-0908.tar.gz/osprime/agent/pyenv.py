"""OSprime's own Python environment. docs/PYTHON.md.

25 September: asked to draw a picture with Python, the assistant needed five
approvals — pip refused (Arch's Python is "externally managed"), pacman had
no password, and it finally built a venv in ~/venv that nothing else knew
about. This gives it one place, known in advance:

  ~/.local/share/osprime/python   — a venv of the osprime user's own, so pip
                                    installs never need root, made with
                                    --system-site-packages so the libraries
                                    Arch installs (matplotlib, numpy, …) are
                                    already in it.

run_shell puts its bin/ first on PATH, so the `python` and `pip install`
the model writes anyway go here. /etc/profile.d/osprime-python.sh does the
same for the terminal. Installing still asks first: pip and python stay
moderate actions in permissions.py.

If the venv cannot be made, nothing else changes.
"""

import os
import pathlib
import subprocess
import sys

# The libraries shell/osprime-python-setup.sh installs from the Arch
# repositories. Import name -> what the prompt calls it.
COMMON = {"matplotlib": "matplotlib", "numpy": "numpy", "PIL": "pillow",
          "pandas": "pandas", "requests": "requests", "openpyxl": "openpyxl"}

import time

_STATE = {"libs": None, "at": 0.0}
LIBS_TTL = 600    # re-checked every ten minutes: the setup script may have run


def home() -> pathlib.Path:
    try:
        import system_tools
        return pathlib.Path(system_tools._user_home())
    except Exception:
        return pathlib.Path(os.path.expanduser("~"))


def root() -> pathlib.Path:
    override = os.environ.get("OSPRIME_PYENV")
    return pathlib.Path(override) if override else \
        home() / ".local" / "share" / "osprime" / "python"


def bin_dir() -> pathlib.Path:
    return root() / "bin"


def ready() -> bool:
    return (bin_dir() / "python").exists() and (bin_dir() / "pip").exists()


def ensure() -> str:
    """Create it once. Returns '' on success or when it already exists."""
    if ready():
        return ""
    try:
        root().parent.mkdir(parents=True, exist_ok=True)
        r = subprocess.run([sys.executable, "-m", "venv",
                            "--system-site-packages", str(root())],
                           capture_output=True, text=True, timeout=180)
        if r.returncode != 0 or not ready():
            return (r.stderr or r.stdout or "venv failed").strip()[-300:]
    except Exception as e:
        return f"{type(e).__name__}: {e}"
    _STATE["libs"] = None
    return ""


def shell_env(env: dict = None) -> dict:
    """The environment run_shell uses: this venv's bin/ first on PATH."""
    env = dict(os.environ if env is None else env)
    if ready():
        env["PATH"] = f"{bin_dir()}:{env.get('PATH', '/usr/bin:/bin')}"
        env["VIRTUAL_ENV"] = str(root())
        env.pop("PYTHONHOME", None)
    return env


def libraries(refresh: bool = False) -> dict:
    """Which of the common libraries this Python can import. Cached."""
    if (_STATE["libs"] is not None and not refresh
            and time.time() - _STATE["at"] < LIBS_TTL):
        return _STATE["libs"]
    py = str(bin_dir() / "python") if ready() else sys.executable
    code = ("import importlib.util, json; print(json.dumps({n: "
            "importlib.util.find_spec(n) is not None for n in %r}))" % list(COMMON))
    try:
        import json
        out = subprocess.run([py, "-c", code], capture_output=True, text=True,
                             timeout=30).stdout
        found = json.loads(out)
    except Exception:
        found = {}
    _STATE["libs"] = {COMMON[k]: bool(found.get(k)) for k in COMMON}
    _STATE["at"] = time.time()
    return _STATE["libs"]


def prompt_line() -> str:
    """One line for the system prompt, or '' when there is no venv."""
    if not ready():
        return ""
    libs = libraries()
    have = [k for k, v in libs.items() if v]
    missing = [k for k, v in libs.items() if not v]
    line = ("Python: `python` and `pip` in the shell are OSprime's own "
            "environment — `pip install <name>` works there without sudo. "
            "Never use pacman or sudo to get a Python library.")
    if have:
        line += " Already installed: " + ", ".join(have) + "."
    if missing:
        line += " Not installed: " + ", ".join(missing) + " (pip install them if needed)."
    return line


def status() -> dict:
    return {"venv": str(root()) if ready() else None, "libraries": libraries()}
