"""Making videos (docs/VIDEOS.md; Ehsan, 12 October).

The same two ways as pictures (agent/images.py), with their own cloud switch:

  * on this computer: Wan2.2 TI2V 5B (Apache 2.0) run by the stable-diffusion.cpp
    engine pictures already use. Offered only on a graphics card with 12 GB or
    more (Ehsan: "below 12 GB, say the card is weak and the cloud makes better
    videos"). About 12.9 GB to download, each file checked against its sha256.
  * in the cloud, on the person's own keys: Google (Veo), xAI (Grok Imagine),
    fal.ai, Higgsfield (Seedance, Kling, Hailuo, Wan…), Runway, Luma and
    Seedance directly through BytePlus. The chat keys from Google and xAI show
    up here by themselves.

A cloud video costs real money, so every one is asked about first, with the
price where the service publishes one (Ehsan, 12 October: "yes, good idea").

A video takes minutes. It is made in the background: the activity card shows
it, the chat stays free, and when it is ready it is shown in the chat that
asked (the page asks /api/videos/jobs), and Brainy gets a dot.
"""
import base64
import datetime
import json
import mimetypes
import os
import pathlib
import re
import shutil
import subprocess
import threading
import time
import uuid

import images
import paths

# ---------------------------------------------------------------------------
# the local model: pinned, checked
# ---------------------------------------------------------------------------
FILES = [
    {"role": "diffusion", "name": "Wan2.2-TI2V-5B-Q8_0.gguf",
     "url": "https://huggingface.co/QuantStack/Wan2.2-TI2V-5B-GGUF/resolve/main/Wan2.2-TI2V-5B-Q8_0.gguf",
     "sha256": "57bece983817ab2f957546683bb670f13be7d99022d45674840cd999a050ea8f", "size": 5400179040},
    {"role": "t5xxl", "name": "umt5-xxl-encoder-Q8_0.gguf",
     "url": "https://huggingface.co/city96/umt5-xxl-encoder-gguf/resolve/main/umt5-xxl-encoder-Q8_0.gguf",
     "sha256": "2521d4de0bf9e1cc6549866463ceae85e4ec3239bc6063f7488810be39033bbc", "size": 6043068256},
    {"role": "vae", "name": "wan2.2_vae.safetensors",
     "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/vae/"
            "wan2.2_vae.safetensors",
     "sha256": "e40321bd36b9709991dae2530eb4ac303dd168276980d3e9bc4b6e2b75fed156", "size": 1409400960},
]
MIN_VRAM_GB = 11.5         # "12 GB or more"; cards report a little less
WEAK = ("the graphics card in this computer is too weak for making videos (it needs 12 GB); "
        "a cloud service makes better videos — switch on Make videos in the cloud")
NEGATIVE = ("static, still image, blurry, low quality, jpeg artifacts, deformed, extra fingers, "
            "bad hands, bad face, distorted limbs, subtitles, text, watermark")
FPS = 24


def home() -> pathlib.Path:
    return paths.data_dir() / "videogen"


def local_ready() -> bool:
    return images._bin() is not None and all((home() / f["name"]).is_file() for f in FILES)


def gpu_ok():
    try:
        import hardware
        gpu = hardware.profile().get("gpu") or {}
    except Exception as e:
        return False, f"could not read this computer ({e})"
    if gpu.get("useful") and float(gpu.get("vram_gb") or 0) >= MIN_VRAM_GB:
        return True, ""
    return False, WEAK


def _total() -> int:
    return sum(f["size"] for f in FILES) + (0 if images._bin() else images.ENGINE["size"])


def install(progress=None) -> dict:
    ok, why = gpu_ok()
    if not ok:
        return {"ok": False, "message": why}
    need = _total() + 1_000_000_000
    base = paths.data_dir() if paths.data_dir().exists() else paths.home()
    if shutil.disk_usage(base).free < need:
        return {"ok": False, "message": f"not enough free disk space — it needs about {need // 1_000_000_000 + 1} GB"}
    home().mkdir(parents=True, exist_ok=True)
    try:
        for f in FILES:
            dest = home() / f["name"]
            if not dest.is_file():
                images._download(f["url"], dest, f["sha256"], f["size"], progress)
        images.ensure_engine(progress)
    except Exception as e:
        return {"ok": False, "message": f"could not finish: {e}"}
    if not local_ready():
        return {"ok": False, "message": "the engine was downloaded but its program was not found in it"}
    return {"ok": True, "message": "This computer can make videos now."}


def _state_file() -> pathlib.Path:
    return paths.data_dir() / "videogen-install.json"


def install_state() -> dict:
    try:
        st = json.loads(_state_file().read_text())
    except Exception:
        return {}
    if st.get("running") and time.time() - st.get("at", 0) > 600:
        st["running"] = False
        st["message"] = "stopped — press Add again to carry on where it left off"
    return st


def _put_state(**kw):
    try:
        _state_file().parent.mkdir(parents=True, exist_ok=True)
        _state_file().write_text(json.dumps(dict(kw, at=time.time())))
    except Exception:
        pass


def start_install() -> dict:
    if install_state().get("running"):
        return {"ok": True, "message": "Already downloading."}
    ok, why = gpu_ok()
    if not ok:
        return {"ok": False, "message": why[0].upper() + why[1:] + "."}
    total = _total()

    def go():
        done = [sum((home() / f["name"]).stat().st_size for f in FILES if (home() / f["name"]).is_file())]
        aid = _activity_begin("Downloading video making", "download")
        last = [0.0]

        def progress(n):
            done[0] += n
            if time.time() - last[0] > 2:
                last[0] = time.time()
                pct = min(99, int(done[0] * 100 / total))
                _put_state(running=True, percent=pct)
                _activity_update(aid, pct)
        _put_state(running=True, percent=int(done[0] * 100 / total))
        r = install(progress)
        _put_state(running=False, ok=r["ok"], message=r["message"], percent=100 if r["ok"] else None)
        _activity_end(aid, r["ok"])
    threading.Thread(target=go, daemon=True).start()
    return {"ok": True, "message": f"Downloading about {total / 1e9:.1f} GB. You can keep working."}


def remove() -> dict:
    if install_state().get("running"):
        return {"ok": False, "message": "Still downloading — wait for it to finish."}
    shutil.rmtree(home(), ignore_errors=True)
    try:
        _state_file().unlink()
    except FileNotFoundError:
        pass
    if not images.local_ready():          # the engine is no longer needed by anything
        shutil.rmtree(images.home() / "bin", ignore_errors=True)
    return {"ok": True, "message": "Video making removed from this computer (about 13 GB freed)."}


def _frames(seconds: int) -> int:
    n = max(1, min(4, int(seconds))) * FPS + 1
    return (n - 1) // 4 * 4 + 1           # the model wants 4n+1 frames


def generate_local(prompt: str, out: pathlib.Path, seconds: int = 2, size: str = "wide",
                   image: str = "") -> str:
    sd = images._bin()
    if sd is None or not local_ready():
        raise RuntimeError("video making is not installed on this computer")
    m = {f["role"]: str(home() / f["name"]) for f in FILES}
    w, h = {"tall": (480, 832), "square": (640, 640)}.get(size, (832, 480))
    raw = out.with_suffix(".avi")
    cmd = [str(sd), "-M", "vid_gen", "--diffusion-model", m["diffusion"], "--vae", m["vae"],
           "--t5xxl", m["t5xxl"], "-p", prompt, "-n", NEGATIVE, "--cfg-scale", "6.0",
           "--sampling-method", "euler", "--flow-shift", "3.0", "-W", str(w), "-H", str(h),
           "--video-frames", str(_frames(seconds)), "--diffusion-fa", "--offload-to-cpu",
           "--vae-tiling", "-o", str(raw)]
    if image:
        cmd += ["-i", image]
    env = dict(os.environ, LD_LIBRARY_PATH=f"{sd.parent}:{os.environ.get('LD_LIBRARY_PATH', '')}")
    import engines
    with engines.card_for_pictures():
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=3600, env=env)
    if r.returncode != 0 or not raw.is_file():
        tail = (r.stderr or r.stdout or "").strip().splitlines()[-3:]
        raise RuntimeError("the video could not be made: " + " ".join(tail)[:300])
    # Browsers do not play the engine's AVI: an MP4 everything can play.
    c = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw), "-c:v", "libx264",
                        "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out)],
                       capture_output=True, text=True, timeout=600)
    if c.returncode == 0 and out.is_file():
        raw.unlink()
        return str(out)
    return str(raw)


# ---------------------------------------------------------------------------
# the cloud
# ---------------------------------------------------------------------------
# Models offered in Settings; the first is the default. "cost": US dollars per
# second where the service publishes one (12 October 2026), else None and the
# question says it is billed by the service. "pic": can start from a picture.
SERVICES = {
    "google": {"name": "Google (Veo)", "good_at": "realistic video with sound", "pic": True,
               "hint": "the same key as Gemini",
               "models": [("veo-3.1-fast-generate-preview", "Veo 3.1 Fast", 0.10),
                          ("veo-3.1-generate-preview", "Veo 3.1 (best)", 0.40),
                          ("veo-3.1-lite-generate-preview", "Veo 3.1 Lite (cheapest)", 0.05)]},
    "xai": {"name": "xAI (Grok Imagine)", "good_at": "quick, bold clips", "pic": False,
            "hint": "the same key as Grok chat",
            "models": [("grok-imagine-video-1.5", "Grok Imagine Video 1.5", None),
                       ("grok-imagine-video", "Grok Imagine Video", None)]},
    "higgsfield": {"name": "Higgsfield", "good_at": "one account for Seedance, Kling, Hailuo and Wan",
                   "pic": False, "hint": "paste it as KEY_ID:KEY_SECRET (console.higgsfield.ai)",
                   "models": [("bytedance/seedance-2.0/text-to-video", "Seedance 2.0", None),
                              ("kling-video/v3.0/std/text-to-video", "Kling 3.0 Standard", None),
                              ("kling-video/v3.0/pro/text-to-video", "Kling 3.0 Pro", None),
                              ("minimax/hailuo-2.3/standard/text-to-video", "Hailuo 2.3", None),
                              ("alibaba/wan-3.0-prime/text-to-video", "Wan 3.0 Prime", None)]},
    "seedance": {"name": "Seedance (BytePlus)", "good_at": "ByteDance's own video model, direct",
                 "pic": True, "hint": "a BytePlus ModelArk API key",
                 "models": [("seedance-1-0-pro-250528", "Seedance 1.0 Pro", None),
                            ("seedance-1-0-lite-t2v-250428", "Seedance 1.0 Lite", None)]},
    "fal": {"name": "fal.ai", "good_at": "one key for many video models", "pic": False,
            "hint": "the same key as for pictures",
            "models": [("fal-ai/bytedance/seedance/v1/pro/text-to-video", "Seedance 1.0 Pro", None),
                       ("fal-ai/kling-video/v2.1/master/text-to-video", "Kling 2.1 Master", None),
                       ("fal-ai/veo3/fast", "Veo 3 Fast", None),
                       ("fal-ai/minimax/hailuo-02/standard/text-to-video", "Hailuo 02", None),
                       ("fal-ai/wan/v2.2-a14b/text-to-video", "Wan 2.2", None)]},
    "runway": {"name": "Runway", "good_at": "film-like motion and camera work", "pic": True,
               "hint": "a key from dev.runwayml.com",
               "models": [("gen4.5", "Gen-4.5", None)]},
    "luma": {"name": "Luma (Dream Machine)", "good_at": "smooth, natural movement", "pic": False,
             "hint": "a key from lumalabs.ai/dream-machine/api",
             "models": [("ray-2", "Ray 2", None), ("ray-flash-2", "Ray 2 Flash (faster)", None)]},
}
CHAT_MAKES = ("google", "xai")          # chat keys that also make videos
_MODEL_RE = re.compile(r"^[\w.:/@-]{1,120}$")


def _cloud():
    import cloud
    return cloud


def default_model(service: str) -> str:
    return SERVICES[service]["models"][0][0]


def price(service: str, model: str):
    for m, _n, c in SERVICES.get(service, {}).get("models", []):
        if m == model:
            return c
    return None


def _makers(st=None) -> list:
    st = st or _cloud().load()
    out = [dict(k, kind="video") for k in st.get("video_keys") or [] if k.get("service") in SERVICES]
    chosen = st.get("video_models") or {}
    for e in st.get("keys") or []:
        if e.get("provider") in CHAT_MAKES:
            out.append({"id": e["id"], "service": e["provider"], "key": e["key"], "kind": "chat",
                        "model": chosen.get(e["id"]) or default_model(e["provider"])})
    return out


def cloud_on(st=None) -> bool:
    """Off until switched on: a video costs money, nothing starts that by itself."""
    st = st or _cloud().load()
    return bool(st.get("videos_cloud"))


def set_cloud(on: bool) -> dict:
    st = _cloud().load()
    st["videos_cloud"] = bool(on)
    _cloud().save(st)
    if on and not _makers(st):
        return {"ok": True, "message": "Videos in the cloud: on — add a service below to use it."}
    return {"ok": True, "message": "Videos will be made in the cloud (you are asked before each one)." if on
            else "Videos will be made on this computer."}


def add_key(service: str, key: str, model: str = "") -> dict:
    if service not in SERVICES:
        return {"ok": False, "message": "Unknown video service."}
    key = (key or "").strip()
    if len(key) < 8 or any(c.isspace() for c in key):
        return {"ok": False, "message": "Paste the key first."}
    if service == "higgsfield" and ":" not in key:
        return {"ok": False, "message": "Higgsfield needs both parts, pasted as KEY_ID:KEY_SECRET."}
    model = (model or "").strip() or default_model(service)
    if not _MODEL_RE.match(model):
        return {"ok": False, "message": "That is not a model name."}
    st = _cloud().load()
    entry = {"id": uuid.uuid4().hex[:8], "service": service, "key": key, "model": model}
    st.setdefault("video_keys", []).append(entry)
    if not st.get("video_default"):
        st["video_default"] = entry["id"]
    _cloud().save(st)
    return {"ok": True, "id": entry["id"],
            "message": f"{SERVICES[service]['name']} saved. It is checked the first time it makes a video."}


def set_model(kid: str, model: str) -> dict:
    model = (model or "").strip()
    if not _MODEL_RE.match(model):
        return {"ok": False, "message": "That is not a model name."}
    st = _cloud().load()
    for k in st.get("video_keys") or []:
        if k["id"] == kid:
            k["model"] = model
            _cloud().save(st)
            return {"ok": True, "message": f"Videos now use {model}."}
    if any(e["id"] == kid and e.get("provider") in CHAT_MAKES for e in st.get("keys") or []):
        st.setdefault("video_models", {})[kid] = model
        _cloud().save(st)
        return {"ok": True, "message": f"Videos now use {model}; the chat model is unchanged."}
    return {"ok": False, "message": "That key is not saved any more."}


def remove_key(kid: str) -> dict:
    st = _cloud().load()
    st["video_keys"] = [k for k in st.get("video_keys") or [] if k["id"] != kid]
    if st.get("video_default") == kid:
        st["video_default"] = st["video_keys"][0]["id"] if st["video_keys"] else ""
    _cloud().save(st)
    return {"ok": True, "message": "Removed."}


def set_default(kid: str) -> dict:
    st = _cloud().load()
    if kid and not any(d["id"] == kid for d in _makers(st)):
        return {"ok": False, "message": "That key is not saved any more."}
    st["video_default"] = kid
    _cloud().save(st)
    return {"ok": True, "message": "Default video service set."}


def live_models(kid: str) -> dict:
    """Google lists its Veo models; the others have the list written above."""
    d = next((d for d in _makers() if d["id"] == kid), None)
    if d is None:
        return {"models": [], "message": "That key is not saved any more."}
    known = [{"id": m, "name": n} for m, n, _c in SERVICES[d["service"]]["models"]]
    found = []
    if d["service"] == "google":
        try:
            j = images._http("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",
                             headers={"x-goog-api-key": d["key"]}, timeout=20)
            found = [r["name"].split("/", 1)[-1] for r in (j or {}).get("models") or []
                     if "veo" in r.get("name", "") and "predictLongRunning" in (r.get("supportedGenerationMethods") or [])]
        except Exception:
            found = []
    have = {m["id"] for m in known}
    return {"models": known + [{"id": m, "name": m} for m in sorted(set(found)) if m not in have],
            "current": d["model"]}


def choose(service: str = ""):
    """(maker, "") | ("local", "") | (None, why) — the video switch decides."""
    st = _cloud().load()
    makers = _makers(st)
    on = cloud_on(st)
    want = (service or "").strip().lower()
    if want in ("local", "here", "this computer"):
        if local_ready():
            return "local", ""
        ok, why = gpu_ok()
        return None, (why if not ok else "video making is not installed here — Settings → Making videos")
    if want:
        if not on:
            return None, ("making videos in the cloud is off — switch it on in Settings → Making videos "
                          "to use " + service)
        for d in makers:
            nm = SERVICES[d["service"]]["name"].lower()
            if want == d["service"] or want in nm or nm.split(" (")[0] in want \
                    or want in d.get("model", "").lower():
                return d, ""
        return None, f"there is no saved key for {service}; add one in Settings → Making videos"
    if on:
        d = next((d for d in makers if d["id"] == st.get("video_default")), None) or (makers[0] if makers else None)
        if d:
            return d, ""
        return None, "making videos in the cloud is on, but no service is added — Settings → Making videos"
    if local_ready():
        return "local", ""
    ok, why = gpu_ok()
    if not ok:
        return None, why
    return None, ("video making is not set up here — Settings → Making videos → Add video making, "
                  "or switch on making videos in the cloud")


def _seconds(service: str, seconds) -> int:
    try:
        s = int(seconds or 0)
    except (TypeError, ValueError):
        s = 0
    if service == "local":
        return max(1, min(4, s or 2))
    if service == "google":
        return 8 if s > 6 else 6 if s > 4 else 4 if s else 8
    if service in ("seedance", "runway"):
        return 10 if s > 7 else 5
    if service == "luma":
        return 9 if s > 7 else 5
    return max(3, min(15, s or 5))


def cost_question(args: dict):
    """(question, detail) for the confirmation before a cloud video, or None
    for one made here. Asked in agent.exec_tool, before anything is sent."""
    how, _why = choose(str(args.get("service") or ""))
    if not isinstance(how, dict):
        return None
    secs = _seconds(how["service"], args.get("seconds"))
    c = price(how["service"], how["model"])
    name = f"{SERVICES[how['service']]['name']} · {how['model']}"
    money = (f"about ${c * secs:.2f}" if c is not None
             else f"billed to your {SERVICES[how['service']]['name'].split(' (')[0]} account")
    return (f"Make a {secs}-second video with {name}? It costs {money}.",
            str(args.get("prompt", ""))[:300])


def _first_url(obj, keys=("url", "uri", "video_url", "video")):
    """The first https link in an answer, looked for under the usual names."""
    if isinstance(obj, str):
        return obj if obj.startswith("https://") else ""
    if isinstance(obj, list):
        for x in obj:
            u = _first_url(x, keys)
            if u:
                return u
        return ""
    if isinstance(obj, dict):
        for k in keys:
            if k in obj:
                u = _first_url(obj[k], keys)
                if u:
                    return u
        for v in obj.values():
            if isinstance(v, (dict, list)):
                u = _first_url(v, keys)
                if u:
                    return u
    return ""


def _download_video(url: str, out: pathlib.Path, headers=None):
    import urllib.request
    if not url.startswith("https://"):
        raise RuntimeError("the service sent no video")
    req = urllib.request.Request(url, headers=dict(images.UA, **(headers or {})))
    with urllib.request.urlopen(req, timeout=300) as r, open(out, "wb") as f:
        n = 0
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            n += len(chunk)
            if n > 500_000_000:
                raise RuntimeError("the video was larger than 500 MB")
            f.write(chunk)


def _data_url(path: str) -> str:
    mime = mimetypes.guess_type(path)[0] or "image/png"
    return f"data:{mime};base64," + base64.b64encode(pathlib.Path(path).read_bytes()).decode()


def _poll(fn, every=5.0, limit=1200, progress=None):
    """fn() → (done, value). Raises after `limit` seconds."""
    t0 = time.time()
    while time.time() - t0 < limit:
        done, value = fn()
        if done:
            return value
        if progress:
            progress(min(95, int((time.time() - t0) * 100 / 240)))
        time.sleep(every)
    raise RuntimeError("the service took too long (20 minutes)")


def _draw(d, prompt, out: pathlib.Path, seconds, size, image="", every=5.0, progress=None):
    s, key, model = d["service"], d["key"], d.get("model") or default_model(d["service"])
    ratio = {"tall": "9:16", "square": "1:1"}.get(size, "16:9")
    http = images._http
    if image and not SERVICES[s]["pic"]:
        raise RuntimeError(f"{SERVICES[s]['name']} here makes videos from words only — describe the "
                           "picture instead, or choose Google, Runway or Seedance for this")
    if s == "google":
        inst = {"prompt": prompt}
        if image:
            inst["image"] = {"bytesBase64Encoded": base64.b64encode(pathlib.Path(image).read_bytes()).decode(),
                             "mimeType": mimetypes.guess_type(image)[0] or "image/png"}
        hdr = {"x-goog-api-key": key}
        op = http(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:predictLongRunning",
                  {"instances": [inst], "parameters": {"aspectRatio": "9:16" if size == "tall" else "16:9",
                                                       "durationSeconds": seconds}}, hdr)
        name = op.get("name", "")

        def check():
            j = http("https://generativelanguage.googleapis.com/v1beta/" + name, headers=hdr)
            if j.get("error"):
                raise RuntimeError("Google could not make it: " + str(j["error"].get("message", ""))[:160])
            return bool(j.get("done")), j
        j = _poll(check, every, progress=progress)
        resp = j.get("response") or {}
        if resp.get("generateVideoResponse", {}).get("raiMediaFilteredReasons"):
            raise RuntimeError("Google would not make that (its content rules)")
        _download_video(_first_url(resp), out, hdr)
        return
    if s == "xai":
        hdr = {"Authorization": "Bearer " + key}
        r = http("https://api.x.ai/v1/videos/generations",
                 {"model": model, "prompt": prompt, "duration": seconds, "aspect_ratio": ratio}, hdr)
        rid = r.get("request_id") or r.get("id")

        def check():
            j = http(f"https://api.x.ai/v1/videos/{rid}", headers=hdr)
            st = str(j.get("status", "")).lower()
            if st in ("failed", "expired", "error"):
                raise RuntimeError("xAI could not make it")
            return st in ("done", "completed", "succeeded") or bool(_first_url(j.get("video") or {})), j
        _download_video(_first_url(_poll(check, every, progress=progress)), out)
        return
    if s == "higgsfield":
        hdr = {"Authorization": "Key " + key, "Idempotency-Key": uuid.uuid4().hex}
        r = http(f"https://api.higgsfield.ai/{model}", {"prompt": prompt, "duration": seconds,
                                                        "aspect_ratio": ratio}, hdr)
        url = r.get("status_url") or f"https://api.higgsfield.ai/requests/{r.get('request_id')}/status"
        if not url.startswith("https://api.higgsfield.ai/"):
            raise RuntimeError("Higgsfield answered with an unexpected address")

        def check():
            j = http(url, headers={"Authorization": "Key " + key})
            st = str(j.get("status", "")).lower()
            if st in ("failed", "nsfw", "canceled", "cancelled"):
                raise RuntimeError("Higgsfield would not make that" if st == "nsfw" else "Higgsfield could not make it")
            return st == "completed", j
        _download_video(_first_url(_poll(check, every, progress=progress)), out)
        return
    if s == "seedance":
        hdr = {"Authorization": "Bearer " + key}
        base = "https://ark.ap-southeast.bytepluses.com/api/v3/contents/generations/tasks"
        content = [{"type": "text", "text": f"{prompt} --duration {seconds} --ratio {ratio}"}]
        if image:
            content.append({"type": "image_url", "image_url": {"url": _data_url(image)}})
        r = http(base, {"model": model, "content": content}, hdr)
        tid = r.get("id")

        def check():
            j = http(f"{base}/{tid}", headers=hdr)
            st = str(j.get("status", "")).lower()
            if st in ("failed", "cancelled", "expired"):
                raise RuntimeError("Seedance could not make it: " + str((j.get("error") or {}).get("message", ""))[:120])
            return st == "succeeded", j
        _download_video(_first_url(_poll(check, every, progress=progress)), out)
        return
    if s == "fal":
        hdr = {"Authorization": "Key " + key}
        r = http(f"https://queue.fal.run/{model}", {"prompt": prompt, "duration": str(seconds),
                                                    "aspect_ratio": ratio}, hdr)
        status_url, result_url = r.get("status_url"), r.get("response_url")
        for u in (status_url, result_url):
            if not (u or "").startswith("https://queue.fal.run/"):
                raise RuntimeError("fal.ai answered with an unexpected address")

        def check():
            j = http(status_url, headers=hdr)
            st = str(j.get("status", "")).upper()
            if st in ("ERROR", "FAILED"):
                raise RuntimeError("fal.ai could not make it")
            return st == "COMPLETED", j
        _poll(check, every, progress=progress)
        _download_video(_first_url(http(result_url, headers=hdr)), out)
        return
    if s == "runway":
        hdr = {"Authorization": "Bearer " + key, "X-Runway-Version": "2024-11-06"}
        body = {"model": model, "promptText": prompt[:1000], "duration": seconds,
                "ratio": {"tall": "720:1280", "square": "960:960"}.get(size, "1280:720")}
        if image:
            body["promptImage"] = _data_url(image)
        r = http("https://api.dev.runwayml.com/v1/image_to_video", body, hdr)
        tid = r.get("id")

        def check():
            j = http(f"https://api.dev.runwayml.com/v1/tasks/{tid}", headers=hdr)
            st = str(j.get("status", "")).upper()
            if st in ("FAILED", "CANCELLED"):
                raise RuntimeError("Runway could not make it: " + str(j.get("failure", ""))[:120])
            return st == "SUCCEEDED", j
        _download_video(_first_url(_poll(check, every, progress=progress).get("output")), out)
        return
    if s == "luma":
        hdr = {"Authorization": "Bearer " + key}
        r = http("https://api.lumalabs.ai/dream-machine/v1/generations",
                 {"prompt": prompt, "model": model, "resolution": "720p", "duration": f"{seconds}s",
                  "aspect_ratio": ratio}, hdr)
        gid = r.get("id")

        def check():
            j = http(f"https://api.lumalabs.ai/dream-machine/v1/generations/{gid}", headers=hdr)
            st = str(j.get("state", "")).lower()
            if st == "failed":
                raise RuntimeError("Luma could not make it: " + str(j.get("failure_reason", ""))[:120])
            return st == "completed", j
        _download_video(_first_url((_poll(check, every, progress=progress).get("assets") or {}).get("video", "")), out)
        return
    raise RuntimeError("unknown video service")


# ---------------------------------------------------------------------------
# jobs: made in the background, shown when ready
# ---------------------------------------------------------------------------
_LOCK = threading.Lock()


def _jobs_file() -> pathlib.Path:
    return paths.data_dir() / "videos-jobs.json"


def jobs() -> list:
    try:
        return json.loads(_jobs_file().read_text())
    except Exception:
        return []


def _put_job(job: dict):
    with _LOCK:
        all_ = [j for j in jobs() if j["id"] != job["id"]][-19:] + [job]
        _jobs_file().parent.mkdir(parents=True, exist_ok=True)
        tmp = _jobs_file().with_suffix(".tmp")
        tmp.write_text(json.dumps(all_, ensure_ascii=False))
        tmp.replace(_jobs_file())


def folder() -> pathlib.Path:
    return paths.home() / "Videos" / "OSprime"


def _name(prompt: str) -> pathlib.Path:
    slug = re.sub(r"[^\w]+", "-", prompt.lower(), flags=re.U).strip("-")[:40] or "video"
    stamp = datetime.datetime.now().strftime("%Y-%m-%d-%H%M%S")
    folder().mkdir(parents=True, exist_ok=True)
    out, n = folder() / f"{stamp}-{slug}.mp4", 2
    while out.exists():
        out, n = folder() / f"{stamp}-{slug}-{n}.mp4", n + 1
    return out


def _activity_begin(label, kind="job"):
    try:
        import activity
        return activity.begin(label, kind)
    except Exception:
        return None


def _activity_update(aid, pct):
    if aid:
        try:
            import activity
            activity.update(aid, pct)
        except Exception:
            pass


def _activity_end(aid, ok):
    if aid:
        try:
            import activity
            activity.end(aid, ok=ok)
        except Exception:
            pass


def _announce(job: dict, helper: str):
    """Brainy's dot and a line in the helper's conversation (agent/watchers.py)."""
    try:
        import hashlib
        import watchers
        with watchers._locked():
            d = watchers._load()
            text = (f"🎬 Your video is ready — made by {job['by']}: {job['path']}" if job["status"] == "done"
                    else f"🎬 The video could not be made: {job.get('error', '')}")
            d["alerts"].append({"id": hashlib.sha1(job["id"].encode()).hexdigest()[:10], "wid": "",
                                "helper": helper or "general", "text": text, "video": job.get("path", ""),
                                "at": int(time.time()), "seen": False})
            d["alerts"] = d["alerts"][-watchers.MAX_ALERTS:]
            watchers._save(d)
        import companion
        companion.attention(True)
    except Exception:
        pass


def resolve_image(arg: str) -> str:
    """'last' (or empty words like "this picture") = the last picture made."""
    a = (arg or "").strip()
    if not a:
        return ""
    if a.lower() in ("last", "latest", "the last picture", "that picture", "this picture"):
        a = images.last().get("path", "")
    p = pathlib.Path(os.path.expanduser(a))
    if not p.is_file() or p.suffix.lower() not in (".png", ".jpg", ".jpeg", ".webp"):
        raise RuntimeError("that picture was not found (a .png, .jpg or .webp file)")
    return str(p)


def make(prompt: str, seconds=None, size: str = "wide", from_image: str = "", service: str = "",
         helper: str = "", send=None, wait: bool = False) -> dict:
    """Starts a video. {"ok", "message", "job"}; with wait=True (tests) it
    returns when the video is done."""
    prompt = " ".join((prompt or "").split())[:1500]
    if len(prompt) < 3:
        return {"ok": False, "message": "Say what the video should show."}
    how, why = choose(service)
    if how is None:
        return {"ok": False, "message": why[0].upper() + why[1:] + "."}
    no = images.refused(prompt, how == "local")
    if no:
        return {"ok": False, "message": no.replace("picture", "video")}
    try:
        image = resolve_image(from_image)
    except RuntimeError as e:
        return {"ok": False, "message": str(e)[0].upper() + str(e)[1:] + "."}
    svc = "local" if how == "local" else how["service"]
    if image and svc != "local" and not SERVICES[svc]["pic"]:
        return {"ok": False, "message": f"{SERVICES[svc]['name']} here makes videos from words only — "
                                        "describe the picture instead, or use Google, Runway or Seedance."}
    secs = _seconds(svc, seconds)
    by = ("this computer (Wan 2.2)" if how == "local"
          else f"{SERVICES[how['service']]['name']} · {how['model']}")
    job = {"id": uuid.uuid4().hex[:10], "status": "running", "prompt": prompt[:200], "by": by,
           "seconds": secs, "started": int(time.time()), "path": "", "error": ""}
    _put_job(job)

    def run():
        aid = _activity_begin("Making a video", "job")
        out = _name(prompt)
        try:
            if how == "local":
                path = generate_local(prompt, out, secs, size, image)
            else:
                _draw(how, prompt, out, secs, size, image,
                      progress=lambda p: _activity_update(aid, p))
                path = str(out)
            job.update(status="done", path=path, finished=int(time.time()))
        except Exception as e:
            try:
                out.unlink()
            except OSError:
                pass
            job.update(status="failed", error=str(e)[:300], finished=int(time.time()))
        _activity_end(aid, job["status"] == "done")
        _announce(job, helper)
        if send:
            try:
                if job["status"] == "done":
                    send({"type": "video", "path": job["path"], "by": by, "job": job["id"]})
            except Exception:
                pass        # the chat that asked may be closed: the alert carries it
        _put_job(job)       # last: whoever polls for it finds everything in place

    if wait:
        run()
        return {"ok": job["status"] == "done", "message": job.get("error") or "done", "job": job}
    threading.Thread(target=run, daemon=True, name="video-" + job["id"]).start()
    minutes = "several minutes" if how == "local" else "a minute or two"
    return {"ok": True, "job": job,
            "message": f"Started a {secs}-second video with {by}. It takes {minutes}; it will appear "
                       "in this chat when it is ready, and Brainy gets a dot."}


def public_view() -> dict:
    st = _cloud().load()
    ok, why = gpu_ok()
    try:
        how, _w = choose()
        uses = ("this computer (Wan 2.2)" if how == "local" else
                f"{SERVICES[how['service']]['name']} · {how['model']}" if isinstance(how, dict) else "")
    except Exception:
        uses = ""
    done = [j for j in jobs() if j["status"] == "done"]
    return {"local": {"ready": local_ready(), "can": ok, "why": why, "install": install_state(),
                      "size_gb": round(_total() / 1e9, 1)},
            "cloud": cloud_on(st), "uses": uses,
            "last": done[-1] if done else {},
            "services": [{"id": k, "name": v["name"], "good_at": v["good_at"], "hint": v["hint"],
                          "models": [{"id": m, "name": n + (f" — about ${c:.2f}/s" if c else "")}
                                     for m, n, c in v["models"]]}
                         for k, v in SERVICES.items()],
            "keys": [{"id": d["id"], "service": d["service"], "name": SERVICES[d["service"]]["name"],
                      "kind": d["kind"], "model": d["model"], "tail": d["key"][-4:]} for d in _makers(st)],
            "default": st.get("video_default", "")}
