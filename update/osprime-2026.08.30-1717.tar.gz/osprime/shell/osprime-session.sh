#!/usr/bin/env bash
# OSprime graphical session: labwc compositor + kiosk chat.
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export XDG_SESSION_TYPE=wayland
export XDG_CURRENT_DESKTOP=labwc
export MOZ_ENABLE_WAYLAND=1
export QT_QPA_PLATFORM=wayland

# Cursor. wlroots draws nothing at all if no XCursor theme is named, which
# presents as an invisible pointer that still clicks.
export XCURSOR_THEME="${XCURSOR_THEME:-Adwaita}"
export XCURSOR_SIZE="${XCURSOR_SIZE:-24}"
export XCURSOR_PATH="${XCURSOR_PATH:-/usr/share/icons:$HOME/.local/share/icons}"

# Second, separate cause of an invisible pointer: on virtualised GPUs
# (VMware, VirtualBox, QEMU) wlroots allocates the hardware cursor plane in
# system memory and the guest driver never scans it out. Software cursors
# cost nothing here and always draw.
if [ -z "${WLR_NO_HARDWARE_CURSORS:-}" ] && \
   grep -qiE 'vmware|virtualbox|qemu|kvm|innotek|microsoft corporation' \
        /sys/class/dmi/id/sys_vendor /sys/class/dmi/id/product_name 2>/dev/null; then
    export WLR_NO_HARDWARE_CURSORS=1
fi
mkdir -p "$XDG_RUNTIME_DIR" 2>/dev/null
chmod 700 "$XDG_RUNTIME_DIR" 2>/dev/null

LOG=/tmp/osprime-shell.log
HERE="$(cd "$(dirname "$0")" && pwd)"
{
  echo "=== OSprime session $(date) ==="
  echo "user=$(id -un) uid=$(id -u) tty=$(tty)"
  echo "XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR"
  echo "dri: $(ls /dev/dri 2>&1 | tr '\n' ' ')"
  echo "labwc: $(command -v labwc || echo MISSING)"
} > "$LOG" 2>&1

# Wait for the web UI, but do NOT block the desktop on it. Previously the
# session existed only to show the chat, so waiting made sense. Now the
# desktop is the product: it must come up even if the agent is broken.
for _ in $(seq 1 30); do
    (echo > /dev/tcp/127.0.0.1/8080) 2>/dev/null && break
    sleep 0.5
done
echo "web-ui reachable: $?" >> "$LOG"

# No -s kiosk argument any more: labwc starts the desktop, and
# ~/.config/labwc/autostart brings up the wallpaper and panel.
labwc -C "$HOME/.config/labwc" >>"$LOG" 2>&1
echo "labwc exited with status $?" >> "$LOG"
