#!/usr/bin/env bash
# Keyboard shortcuts for the companion (shell/labwc/rc.xml):
#   listen   Super+Space   talk to it (docs/COMPANION.md, phase 2)
#   point    Super+T       ask about part of the screen (phase 3)
#
# The companion is a running GTK program; a shortcut reaches it as a signal
# rather than as a second copy of it. With the companion hidden or switched
# off, Super+Space opens the chat instead, so the key never does nothing.
case "${1:-}" in
    listen) sig=USR1 ;;
    point) sig=USR2 ;;
    *) echo "usage: $0 listen|point" >&2; exit 2 ;;
esac
if pkill -"$sig" -u "$(id -u)" -f "osprime-companion.py" 2>/dev/null; then
    exit 0
fi
exec bash "$(dirname "$0")/osprime-toggle.sh"
