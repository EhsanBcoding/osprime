"""Drop a file on Brainy (a Coucou idea, approved 9 October).

Dragging a file from Files onto the character opens the panel with that file
and a few things to do with it, chosen by what kind of file it is. Nothing
happens until one is pressed: a drop is a question, not a command.

  * a picture: it becomes the selected area of point-and-ask
    (companion_point.py), so "What is this?" and the rest work as they do
    for part of the screen;
  * a document (text, PDF, Word, OpenDocument): summarise it, or ask about
    it (the assistant reads it with read_file, which reads PDF and Word);
  * a PDF also: make a scan searchable, or make it smaller;
  * anything else: ask about it.
"""
import pathlib
import urllib.parse

IMAGE = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}
DOC = {".txt", ".md", ".csv", ".json", ".log", ".html", ".htm", ".py", ".js", ".sh",
       ".pdf", ".docx", ".odt", ".pptx", ".xlsx", ".ods", ".rtf", ".srt", ".tex"}
MAX_FILES = 5


def paths_from_uris(uris) -> list:
    """file:// URIs from the drop, as existing local files; nothing else."""
    out = []
    for u in uris or []:
        u = (u or "").strip()
        if not u.startswith("file://"):
            continue
        p = pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(u).path))
        try:
            if p.is_file():
                out.append(p)
        except OSError:
            continue
        if len(out) >= MAX_FILES:
            break
    return out


def kind(path: pathlib.Path) -> str:
    ext = path.suffix.lower()
    return "image" if ext in IMAGE else "pdf" if ext == ".pdf" else "doc" if ext in DOC else "other"


def actions(paths: list) -> list:
    """[(button label, what to send or "", how)] — how: send | ask | point."""
    if not paths:
        return []
    if len(paths) > 1:
        names = ", ".join(str(p) for p in paths)
        out = [("Summarise them", f"Read these files and summarise each in a few lines: {names}", "send")]
        if all(kind(p) == "pdf" for p in paths):
            out.append(("Merge into one PDF", f"Merge these PDFs into one, in this order: {names}", "send"))
        out.append(("Ask about them", f"About the files {names}: ", "ask"))
        return out
    p = paths[0]
    k = kind(p)
    if k == "image":
        return [("Look at it", "", "point")]
    out = []
    if k in ("doc", "pdf"):
        out.append(("Summarise", f"Read the file {p} and summarise it in a few lines.", "send"))
    if k == "pdf":
        out.append(("Make a scan searchable", f"Make the scanned PDF {p} searchable (OCR).", "send"))
        out.append(("Make it smaller", f"Compress the PDF {p}.", "send"))
    out.append(("Ask about it", f"About the file {p}: ", "ask"))
    return out
