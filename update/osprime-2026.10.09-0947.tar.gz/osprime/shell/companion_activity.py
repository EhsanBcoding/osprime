"""The live-activity card above Brainy (agent/activity.py).

A small card on the character's corner — above it when Brainy sits at the
bottom of the screen, below it at the top — with what is running and how
far along it is. It appears when something starts, shows a tick for a few
seconds when it ends, and goes. A click opens the panel. It never takes the
keyboard and never makes a sound.
"""
import gi

gi.require_version("Gtk", "3.0")
gi.require_version("GtkLayerShell", "0.1")
from gi.repository import Gtk, Gdk, GtkLayerShell, Pango  # noqa: E402

CSS = b"""
#activity { background-color: transparent; }
.acard { background-color: #161b22; border: 1px solid #30363d; border-radius: 12px;
         padding: 6px 10px; }
.acard label { color: #e6edf3; font-size: 12px; }
.acard.ok { border-color: #238636; }
.acard.bad { border-color: #da3633; }
.acard progressbar trough { min-height: 4px; background-color: #30363d; border-radius: 2px; }
.acard progressbar progress { min-height: 4px; background-color: #58a6ff; border-radius: 2px; }
"""
WIDTH = 240


class ActivityCard:
    def __init__(self, companion):
        self.c = companion
        self.shown_id = None
        prov = Gtk.CssProvider()
        prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self.win = Gtk.Window()
        self.win.set_name("activity")
        GtkLayerShell.init_for_window(self.win)
        GtkLayerShell.set_layer(self.win, GtkLayerShell.Layer.TOP)
        GtkLayerShell.set_namespace(self.win, "osprime-companion-activity")
        GtkLayerShell.set_exclusive_zone(self.win, 0)
        try:
            GtkLayerShell.set_keyboard_mode(self.win, GtkLayerShell.KeyboardMode.NONE)
        except Exception:
            pass
        visual = self.win.get_screen().get_rgba_visual()
        if visual is not None:
            self.win.set_visual(visual)
        self.win.set_app_paintable(True)
        self.win.connect("draw", self._clear)
        self.win.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.win.connect("button-press-event", self._click)
        self.box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.box.get_style_context().add_class("acard")
        self.box.set_size_request(WIDTH, -1)
        self.label = Gtk.Label(label="", xalign=0)
        self.label.set_ellipsize(Pango.EllipsizeMode.END)
        self.label.set_max_width_chars(34)
        self.bar = Gtk.ProgressBar()
        self.box.pack_start(self.label, False, False, 0)
        self.box.pack_start(self.bar, False, False, 0)
        self.win.add(self.box)

    def _clear(self, _w, cr):
        import cairo
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        return False

    def _click(self, *_):
        self.c.toggle_bubble()
        return True

    def reposition(self):
        c = self.c
        for e in (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.BOTTOM,
                  GtkLayerShell.Edge.LEFT, GtkLayerShell.Edge.RIGHT):
            GtkLayerShell.set_anchor(self.win, e, False)
        v, h = c.CORNERS[c.corner]
        GtkLayerShell.set_anchor(self.win, v, True)
        GtkLayerShell.set_anchor(self.win, h, True)
        GtkLayerShell.set_margin(self.win, h, max(0, c.mx))
        GtkLayerShell.set_margin(self.win, v, max(0, c.my + c.h + 6))

    def show(self, s: dict):
        """s: activity.summary(); empty hides the card."""
        if not s:
            if self.win.get_visible():
                self.win.hide()
            self.shown_id = None
            return
        self.label.set_text(s["text"])
        ctx = self.box.get_style_context()
        for cls in ("ok", "bad"):
            ctx.remove_class(cls)
        if s.get("done"):
            ctx.add_class("ok" if s.get("ok") else "bad")
            self.bar.set_fraction(1.0 if s.get("ok") else self.bar.get_fraction())
        elif s.get("fraction") is not None:
            self.bar.set_fraction(s["fraction"])
        else:
            self.bar.pulse()              # how far along is not known
        if not self.win.get_visible():
            self.reposition()
            self.win.show_all()
        self.shown_id = s.get("id")

    def rect(self):
        """Where it is on the screen, for the guide's change detection."""
        if not self.win.get_visible():
            return None
        w, h = self.win.get_size()
        sw, _sh = self.c.screen_size()
        cx, cy = self.c.top_left()
        v, hz = self.c.corner.split("-")
        x = sw - self.c.mx - w if hz == "right" else self.c.mx
        return (x, cy - 6 - h, w, h) if v == "bottom" else (x, cy + self.c.h + 6, w, h)
