"""What is on the screen, and exactly where (docs/COMPANION.md, phase 4).

The guide must point at the real control, not at a guess. Two sources,
neither of which is the model:

  * AT-SPI, Linux's accessibility tree: every button, field, menu item and
    tab of the front window, with its name, its role and its rectangle.
    Wayland gives those rectangles relative to the window, not the screen
    (a program is not told where its window is), so:
  * OCR (tesseract, English + Persian): every word on the screen with its
    rectangle in screen pixels. Words that are also the names of controls
    tie the two together: the difference between where OCR saw "Save" and
    where AT-SPI says the Save button sits in its window IS the window's
    position. Several controls have to agree before it is trusted.

What the model gets is a numbered list built from both; it answers with a
number, and the rectangle comes from here. Only for a control with no text
and no accessibility (an icon in a game) does the model's own box get used,
and then the bubble says it is a best guess.

The functions that parse and combine are pure, so tests/test_guide.py runs
them on recorded input; capture() and atspi_controls() touch the live
desktop and degrade to empty when they cannot.
"""
import os
import re
import shutil
import subprocess
import time

# Roles worth pointing at, as AT-SPI names them (Atspi.Role nicks).
CLICKABLE = {
    "push button", "toggle button", "check box", "radio button", "menu item",
    "check menu item", "radio menu item", "menu", "page tab", "link",
    "combo box", "list item", "tree item", "table cell", "icon", "entry",
    "text", "password text", "spin button", "slider", "button",
    "split button", "switch",
}
# Plain labels and pictures are left to OCR: as controls they fill the list
# with things nobody clicks.
SENSITIVE_ROLES = {"password text"}
SENSITIVE_WORDS = re.compile(
    r"pass(word|code|phrase)|\bpin\b|cvv|cvc|card.?number|security code|iban|"
    r"social security|رمز|گذرواژه|کلمه عبور|شماره کارت|کد امنیتی", re.I)
IRREVERSIBLE = re.compile(
    r"\b(send|submit|pay|purchase|buy|delete|remove|erase|format|post|publish|"
    r"confirm|uninstall|empty trash)\b|ارسال|پرداخت|خرید|حذف|پاک|انتشار|تأیید", re.I)
MAX_ELEMENTS = 150


# ---- the screen --------------------------------------------------------------
def capture(path: str):
    """The whole screen as a PNG (no cursor). (width, height) or None."""
    if not shutil.which("grim"):
        return None
    r = subprocess.run(["grim", "-t", "png", path], capture_output=True, timeout=20)
    if r.returncode != 0 or not os.path.isfile(path):
        return None
    try:
        import cairo
        s = cairo.ImageSurface.create_from_png(path)
        return s.get_width(), s.get_height()
    except Exception:
        return None


def ocr_tsv(path: str, langs: str = "eng+fas") -> str:
    if not shutil.which("tesseract"):
        return ""
    try:
        r = subprocess.run(["tesseract", path, "stdout", "-l", langs, "--psm", "11", "tsv"],
                           capture_output=True, text=True, timeout=60)
        return r.stdout if r.returncode == 0 else ""
    except Exception:
        return ""


def ocr_langs() -> str:
    """Persian too when the person reads or types it; it doubles the time."""
    try:
        import paths
        env = paths.read_desktop_env()
        if "fa" in env.get("OSPRIME_LANG", "") or "fa" in env.get("OSPRIME_KEYBOARD", ""):
            return "eng+fas"
    except Exception:
        pass
    return "eng"


_JUNK = re.compile(r"^[\W_|]+|[\W_|]+$")


def ocr_lines(path: str, langs: str = None):
    """Every line of text on the screen, in screenshot pixels.

    Screen text is small for tesseract, so the picture is doubled first
    (measured 8 October: "Theme" was missed at 1x and found at 2x). And a
    second pass reads light text on coloured buttons — white "Apply" on blue
    was invisible to the first: each pixel's difference from its own
    neighbourhood (a median, which wipes out thin letters and keeps the
    button's colour) becomes dark-on-white whatever the colours were."""
    langs = langs or ocr_langs()
    try:
        from PIL import Image, ImageChops, ImageFilter
    except Exception:
        return parse_tsv(ocr_tsv(path, langs))
    import tempfile
    im = Image.open(path).convert("RGB")
    big = im.resize((im.width * 2, im.height * 2), Image.LANCZOS)
    passes = []
    with tempfile.TemporaryDirectory() as td:
        a = os.path.join(td, "a.png")
        big.convert("L").save(a)
        passes.append(parse_tsv(ocr_tsv(a, langs)))
        b = os.path.join(td, "b.png")
        bg = big.filter(ImageFilter.MedianFilter(11))
        diff = ImageChops.difference(big, bg).convert("L").point(lambda v: min(255, v * 3))
        ImageChops.invert(diff).save(b)
        passes.append(parse_tsv(ocr_tsv(b, langs)))
    return merge_lines(passes, 0.5)


def merge_lines(passes, scale=1.0):
    """Lines from several OCR passes, each once: a later pass adds only what
    the earlier ones did not see. Boxes scaled back to the screenshot."""
    out = []
    for lines in passes:
        for L in lines:
            text = _JUNK.sub("", L["text"]).strip()
            if len(text) < 2:
                continue
            x, y, w, h = (v * scale for v in L["box"])
            cx, cy = x + w / 2, y + h / 2
            if any(o["box"][0] <= cx <= o["box"][0] + o["box"][2] and
                   o["box"][1] <= cy <= o["box"][1] + o["box"][3] for o in out):
                continue
            out.append({"text": text, "box": (x, y, w, h)})
    return out


def parse_tsv(tsv: str, min_conf: float = 55):
    """tesseract TSV -> lines [{text, box:(x, y, w, h)}] in screen pixels.
    Words of one line are joined, so "Save as" is one target."""
    lines = {}
    for row in tsv.splitlines()[1:]:
        f = row.split("\t")
        if len(f) < 12 or f[0] != "5":
            continue
        try:
            conf = float(f[10])
            x, y, w, h = (int(v) for v in f[6:10])
        except ValueError:
            continue
        word = f[11].strip()
        if not word or conf < min_conf:
            continue
        key = (f[2], f[3], f[4])            # block, paragraph, line
        L = lines.setdefault(key, {"words": [], "x0": x, "y0": y, "x1": x + w, "y1": y + h})
        L["words"].append((x, word, (x, y, w, h)))
        L["x0"], L["y0"] = min(L["x0"], x), min(L["y0"], y)
        L["x1"], L["y1"] = max(L["x1"], x + w), max(L["y1"], y + h)
    out = []
    for L in lines.values():
        words = sorted(L["words"])
        out.append({"text": " ".join(w for _, w, _ in words),
                    "box": (L["x0"], L["y0"], L["x1"] - L["x0"], L["y1"] - L["y0"]),
                    "words": [{"text": w, "box": b} for _, w, b in words]})
    return out


# ---- the accessibility tree ----------------------------------------------------
def atspi_controls(budget: float = 1.5):
    """The front window's controls: (window info, [controls]). Each control:
    {name, role, wbox (window coords), sbox (screen coords as reported),
    sensitive}. ({}, []) when AT-SPI is not there or nothing is in front."""
    try:
        import gi
        gi.require_version("Atspi", "2.0")
        from gi.repository import Atspi
    except Exception:
        return {}, []
    try:
        Atspi.set_timeout(800, 3000)
    except Exception:
        pass
    deadline = time.monotonic() + budget
    desktop = Atspi.get_desktop(0)
    front = None
    for i in range(desktop.get_child_count()):
        app = desktop.get_child_at_index(i)
        if app is None:
            continue
        name = (app.get_name() or "")
        if name.startswith("osprime-companion") or name in ("waybar", "osprime-desktop.py"):
            continue
        for j in range(app.get_child_count()):
            win = app.get_child_at_index(j)
            try:
                if win and win.get_state_set().contains(Atspi.StateType.ACTIVE):
                    front = (app, win)
                    break
            except Exception:
                continue
        if front:
            break
    if not front:
        return {}, []
    app, win = front
    info = {"app": app.get_name() or "", "title": win.get_name() or ""}
    try:
        e = win.get_extents(Atspi.CoordType.SCREEN)
        info["sbox"] = (e.x, e.y, e.width, e.height)
        info["wsize"] = (e.width, e.height)
    except Exception:
        pass
    out = []
    ww, wh = info.get("wsize") or (100000, 100000)
    # A web page is a deep tree, most of it scrolled out of sight: a browser
    # gets more time, and whatever lies outside the window is not walked
    # (9 October: the Google sign-up links were past the old limit).
    browser = any(b in info["app"].lower() for b in ("chrom", "firefox", "browser", "brave"))
    if browser:
        deadline += 1.5

    def walk(node, depth, in_doc=False):
        if node is None or depth > 60 or len(out) >= 600 or time.monotonic() > deadline:
            return
        try:
            role = node.get_role_name()
            states = node.get_state_set()
            showing = states.contains(Atspi.StateType.SHOWING) and states.contains(Atspi.StateType.VISIBLE)
        except Exception:
            return
        if not showing and depth > 1:
            return
        if role in ("document web", "document frame"):
            in_doc = True
        try:
            e = node.get_extents(Atspi.CoordType.WINDOW)
            if depth > 1 and e.width > 0 and (e.x > ww or e.y > wh or e.x + e.width < 0 or e.y + e.height < 0):
                return          # scrolled away: nothing in it can be clicked now
        except Exception:
            pass
        if role in CLICKABLE:
            try:
                name = (node.get_name() or "").strip()
                if not name and role in ("entry", "text", "password text"):
                    name = (node.get_description() or "").strip()
                w = node.get_extents(Atspi.CoordType.WINDOW)
                s = node.get_extents(Atspi.CoordType.SCREEN)
                if w.width > 2 and w.height > 2 and (name or role in ("entry", "password text")):
                    out.append({"name": name[:80], "role": role,
                                "wbox": (w.x, w.y, w.width, w.height),
                                "sbox": (s.x, s.y, s.width, s.height),
                                "page": in_doc,
                                "sensitive": role in SENSITIVE_ROLES or bool(SENSITIVE_WORDS.search(name))})
            except Exception:
                pass
        try:
            n = node.get_child_count()
        except Exception:
            return
        for k in range(min(n, 300)):
            try:
                walk(node.get_child_at_index(k), depth + 1, in_doc)
            except Exception:
                continue

    walk(win, 0)
    return info, out


# ---- tying the two together -----------------------------------------------------
def _norm(s: str) -> str:
    return re.sub(r"[\W_]+", " ", (s or "").lower()).strip()


def window_offset(controls, lines, scale=1.0, tol=8):
    """Where the front window is on the screen, from controls whose name OCR
    read too. Each match proposes an offset: OCR box − window box.

    Vertically, text sits in the middle of its control: centres compared.
    Across, it depends: a button centres its label, a list row or a menu
    item starts it after some padding. So each match proposes both — "text
    centred" and "text after a padding as wide as the vertical one" — and the
    proposals that agree with each other win: centred buttons of different
    widths only agree on the first, left-aligned rows only on the second.
    (8 October, a test window: centres alone were 13 px off on a list.)
    It takes two matches to be believed. `scale` turns AT-SPI's logical
    pixels into the picture's."""
    xs_c, xs_l, ys = [], [], []
    for c in controls:
        name = _norm(c["name"])
        if len(name) < 3:
            continue
        wx, wy, ww, wh = (v * scale for v in c["wbox"])
        for L in lines:
            if _norm(L["text"]) != name:
                continue
            lx, ly, lw, lh = L["box"]
            ys.append(ly + lh / 2 - (wy + wh / 2))
            xs_c.append(lx + lw / 2 - (wx + ww / 2))
            xs_l.append(lx - max(0.0, (wh - lh) / 2) - wx)
    if len(ys) < 2:
        return None

    def cluster(vals):
        best = []
        for v in vals:
            g = [u for u in vals if abs(u - v) <= tol]
            if len(g) > len(best):
                best = g
        return best
    yb = cluster(ys)
    if len(yb) < 2:
        return None
    xc, xl = cluster(xs_c), cluster(xs_l)
    xb = xc if len(xc) >= len(xl) else xl
    return (sum(xb) / len(xb), sum(yb) / len(yb))


def candidates(info, controls, lines, screen_w, screen_h, scale=1.0, maximised=None):
    """The numbered list the model chooses from. Rectangles in screenshot
    pixels. AT-SPI controls first (their names and roles are exact), then
    OCR lines that no control already covers."""
    off = window_offset(controls, lines, scale)
    how = "ocr-anchored" if off else None
    if off is None:
        sb = info.get("sbox")
        if sb and (sb[0] or sb[1]):                       # the screen position is real
            off, how = (sb[0] * scale, sb[1] * scale), "atspi"
        elif maximised:
            off, how = (maximised[0] * scale, maximised[1] * scale), "maximised"
    out = []
    # The page before the browser around it: on a web page the thing to
    # click is almost always in the page, and the list is cut at
    # MAX_ELEMENTS.
    controls = sorted(controls, key=lambda c: not c.get("page"))
    if off is not None:
        for c in controls:
            x, y, w, h = (v * scale for v in c["wbox"])
            box = (x + off[0], y + off[1], w, h)
            if box[0] < 0 or box[1] < 0 or box[0] + w > screen_w or box[1] + h > screen_h:
                continue
            out.append({"type": c["role"], "name": c["name"], "box": box,
                        "sensitive": c["sensitive"], "from": "accessibility"})
    taken = [e["box"] for e in out]

    def covered(b):
        cx, cy = b[0] + b[2] / 2, b[1] + b[3] / 2
        return any(t[0] <= cx <= t[0] + t[2] and t[1] <= cy <= t[1] + t[3] for t in taken)
    for L in lines:
        if len(L["text"]) < 2 or covered(L["box"]):
            continue
        x, y, w, h = L["box"]
        pad = max(4, h * 0.4)                  # a little of the button around the word
        out.append({"type": "text", "name": L["text"][:80],
                    "box": (max(0, x - pad), max(0, y - pad), w + 2 * pad, h + 2 * pad),
                    "sensitive": bool(SENSITIVE_WORDS.search(L["text"])), "from": "ocr"})
    out = out[:MAX_ELEMENTS]
    for i, e in enumerate(out, 1):
        e["id"] = i
    return out, how


def describe_list(cands, screen_w, screen_h) -> str:
    """id | type | "name" | x,y,w,h as fractions of the screen."""
    rows = []
    for e in cands:
        x, y, w, h = e["box"]
        rows.append(f'{e["id"]} | {e["type"]} | "{e["name"]}" | '
                    f'{x / screen_w:.3f},{y / screen_h:.3f},{w / screen_w:.3f},{h / screen_h:.3f}')
    return "\n".join(rows)


# ---- did the screen change? ---------------------------------------------------
def grid(path: str, cols=96, rows=54):
    """The screenshot shrunk to a small grey grid, for "did anything change"."""
    try:
        import cairo
        src = cairo.ImageSurface.create_from_png(path)
        dst = cairo.ImageSurface(cairo.FORMAT_ARGB32, cols, rows)
        cr = cairo.Context(dst)
        cr.scale(cols / src.get_width(), rows / src.get_height())
        cr.set_source_surface(src, 0, 0)
        cr.get_source().set_filter(cairo.FILTER_GOOD)
        cr.paint()
        data, stride = dst.get_data(), dst.get_stride()
        return [[(data[y * stride + x * 4] + data[y * stride + x * 4 + 1] + data[y * stride + x * 4 + 2]) // 3
                 for x in range(cols)] for y in range(rows)]
    except Exception:
        return None


def changed(a, b, ignore=frozenset(), cell_delta=18, share=0.004) -> bool:
    """Did enough of the screen change — ignoring the cells our own strand,
    ring and bubble are drawn over, which would otherwise count as change."""
    if not a or not b or len(a) != len(b):
        return False
    rows, cols = len(a), len(a[0])
    diff = sum(1 for y in range(rows) for x in range(cols)
               if (y, x) not in ignore and abs(a[y][x] - b[y][x]) > cell_delta)
    return diff >= max(2, share * rows * cols)
