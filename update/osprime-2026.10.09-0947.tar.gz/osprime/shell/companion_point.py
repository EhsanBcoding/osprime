"""Point and ask (docs/COMPANION.md, phase 3): Super+T, drag over any part of
the screen, ask about it.

The selection is the whole of what is seen: one picture of the area you
dragged over, saved in a private folder in memory (paths.point_dir(), 0700)
and deleted two minutes after it was used, or when the bubble starts over.
Nothing is captured before you choose, and nothing outside the area.

slurp draws the selection (Esc cancels), grim takes the picture; both ship
with OSprime for the screenshot tool already. The assistant side is
agent.with_selected_area(): the vision model (local, or the cloud one when it
is on) reads the picture and its account goes along with the question.
"""
import os
import pathlib
import re
import shutil
import subprocess
import time

import paths

KEEP_SECONDS = 120
_GEOM = re.compile(r"^-?\d+,-?\d+ \d+x\d+$")

# The three buttons under the picture. The question goes to the model as
# written, so it is in the language the system speaks.
PRESETS = {
    "en": [("Explain", "What is this? Explain it simply."),
           ("Fix", "Something is wrong here. What is the problem, and how do I fix it?"),
           ("Guide me", "Show me step by step how to do this.")],
    "fa": [("توضیح بده", "این چیه؟ ساده توضیح بده."),
           ("درستش کن", "اینجا یه مشکلی هست. مشکل چیه و چطور درستش کنم؟"),
           ("قدم‌به‌قدم", "قدم‌به‌قدم نشونم بده چطور این کار رو انجام بدم.")],
}


def presets():
    lang = paths.read_desktop_env().get("OSPRIME_LANG", "en").strip('"')
    return PRESETS.get(lang, PRESETS["en"])


def folder() -> pathlib.Path:
    d = paths.point_dir()
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o700)
    return d


def sweep(max_age: float = KEEP_SECONDS):
    """Delete pictures older than max_age (0: all of them)."""
    try:
        now = time.time()
        for f in folder().glob("*.png"):
            if max_age == 0 or now - f.stat().st_mtime > max_age:
                f.unlink(missing_ok=True)
    except Exception:
        pass


def can_point():
    for tool in ("slurp", "grim"):
        if not shutil.which(tool):
            return False, f"{tool} is missing, so I cannot select part of the screen."
    return True, ""


def select_area():
    """('x,y wxh', '') when an area was dragged; (None, '') when the person
    pressed Esc; (None, reason) when it could not run."""
    try:
        r = subprocess.run(["slurp", "-b", "0b0f1866", "-c", "4fd6d6ff", "-w", "2"],
                           capture_output=True, text=True, timeout=120)
    except Exception as e:
        return None, f"could not start the selection ({e})"
    geom = (r.stdout or "").strip()
    if r.returncode != 0 or not geom:
        return None, ""
    if not _GEOM.match(geom):
        return None, f"the selection came back as {geom!r}"
    w, h = (int(v) for v in geom.split(" ")[1].split("x"))
    if w < 4 or h < 4:
        return None, "that area is too small — drag over what you mean"
    return geom, ""


def capture(geom: str):
    """(path, '') or (None, reason)."""
    sweep()
    path = folder() / f"area-{int(time.time() * 1000)}.png"
    try:
        r = subprocess.run(["grim", "-g", geom, str(path)], capture_output=True,
                           text=True, timeout=30)
    except Exception as e:
        return None, f"the picture could not be taken ({e})"
    if r.returncode != 0 or not path.is_file():
        return None, "the picture could not be taken: " + (r.stderr or "").strip()[:200]
    os.chmod(path, 0o600)
    return path, ""
