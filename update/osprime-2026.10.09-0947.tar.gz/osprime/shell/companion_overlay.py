"""The strand: from the character's hand to the one thing to click
(docs/COMPANION.md, phase 4).

A transparent layer over the whole screen that never takes a click: the
person clicks the real control underneath. It draws three things —

  * the strand, a soft silver tube that unwinds from the hand to the target
    in about 0.7 s and winds back the same way, with a light running along it
    so a settled pointer still reads as alive;
  * a ring around the target, in the character's glow colour (amber, with a
    dashed ring, when it is a best guess);
  * a small tag beside the target with the instruction, so the eye does not
    have to travel back to the bubble.

Once arrived it breathes for a few seconds, then holds still to spare the
processor. The drawing is a pure function of (start, target, progress, t),
`paint()`, so the tests render it to a PNG without a compositor.
"""
import math
import time

import cairo

UNWIND = 0.7
REWIND = 0.5
BREATHE = 6.0


def ease(p):
    return 1 - (1 - p) ** 3


def _bezier(p0, p1, p2, p3, t):
    u = 1 - t
    return (u ** 3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t ** 3 * p3[0],
            u ** 3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t ** 3 * p3[1])


def edge_point(start, rect, pad=10):
    """Where the strand stops: the edge of the (padded) target, on the line
    from its centre towards the hand."""
    x, y, w, h = rect
    cx, cy = x + w / 2, y + h / 2
    dx, dy = start[0] - cx, start[1] - cy
    if dx == 0 and dy == 0:
        return cx, cy
    hw, hh = w / 2 + pad, h / 2 + pad
    k = min(hw / abs(dx) if dx else 1e9, hh / abs(dy) if dy else 1e9)
    return cx + dx * k, cy + dy * k


def path_points(start, rect, n=64):
    """The strand as points: one gentle S-curve that bows toward the middle
    of the line, so it never runs straight across text."""
    end = edge_point(start, rect)
    dx, dy = end[0] - start[0], end[1] - start[1]
    dist = math.hypot(dx, dy) or 1
    nx, ny = -dy / dist, dx / dist
    bow = min(120, dist * 0.18)
    c1 = (start[0] + dx * 0.3 + nx * bow, start[1] + dy * 0.3 + ny * bow)
    c2 = (start[0] + dx * 0.7 - nx * bow * 0.6, start[1] + dy * 0.7 - ny * bow * 0.6)
    return [_bezier(start, c1, c2, end, i / (n - 1)) for i in range(n)]


def paint(cr, start, rect, progress, t, colour=(0.35, 0.92, 0.88), guess=False,
          label="", rtl=False):
    """One frame. progress 0..1: how far the strand has unwound."""
    if rect is None or progress <= 0:
        return
    pts = path_points(start, rect)
    k = max(2, int(len(pts) * min(1.0, progress)))
    shown = pts[:k]
    accent = (1.0, 0.70, 0.25) if guess else colour
    # The tube: a dark edge, a silver body, a bright core.
    for width, rgba in ((7, (0.05, 0.06, 0.08, 0.55)), (5, (0.70, 0.73, 0.78, 0.95)),
                        (2, (0.97, 0.98, 1.0, 0.9))):
        cr.move_to(*shown[0])
        for p in shown[1:]:
            cr.line_to(*p)
        cr.set_source_rgba(*rgba)
        cr.set_line_width(width)
        cr.set_line_cap(cairo.LINE_CAP_ROUND)
        cr.set_line_join(cairo.LINE_JOIN_ROUND)
        cr.stroke()
    # A light running from the hand to the tip.
    if progress >= 1:
        f = (t / 1.6) % 1.0
        lx, ly = pts[min(len(pts) - 1, int(f * (len(pts) - 1)))]
        g = cairo.RadialGradient(lx, ly, 0, lx, ly, 14)
        g.add_color_stop_rgba(0, *accent, 0.95)
        g.add_color_stop_rgba(1, *accent, 0)
        cr.set_source(g)
        cr.arc(lx, ly, 14, 0, 2 * math.pi)
        cr.fill()
    # The tip always carries a light, so it can be found on a busy screen.
    tx, ty = shown[-1]
    g = cairo.RadialGradient(tx, ty, 0, tx, ty, 10)
    g.add_color_stop_rgba(0, 1, 1, 1, 0.95)
    g.add_color_stop_rgba(1, *accent, 0)
    cr.set_source(g)
    cr.arc(tx, ty, 10, 0, 2 * math.pi)
    cr.fill()
    if progress < 1:
        return
    # The ring, breathing for a while after it arrives.
    x, y, w, h = rect
    breath = 0.5 + 0.5 * math.sin(t * 3.2) if t < BREATHE else 0.6
    pad = 5 + 2 * breath
    r = min(12, (h + 2 * pad) / 2)
    _round_rect(cr, x - pad, y - pad, w + 2 * pad, h + 2 * pad, r)
    cr.set_source_rgba(*accent, 0.30 + 0.25 * breath)
    cr.set_line_width(6)
    cr.stroke_preserve()
    cr.set_source_rgba(*accent, 0.95)
    cr.set_line_width(2)
    if guess:
        cr.set_dash([6, 4])
    cr.stroke()
    cr.set_dash([])
    if label:
        _tag(cr, label, rect, accent, rtl)


def _round_rect(cr, x, y, w, h, r):
    cr.new_sub_path()
    cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
    cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
    cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
    cr.close_path()


def tag_rect(rect, tw, th, screen=None):
    """Beside the target (to the right) when there is room, so it does not
    cover the controls under it in a list; else below; else above."""
    x, y, w, h = rect
    sw, sh = screen or (10 ** 6, 10 ** 6)
    if x + w + 16 + tw <= sw - 4:
        return x + w + 16, max(4, min(y + h / 2 - th / 2, sh - th - 4)), tw, th
    tx, ty = x, y + h + 12
    if ty + th > sh:
        ty = y - th - 12
    tx = max(4, min(tx, sw - tw - 4))
    return tx, ty, tw, th


def _tag(cr, text, rect, accent, rtl):
    try:
        gi_layout = _layout(cr, text, rtl)
    except Exception:
        return
    lw, lh = gi_layout.get_pixel_size()
    tw, th = min(lw, 360) + 20, lh + 12
    clip = cr.get_target()
    try:
        screen = (clip.get_width(), clip.get_height())
    except Exception:
        screen = None
    x, y, w, h = tag_rect(rect, tw, th, screen)
    _round_rect(cr, x, y, w, h, 8)
    cr.set_source_rgba(0.09, 0.11, 0.15, 0.94)
    cr.fill_preserve()
    cr.set_source_rgba(*accent, 0.9)
    cr.set_line_width(1.5)
    cr.stroke()
    cr.move_to(x + 10, y + 6)
    cr.set_source_rgb(0.92, 0.95, 0.98)
    from gi.repository import PangoCairo
    PangoCairo.show_layout(cr, gi_layout)


def _layout(cr, text, rtl):
    import gi
    gi.require_version("Pango", "1.0")
    gi.require_version("PangoCairo", "1.0")
    from gi.repository import Pango, PangoCairo
    layout = PangoCairo.create_layout(cr)
    layout.set_font_description(Pango.FontDescription("Noto Sans 11"))
    layout.set_width(360 * Pango.SCALE)
    layout.set_wrap(Pango.WrapMode.WORD_CHAR)
    layout.set_alignment(Pango.Alignment.RIGHT if rtl else Pango.Alignment.LEFT)
    layout.set_text(text, -1)
    return layout


def cells_under(start, rect, label_rect, cols, rows, scale_x, scale_y, margin=1):
    """Grid cells (row, col) the overlay draws on, so "did the screen
    change" ignores our own drawing. Coordinates in screen pixels of the
    picture; scale = grid cells per pixel."""
    cells = set()

    def add(px, py, m=margin):
        cx, cy = int(px * scale_x), int(py * scale_y)
        for yy in range(cy - m, cy + m + 1):
            for xx in range(cx - m, cx + m + 1):
                if 0 <= yy < rows and 0 <= xx < cols:
                    cells.add((yy, xx))
    for p in path_points(start, rect, 96):
        add(*p)
    for r in [rect] + ([label_rect] if label_rect else []):
        x, y, w, h = r
        pad = 14
        for yy in range(int((y - pad) * scale_y) - 1, int((y + h + pad) * scale_y) + 2):
            for xx in range(int((x - pad) * scale_x) - 1, int((x + w + pad) * scale_x) + 2):
                if 0 <= yy < rows and 0 <= xx < cols:
                    cells.add((yy, xx))
    return cells


class Overlay:
    """The window. Built lazily by the guide; GTK only from here down."""

    def __init__(self, colour=(0.35, 0.92, 0.88)):
        import gi
        gi.require_version("Gtk", "3.0")
        gi.require_version("GtkLayerShell", "0.1")
        from gi.repository import Gtk, GLib, GtkLayerShell
        self.Gtk, self.GLib = Gtk, GLib
        self.colour = colour
        self.start = (0, 0)
        self.rect = None
        self.label = ""
        self.rtl = False
        self.guess = False
        self.progress = 0.0
        self.direction = 0          # +1 unwinding, -1 rewinding
        self.t_arrived = 0.0
        self._clock = None
        self.on_hidden = None
        self.win = Gtk.Window()
        GtkLayerShell.init_for_window(self.win)
        GtkLayerShell.set_layer(self.win, GtkLayerShell.Layer.OVERLAY)
        GtkLayerShell.set_namespace(self.win, "osprime-companion-guide")
        for e in (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.BOTTOM,
                  GtkLayerShell.Edge.LEFT, GtkLayerShell.Edge.RIGHT):
            GtkLayerShell.set_anchor(self.win, e, True)
        GtkLayerShell.set_exclusive_zone(self.win, -1)
        try:
            GtkLayerShell.set_keyboard_mode(self.win, GtkLayerShell.KeyboardMode.NONE)
        except Exception:
            pass
        visual = self.win.get_screen().get_rgba_visual()
        if visual is not None:
            self.win.set_visual(visual)
        self.win.set_app_paintable(True)
        self.win.connect("draw", self._draw)
        self.win.connect("realize", lambda *_: self._click_through())

    def _click_through(self):
        gw = self.win.get_window()
        if gw is not None:
            gw.input_shape_combine_region(cairo.Region(), 0, 0)   # no clicks, ever

    def size(self):
        w, h = self.win.get_size()
        if w < 50:
            from gi.repository import Gdk
            g = Gdk.Display.get_default().get_monitor(0).get_geometry()
            w, h = g.width, g.height
        return w, h

    def point(self, start, rect, label="", guess=False, rtl=False):
        self.start, self.rect, self.label, self.guess, self.rtl = start, rect, label, guess, rtl
        self.progress, self.direction = 0.0, 1
        self.win.show_all()
        self._click_through()
        self._run()

    def wind_back(self, then=None):
        self.on_hidden = then
        if self.rect is None or not self.win.get_visible():
            self._hidden()
            return
        self.direction = -1
        self._run()

    def _hidden(self):
        self.win.hide()
        self.rect = None
        cb, self.on_hidden = self.on_hidden, None
        if cb:
            cb()

    def _run(self):
        if self._clock is None:
            self._last = time.monotonic()
            self._clock = self.GLib.timeout_add(16, self._tick)

    def _tick(self):
        now = time.monotonic()
        dt, self._last = now - self._last, now
        if self.direction > 0:
            self.progress = min(1.0, self.progress + dt / UNWIND)
            if self.progress >= 1.0:
                self.direction = 0
                self.t_arrived = now
        elif self.direction < 0:
            self.progress = max(0.0, self.progress - dt / REWIND)
            if self.progress <= 0:
                self.direction = 0
                self._clock = None
                self._hidden()
                return False
        self.win.queue_draw()
        if self.direction == 0 and now - self.t_arrived > BREATHE:
            self._clock = None          # settled: hold still, no more frames
            return False
        return True

    def _draw(self, _w, cr):
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)
        t = time.monotonic() - self.t_arrived if self.direction == 0 else 0
        paint(cr, self.start, self.rect, ease(self.progress), t, self.colour,
              self.guess, self.label if self.progress >= 1 else "", self.rtl)
        return False
