---
name: General
name_fa: همه‌کاره
color: "#e6edf3"
tools: []
glance: today
order: 0
---
The everyday assistant: everything this computer can do.
