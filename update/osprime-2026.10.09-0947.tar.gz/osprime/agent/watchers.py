"""Watchers: things a person asked a helper to keep an eye on (docs/HELPERS.md,
step 3; Ehsan, 9 October).

"Tell me when Bitcoin goes over 70,000." "Let me know when new papers on
sleep and memory come out." "Watch the CI of my repo." A watcher is one of
those, saved, and checked in the background with data only — no model runs,
so it costs nothing and works with the local model off.

Rules (docs/COMPANION.md, and the lesson of the reminder that fired every
minute on 7 October):

  * Only what the person set up. A watcher is made by asking (tool "watch")
    and can be seen, paused and removed in Settings → Watchers. Like a
    reminder, it is the person's own alarm, so it is outside proactive.py's
    two-a-day limit — but nothing here ever invents one.
  * Each fires ONCE when its condition becomes true, then waits until the
    condition has been false again (armed/disarmed). A price sitting above
    the line is one alert, not one every five minutes.
  * The first look is a baseline, never an alert: "new papers" means new
    since you asked, not everything that already exists.
  * The alert is a dot on Brainy and a line in that helper's conversation
    in the panel (Ehsan, 9 October). Nothing opens, nothing makes a sound.
  * Free sources only, the same as the helpers' tools.

State is one JSON file in the person's state folder, written atomically
under a lock (the agent checks, the panel marks alerts as read).
"""
import contextlib
import difflib
import hashlib
import html as htmllib
import ipaddress
import json
import os
import pathlib
import re
import socket
import threading
import time
import urllib.parse

import paths

# kind -> (seconds between checks, the helper it belongs to by default)
KINDS = {
    "price": (300, "trader"),
    "papers": (86400, "researcher"),
    "github": (900, "engineer"),
    "repo": (86400, "engineer"),
    "page": (86400, "general"),
}
MAX_WATCHERS = 30
MAX_ALERTS = 60
LOOP_SECONDS = 60
_REPO = re.compile(r"^[A-Za-z0-9_.-]{1,39}/[A-Za-z0-9_.-]{1,100}$")


# ---------------------------------------------------------------------------
# the file
# ---------------------------------------------------------------------------
def _file() -> pathlib.Path:
    return paths.state_dir() / "watchers.json"


@contextlib.contextmanager
def _locked():
    f = _file()
    f.parent.mkdir(parents=True, exist_ok=True)
    with open(str(f) + ".lock", "a+") as lk:
        try:
            import fcntl
            fcntl.flock(lk, fcntl.LOCK_EX)
        except Exception:
            pass
        yield


def _load() -> dict:
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
        if isinstance(d, dict):
            d.setdefault("watchers", [])
            d.setdefault("alerts", [])
            return d
    except Exception:
        pass
    return {"watchers": [], "alerts": []}


def _save(d: dict):
    f = _file()
    tmp = f.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(f)


# ---------------------------------------------------------------------------
# making, listing, removing
# ---------------------------------------------------------------------------
def _public_url(url: str) -> bool:
    """A web page on the internet, not this computer or the home network."""
    try:
        u = urllib.parse.urlparse(url)
        if u.scheme not in ("http", "https") or not u.hostname:
            return False
        for info in socket.getaddrinfo(u.hostname, None):
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                return False
        return True
    except Exception:
        return False


def describe(w: dict) -> str:
    p = w.get("params", {})
    k = w.get("kind")
    if k == "price":
        if p.get("op") == "move":
            return f"{p['symbol']} moves {p['value']:g}% or more in a day"
        return f"{p['symbol']} {p['op']} {p['value']:,.10g}"
    if k == "papers":
        return f"new papers on “{p['query']}”"
    if k == "github":
        return f"CI failures and new pull requests on {p['repo']}"
    if k == "repo":
        return f"{pathlib.Path(p['path']).name}: changes not committed for {p['days']} days"
    if k == "page":
        return f"changes on {p['url']}"
    return k or "?"


def add(kind: str, params: dict, helper: str = "", label: str = "") -> dict:
    kind = (kind or "").strip().lower()
    if kind not in KINDS:
        return {"ok": False, "message": "Kind is one of: " + ", ".join(KINDS)}
    p = {}
    params = params or {}
    if kind == "price":
        import helpers
        sym = str(params.get("symbol") or "").strip().upper()
        if helpers.classify(sym)[0] is None:
            return {"ok": False, "message": f"{sym!r} is not a symbol I can price."}
        op = str(params.get("op") or "above").lower()
        if op not in ("above", "below", "move"):
            return {"ok": False, "message": "op is above, below or move (a % change in a day)."}
        try:
            value = float(str(params.get("value")).replace(",", ""))
        except (TypeError, ValueError):
            return {"ok": False, "message": "Say the price (or the %) to watch for."}
        if value <= 0 or (op == "move" and value > 100):
            return {"ok": False, "message": "That number cannot be watched."}
        p = {"symbol": sym, "op": op, "value": value}
    elif kind == "papers":
        q = " ".join(str(params.get("query") or "").split())[:200]
        if len(q) < 3:
            return {"ok": False, "message": "Say the topic to watch."}
        p = {"query": q}
    elif kind == "github":
        repo = str(params.get("repo") or "").strip().removeprefix("https://github.com/").strip("/")
        if not _REPO.match(repo):
            return {"ok": False, "message": "A GitHub repository is owner/name."}
        p = {"repo": repo}
    elif kind == "repo":
        path = pathlib.Path(os.path.expanduser(str(params.get("path") or ""))).resolve()
        if not (path / ".git").exists():
            return {"ok": False, "message": f"{path} is not a git project."}
        try:
            days = max(1, min(60, int(params.get("days") or 3)))
        except (TypeError, ValueError):
            days = 3
        p = {"path": str(path), "days": days}
    elif kind == "page":
        url = str(params.get("url") or "").strip()
        if not _public_url(url):
            return {"ok": False, "message": "Only a public web page (http or https) can be watched."}
        p = {"url": url}
    with _locked():
        d = _load()
        for w in d["watchers"]:
            if w["kind"] == kind and w["params"] == p:
                return {"ok": True, "id": w["id"], "message": "Already watching: " + describe(w) + "."}
        if len(d["watchers"]) >= MAX_WATCHERS:
            return {"ok": False, "message": f"There are already {MAX_WATCHERS} watchers; remove one first."}
        import helpers
        hid = helper if helper and helpers.get(helper) else KINDS[kind][1]
        w = {"id": hashlib.sha1(f"{kind}{p}{time.time()}".encode()).hexdigest()[:8],
             "kind": kind, "params": p, "helper": hid, "label": (label or "")[:80],
             "every": KINDS[kind][0], "created": int(time.time()), "last_check": 0,
             "paused": False, "armed": True, "memo": {}}
        d["watchers"].append(w)
        _save(d)
    return {"ok": True, "id": w["id"], "message": "Watching: " + describe(w) +
            ". You will see a dot on Brainy when it happens."}


def list_all(helper: str = "") -> list:
    out = []
    for w in _load()["watchers"]:
        if helper and w.get("helper") != helper:
            continue
        out.append({"id": w["id"], "kind": w["kind"], "helper": w.get("helper"),
                    "what": describe(w), "paused": bool(w.get("paused")),
                    "last_check": w.get("last_check", 0), "error": w.get("error", "")})
    return out


def remove(wid: str) -> dict:
    with _locked():
        d = _load()
        keep = [w for w in d["watchers"] if w["id"] != wid]
        if len(keep) == len(d["watchers"]):
            return {"ok": False, "message": "No such watcher."}
        gone = next(w for w in d["watchers"] if w["id"] == wid)
        d["watchers"] = keep
        _save(d)
    return {"ok": True, "message": "Stopped watching: " + describe(gone) + "."}


def pause(wid: str, on: bool = True) -> dict:
    with _locked():
        d = _load()
        for w in d["watchers"]:
            if w["id"] == wid:
                w["paused"] = bool(on)
                _save(d)
                return {"ok": True, "message": ("Paused: " if on else "Watching again: ") + describe(w) + "."}
    return {"ok": False, "message": "No such watcher."}


# ---------------------------------------------------------------------------
# alerts
# ---------------------------------------------------------------------------
def unseen(helper: str = "") -> list:
    return [a for a in _load()["alerts"] if not a.get("seen") and (not helper or a["helper"] == helper)]


def mark_seen(helper: str = "") -> int:
    n = 0
    with _locked():
        d = _load()
        for a in d["alerts"]:
            if not a.get("seen") and (not helper or a["helper"] == helper):
                a["seen"] = True
                n += 1
        if n:
            _save(d)
    return n


# ---------------------------------------------------------------------------
# the checks — data only
# ---------------------------------------------------------------------------
def _armed(w, cond: bool, text: str):
    """Once when it becomes true; again only after it has been false."""
    if cond and w.get("armed", True):
        w["armed"] = False
        return text
    if not cond:
        w["armed"] = True
    return None


def check_price(w, now):
    import helpers
    p = w["params"]
    r = json.loads(helpers.market_price([p["symbol"]]))["prices"].get(p["symbol"], {})
    if "price" not in r:
        raise RuntimeError(r.get("error") or "no price")
    price, ch = float(r["price"]), r.get("change_pct")
    src = r.get("source", "")
    if p["op"] == "above":
        cond = price >= p["value"]
    elif p["op"] == "below":
        cond = price <= p["value"]
    else:
        cond = ch is not None and abs(float(ch)) >= p["value"]
    w["memo"]["last"] = price
    chs = f" ({float(ch):+.2f}%)" if ch is not None else ""
    return _armed(w, cond, f"{p['symbol']} is {helpers._price(price)}{chs} — you asked to know when "
                           f"{describe(w)}. Source: {src}. Information only, not advice.")


def check_papers(w, now):
    import helpers
    p = w["params"]
    since = time.strftime("%Y-%m-%d", time.gmtime(w["created"] - 86400))
    j = helpers._get_json("https://api.openalex.org/works?per-page=15&sort=publication_date:desc"
                          "&filter=from_publication_date:%s&search=%s"
                          % (since, urllib.parse.quote(p["query"])))
    found = {str(x.get("id")): (x.get("title") or x.get("display_name") or "")
             for x in (j or {}).get("results", []) if x.get("id")}
    seen = set(w["memo"].get("seen", []))
    first = "seen" not in w["memo"]
    new = [t for i, t in found.items() if i not in seen]
    w["memo"]["seen"] = sorted(seen | set(found))[-300:]
    if first or not new:
        return None
    titles = "; ".join(t[:90] for t in new[:3])
    return (f"{len(new)} new paper{'s' if len(new) > 1 else ''} on “{p['query']}”: {titles}"
            f"{' …' if len(new) > 3 else ''}. Source: OpenAlex. Ask me for details.")


def check_github(w, now):
    import helpers
    repo = w["params"]["repo"]
    base = f"https://api.github.com/repos/{repo}"
    runs = (helpers._get_json(base + "/actions/runs?per_page=1") or {}).get("workflow_runs") or []
    prs = helpers._get_json(base + "/pulls?state=open&per_page=10") or []
    first = "prs" not in w["memo"]
    out = []
    if runs:
        r = runs[0]
        if r.get("status") == "completed":
            if (not first and r.get("id") != w["memo"].get("run")
                    and r.get("conclusion") in ("failure", "timed_out")):
                out.append(f"CI failed on {repo} ({r.get('head_branch')}): {r.get('name')}")
            w["memo"]["run"] = r.get("id")
    known = set(w["memo"].get("prs", []))
    nums = [x["number"] for x in prs if isinstance(x, dict) and "number" in x]
    if not first:
        for x in prs:
            if isinstance(x, dict) and x.get("number") not in known:
                out.append(f"New pull request on {repo}: #{x['number']} {x.get('title', '')[:80]}")
    w["memo"]["prs"] = sorted(known | set(nums))[-200:]
    return ("; ".join(out) + ". Source: GitHub.") if out else None


def check_repo(w, now):
    import helpers
    p = w["params"]
    s = helpers.repo_state(p["path"])
    if s["changed"]:
        w["memo"].setdefault("dirty_since", now)
    else:
        w["memo"].pop("dirty_since", None)
    since = w["memo"].get("dirty_since")
    cond = bool(since) and now - since >= p["days"] * 86400
    return _armed(w, cond, f"{s['name']} has {s['changed']} change(s) not committed for "
                           f"{p['days']} days or more (branch {s['branch']}).")


_DROP = re.compile(r"(?is)<(script|style|noscript|nav|header|footer|aside|form|svg|iframe)\b.*?</\1>")


def page_lines(page: str) -> list:
    """The text a person reads, without what changes on its own: numbers
    (clocks, counters, prices in a sidebar) are taken out and very short
    lines (menus, buttons) are skipped."""
    t = _DROP.sub(" ", page or "")
    t = re.sub(r"(?i)<(br|p|div|li|h[1-6]|tr|section|article)\b[^>]*>", "\n", t)
    t = htmllib.unescape(re.sub(r"(?s)<[^>]+>", " ", t))
    out = []
    for line in t.splitlines():
        line = " ".join(re.sub(r"[\d۰-۹٠-٩]+", "#", line).split())
        if len(line.split()) >= 4:
            out.append(line[:300])
    return out[:600]


def page_changed(old: list, new: list):
    """-> the first new lines, when enough of the page is different."""
    if not old:
        return None
    sm = difflib.SequenceMatcher(None, old, new, autojunk=False)
    added = [l for tag, _a, _b, c, d in sm.get_opcodes() if tag in ("replace", "insert") for l in new[c:d]]
    if len(added) >= 2 and (sm.ratio() < 0.97 or len(added) >= 5):
        return added
    return None


def check_page(w, now):
    import webtools
    url = w["params"]["url"]
    if not _public_url(url):
        raise RuntimeError("not a public page")
    lines = page_lines(webtools._http_get(url, timeout=25)[:2_000_000])
    if not lines:
        raise RuntimeError("no readable text on the page")
    old = w["memo"].get("lines")
    w["memo"]["lines"] = lines
    added = page_changed(old or [], lines)
    if not added:
        return None
    return f"The page {url} has changed. New: “{added[0][:140]}”" + \
           (f" and {len(added) - 1} more line(s)." if len(added) > 1 else ".")


CHECKS = {"price": check_price, "papers": check_papers, "github": check_github,
          "repo": check_repo, "page": check_page}


def run_due(now=None, force=False) -> list:
    """Checks every watcher whose time has come. Returns the new alerts.
    The network is used outside the lock; only the results are merged in."""
    now = now or time.time()
    due = [w for w in _load()["watchers"]
           if not w.get("paused") and (force or now - w.get("last_check", 0) >= w.get("every", 3600))]
    results = {}
    for w in due:
        w.setdefault("memo", {})
        try:
            text = CHECKS[w["kind"]](w, now)
            w["error"] = ""
        except Exception as e:
            text = None
            w["error"] = f"{type(e).__name__}: {e}"[:160]
        w["last_check"] = now
        results[w["id"]] = (w, text)
    if not results:
        return []
    new = []
    with _locked():
        d = _load()
        for i, cur in enumerate(d["watchers"]):
            if cur["id"] in results:
                w, text = results[cur["id"]]
                w["paused"] = cur.get("paused", False)      # changed meanwhile in Settings
                d["watchers"][i] = w
                if text:
                    a = {"id": hashlib.sha1(f"{w['id']}{now}".encode()).hexdigest()[:10],
                         "wid": w["id"], "helper": w["helper"], "text": text,
                         "at": int(now), "seen": False}
                    d["alerts"].append(a)
                    new.append(a)
        d["alerts"] = d["alerts"][-MAX_ALERTS:]
        _save(d)
    return new


def start(on_alert=None):
    """The background loop, in the agent. Never takes the agent down."""
    def loop():
        time.sleep(20)
        while True:
            try:
                new = run_due()
                if new:
                    try:
                        import companion
                        companion.attention(True)
                    except Exception:
                        pass
                    if on_alert:
                        on_alert(new)
            except Exception as e:
                print(f"watchers: {e}")
            time.sleep(LOOP_SECONDS)
    t = threading.Thread(target=loop, daemon=True, name="watchers")
    t.start()
    return t


# ---------------------------------------------------------------------------
# the agent's tool
# ---------------------------------------------------------------------------
def tool(args: dict, helper: str = "") -> str:
    a = str(args.get("action") or "add").lower()
    if a == "list":
        items = list_all()
        if not items:
            return "No watchers. Ask, e.g. “tell me when BTC goes over 70000”."
        return json.dumps(items, ensure_ascii=False)
    if a in ("remove", "pause", "resume"):
        wid = str(args.get("id") or "")
        if not wid:
            # by words: the one whose description contains them
            q = str(args.get("what") or args.get("query") or args.get("symbol") or "").lower()
            hits = [w for w in list_all() if q and q in w["what"].lower()]
            if len(hits) != 1:
                return "ERROR: say which one (the id from action=list)."
            wid = hits[0]["id"]
        r = remove(wid) if a == "remove" else pause(wid, a == "pause")
        return r["message"] if r["ok"] else "ERROR: " + r["message"]
    kind = str(args.get("kind") or "").lower()
    params = {k: args.get(k) for k in ("symbol", "op", "value", "query", "repo", "path", "days", "url")
              if args.get(k) not in (None, "")}
    r = add(kind, params, helper=helper)
    return r["message"] if r["ok"] else "ERROR: " + r["message"]
