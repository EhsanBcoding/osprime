"""Live activity: what OSprime is busy with, beside Brainy (docs/COMPANION.md,
"Live activity"; a Coucou idea, approved 9 October).

A long job — a background command, a model download — shows as a small
card above the companion: what it is, how far along when that is known, and
a tick when it is done. It goes by itself a few seconds after it ends. It is
information, not a notification: nothing opens and nothing makes a sound.

Writers (the agent's jobs, Settings' model download) call begin/update/end;
the companion reads current(). One small JSON file beside the companion's
state file, written atomically under a lock, so two processes can share it.
A crashed writer leaves at most a stale entry, which is dropped after six
hours (or at once, when its process is gone).
"""
import contextlib
import json
import os
import pathlib
import time
import uuid

import paths

SHOW_DONE = 8            # seconds a finished activity stays, with its tick
STALE = 6 * 3600         # an activity nobody ended is dropped after this
MAX = 12


def _file() -> pathlib.Path:
    if os.environ.get("OSPRIME_ACTIVITY"):
        return pathlib.Path(os.environ["OSPRIME_ACTIVITY"])
    return paths.companion_state().with_name("osprime-activity.json")


@contextlib.contextmanager
def _locked():
    f = _file()
    f.parent.mkdir(parents=True, exist_ok=True)
    with open(str(f) + ".lock", "a+") as lk:
        try:
            import fcntl
            fcntl.flock(lk, fcntl.LOCK_EX)
        except Exception:
            pass
        yield


def _load() -> list:
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
        return d if isinstance(d, list) else []
    except Exception:
        return []


def _save(items: list):
    f = _file()
    tmp = f.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(items[-MAX:], ensure_ascii=False), encoding="utf-8")
    tmp.replace(f)


def _alive(pid) -> bool:
    try:
        os.kill(int(pid), 0)
        return True
    except ProcessLookupError:
        return False
    except Exception:
        return True              # another account's process: assume alive


def begin(label: str, kind: str = "job", progress=None) -> str:
    aid = uuid.uuid4().hex[:8]
    try:
        with _locked():
            items = _load()
            items.append({"id": aid, "label": " ".join(str(label or "Working").split())[:60],
                          "kind": kind, "progress": progress, "detail": "",
                          "started": time.time(), "ended": None, "ok": None,
                          "pid": os.getpid()})
            _save(items)
    except Exception:
        pass                     # showing progress must never break the work
    return aid


def update(aid: str, progress=None, detail: str = None):
    try:
        with _locked():
            items = _load()
            for a in items:
                if a["id"] == aid and a.get("ended") is None:
                    if progress is not None:
                        a["progress"] = max(0, min(100, int(progress)))
                    if detail is not None:
                        a["detail"] = str(detail)[:80]
            _save(items)
    except Exception:
        pass


def end(aid: str, ok: bool = True, detail: str = ""):
    try:
        with _locked():
            items = _load()
            for a in items:
                if a["id"] == aid and a.get("ended") is None:
                    a.update(ended=time.time(), ok=bool(ok), detail=str(detail or "")[:80],
                             progress=100 if ok else a.get("progress"))
            _save(items)
    except Exception:
        pass


def current(now=None) -> list:
    """Running ones (oldest first), then ones that ended in the last few
    seconds. Never raises."""
    now = now or time.time()
    out = []
    for a in _load():
        if a.get("ended") is not None:
            if now - a["ended"] <= SHOW_DONE:
                out.append(a)
        elif now - a.get("started", 0) < STALE and _alive(a.get("pid", 0)):
            out.append(a)
    out.sort(key=lambda a: (a.get("ended") is not None, a.get("started", 0)))
    return out


def summary(items: list) -> dict:
    """What the card shows: one line, a fraction or None, and a mark."""
    if not items:
        return {}
    a = items[0]
    running = [x for x in items if x.get("ended") is None]
    more = len(running) - 1 if a.get("ended") is None else len(running)
    if a.get("ended") is not None:
        mark = "✓" if a.get("ok") else "✕"
        text = f"{mark} {a['label']}" + ("" if a.get("ok") else " — did not finish")
    else:
        mark = ""
        pct = a.get("progress")
        text = a["label"] + (f" · {pct}%" if pct is not None else "") + \
            (f" · {a['detail']}" if a.get("detail") else "")
    if more > 0:
        text += f"  (+{more} more)"
    return {"text": text, "fraction": (a["progress"] / 100) if a.get("progress") is not None else None,
            "done": a.get("ended") is not None, "ok": a.get("ok"), "id": a["id"]}
