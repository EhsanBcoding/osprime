#!/usr/bin/env bash
# The Apps menu.
#
# archiso's base image drags in a rescue toolkit — xgps, xgpsspeed, Avahi
# browsers, Software Token, Qt V4L2 test utilities, lftp, Vim. Useful on an
# installer ISO, meaningless to someone who wants to open their photos, and
# together they make the menu unusable for the person this OS is for.
#
# So the menu is a curated list rather than whatever happens to be installed.
# Everything else is still installed and still runnable from a terminal; it
# is simply not offered to someone browsing for an application.
#
# Adding an application to the OS means adding its name here too.

ALLOW=(
  osprime-settings
  thunar
  mousepad
  imv
  mpv
  gimp org.gnome.gimp
  libreoffice-writer libreoffice-calc libreoffice-impress libreoffice-startcenter
  galculator
  chromium
  foot
)

SEARCH=(/usr/share/applications /usr/local/share/applications
        "$HOME/.local/share/applications")

MENU="$(mktemp -d)"
trap 'rm -rf "$MENU"' EXIT
mkdir -p "$MENU/applications"

found=0
for name in "${ALLOW[@]}"; do
    for dir in "${SEARCH[@]}"; do
        if [ -f "$dir/$name.desktop" ]; then
            cp "$dir/$name.desktop" "$MENU/applications/"
            found=$((found + 1))
            break
        fi
    done
done

# An empty menu is worse than a cluttered one: fall back rather than show
# the user nothing at all.
if [ "$found" -eq 0 ]; then
    exec fuzzel
fi

# fuzzel reads <dir>/applications/*.desktop for each entry in XDG_DATA_DIRS.
# Pointing both variables at the curated directory hides everything else.
export XDG_DATA_DIRS="$MENU"
export XDG_DATA_HOME="$MENU"
exec fuzzel
