"""OSprime local inference backend.

Speaks the OpenAI-compatible /v1/chat/completions API, which BOTH
llama.cpp's llama-server and Ollama serve. That means the engine choice
stays swappable and nothing here is locked to one of them.

Why this module exists: router.chat_ollama() could only chat. Every tool
(run_shell, read_file, remember, ...) lived in the Claude path, so an
offline OSprime degraded into a plain chatbot that could not touch the
machine. This gives the local model the same tools.

Small models are unreliable at tool calling, so we use two tiers:
  1. native `tools` parameter, if the server and model support it
  2. a text protocol the model is drilled on, parsed out of the reply

Tier 2 is the safety net that makes 1-3B models usable.
"""

import json
import os
import pathlib
import re
import urllib.error
import urllib.request

# Candidate endpoints, tried in order. llama-server first (leaner, ships
# in the ISO), Ollama second (common on a developer's machine).
# 8087, not 8080 — the OSprime web UI already owns 8080.
ENDPOINTS = [
    os.environ.get("OSPRIME_LOCAL_URL", "http://127.0.0.1:8087/v1"),
    "http://127.0.0.1:11434/v1",
]

MODEL = os.environ.get("OSPRIME_LOCAL_MODEL", "local")
TIMEOUT = int(os.environ.get("OSPRIME_LOCAL_TIMEOUT", "300"))

_ENDPOINT_CACHE = {"url": None}


# --------------------------------------------------------------------------
# endpoint discovery
# --------------------------------------------------------------------------

def _probe(url: str, timeout: float = 1.5) -> bool:
    try:
        urllib.request.urlopen(f"{url}/models", timeout=timeout)
        return True
    except urllib.error.HTTPError:
        return True          # responded, just not with a model list
    except Exception:
        return False


def endpoint(refresh: bool = False):
    """Return the first reachable local endpoint, or None if none is up."""
    if _ENDPOINT_CACHE["url"] and not refresh:
        return _ENDPOINT_CACHE["url"]
    for url in ENDPOINTS:
        if _probe(url):
            _ENDPOINT_CACHE["url"] = url
            return url
    _ENDPOINT_CACHE["url"] = None
    return None


def available() -> bool:
    return endpoint() is not None


def describe_image(path: str, question: str = "",
                   timeout: int = 180) -> str:
    """Ask the local model what is in an image.

    The same /v1/chat/completions endpoint, with the image inlined as a
    data URL — which is how llama.cpp's multimodal support (libmtmd) takes
    it, so nothing new has to be spoken to.

    Returns a string starting with 'ERROR:' when it cannot be done, and
    that includes the case where the model has no eyes. A model without a
    projector does not refuse an image: it ignores it and describes
    something plausible instead, which is the worst possible answer. So
    this checks that the running model was installed to see BEFORE asking,
    rather than trusting whatever comes back.
    """
    import base64
    import mimetypes

    p = pathlib.Path(path)
    if not p.is_file():
        return f"ERROR: there is no file at {path}"

    try:
        import hardware
        if not hardware.installed().get("sees"):
            return ("ERROR: the model running on this computer cannot see "
                    "images. Install one that can: "
                    "sudo bash /opt/osprime/shell/osprime-profile.sh "
                    "vision-large")
    except Exception:
        pass    # if the profile cannot be read, try anyway and let it fail

    if not endpoint():
        return "ERROR: the local model is not running"

    mime = mimetypes.guess_type(str(p))[0] or "image/jpeg"
    try:
        data = base64.b64encode(p.read_bytes()).decode("ascii")
    except Exception as e:
        return f"ERROR: could not read {path}: {e}"

    ask = (question or "").strip() or "Describe what you see in this image."
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": [
            {"type": "text", "text": ask},
            {"type": "image_url",
             "image_url": {"url": f"data:{mime};base64,{data}"}},
        ]}],
        "max_tokens": 400,
    }
    try:
        r = _post("/chat/completions", payload, timeout=timeout)
    except Exception as e:
        return f"ERROR: the model could not look at it: {e}"
    try:
        return (r["choices"][0]["message"]["content"] or "").strip() \
               or "ERROR: the model returned nothing"
    except Exception:
        return "ERROR: the model's answer was not in the expected shape"


def _post(path: str, payload: dict, timeout: int = TIMEOUT):
    url = endpoint()
    if not url:
        raise RuntimeError("No local model engine is reachable.")
    req = urllib.request.Request(
        f"{url}{path}", data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


# --------------------------------------------------------------------------
# tool schema translation
# --------------------------------------------------------------------------

def to_openai_tools(tools: list) -> list:
    """Convert Anthropic-style tool defs (as used in agent.TOOLS) to OpenAI."""
    return [{
        "type": "function",
        "function": {
            "name": t["name"],
            "description": t.get("description", ""),
            "parameters": t.get("input_schema", {"type": "object", "properties": {}}),
        },
    } for t in tools]


def _protocol_prompt(tools: list) -> str:
    """Tier-2 instructions: teach the model an explicit call format."""
    lines = []
    for t in tools:
        props = t.get("input_schema", {}).get("properties", {})
        lines.append(f"- {t['name']}({', '.join(props)}): {t.get('description', '')[:120]}")
    return (
        "\n\nYou can call tools. To call one, reply with NOTHING but a single "
        "line in this exact format:\n"
        "<tool>{\"name\": \"tool_name\", \"args\": {...}}</tool>\n"
        "Do not explain the call, do not wrap it in code fences, do not invent "
        "results. After you receive the result you may answer normally.\n"
        "Available tools:\n" + "\n".join(lines)
    )


_TOOL_RE = re.compile(r"<tool>\s*(\{.*?\})\s*</tool>", re.S)


def parse_protocol_call(text: str):
    """Extract a tier-2 tool call from model text. Returns (name, args) or None."""
    m = _TOOL_RE.search(text or "")
    if not m:
        # some models drop the tags and emit a bare JSON object
        s, e = (text or "").find("{"), (text or "").rfind("}")
        if s == -1 or e <= s:
            return None
        blob = text[s:e + 1]
    else:
        blob = m.group(1)
    try:
        obj = json.loads(blob)
    except json.JSONDecodeError:
        return None
    name = obj.get("name") or obj.get("tool")
    if not isinstance(name, str):
        return None
    args = obj.get("args") or obj.get("arguments") or obj.get("input") or {}
    if isinstance(args, str):
        try:
            args = json.loads(args)
        except json.JSONDecodeError:
            args = {}
    return (name, args if isinstance(args, dict) else {})


def strip_protocol(text: str) -> str:
    """Remove the call and any now-empty code fence the model wrapped it in."""
    out = _TOOL_RE.sub("", text or "")
    out = re.sub(r"```[a-zA-Z]*\s*```", "", out)
    return out.strip()


# --------------------------------------------------------------------------
# chat
# --------------------------------------------------------------------------

def chat(messages: list, system: str, tools: list = None, native: bool = True):
    """One local completion.

    Returns (text, tool_calls) where tool_calls is a list of
    {"id", "name", "args"}. Falls back to the text protocol when the
    server rejects the native `tools` parameter or the model ignores it.
    """
    sys_text = system
    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": sys_text}] + messages,
        "stream": False,
        "temperature": 0.3,
    }

    if tools and native:
        payload["tools"] = to_openai_tools(tools)
        payload["tool_choice"] = "auto"
        try:
            data = _post("/chat/completions", payload)
        except urllib.error.HTTPError:
            # server or model does not understand `tools` -> tier 2
            return chat(messages, system, tools, native=False)
    else:
        if tools:
            payload["messages"][0]["content"] = sys_text + _protocol_prompt(tools)
        data = _post("/chat/completions", payload)

    choice = (data.get("choices") or [{}])[0]
    msg = choice.get("message", {}) or {}
    text = msg.get("content") or ""

    calls = []
    for c in msg.get("tool_calls") or []:
        fn = c.get("function", {}) or {}
        raw = fn.get("arguments") or "{}"
        try:
            args = json.loads(raw) if isinstance(raw, str) else raw
        except json.JSONDecodeError:
            args = {}
        calls.append({"id": c.get("id", fn.get("name", "call")),
                      "name": fn.get("name", ""),
                      "args": args if isinstance(args, dict) else {}})

    # tier 2: model replied in text even though tools were offered natively
    if not calls and tools:
        parsed = parse_protocol_call(text)
        if parsed:
            calls = [{"id": "call_0", "name": parsed[0], "args": parsed[1]}]
            text = strip_protocol(text)

    return text, calls


def chat_stream(messages: list, system: str, on_delta):
    """Plain streaming chat, no tools — used once the model is done calling."""
    url = endpoint()
    if not url:
        raise RuntimeError("No local model engine is reachable.")
    payload = json.dumps({
        "model": MODEL,
        "messages": [{"role": "system", "content": system}] + messages,
        "stream": True,
        "temperature": 0.3,
    }).encode()
    req = urllib.request.Request(
        f"{url}/chat/completions", data=payload,
        headers={"Content-Type": "application/json"})
    out = []
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        for raw in r:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            body = line[5:].strip()
            if body == "[DONE]":
                break
            try:
                delta = json.loads(body)["choices"][0].get("delta", {})
            except (json.JSONDecodeError, KeyError, IndexError):
                continue
            piece = delta.get("content") or ""
            if piece:
                out.append(piece)
                on_delta(piece)
    return "".join(out)
