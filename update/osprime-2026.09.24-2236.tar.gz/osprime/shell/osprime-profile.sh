#!/usr/bin/env bash
# Look at this machine and pick the model that suits it.
#
#   bash osprime-profile.sh              report only — changes nothing
#   sudo bash osprime-profile.sh --install   download it and switch over
#   sudo bash osprime-profile.sh vision-large   install a model that can see
#
# A vision tier is named explicitly and is never recommended automatically.
# Eyesight is something the user asks for; it is not a reason for the
# machine to change its own brain. And the old model stays on disk, so the
# way back is a one-line command rather than another download.
#
# Reporting and installing are separate on purpose. The install downloads
# gigabytes; on a phone tether that is somebody's money, and a script that
# spends it because it was run to see what it would say is a script nobody
# should run.
#
# The switch is also staged rather than done in one step: the new model is
# downloaded beside the old one, started on a spare port and asked a
# question, and only if it answers is the engine pointed at it. A model
# that downloads but will not load leaves the machine exactly as it was,
# still able to talk — which is the difference between a bad update and an
# unusable computer.
set -u

HERE="$(cd "$(dirname "$0")" && pwd)"
AGENT="$(cd "$HERE/../agent" && pwd)"
MODELS="${OSPRIME_MODELS:-/var/lib/osprime/models}"
PROBE_PORT="${OSPRIME_PROBE_PORT:-8091}"

py() { PYTHONPATH="$AGENT" python3 "$@"; }

# Which tier this run is about: the recommendation, or one named on the
# command line.
WANT=""
case "${1:-}" in
    vision-medium|vision-large|tiny|small|medium|large) WANT="$1" ;;
esac

read_field() {   # read_field <python expression on the chosen spec>
    py -c "
import hardware, json
r = hardware.spec_for('$WANT') if '$WANT' else hardware.recommend()
print($1)
"
}

# --------------------------------------------------------------------------
# report
# --------------------------------------------------------------------------

py -c "
import hardware
r = hardware.report()
m, now, rec = r['machine'], r['running_now'], r['recommended']
print()
print('This machine')
print(f\"  processor    {m['cpu']}\")
print(f\"  cores        {m['cores']}\")
print(f\"  memory       {m['ram_gb']} GB\")
print(f\"  free disk    {m['disk_free_mb']} MB\")
g = m['gpu']
print(f\"  graphics     {g['kind'] or 'none usable'} — {g['why']}\")
print()
print('Running now')
print(f\"  {now['label'] or 'the model the system was installed with'}\")
print(f\"  {now['path']} ({now['size_mb']} MB)\" if now['exists']
      else f\"  MISSING: {now['path']}\")
print()
print('Recommended')
print(f\"  {rec['label']}  ({rec['disk_mb']} MB download)\")
print(f\"  {rec['why']}\")
print(f\"  {rec['note']}\")
print()
"

if [ "${1:-}" != "--install" ] && [ -z "$WANT" ]; then
    echo "Nothing was changed. To download and switch over:"
    echo "    sudo bash $0 --install"
    echo
    py -c "
import hardware
print('Models that can also see (never installed automatically):')
for v in hardware.vision_options():
    ok = all((v['enough_disk'], v['enough_ram']))
    print(f\"  {v['label']}  ({v['download_mb']} MB)\")
    print(f\"    {v['note']}\")
    print(f\"    room on disk: {'yes' if v['enough_disk'] else 'NO'}\"
          f\"   memory: {'yes' if v['enough_ram'] else 'NO'}\"
          f\"   fits on the graphics card: \"
          f\"{'yes' if v['fits_on_the_graphics_card'] else 'no — it would run on the processor, slowly'}\")
    if ok:
        print(f\"    {v['how_to_install']}\")
"
    exit 0
fi

[ "$EUID" -eq 0 ] || { echo "The install step needs sudo."; exit 1; }

# --------------------------------------------------------------------------
# install
# --------------------------------------------------------------------------

TIER="$(read_field "r['tier']")"
LABEL="$(read_field "r['label']")"
FIRST="$(read_field "r['files'][0]")"
URLS="$(read_field "'\n'.join(r['urls'])")"
FILES="$(read_field "'\n'.join(r['files'])")"
# Empty for a text-only model, which is what makes ${PROJ:+--mmproj "$PROJ"}
# below add nothing rather than add an empty flag.
# mmproj_local, not mmproj: the name it is saved under is the tier's own,
# because every vision model publishes its projector as mmproj-F16.gguf.
MMPROJ="$(read_field "r.get('mmproj_local') or ''")"
PROJ=""
[ -n "$MMPROJ" ] && PROJ="$MODELS/$MMPROJ"

CURRENT_TIER="$(py -c "import hardware; print(hardware.installed()['tier'])")"
if [ "$TIER" = "$CURRENT_TIER" ]; then
    echo "Already running $LABEL. Nothing to do."
    exit 0
fi

mkdir -p "$MODELS"
echo "> downloading $LABEL"
paste -d' ' <(printf '%s\n' "$URLS") <(printf '%s\n' "$FILES") |
while read -r url name; do
    dest="$MODELS/$name"
    if [ -s "$dest" ]; then
        echo "  already have $name"
        continue
    fi
    echo "  $name"
    # --continue-at so a dropped connection resumes rather than restarting a
    # two-gigabyte download.
    curl -fL --retry 3 --continue-at - -o "$dest.part" "$url" || {
        echo "  download failed — nothing was changed."; exit 1; }
    mv "$dest.part" "$dest"
done || exit 1

TARGET="$MODELS/$FIRST"
[ -s "$TARGET" ] || { echo "Download incomplete — nothing was changed."; exit 1; }

# --------------------------------------------------------------------------
# prove it works before switching to it
# --------------------------------------------------------------------------

BIN="$(command -v llama-server || command -v llama-cpp-server || true)"
[ -n "$BIN" ] || { echo "No llama-server to test with — nothing was changed."; exit 1; }

echo "> checking it actually loads and answers"
# The projector goes in here too. Probing a vision model without it proves
# only that it loads blind, which is the exact failure this check exists to
# catch: the model works, the eyesight silently does not.
if [ -n "$PROJ" ] && [ ! -s "$PROJ" ]; then
    echo "The vision file did not download: $PROJ"
    echo "Nothing was changed."
    exit 1
fi
"$BIN" -m "$TARGET" --host 127.0.0.1 --port "$PROBE_PORT" --ctx-size 512 \
       ${PROJ:+--mmproj "$PROJ"} \
       >/tmp/osprime-probe.log 2>&1 &
PROBE_PID=$!
# shellcheck disable=SC2064
trap "kill $PROBE_PID 2>/dev/null" EXIT

ok=0
for _ in $(seq 1 120); do
    sleep 1
    kill -0 "$PROBE_PID" 2>/dev/null || break     # it died; stop waiting
    if curl -fsS --max-time 5 -X POST "http://127.0.0.1:$PROBE_PORT/v1/chat/completions" \
        -H 'Content-Type: application/json' \
        -d '{"messages":[{"role":"user","content":"Say OK"}],"max_tokens":5}' \
        >/tmp/osprime-probe-answer.json 2>/dev/null; then
        ok=1; break
    fi
done
kill "$PROBE_PID" 2>/dev/null
wait "$PROBE_PID" 2>/dev/null
trap - EXIT

if [ "$ok" -ne 1 ]; then
    echo
    echo "$LABEL downloaded but would not answer. The machine is unchanged"
    echo "and still running its previous model. The engine's own log:"
    tail -20 /tmp/osprime-probe.log
    exit 1
fi
echo "  it answered"

# It answers. But can it still call a tool?
#
# This whole product runs on tool calls. A model that talks beautifully and
# will not call a tool is useless here, and swapping in a vision model to
# gain eyesight while silently losing tool reliability would be the worst
# kind of trade — everything would get a little less dependable with no
# visible cause.
#
# So ask it to call one, with a tool definition it cannot answer in prose,
# and refuse the switch if it does not. A warning rather than a hard stop
# only for the text tiers, which have been in use for weeks and are known
# to work; for a vision tier this is the gate.
echo "> checking it can still call a tool"
"$BIN" -m "$TARGET" --host 127.0.0.1 --port "$PROBE_PORT" \
       --ctx-size 2048 --jinja ${PROJ:+--mmproj "$PROJ"} \
       >/tmp/osprime-probe-tools.log 2>&1 &
PROBE_PID=$!
# shellcheck disable=SC2064
trap "kill $PROBE_PID 2>/dev/null" EXIT
# Asked through agent/local.py, NOT with a hand-written curl.
#
# The first version of this check posted the OpenAI `tools` parameter
# directly and failed Qwen2.5-VL — correctly, as it turned out, but for an
# incomplete reason. OSprime does not require native tool calling: local.py
# has a text protocol that puts the tools in the system prompt and needs no
# chat-template support at all. A gate that tests only the native path is
# measuring something adjacent to the question, and this project has been
# bitten by that before.
#
# So test the real thing: whichever route local.chat() would actually take.
tools_ok=0
for _ in $(seq 1 60); do
    sleep 2
    kill -0 "$PROBE_PID" 2>/dev/null || break
    if OSPRIME_LOCAL_URL="http://127.0.0.1:$PROBE_PORT/v1" \
       OSPRIME_LOCAL_TIMEOUT=60 py -c "
import sys, local
tools = [{'name': 'get_time',
          'description': 'The current time on this computer.',
          'input_schema': {'type': 'object', 'properties': {}}}]
try:
    text, calls = local.chat(
        [{'role': 'user', 'content': 'What time is it?'}],
        'You are a helpful assistant on this computer.', tools)
except Exception as e:
    print('probe failed:', e, file=sys.stderr); sys.exit(2)
print('CALLED' if any(c.get('name') == 'get_time' for c in calls) else 'NO_CALL')
sys.exit(0 if calls else 1)
" >/tmp/osprime-probe-tools-answer.txt 2>>/tmp/osprime-probe-tools.log; then
        tools_ok=1
    elif [ $? -eq 2 ]; then
        continue          # server not up yet
    fi
    break
done
kill "$PROBE_PID" 2>/dev/null
wait "$PROBE_PID" 2>/dev/null
trap - EXIT

if [ "$tools_ok" -eq 1 ]; then
    echo "  it called the tool — switching over"
elif [ -n "${PROJ:-}" ]; then
    echo
    echo "$LABEL answers, but did NOT call a tool when given one."
    echo "That matters more than eyesight here: almost everything OSprime"
    echo "does is a tool call. The machine is unchanged and still running"
    echo "its previous model."
    echo "The engine's own log:"
    tail -20 /tmp/osprime-probe-tools.log
    exit 1
else
    echo "  WARNING: it did not call the tool in this check. Switching"
    echo "  anyway because this is a text tier that has been in use, but"
    echo "  if tools start failing, this is the first thing to suspect."
fi

py -c "
import hardware
print(hardware.write_env('$TIER', '$TARGET'))
"

systemctl restart osprime-model.service 2>/dev/null || \
    echo "note: restart osprime-model.service to use it."

echo
echo "Now running $LABEL. The previous model is still in $MODELS —"
echo "delete it once you are happy, or keep it to fall back to."
