"""OSprime self-update (OTA) with automatic rollback.

Layout:
    /opt/osprime                         <- live code, root-owned
    /var/lib/osprime-backups/<timestamp> <- previous versions, root-owned

The backups used to live in /var/lib/osprime/backups, inside the directory
the agent owns. Rollback runs as root and copies a backup into /opt, so the
unprivileged agent could write code into a backup, ask root to roll back —
which sudoers allows without a password — and have its own code become the
operating system. See docs/SECURITY.md, #2. The docstring of
_rollback_as_root below already said the unprivileged side may choose WHEN
to roll back but never WHAT to; the WHAT was being read from a place the
unprivileged side could write.

An update stages the new code, verifies it compiles, swaps it in, and
restores the backup if anything fails.
"""

import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import urllib.request

INSTALL_DIR = pathlib.Path(os.environ.get("OSPRIME_INSTALL", "/opt/osprime"))
BACKUP_DIR = pathlib.Path(os.environ.get("OSPRIME_BACKUPS", "/var/lib/osprime-backups"))

# Who a backup must belong to before root will restore it. A module constant
# so the tests can run as an ordinary user; nothing in the product changes it.
TRUSTED_UID = 0

# Where releases are announced. A static file is enough — no server code.
MANIFEST_URL = os.environ.get(
    "OSPRIME_MANIFEST_URL",
    "https://ehsanbcoding.github.io/osprime/update/manifest.json")

# Direct archive URL, used only when a manifest is deliberately bypassed
# (local testing, or an explicitly supplied package).
SOURCE_URL = os.environ.get("OSPRIME_UPDATE_URL", "")

VERSION_FILE = INSTALL_DIR / "VERSION"
# "skills" belongs here: skills are the product, and leaving them out meant
# they were written, packaged, and never actually delivered to a machine.
CODE_DIRS = ("agent", "ui", "onboarding", "tools.d", "shell", "installer",
             "skills")
KEEP_BACKUPS = 3
NET_TIMEOUT = 15


def current_version() -> str:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        return "unknown"


def fetch_manifest(url: str = "") -> dict:
    """Read the release manifest. Returns {} when unreachable — being
    offline is a normal state here, not an error worth surfacing."""
    url = url or MANIFEST_URL
    try:
        with urllib.request.urlopen(url, timeout=NET_TIMEOUT) as r:
            data = json.load(r)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _newer(latest: str, current: str) -> bool:
    """Versions are YYYY.MM.DD-HHMM, so string order is chronological."""
    if not latest:
        return False
    if current in ("", "unknown", "dev"):
        return True
    return latest > current


def check(url: str = "") -> dict:
    """Is there a newer version? Never installs anything."""
    m = fetch_manifest(url)
    if not m:
        return {"available": False, "reason": "could not reach the update server",
                "current": current_version()}
    latest = str(m.get("version", ""))
    return {
        "available": _newer(latest, current_version()),
        "current": current_version(),
        "latest": latest,
        "notes": m.get("notes", ""),
        "url": m.get("url", ""),
        "sha256": m.get("sha256", ""),
        # Dropping this silently meant a release could declare dependencies
        # and none of them were ever installed — the update looked successful
        # and the new code was broken.
        "packages": m.get("packages", []),
    }


def _sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _compiles(root: pathlib.Path) -> bool:
    """Every python file in the staged tree must byte-compile."""
    files = [str(p) for d in CODE_DIRS for p in (root / d).rglob("*.py")]
    if not files:
        return False
    env = dict(os.environ, PYTHONPYCACHEPREFIX=tempfile.mkdtemp())
    r = subprocess.run(["python3", "-m", "py_compile", *files],
                       capture_output=True, text=True, env=env)
    return r.returncode == 0


def _install_packages(pkgs: list) -> str:
    """Install system packages named in the manifest.

    Code-only updates cannot deliver a skill that needs ocrmypdf or
    imagemagick, so an update has to be able to bring its dependencies.

    This used to be `-Sy` and then `-S`, which is the textbook Arch
    partial-upgrade: it refreshes the package list and then installs
    against a system that has not been upgraded to match. That is not a
    theoretical risk here — it is precisely how a driver landed built for a
    kernel that was not running, and the desktop stopped coming up three
    times in a row. The comment that used to sit here even said so, and
    accepted it to avoid pulling the whole system on every skill install.

    One transaction now, and it upgrades. It costs more when a release
    names packages, which is rare, and it removes an entire class of
    failure that has already cost this project a day. A release that pulls
    a new kernel wants a reboot afterwards, which is worth saying out loud
    to whoever installed it.
    """
    if not pkgs:
        return ""
    if not shutil.which("pacman"):
        return "package manager not available"
    r = subprocess.run(["pacman", "-Syu", "--needed", "--noconfirm", *pkgs],
                       capture_output=True, text=True, timeout=3600)
    if r.returncode != 0:
        tail = (r.stderr or r.stdout or "").strip().splitlines()
        return f"packages failed: {tail[-1] if tail else 'unknown error'}"
    return f"{len(pkgs)} package(s) checked"


# Where system files land. "/" in the product; a directory in the tests,
# because the only other way to test code that writes to /etc is on the
# machine it could break.
SYSTEM_ROOT = pathlib.Path(os.environ.get("OSPRIME_SYSTEM_ROOT", "/"))

# The only places an update may write outside /opt/osprime, and therefore
# the only places a rollback may delete from. Must match the list in
# release.sh that builds the package's system/ tree.
SYSTEM_DIRS = ("etc/systemd/system", "usr/share/applications", "etc/gtk-3.0")


def _in_system_dirs(rel: pathlib.Path) -> bool:
    rel_s = rel.as_posix()
    return ".." not in rel.parts and any(
        rel_s == d or rel_s.startswith(d + "/") for d in SYSTEM_DIRS)


def _apply_system_files(root: pathlib.Path, keep: pathlib.Path = None) -> str:
    """Copy the package's system/ tree over the real filesystem.

    This is how service units and menu entries reach an installed machine.
    Without it, a new .desktop file only ever appears by rebuilding the ISO —
    which is exactly why Settings was missing from the Apps menu.

    Two things changed on 23 September (docs/SECURITY.md, #7):

    * A failed copy RAISES. It used to return "3 updated, 1 failed" as a
      note beside a successful update — new code running against half-new
      service units, reported as success. Raising makes apply_staged roll
      the whole release back, the same rule post-install already followed.

    * What is about to be overwritten is kept first, in the backup, under
      system/; and what did not exist before is listed in system-new.txt.
      Rollback used to restore code only, so "rolled back" meant the old
      agent running under the new release's service units.
    """
    src = root / "system"
    if not src.is_dir():
        return ""
    count, added = 0, []
    for path in sorted(src.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(src)
        if not _in_system_dirs(rel):
            raise RuntimeError(f"the package tried to write {rel}, which is "
                               "outside the system directories an update "
                               "may change")
        dest = SYSTEM_ROOT / rel
        try:
            if keep is not None:
                if dest.is_file():
                    saved = keep / "system" / rel
                    saved.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dest, saved)
                else:
                    added.append(rel.as_posix())
                    # Written as we go, not at the end: if the copy below
                    # fails, rollback still needs to know about the files
                    # that DID land before it.
                    (keep / "system-new.txt").write_text(
                        "\n".join(added) + "\n", encoding="utf-8")
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
            count += 1
        except Exception as e:
            raise RuntimeError(f"could not install {dest}: {e}")
    if count:
        if shutil.which("systemctl") and str(SYSTEM_ROOT) == "/":
            subprocess.run(["systemctl", "daemon-reload"], capture_output=True)
        if shutil.which("update-desktop-database") and str(SYSTEM_ROOT) == "/":
            subprocess.run(["update-desktop-database",
                            "/usr/share/applications"], capture_output=True)
    return f"{count} system file(s) updated" if count else ""


def _restore_system_files(b: pathlib.Path) -> str:
    """Put back what _apply_system_files replaced, and remove what it added.

    Only ever called on a backup that untrusted() has already cleared, and
    even then only touches paths inside SYSTEM_DIRS — a rollback runs as
    root and deletes files, and a list of files to delete is exactly the
    kind of input that deserves a second check.
    """
    restored = removed = 0
    kept = b / "system"
    if kept.is_dir():
        for path in sorted(kept.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(kept)
            if not _in_system_dirs(rel):
                continue
            dest = SYSTEM_ROOT / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
            restored += 1
    listing = b / "system-new.txt"
    if listing.is_file():
        for line in listing.read_text(encoding="utf-8").splitlines():
            rel = pathlib.Path(line.strip())
            if not line.strip() or rel.is_absolute() or not _in_system_dirs(rel):
                continue
            target = SYSTEM_ROOT / rel
            if target.is_file() and not target.is_symlink():
                target.unlink()
                removed += 1
    if (restored or removed) and shutil.which("systemctl") \
            and str(SYSTEM_ROOT) == "/":
        subprocess.run(["systemctl", "daemon-reload"], capture_output=True)
    if not (restored or removed):
        return ""
    return f"{restored} system file(s) put back, {removed} removed"


def _run_post_install(root: pathlib.Path) -> str:
    """The part of a release that copying files cannot express.

    Ownership, sudo rules, anything that is not code. A failure here used to
    be reported as a note alongside a successful update, which is how half a
    change ships: the new service units are already in place and the
    permissions they depend on are not.

    So it raises. apply_staged catches that and rolls the whole release
    back, which is the only honest outcome — a machine half-moved is worse
    than one that never moved.
    """
    script = root / "post_install.sh"
    if not script.is_file():
        return ""
    r = subprocess.run(["bash", str(script)], capture_output=True,
                       text=True, timeout=900)
    detail = ((r.stdout or "") + (r.stderr or "")).strip()
    if r.returncode != 0:
        raise RuntimeError("post-install failed: " + (detail[-300:] or "no output"))
    return "post-install ran"


def _find_root(extracted: pathlib.Path) -> pathlib.Path:
    """Archives usually contain a single top-level folder."""
    if (extracted / "agent").is_dir():
        return extracted
    subs = [p for p in extracted.iterdir() if p.is_dir()]
    for s in subs:
        if (s / "agent").is_dir():
            return s
    return extracted


def untrusted(path: pathlib.Path) -> str:
    """Why this backup must not be restored by root, or "" if it may be.

    The property that matters is WHO COULD HAVE WRITTEN IT, so that is what
    is checked, directly, on every file — not where the directory is, which
    is a proxy for it, and a proxy is what failed last time:

      * owned by root (TRUSTED_UID);
      * not writable by group or others;
      * no symlinks anywhere. copytree follows them, so a link inside a
        backup pointing into the agent's own home would copy agent-written
        code into /opt even with every real file root-owned.

    Readable by everyone is fine and deliberate. The code is not secret, and
    the web interface, which runs as osprime, has to list the backups to
    offer a rollback at all.
    """
    try:
        for p in [path] + sorted(path.rglob("*")):
            st = os.lstat(p)
            rel = p.relative_to(path.parent)
            if pathlib.Path(p).is_symlink():
                return f"{rel} is a symbolic link"
            if st.st_uid != TRUSTED_UID:
                return f"{rel} is not owned by root"
            if st.st_mode & 0o022:
                return f"{rel} is writable by someone other than root"
    except OSError as e:
        return f"could not be checked ({e})"
    return ""


def _dir_untrusted(d: pathlib.Path) -> str:
    """The same test as untrusted(), for one directory and not its contents."""
    try:
        st = os.lstat(d)
    except OSError as e:
        return f"{d} could not be checked ({e})"
    if d.is_symlink():
        return f"{d} is a symbolic link"
    if st.st_uid != TRUSTED_UID:
        return f"{d} is not owned by root"
    if st.st_mode & 0o022:
        return f"{d} is writable by someone other than root"
    return ""


def backup() -> pathlib.Path:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    # Readable, not writable, by anyone but root. See untrusted().
    try:
        os.chmod(BACKUP_DIR, 0o755)
    except OSError:
        pass
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = BACKUP_DIR / stamp
    n = 1
    while dest.exists():                 # two updates in the same second
        dest = BACKUP_DIR / f"{stamp}-{n}"
        n += 1
    dest.mkdir()
    for d in CODE_DIRS:
        src = INSTALL_DIR / d
        if src.is_dir():
            shutil.copytree(src, dest / d, dirs_exist_ok=True)
    if VERSION_FILE.exists():
        shutil.copy(VERSION_FILE, dest / "VERSION")
    _prune_backups()
    return dest


def _prune_backups():
    if not BACKUP_DIR.is_dir():
        return
    olds = sorted([p for p in BACKUP_DIR.iterdir() if p.is_dir()])
    for p in olds[:-KEEP_BACKUPS]:
        shutil.rmtree(p, ignore_errors=True)


def list_backups() -> list:
    try:
        if not BACKUP_DIR.is_dir():
            return []
        return sorted(p.name for p in BACKUP_DIR.iterdir()
                      if p.is_dir() and not p.is_symlink())
    except OSError:
        return []


def _swap_in(src_root: pathlib.Path):
    for d in CODE_DIRS:
        s = src_root / d
        if not s.is_dir():
            continue
        target = INSTALL_DIR / d
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(s, target)


def _rollback_as_root(restart: bool = True) -> str:
    """Ask root to put the previous version back.

    Same boundary as _as_root, and the same reasoning: the unprivileged
    side may say WHEN to roll back, not WHAT to roll back to. The
    privileged side picks the most recent backup itself, so there is no
    argument for a caller to aim somewhere else.

    restart=False exists for the same reason it does on the update path.
    The root side restarting osprime-web would kill the server that is
    sitting here waiting for this very command to return, and the user
    would see a rollback that "failed" while succeeding.
    """
    if not shutil.which("sudo"):
        return ("ERROR: rolling back needs root and sudo is not available "
                "on this system.")
    cmd = ["sudo", "-n", sys.executable,
           str(pathlib.Path(__file__).resolve()), "--rollback"]
    if not restart:
        cmd.append("--no-restart")
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    out = (r.stdout or "").strip() or (r.stderr or "").strip()
    if r.returncode != 0:
        if "password is required" in out or "no tty" in out.lower():
            return ("ERROR: this system will not let the assistant roll back "
                    "without a password. Run it yourself with: sudo python3 "
                    "/opt/osprime/agent/updater.py --rollback")
        return out or "ERROR: the rollback failed and said nothing."
    return out


def restore(name: str = "", restart: bool = True) -> str:
    """Put a previous version back.

    Writes to /opt/osprime, which is root-owned on purpose — that is what
    stops the unprivileged agent rewriting the code it may ask root to run.
    So an ordinary user hands the whole job to root, exactly as an update
    does. Without this the button existed and failed with a bare permission
    error at the one moment a person most needs it to work.
    """
    if os.geteuid() != 0:
        if name:
            return ("ERROR: only the most recent backup can be restored "
                    "without root. Run it yourself to choose another: "
                    "sudo python3 /opt/osprime/agent/updater.py --rollback")
        return _rollback_as_root(restart)

    backups = list_backups()
    if not backups:
        return "no backup available"
    name = name or backups[-1]
    # Checked against the list, not just for being a directory. `is_dir()`
    # happily accepts "../../etc" — and this function is reachable from a
    # tool a language model calls, behind sudo. A name that is not one of
    # ours is not a name.
    if name not in backups:
        return f"backup {name} not found"
    src = BACKUP_DIR / name
    # The directory holding the backups is checked as well as the backup:
    # if something other than root can write it, it can swap a backup for
    # one of its own between our check and our copy.
    why = untrusted(src) or _dir_untrusted(BACKUP_DIR)
    if why:
        return (f"ERROR: refusing to restore backup {name}: {why}. A backup "
                "that anything but root could have written is not restored "
                "as root. Nothing was changed.")
    _swap_in(src)
    v = src / "VERSION"
    if v.exists():
        shutil.copy(v, VERSION_FILE)
    sys_msg = _restore_system_files(src)
    # Said plainly rather than implied. Packages an update installed stay
    # installed: pacman cannot reliably downgrade one without taking its
    # dependents with it, and an old OSprime running beside a newer library
    # is the normal case on Arch anyway. What matters is that "rolled back"
    # does not claim more than happened — the old message did.
    parts = [f"restored backup {name}: code"]
    if sys_msg:
        parts.append(sys_msg)
    return (", ".join(parts)
            + ". System packages installed by the update were left as they are.")


def restart_services() -> str:
    # The desktop shell holds its config in memory. Without these two, a
    # change to the panel or the key bindings only appeared after a logout,
    # which looked like the update had not arrived at all.
    subprocess.run(["pkill", "-USR2", "waybar"], capture_output=True)
    if shutil.which("labwc"):
        subprocess.run(["labwc", "--reconfigure"], capture_output=True)

    if not shutil.which("systemctl"):
        return "systemctl not available (restart manually)"

    # As an ordinary user these need sudo, and the sudoers file names these
    # exact units. Nothing else is reachable through it: the unit files are
    # root-owned, so "restart osprime-agent" cannot be made to mean
    # something other than restarting osprime-agent.
    pre = [] if os.geteuid() == 0 else ["sudo", "-n"]

    # The inference engine is restarted too, and deliberately last. Its
    # launch script carries the performance flags, so leaving it running on
    # the old ones meant an update that reported success while half of it
    # had not taken effect until the next reboot — the same silent partial
    # application that has cost this project more time than any other bug.
    #
    # It costs a slow first answer while the model loads again, which is
    # worth saying out loud rather than leaving the user to wonder.
    r = subprocess.run(pre + ["systemctl", "restart",
                              "osprime-agent", "osprime-web"],
                       capture_output=True, text=True)
    if r.returncode != 0:
        return f"restart failed: {r.stderr.strip()}"
    m = subprocess.run(pre + ["systemctl", "restart", "osprime-model"],
                       capture_output=True, text=True)
    if m.returncode != 0:
        return ("services restarted, but the inference engine did not: "
                + m.stderr.strip())
    return ("services restarted — the engine is reloading the model, so the "
            "first answer will take longer than usual")


def _as_root(restart: bool) -> str:
    """Ask root to install the update the manifest names.

    This is the whole privilege boundary. The agent runs as an ordinary
    user and may say WHEN to update; it may not say WHAT the update is.
    So the privileged side does the fetching, the checksum and the
    installing itself, from a manifest URL baked into this file — which
    lives in /opt/osprime, owned by root, and is therefore not something
    the unprivileged side can rewrite before asking for it to be run.

    A helper that installed whatever the caller had already staged would
    look like a boundary and be a doorway.
    """
    if not shutil.which("sudo"):
        return ("ERROR: updating needs root and sudo is not available on "
                "this system.")
    cmd = ["sudo", "-n", sys.executable, str(pathlib.Path(__file__).resolve()),
           "--install"]
    if not restart:
        cmd.append("--no-restart")
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=2400)
    out = (r.stdout or "").strip() or (r.stderr or "").strip()
    if r.returncode != 0:
        if "password is required" in out or "no tty" in out.lower():
            return ("ERROR: this system will not let the assistant install "
                    "updates without a password. Run it yourself with: "
                    "sudo python3 /opt/osprime/agent/updater.py --install")
        return out or "ERROR: the update failed and said nothing."
    return out


def succeeded(result: str) -> bool:
    """Did that string from update() mean an update was installed?

    One sentence, in one place. Two callers decide what to do next based on
    this — the Settings page and the chat tool — and when they each had
    their own copy of the test, only one of them was right.
    """
    return (result or "").startswith("updated to")


def update(url: str = "", restart: bool = True, expect_sha: str = "",
           version: str = "", packages: list = None) -> str:
    """Install an update. With no url, the manifest decides what to fetch.

    The checksum is not optional on the manifest path. This code downloads an
    archive and then runs it as the system's own brain, so an unverified
    package means whoever controls the URL controls the machine.
    """
    # Installing writes to /opt/osprime and runs pacman, which the agent no
    # longer has the right to do. Hand the whole job to root rather than
    # failing halfway through with a permission error.
    if os.geteuid() != 0 and not url:
        return _as_root(restart)

    if not url:
        info = check()
        if not info.get("latest"):
            return f"no update available ({info.get('reason', 'up to date')})"
        if not info["available"]:
            return f"already on the latest version ({info['current']})"
        url = info["url"]
        expect_sha = expect_sha or info["sha256"]
        version = version or info["latest"]
        packages = info.get("packages") or []
        if not url:
            return "manifest is missing a download url"
        if not expect_sha:
            return "manifest has no sha256 — refusing to install an unverified package"

    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        archive = tmp / "src.tar.gz"
        try:
            if url.startswith(("http://", "https://")):
                urllib.request.urlretrieve(url, archive)
            else:                                  # local file (also used in tests)
                shutil.copy(url, archive)
        except Exception as e:
            return f"download failed: {e}"

        if expect_sha:
            got = _sha256(archive)
            if got.lower() != expect_sha.lower():
                return ("update rejected: checksum mismatch — nothing was changed.\n"
                        f"  expected {expect_sha}\n  got      {got}")

        extract = tmp / "x"
        extract.mkdir()
        try:
            shutil.unpack_archive(str(archive), str(extract))
        except Exception as e:
            return f"extract failed: {e}"

        root = _find_root(extract)
        if not (root / "agent" / "agent.py").is_file():
            return "invalid package: agent/agent.py missing"
        if not _compiles(root):
            return "update rejected: new code does not compile (nothing changed)"

        # Hand the installation to the updater *inside the package*, when it
        # knows how to accept it.
        #
        # Otherwise every change to this file takes effect one release late:
        # the code that installs a release is always the previous release's
        # code. That cost us a missing Settings entry and would cost the same
        # again for every future change here.
        staged = root / "agent" / "updater.py"
        try:
            can_hand_off = "--apply" in staged.read_text(encoding="utf-8")
        except Exception:
            can_hand_off = False

        if can_hand_off:
            r = subprocess.run(
                [sys.executable, str(staged), "--apply", str(root),
                 version or "", *(packages or [])],
                capture_output=True, text=True, timeout=2400)
            out = (r.stdout or "").strip() or (r.stderr or "").strip()
            if r.returncode != 0:
                return out or "update failed while applying"
            msg = out or f"updated to {current_version()}"
            if restart:
                msg += " — " + restart_services()
            return msg

        # Older package: apply it here, the old way.
        extra = []
        pkg_msg = _install_packages(list(packages or []))
        if pkg_msg:
            extra.append(pkg_msg)
            if pkg_msg.startswith("packages failed"):
                return f"update stopped: {pkg_msg} — nothing was changed"

        b = backup()
        try:
            _swap_in(root)
            for msg in (_apply_system_files(root, b), _run_post_install(root)):
                if msg:
                    extra.append(msg)
            # Record the version the manifest advertised, not the clock. Using
            # local time here left the installed version below the published
            # one, so check() reported an update available forever.
            new_v = version
            if not new_v and (root / "VERSION").is_file():
                new_v = (root / "VERSION").read_text(encoding="utf-8").strip()
            if not new_v:
                new_v = datetime.datetime.now().strftime("%Y.%m.%d-%H%M")
            VERSION_FILE.write_text(new_v + "\n", encoding="utf-8")
        except Exception as e:
            restore(b.name)
            return f"update failed ({e}) — rolled back to {b.name}"

    msg = f"updated to {current_version()} (backup: {b.name})"
    if extra:
        msg += " — " + "; ".join(extra)
    if restart:
        msg += " — " + restart_services()
    return msg


def apply_staged(root: pathlib.Path, version: str = "",
                 packages: list = None) -> str:
    """Install an already downloaded and verified package.

    Called by the *previous* version's updater as a subprocess, so that the
    logic in this file is what runs — not whatever shipped last time.
    """
    extra = []
    pkg_msg = _install_packages(list(packages or []))
    if pkg_msg:
        extra.append(pkg_msg)
        if pkg_msg.startswith("packages failed"):
            raise RuntimeError(f"update stopped: {pkg_msg} — nothing was changed")

    b = backup()
    try:
        _swap_in(root)
        for msg in (_apply_system_files(root, b), _run_post_install(root)):
            if msg:
                extra.append(msg)
        new_v = version
        if not new_v and (root / "VERSION").is_file():
            new_v = (root / "VERSION").read_text(encoding="utf-8").strip()
        if not new_v:
            new_v = datetime.datetime.now().strftime("%Y.%m.%d-%H%M")
        VERSION_FILE.write_text(new_v + "\n", encoding="utf-8")
    except Exception as e:
        restore(b.name)
        raise RuntimeError(f"update failed ({e}) — rolled back to {b.name}")

    msg = f"updated to {current_version()} (backup: {b.name})"
    if extra:
        msg += " — " + "; ".join(extra)
    return msg


def status() -> dict:
    return {"version": current_version(), "install_dir": str(INSTALL_DIR),
            "backups": list_backups(), "manifest": MANIFEST_URL}


if __name__ == "__main__":
    # Entry point for the hand-off described in update(): the outgoing
    # version downloads and verifies, then runs this file from the new
    # package to do the actual installation.
    #
    #   python3 updater.py --apply <extracted-root> <version> [packages...]
    #
    # And the privileged entry point the unprivileged agent asks for by name
    # through sudo. It takes no description of what to install: the manifest
    # decides, and the manifest URL is in this file, which the caller cannot
    # write to.
    if len(sys.argv) >= 2 and sys.argv[1] == "--rollback":
        # Takes no argument, deliberately: see _rollback_as_root.
        if os.geteuid() != 0:
            print("--rollback must be run as root", file=sys.stderr)
            sys.exit(1)
        try:
            msg = restore()
            print(msg)
            if not msg.startswith("restored"):
                sys.exit(1)
            if "--no-restart" not in sys.argv:
                print(restart_services())
        except Exception as e:
            print(e, file=sys.stderr)
            sys.exit(1)
        sys.exit(0)

    if len(sys.argv) >= 2 and sys.argv[1] == "--install":
        if os.geteuid() != 0:
            print("--install must be run as root", file=sys.stderr)
            sys.exit(1)
        try:
            print(update(restart="--no-restart" not in sys.argv))
        except Exception as e:
            print(e, file=sys.stderr)
            sys.exit(1)
        sys.exit(0)

    if len(sys.argv) >= 3 and sys.argv[1] == "--apply":
        try:
            print(apply_staged(pathlib.Path(sys.argv[2]),
                               sys.argv[3] if len(sys.argv) > 3 else "",
                               sys.argv[4:]))
        except Exception as e:
            print(e, file=sys.stderr)
            sys.exit(1)
    else:
        print(json.dumps(status(), indent=2))
