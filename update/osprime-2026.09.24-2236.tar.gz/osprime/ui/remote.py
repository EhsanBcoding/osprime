"""Remote access: using OSprime from a phone on the same network.

Designed in docs/SECURITY.md ("The access model") and agreed with Ehsan on
23 September. The shape, in one paragraph:

    Off by default. Switched on in Settings, on the computer. A second
    listener opens on the local network — a separate port, so a request
    arriving there can never be mistaken for one from the machine itself.
    A device pairs by scanning a QR code (or typing a six-digit code) shown
    on the computer's own screen; that is the whole of the authentication,
    because you had to be at the computer to see it. Each paired device gets
    its own long random key, stored on the phone as a cookie and on the
    computer only as a hash. Devices are listed in Settings and can be
    removed one at a time. Anything that needs approval is approved on the
    computer, unless a device has been given that right explicitly.

This module holds the state and the rules. web.py does the wiring: it runs
the second listener and asks this module who is allowed in.

What it is not: access from outside the house. That needs a relay or a
tunnel and is a separate project. The listener refuses any client that is
not on a private network address, so the machine being plugged straight
into the internet does not quietly turn this into that.
"""

import hashlib
import hmac
import ipaddress
import json
import os
import pathlib
import secrets
import subprocess
import threading
import time

STATE_PATH = pathlib.Path(os.environ.get("OSPRIME_REMOTE_STATE",
                                         "/etc/osprime/remote.json"))
PORT = int(os.environ.get("OSPRIME_REMOTE_PORT", "8081"))
COOKIE = "osprime_device"

PAIR_SECONDS = 120        # how long a QR code / code is good for
PAIR_TRIES = 5            # wrong codes before the pairing window closes
FAIL_LIMIT = 10           # bad keys or codes from one address per minute…
BLOCK_SECONDS = 3600      # …before that address is ignored for an hour
SEEN_EVERY = 300          # how often last-seen is written to disk

_lock = threading.Lock()
_pairing = None           # the open pairing window, in memory only
_fails = {}               # ip -> [timestamps]
_blocked = {}             # ip -> until
_seen_written = {}        # device id -> when last_seen was last saved


# --- state on disk -------------------------------------------------------------
def _load() -> dict:
    try:
        s = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        if isinstance(s, dict):
            s.setdefault("enabled", False)
            s.setdefault("devices", [])
            return s
    except Exception:
        pass
    return {"enabled": False, "devices": []}


def _save(s: dict) -> bool:
    """Mode 600: the file holds hashes, not keys, but who is paired and when
    they were last seen is nobody else's business."""
    try:
        STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = STATE_PATH.with_suffix(".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(s, f, indent=2)
        os.replace(tmp, STATE_PATH)
        return True
    except Exception:
        return False


def enabled() -> bool:
    return bool(_load().get("enabled"))


def set_enabled(on: bool) -> bool:
    global _pairing
    with _lock:
        s = _load()
        s["enabled"] = bool(on)
        if not on:
            _pairing = None      # switching off also closes a pairing window
        return _save(s)


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def devices() -> list:
    """What Settings shows. Never the hashes."""
    out = []
    for d in _load()["devices"]:
        out.append({k: d.get(k) for k in
                    ("id", "name", "created", "last_seen", "can_approve")})
    return out


def remove_device(dev_id: str) -> bool:
    with _lock:
        s = _load()
        before = len(s["devices"])
        s["devices"] = [d for d in s["devices"] if d.get("id") != dev_id]
        return len(s["devices"]) < before and _save(s)


def set_can_approve(dev_id: str, on: bool) -> bool:
    with _lock:
        s = _load()
        for d in s["devices"]:
            if d.get("id") == dev_id:
                d["can_approve"] = bool(on)
                return _save(s)
    return False


# --- the network -------------------------------------------------------------------
_addr_cache = (0.0, [])


def lan_addresses(fresh: bool = False) -> list:
    """This machine's addresses on local networks, the ones a phone can use.

    Cached for thirty seconds: every request to the remote listener checks
    its Host header against this list, and running `ip` for each one is
    wasteful. Pairing asks for a fresh list, because that is the moment an
    address that changed a second ago matters.
    """
    global _addr_cache
    if not fresh and time.time() - _addr_cache[0] < 30:
        return list(_addr_cache[1])
    found = []
    try:
        out = subprocess.run(["ip", "-4", "-o", "addr", "show", "scope",
                              "global"], capture_output=True, text=True,
                             timeout=5).stdout
        for line in out.splitlines():
            parts = line.split()
            if "inet" in parts:
                addr = parts[parts.index("inet") + 1].split("/")[0]
                if _private(addr):
                    found.append(addr)
    except Exception:
        pass
    _addr_cache = (time.time(), found)
    return list(found)


def _private(ip: str) -> bool:
    """A home or office network address — not the internet, not loopback.

    Checked on every request to the remote listener. Without it, a machine
    plugged straight into a modem with a public address would be offering
    its pairing page to the whole internet, and "only on my Wi-Fi" would
    have been a promise the code did not keep.
    """
    try:
        a = ipaddress.ip_address(ip.split("%")[0])
    except ValueError:
        return False
    if a.is_loopback:
        return False
    if isinstance(a, ipaddress.IPv6Address) and a.ipv4_mapped:
        return _private(str(a.ipv4_mapped))
    return a.is_private or a.is_link_local


def allowed_client(ip: str) -> str:
    """"" if this address may talk to the remote listener at all."""
    if not _private(ip):
        return "not on a local network"
    with _lock:
        until = _blocked.get(ip, 0)
        if until > time.time():
            return "too many failed attempts from this address"
    return ""


def _failed(ip: str):
    """Count a bad key or a wrong code. Ten in a minute, and that address is
    ignored for an hour. A 32-byte key is not guessable; the limit is for
    the six-digit code, and for keeping the log readable."""
    now = time.time()
    with _lock:
        recent = [t for t in _fails.get(ip, []) if now - t < 60] + [now]
        _fails[ip] = recent
        if len(recent) >= FAIL_LIMIT:
            _blocked[ip] = now + BLOCK_SECONDS
            _fails[ip] = []
            print(f"remote: {ip} blocked for an hour after {FAIL_LIMIT} "
                  "failed attempts", flush=True)


# --- pairing ---------------------------------------------------------------------------
def start_pairing() -> dict:
    """Open a pairing window. Called from Settings on the computer only."""
    global _pairing
    if not enabled():
        return {"ok": False, "message": "Turn on access from other devices first."}
    addrs = lan_addresses(fresh=True)
    if not addrs:
        return {"ok": False, "message": "This computer is not connected to a "
                "local network, so there is no address a phone could use."}
    nonce = secrets.token_urlsafe(16)
    code = f"{secrets.randbelow(10 ** 6):06d}"
    with _lock:
        _pairing = {"nonce": _hash(nonce), "code": _hash(code),
                    "expires": time.time() + PAIR_SECONDS, "tries": 0}
    base = f"http://{addrs[0]}:{PORT}"
    return {"ok": True, "url": f"{base}/pair?k={nonce}", "address": base,
            "addresses": [f"http://{a}:{PORT}" for a in addrs],
            "code": code, "seconds": PAIR_SECONDS}


def cancel_pairing():
    global _pairing
    with _lock:
        _pairing = None


def pairing_open() -> bool:
    with _lock:
        return bool(_pairing and _pairing["expires"] > time.time())


def complete_pairing(ip: str, name: str, nonce: str = "", code: str = ""):
    """(cookie value, device) on success, (None, reason) otherwise.

    Single use: a successful pairing closes the window, so the QR code on
    the screen cannot be photographed and used a second time. Five wrong
    codes close it too.
    """
    global _pairing
    with _lock:
        p = _pairing
        if not p or p["expires"] <= time.time():
            _pairing = None
            return None, ("No pairing is in progress. Start one in Settings "
                          "on the computer, then scan the code again.")
        ok = False
        if nonce and hmac.compare_digest(_hash(nonce), p["nonce"]):
            ok = True
        elif code and hmac.compare_digest(_hash(code.strip()), p["code"]):
            ok = True
        if not ok:
            p["tries"] += 1
            if p["tries"] >= PAIR_TRIES:
                _pairing = None
            failed_reason = "That code is not right."
        else:
            _pairing = None
            failed_reason = ""
    if failed_reason:
        _failed(ip)
        return None, failed_reason

    token = secrets.token_urlsafe(32)
    dev = {"id": secrets.token_hex(4),
           "name": (name or "").strip()[:40] or "Phone",
           "hash": _hash(token),
           "created": time.strftime("%Y-%m-%d %H:%M"),
           "last_seen": time.strftime("%Y-%m-%d %H:%M"),
           # The default agreed on 23 September: approvals happen on the
           # computer. A device earns the right to approve only when someone
           # at the computer gives it.
           "can_approve": False}
    with _lock:
        s = _load()
        s["devices"].append(dev)
        if not _save(s):
            return None, "Could not save the pairing on the computer."
    print(f"remote: paired {dev['name']} ({dev['id']}) from {ip}", flush=True)
    return f"{dev['id']}.{token}", {k: dev[k] for k in dev if k != "hash"}


# --- who is asking -----------------------------------------------------------------------
def _cookie_value(cookie_header: str) -> str:
    for part in (cookie_header or "").split(";"):
        k, _, v = part.strip().partition("=")
        if k == COOKIE:
            return v.strip()
    return ""


def authenticate(cookie_header: str, ip: str):
    """The paired device making this request, or None."""
    value = _cookie_value(cookie_header)
    if not value:
        return None
    dev_id, _, token = value.partition(".")
    if not dev_id or not token:
        _failed(ip)
        return None
    h = _hash(token)
    for d in _load()["devices"]:
        if d.get("id") == dev_id and hmac.compare_digest(d.get("hash", ""), h):
            _touch(d["id"])
            return {k: d.get(k) for k in ("id", "name", "can_approve")}
    # A cookie that does not match: a removed device, or someone guessing.
    _failed(ip)
    return None


def _touch(dev_id: str):
    """Record last-seen, but not on every request — this file is written by
    the web process and a phone polling every three seconds would rewrite
    it twenty times a minute."""
    now = time.time()
    if now - _seen_written.get(dev_id, 0) < SEEN_EVERY:
        return
    _seen_written[dev_id] = now
    with _lock:
        s = _load()
        for d in s["devices"]:
            if d.get("id") == dev_id:
                d["last_seen"] = time.strftime("%Y-%m-%d %H:%M")
        _save(s)


# --- what a paired device may do ----------------------------------------------------------
#
# Allowlists, not blocklists. Anything added to the web interface later is
# LOCAL ONLY until someone decides otherwise and adds it here — a new
# endpoint must not become reachable from a phone because nobody thought
# about phones when writing it.
REMOTE_GET = {
    "/", "/settings",
    "/api/settings", "/api/display", "/api/overview", "/api/storage",
    "/api/backgrounds", "/api/capture", "/api/devices", "/api/apps",
    "/api/profile", "/api/voice/status", "/api/notifications",
    "/api/memory", "/api/wifi/scan", "/api/backups", "/api/update/check",
    "/api/remote/whoami",
}
REMOTE_GET_PREFIX = ("/api/file?",)
REMOTE_POST = {
    "/api/chat", "/api/confirm", "/api/end", "/api/stt", "/api/tts",
    "/api/settings", "/api/open", "/api/proactive/dismiss", "/api/browse",
    # Searching the catalogue only reads it. Installing and uninstalling
    # are not here: they put software on the computer or take it off, and
    # that is decided at the computer.
    "/api/apps/search",
}

# Settings a phone may change: how the computer looks and sounds. Everything
# that decides what the assistant may do without asking — the confirmation
# level, the cloud, the API key, the camera and microphone permissions,
# whether it may speak first — is changed at the computer, for the same
# reason approvals are.
REMOTE_SETTING_KEYS = {"wallpaper", "volume", "scale", "text_size",
                       "resolution", "desktop", "companion", "language"}


def selftest() -> list:
    """What a phone must never reach, checked on every release.

    Written as a list of consequences rather than of endpoints: each line is
    something that must stay at the computer, so that adding a convenient
    endpoint to REMOTE_POST cannot quietly give a phone one of these.
    """
    must_be_local = [
        ("POST", "/api/update/install", "installing an update"),
        ("POST", "/api/rollback", "rolling back"),
        ("POST", "/api/apps/install", "installing software"),
        ("POST", "/api/apps/uninstall", "removing software"),
        ("POST", "/api/memory/forget", "deleting what the assistant remembers"),
        ("POST", "/api/wifi/connect", "moving the computer to another network"),
        ("POST", "/api/wifi/forget", "disconnecting the computer"),
        ("POST", "/api/remote/enable", "switching remote access"),
        ("POST", "/api/remote/pair", "pairing another device"),
        ("POST", "/api/remote/device", "granting a device the right to approve"),
        ("GET", "/api/remote", "seeing which devices are paired"),
        ("GET", "/api/approvals", "seeing requests waiting at the computer"),
        ("POST", "/api/onboard", "rewriting the user's profile"),
        ("PUT", "/api/settings", "any method but GET and POST"),
    ]
    bad = [f"remote: a phone could reach {what} ({m} {p})"
           for m, p, what in must_be_local if path_allowed(m, p)]
    for key in ("confirm_level", "cloud_mode", "api_key", "allow_camera",
                "allow_microphone", "proactive"):
        if key in REMOTE_SETTING_KEYS:
            bad.append(f"remote: a phone could change {key}")
    for ip, want in (("192.168.1.20", True), ("10.0.0.5", True),
                     ("172.16.4.4", True), ("8.8.8.8", False),
                     ("127.0.0.1", False), ("100.64.0.1", False)):
        if _private(ip) != want:
            bad.append(f"remote: {ip} treated as "
                       f"{'private' if not want else 'public'}")
    return bad


def path_allowed(method: str, path: str) -> bool:
    path_only = path.split("#", 1)[0]
    if method == "GET":
        bare = path_only.split("?", 1)[0]
        return bare in REMOTE_GET or path_only.startswith(REMOTE_GET_PREFIX)
    if method == "POST":
        return path_only.split("?", 1)[0] in REMOTE_POST
    return False
