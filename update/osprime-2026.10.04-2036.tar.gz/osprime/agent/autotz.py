"""Set the time zone automatically. Asked for by Ehsan, 1 October.

Phones do it; a buyer should not have to know their zone is called
America/Los_Angeles. When the switch is on (the default), the computer asks
geoip.ubuntu.com — the service Ubuntu's own installer uses, which answers
with nothing but a location and a time zone — once shortly after start-up
and then every few hours, and sets the zone if it changed (a laptop that
travelled).

What leaves the computer: the request itself, so the service sees this
computer's public IP address. Nothing else is sent. Settings says so next
to the switch, and it can be switched off.

A zone the person chose by hand always wins: choosing one switches this off
(system_tools.set_timezone with by_hand=True).

Runs inside the assistant, as the person, through the same named sudo rule
(timedatectl set-timezone) Settings uses — nothing here runs as root.
"""
import re
import threading
import time
import urllib.request

import paths

URL = "https://geoip.ubuntu.com/lookup"
KEY = "OSPRIME_AUTO_TIMEZONE"
FIRST_WAIT = 30            # seconds after start-up: give the network a moment
EVERY = 6 * 3600           # then every six hours
_ZONE = re.compile(r"<TimeZone>\s*([A-Za-z0-9_+\-]+(?:/[A-Za-z0-9_+\-]+){0,2})\s*</TimeZone>")


def enabled() -> bool:
    return paths.read_desktop_env().get(KEY, "yes").strip('"').lower() != "no"


def set_enabled(on: bool) -> bool:
    return paths.write_desktop_env(KEY, "yes" if on else "no")


def lookup(url: str = URL, timeout: float = 10, opener=None) -> str:
    """The zone geoip.ubuntu.com reports, or "" — never raises."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "OSprime"})
        with (opener or urllib.request.urlopen)(req, timeout=timeout) as r:
            body = r.read(65536).decode("utf-8", "replace")
    except Exception:
        return ""
    m = _ZONE.search(body)
    return m.group(1) if m else ""


def check_once(lookup_fn=None) -> str:
    """One look. Returns what happened, for the log."""
    import system_tools
    if not enabled():
        return "off"
    zone = (lookup_fn or lookup)()
    if not zone:
        return "no answer"
    resolved, _ = system_tools.resolve_timezone(zone)
    if resolved != zone:
        return f"ignored an unknown zone: {zone!r}"
    current = system_tools.current_timezone()
    if current == zone:
        return f"unchanged ({zone})"
    msg = system_tools.set_timezone(zone, by_hand=False)
    return msg


def _loop():
    time.sleep(FIRST_WAIT)
    while True:
        try:
            print(f"auto time zone: {check_once()}", flush=True)
        except Exception as e:
            print(f"auto time zone failed: {e}", flush=True)
        time.sleep(EVERY)


def start():
    threading.Thread(target=_loop, daemon=True, name="autotz").start()
