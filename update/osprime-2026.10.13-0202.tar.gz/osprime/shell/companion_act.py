"""Brainy does it for you, in the background (docs/ACT.md; Ehsan, 13 October).

Asked "do it for me: …", the assistant first uses its own tools (the
direct way, no screen at all). When the job lives in an app's window, it
hands the goal here, and this works in that window through accessibility
(act_probe.py): pressing and filling in, with no mouse and no keyboard —
the person goes on working in their own window at the same time.

  * One approval for the whole task; anything irreversible (send, delete,
    pay, install, shut down…) is asked about on its own (Ehsan).
  * Never a password field, a terminal, or a window that asks for a
    password (act_logic.validate / act_probe.window_ok).
  * Super+Escape, or Stop in the panel, stops it at once.
  * At most 15 steps; each step is one model call with words only.
"""
import threading
import time

from gi.repository import GLib

import act_logic as al
import act_probe as ap


class ActSession:
    def __init__(self, companion, bubble):
        self.c = companion
        self.b = bubble
        self.active = False
        self.goal = ""
        self.history = []
        self.win = None              # the window being worked in (title, app)
        self.pending = None
        self._reply = None
        self._reply_ev = threading.Event()
        self._answer = None
        self._answer_ev = threading.Event()
        self._stop = threading.Event()

    # ---- control (GTK thread) ----------------------------------------------
    def start(self, goal: str):
        self.stop(quiet=True)
        self.goal = " ".join((goal or "").split())[:300]
        if not self.goal:
            return
        self.history, self.win = [], None
        self._stop.clear()
        self.b.guide_card(
            f"Brainy will do this for you, in the background: “{self.goal}”.\n"
            "It presses and fills in through the app itself — your mouse and keyboard stay "
            "yours. Up to 15 steps; anything that cannot be undone is asked first. "
            "Super+Esc stops it.",
            [("Do it", self._go), ("Cancel", lambda: self.stop(quiet=True))])

    def _go(self):
        self.active = True
        self.c.set_local_state("reading")
        threading.Thread(target=self._run, daemon=True, name="act").start()

    def stop(self, quiet=False):
        was = self.active
        self.active = False
        self._stop.set()
        self._answer_ev.set()
        self._reply_ev.set()
        try:
            self.c.set_local_state(None)
        except Exception:
            pass
        if was and not quiet:
            GLib.idle_add(lambda: self.b.guide_card("Stopped. Nothing more will be pressed.", [], final=True)
                          and False)

    # ---- the work (its own thread) ---------------------------------------------
    def _ui(self, text, buttons=(), final=False):
        GLib.idle_add(lambda: self.b.guide_card(text, list(buttons), final=final) and False)

    def _ask_person(self, text) -> bool:
        """An irreversible step: asked on its own, the task waits."""
        self._answer, self._answer_ev = None, threading.Event()

        def yes():
            self._answer = True
            self._answer_ev.set()

        def no():
            self._answer = False
            self._answer_ev.set()
        self._ui(text, [("Yes, do it", yes), ("Skip", no), ("Stop", self.stop)])
        self._answer_ev.wait(600)
        return bool(self._answer) and not self._stop.is_set()

    def ask(self, prompt) -> str:
        self._reply_ev.clear()
        self._reply = None
        self.pending = f"a{time.time():.3f}"
        try:
            self.b.guide_link().send({"type": "guide_step", "id": self.pending, "text_only": True,
                                      "prompt": prompt, "system": al.SYSTEM})
        except OSError:
            return "ERROR: the assistant is not running"
        if not self._reply_ev.wait(240):
            return "ERROR: no answer in four minutes"
        return self._reply or "ERROR: empty answer"

    def on_reply(self, msg):
        if msg.get("id") == self.pending:
            self._reply = str(msg.get("raw") or "")
            self._reply_ev.set()

    def _current(self, wins):
        """The window worked in, found again (windows come and go)."""
        if self.win:
            for w in wins:
                if w["app"] == self.win[1] and w["title"] == self.win[0]:
                    return w
            for w in wins:
                if w["app"] == self.win[1]:
                    return w
        return None

    def _run(self):
        did = []
        try:
            for step in range(1, al.MAX_STEPS + 1):
                if self._stop.is_set():
                    return
                self._ui(f"Step {step}: looking…", [("Stop", self.stop)])
                wins = ap.list_windows()
                cur = self._current(wins)
                ctrls = ap.controls(cur) if cur and not cur["ok"] else []
                prompt = al.build_request(self.goal, self.history, ap.describe_windows(wins),
                                          f'{cur["app"]} — "{cur["title"]}"' if cur else "",
                                          ap.describe_controls(ctrls))
                raw = self.ask(prompt)
                if self._stop.is_set():
                    return
                if raw.startswith("ERROR:"):
                    self._ui(f"I could not go on: {raw[6:].strip()}.", final=True)
                    return
                r = al.validate(al.parse_reply(raw), ctrls, wins)
                if not r["ok"]:
                    # Told to the model as a step, so it can choose differently.
                    self.history.append(f"(refused: {r['why']})")
                    if len(self.history) >= 3 and all(h.startswith("(refused") for h in self.history[-3:]):
                        self._ui(f"I keep getting stuck ({r['why']}). Stopped; nothing else was pressed.",
                                 final=True)
                        return
                    continue
                say = r["say"] or r["do"]
                if r["do"] == "done":
                    self._ui("✓ " + (say or "Done.") + ("\n" + "\n".join("• " + d for d in did) if did else ""),
                             final=True)
                    return
                if r["do"] == "stuck":
                    self._ui("I could not do it here: " + (say or "no way forward") +
                             ". Nothing else was pressed.", final=True)
                    return
                if r["do"] == "window":
                    self.win = (r["window"]["title"], r["window"]["app"])
                    self.history.append(f"Working in {r['window']['app']}")
                    continue
                if r["do"] == "open":
                    try:
                        import desktop
                        desktop.launch(r["app"])
                    except Exception as e:
                        self.history.append(f"(could not open {r['app']}: {e})")
                        continue
                    self.history.append(f"Opened {r['app']}")
                    did.append(f"opened {r['app']}")
                    self.win = ("", r["app"])
                    time.sleep(3)
                    continue
                c = r["ctrl"]
                if r["irreversible"] and not self._ask_person(
                        f"Step {step}: {say}\n“{c['name']}” cannot be undone. Do it?"):
                    if self._stop.is_set():
                        return
                    self.history.append(f"(the user said no to pressing {c['name']!r}; do not press it)")
                    continue
                ok = ap.do_type(c, r["text"]) if r["do"] == "type" else ap.do_press(c)
                what = (f"typed into “{c['name']}”" if r["do"] == "type"
                        else f"pressed “{c['name']}”")
                if ok:
                    self.history.append(say or what)
                    did.append(what)
                    self._ui(f"Step {step}: {say}", [("Stop", self.stop)])
                else:
                    self.history.append(f"(that did not work: {what})")
                time.sleep(0.6)
            self._ui("That is a lot of steps — I stopped here.\n" + "\n".join("• " + d for d in did),
                     final=True)
        finally:
            self.active = False
            GLib.idle_add(lambda: self.c.set_local_state(None) and False)
