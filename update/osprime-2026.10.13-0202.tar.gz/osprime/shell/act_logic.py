"""The contract with the model for "do it for me" (docs/ACT.md).

One model call per step, words only (no picture: the window Brainy works in
may be behind the person's): the goal, what has been done, the open
windows, and the numbered controls of the window being worked in. The
model names ONE action. Everything it says is checked here before anything
happens — a prompt is not a safety boundary:

  * never a password, PIN or card field, never a terminal, never a window
    that asks for a password (act_probe.window_ok);
  * typing only into a field that takes text;
  * a control whose name or step says send / delete / pay / … is
    irreversible: asked about on its own, even inside an approved task
    (Ehsan, 13 October).
"""
import json
import re

import guide_probe as gp

MAX_STEPS = 15
# More than the guide's list: the guide only points, this presses.
FINAL = re.compile(r"\b(install|uninstall|shut ?down|power off|restart|reboot|sign out|log ?out|"
                   r"discard|overwrite|reset|format|empty|clear (all|history))\b|"
                   r"خاموش|نصب|حذف نصب|راه.?اندازی مجدد|خروج از حساب|بازنشانی", re.I)
MAX_TEXT = 2000

SYSTEM = (
    "You operate apps on the user's computer for them, through the apps' accessibility "
    "controls. Nothing you do moves the mouse; the user keeps working meanwhile.\n"
    "You get the goal, the steps already done, the open windows and the numbered "
    "controls of the window you are working in.\n"
    "Reply with JSON only:\n"
    '{"say": "<what you do now, at most 10 words, in the user\'s language>", '
    '"do": "press"|"type"|"window"|"open"|"done"|"stuck", '
    '"id": <control number, for press and type>, "text": "<for type>", '
    '"window": <window number, for window>, "app": "<app name, for open>"}\n'
    "Rules:\n"
    "- One action per reply. After it you get the new state.\n"
    "- press: a button, tab, menu item, list item, check box. type: put text into a "
    "field (it replaces what is there).\n"
    "- window: work in another open window. open: start an app that is not open.\n"
    "- done when the goal is reached (say a short closing line). stuck when it cannot "
    "be done here (say why).\n"
    "- Never use a password, PIN or card field. Never work in a terminal.\n"
    "- Plain words in say; never mention numbers from the lists.")


def _clip(s, n):
    s = re.sub(r"\s+", " ", str(s or "")).strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def build_request(goal, history, windows_listing, current, controls_listing):
    done = "\n".join(f"{i}. {_clip(h, 100)}" for i, h in enumerate(history, 1)) or "(none yet)"
    return "\n".join([
        "Goal: " + _clip(goal, 300),
        "Steps already done:", done,
        "Open windows (number | app | title):", windows_listing or "(none)",
        "Working in window: " + (current or "(none chosen yet — pick one with window, or open an app)"),
        "Its controls (number | type | name | state):", controls_listing or "(nothing usable)",
        "", "The one next action? JSON only."])


def parse_reply(raw):
    if raw is None:
        return None
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", str(raw).strip())
    a, b = s.find("{"), s.rfind("}")
    if a < 0 or b <= a:
        return None
    try:
        return json.loads(s[a:b + 1])
    except ValueError:
        return None


_APP = re.compile(r"^[\w .+-]{1,40}$")


def validate(reply, controls, windows):
    """-> {"ok", "why", "do", "say", "ctrl", "text", "window", "app", "irreversible"}"""
    out = {"ok": False, "why": "", "do": "", "say": "", "ctrl": None, "text": "", "window": None,
           "app": "", "irreversible": False}
    if not isinstance(reply, dict):
        out["why"] = "the model did not answer in the agreed form"
        return out
    out["say"] = _clip(reply.get("say"), 120)
    do = str(reply.get("do") or "").lower()
    out["do"] = do
    if do in ("done", "stuck"):
        out["ok"] = True
        return out
    if do == "open":
        app = _clip(reply.get("app"), 40)
        if not _APP.match(app):
            out["why"] = "no app named to open"
            return out
        import act_probe
        if act_probe.window_ok(app, ""):
            out["why"] = act_probe.window_ok(app, "")
            return out
        out.update(ok=True, app=app)
        return out
    if do == "window":
        try:
            w = next(x for x in windows if x["id"] == int(reply.get("window")))
        except (StopIteration, TypeError, ValueError):
            out["why"] = "no such window"
            return out
        if w.get("ok"):
            out["why"] = w["ok"]
            return out
        out.update(ok=True, window=w)
        return out
    if do not in ("press", "type"):
        out["why"] = f"unknown action {do!r}"
        return out
    try:
        c = next(x for x in controls if x["id"] == int(reply.get("id")))
    except (StopIteration, TypeError, ValueError):
        out["why"] = "no such control"
        return out
    if c.get("sensitive"):
        out["why"] = "that is a password or card field; Brainy never uses those"
        return out
    if do == "type":
        if not c.get("editable"):
            out["why"] = "that control does not take text"
            return out
        text = str(reply.get("text") or "")
        if not text or len(text) > MAX_TEXT:
            out["why"] = "no text to type" if not text else "too much text"
            return out
        out["text"] = text
    elif not c.get("actions"):
        out["why"] = "that control cannot be pressed"
        return out
    out.update(ok=True, ctrl=c)
    name = c.get("name", "")
    out["irreversible"] = do == "press" and bool(
        gp.IRREVERSIBLE.search(name) or FINAL.search(name) or
        gp.IRREVERSIBLE.search(out["say"]) or FINAL.search(out["say"]))
    return out
