"""OSprime system control.

Narrow, named operations instead of asking the model to compose shell
commands. A 1.5B model cannot reliably remember that setting the clock means
`timedatectl set-time "2026-08-15 14:30:00"` — it can reliably pick
`set_time` from a list and fill one field. That difference is why asking
OSprime to fix the clock failed.

Every function here also has a second consumer: Settings. Both read and write
through this module so the two can never disagree about what the system
currently is.

Each returns a short human sentence, because the result is shown to the user.
"""

import datetime as _dt
import glob
import json
import os
import pathlib
import re
import shlex
import shutil
import subprocess

CONFIG_PATH = pathlib.Path(os.environ.get("OSPRIME_DESKTOP_ENV",
                                          "/etc/osprime/desktop.env"))
TIMEOUT = 30


def _wayland_env():
    """The environment a program needs to talk to the screen.

    wlr-randr, grim and swaybg all connect to the compositor through
    WAYLAND_DISPLAY and XDG_RUNTIME_DIR. The agent and the web UI are
    systemd services, and a service inherits neither — so every one of those
    tools failed, and Settings reported "could not find the screen" and
    "resolution: not available" on a laptop whose screen was plainly there.
    Nothing was wrong with the display. The process asking simply had no way
    to reach it.

    So find the compositor's socket rather than assume it. There is normally
    exactly one.
    """
    e = os.environ.copy()
    if e.get("WAYLAND_DISPLAY") and e.get("XDG_RUNTIME_DIR"):
        return e
    for sock in sorted(glob.glob("/run/user/*/wayland-*")):
        if sock.endswith(".lock"):
            continue
        e["XDG_RUNTIME_DIR"] = os.path.dirname(sock)
        e["WAYLAND_DISPLAY"] = os.path.basename(sock)
        return e
    return e


def _no_display_error() -> str:
    """One sentence for the one cause worth distinguishing."""
    if not glob.glob("/run/user/*/wayland-*"):
        return ("ERROR: no graphical session is running, so there is no "
                "screen to read. This works from the desktop.")
    return ""


def _run(args, timeout: int = TIMEOUT, env=None):
    """Run a command directly — no shell, so nothing can be injected."""
    try:
        r = subprocess.run(args, capture_output=True, text=True,
                           timeout=timeout, env=env)
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", f"{args[0]} is not installed"
    except subprocess.TimeoutExpired:
        return 124, "", f"{args[0]} timed out"


def _sudo(args):
    """These actions need root. The agent runs unprivileged by design."""
    if os.geteuid() == 0:
        return _run(args)
    if shutil.which("sudo"):
        return _run(["sudo", "-n"] + args)
    return 1, "", "root privileges are required and sudo is unavailable"


# --------------------------------------------------------------------------
# time
# --------------------------------------------------------------------------

_DT = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$")


def get_time() -> str:
    code, out, _ = _run(["timedatectl", "show", "--property=Timezone",
                         "--property=NTP", "--property=TimeUSec", "--value"])
    if code != 0:
        return "ERROR: could not read the clock"
    parts = out.splitlines()
    return json.dumps({"timezone": parts[0] if parts else "",
                       "auto_sync": (parts[1] if len(parts) > 1 else "") == "yes",
                       "time": parts[2] if len(parts) > 2 else ""})


def set_time(datetime: str) -> str:
    """Set the clock. Expects `YYYY-MM-DD HH:MM` or with seconds.

    The parameter is named to match the tool schema exactly — the dispatcher
    passes arguments through by keyword, so a mismatch here is a runtime
    failure the model cannot recover from.
    """
    s = (datetime or "").strip().replace("T", " ")
    if not _DT.match(s):
        return ("ERROR: I need the time as YYYY-MM-DD HH:MM, "
                f"and I was given '{datetime}'.")
    if len(s) == 16:
        s += ":00"
    # Automatic sync overrides any manual setting, so it has to go first.
    _sudo(["timedatectl", "set-ntp", "false"])
    code, _, err = _sudo(["timedatectl", "set-time", s])
    if code != 0:
        return f"ERROR: could not set the clock: {err}"
    return f"clock set to {s}" + _host_clock_note()


def get_time() -> str:
    """What this computer currently believes the time and date to be.

    The set-system-time skill has told the assistant to verify with this
    since it was written, but the tool was never actually exposed — so the
    check step silently did nothing. That is very likely how it once
    announced a timezone had been set when it had not.
    """
    props = ("Timezone", "NTP", "NTPSynchronized", "LocalRTC")
    out = {}
    for p in props:
        code, val, _ = _run(["timedatectl", "show", f"--property={p}",
                             "--value"])
        out[p.lower()] = val if code == 0 else ""
    now = _dt.datetime.now()
    return json.dumps({
        "local_time": now.strftime("%Y-%m-%d %H:%M:%S"),
        "day": now.strftime("%A"),
        "timezone": out.get("timezone", ""),
        "automatic_sync": out.get("ntp", "") == "yes",
        "synchronised": out.get("ntpsynchronized", "") == "yes",
        "note": _host_clock_note().strip(" —"),
    })


def _host_clock_note() -> str:
    """Warn when something outside this system owns the clock.

    A virtual machine's guest agent resets the guest clock from the host on
    every boot, so a manually set time silently reverts and the user is left
    thinking the setting did not save. Saying so is better than letting them
    set it again and again.
    """
    for agent in ("vmtoolsd", "qemu-ga", "VBoxService"):
        if subprocess.run(["pgrep", "-x", agent],
                          capture_output=True).returncode == 0:
            return (" — note: this machine is a virtual machine and its host "
                    "resets the clock on every restart, so this will not "
                    "survive a reboot. On real hardware it will.")
    return ""


def resolve_timezone(text: str):
    """Turn what a person types into an IANA zone name.

    Nobody living in Irvine knows their timezone is called
    America/Los_Angeles. Requiring the exact name made a correct request look
    like a user error, so the city is resolved here instead — the tz database
    already lists every city it knows.

    Returns (zone, candidates). Exactly one of them is meaningful.
    """
    want = (text or "").strip()
    if not want:
        return None, []
    code, out, _ = _run(["timedatectl", "list-timezones", "--no-pager"])
    if code != 0:
        return want, []          # cannot check; let timedatectl decide
    zones = out.split()

    if want in zones:
        return want, []

    norm = want.replace(" ", "_").lower()
    exact = [z for z in zones if z.lower() == norm]
    if exact:
        return exact[0], []

    # A bare city: match the last component of the zone name.
    city = [z for z in zones if z.rsplit("/", 1)[-1].lower() == norm.rsplit("/", 1)[-1]]
    if len(city) == 1:
        return city[0], []
    if city:
        return None, city[:6]

    loose = [z for z in zones if norm.rsplit("/", 1)[-1] in z.lower()]
    if len(loose) == 1:
        return loose[0], []
    return None, loose[:6]


def set_timezone(zone: str) -> str:
    resolved, options = resolve_timezone(zone)
    if not resolved:
        if options:
            return (f"ERROR: '{zone}' matches several timezones. "
                    f"Which one: {', '.join(options)}?")
        return (f"ERROR: '{zone}' does not match any timezone. Give me the "
                "nearest large city, or a name like Europe/Berlin.")
    code, _, err = _sudo(["timedatectl", "set-timezone", resolved])
    if code != 0:
        return f"ERROR: could not set timezone: {err}"
    if resolved != (zone or "").strip():
        return f"timezone set to {resolved} (matched from '{zone}')"
    return f"timezone set to {resolved}"


def set_auto_time(enabled: bool = True) -> str:
    code, _, err = _sudo(["timedatectl", "set-ntp", "true" if enabled else "false"])
    if code != 0:
        return f"ERROR: could not change automatic time: {err}"
    return "clock now syncs automatically" if enabled else "automatic clock sync off"


# --------------------------------------------------------------------------
# network
# --------------------------------------------------------------------------

def _tsplit(line: str) -> list:
    """Split one line of `nmcli -t` output.

    nmcli separates fields with a colon and escapes any colon inside a value
    as `\\:`. Splitting naively tore apart every network whose name contains
    one, which is common enough on phone hotspots.
    """
    fields, cur, esc = [], [], False
    for ch in line:
        if esc:
            cur.append(ch)
            esc = False
        elif ch == "\\":
            esc = True
        elif ch == ":":
            fields.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    fields.append("".join(cur))
    return fields


def wifi_radio(on: bool = True) -> str:
    code, _, err = _sudo(["nmcli", "radio", "wifi", "on" if on else "off"])
    if code != 0:
        return f"ERROR: could not turn the Wi-Fi radio {'on' if on else 'off'}: {err}"
    return f"Wi-Fi radio {'on' if on else 'off'}"


def _has_wifi_device() -> bool:
    code, out, _ = _run(["nmcli", "-t", "-f", "TYPE", "device", "status"])
    return code == 0 and any(l.strip() == "wifi" for l in out.splitlines())


def list_wifi() -> str:
    if not shutil.which("nmcli"):
        return "ERROR: NetworkManager is not available on this system."
    if not _has_wifi_device():
        return ("ERROR: this machine has no Wi-Fi adapter. If it is connected "
                "by cable, it may already be online.")

    # A blocked radio reports zero networks, which reads as "nothing nearby"
    # rather than "the switch is off" — so turn it on rather than mislead.
    code, out, _ = _run(["nmcli", "-t", "-f", "WIFI", "radio"])
    if code == 0 and out.strip().endswith("disabled"):
        r = wifi_radio(True)
        if r.startswith("ERROR"):
            return r

    # Without an explicit rescan the list is whatever was cached, which on a
    # freshly booted machine is usually nothing at all.
    _run(["nmcli", "device", "wifi", "rescan"], timeout=30)

    code, out, err = _run(["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY,IN-USE",
                           "device", "wifi", "list"], timeout=45)
    if code != 0:
        return f"ERROR: could not scan for networks: {err}"

    known = _saved_networks()
    seen, rows = set(), []
    for line in out.splitlines():
        p = _tsplit(line)
        ssid = (p[0] if p else "").strip()
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        rows.append({
            "ssid": ssid,
            "signal": p[1].strip() if len(p) > 1 else "",
            "secured": bool(p[2].strip()) if len(p) > 2 else True,
            "active": (p[3].strip() == "*") if len(p) > 3 else False,
            "saved": ssid in known,
        })
    if not rows:
        return "no networks found"
    rows.sort(key=lambda r: int(r["signal"] or 0), reverse=True)
    return json.dumps(rows[:20])


def _saved_networks() -> set:
    code, out, _ = _run(["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"])
    if code != 0:
        return set()
    names = set()
    for line in out.splitlines():
        p = _tsplit(line)
        if len(p) > 1 and "wireless" in p[1]:
            names.add(p[0])
    return names


def connect_wifi(ssid: str, password: str = "") -> str:
    if not ssid:
        return "ERROR: I need the network name."
    if not shutil.which("nmcli"):
        return "ERROR: NetworkManager is not available on this system."

    # -w is a global option and must come before the object. Appending it
    # after the command made nmcli reject every connection attempt outright,
    # which is why joining a network never once worked.
    base = ["nmcli", "-w", "30"]

    # A network joined before has its password stored; asking for it again
    # would be a worse experience than simply bringing the profile up.
    if not password and ssid in _saved_networks():
        code, _, err = _sudo(base + ["connection", "up", "id", ssid])
        if code == 0:
            return f"connected to {ssid}"

    args = base + ["device", "wifi", "connect", ssid]
    if password:
        args += ["password", password]
    code, _, err = _sudo(args)
    if code != 0:
        low = (err or "").lower()
        if "secrets" in low or "no key available" in low or "802-11" in low:
            return f"ERROR: '{ssid}' needs a password, or the password was wrong."
        if "not found" in low or "no network" in low:
            return f"ERROR: '{ssid}' is not in range. Scan again and pick it from the list."
        return f"ERROR: could not connect to {ssid}: {err or 'unknown reason'}"
    return f"connected to {ssid}"


def forget_wifi(ssid: str) -> str:
    if not ssid:
        return "ERROR: I need the network name."
    code, _, err = _sudo(["nmcli", "connection", "delete", "id", ssid])
    if code != 0:
        return f"ERROR: could not forget {ssid}: {err}"
    return f"forgot {ssid}"


def network_status() -> str:
    code, out, _ = _run(["nmcli", "-t", "-f", "TYPE,STATE,CONNECTION",
                         "device", "status"])
    if code != 0:
        return "ERROR: could not read network status"
    active = [l for l in out.splitlines() if ":connected:" in l]
    if not active:
        return "not connected to any network"
    return json.dumps([{"type": l.split(":")[0], "name": l.split(":")[2]}
                       for l in active])


# --------------------------------------------------------------------------
# appearance and locale — shared with Settings through desktop.env
# --------------------------------------------------------------------------

def _read_env() -> dict:
    out = {}
    try:
        for line in CONFIG_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except Exception:
        pass
    return out


def _write_env(key: str, value: str) -> bool:
    """Update one key, preserving comments and the rest of the file."""
    try:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        lines = (CONFIG_PATH.read_text(encoding="utf-8").splitlines()
                 if CONFIG_PATH.exists() else [])
        done = False
        for i, line in enumerate(lines):
            if line.strip().startswith(f"{key}="):
                lines[i] = f"{key}={value}"
                done = True
                break
        if not done:
            lines.append(f"{key}={value}")
        CONFIG_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return True
    except Exception:
        return False


_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")


def set_wallpaper(color: str) -> str:
    """Solid colour only for now — no image support yet."""
    c = (color or "").strip()
    named = {"petrol": "#12232E", "beige": "#D9CFBC", "black": "#0B0B0B",
             "navy": "#101A2E", "grey": "#2B2E33", "gray": "#2B2E33"}
    c = named.get(c.lower(), c)
    if not _HEX.match(c):
        return (f"ERROR: '{color}' is not a colour I understand. "
                "Give me a hex value like #12232E, or: petrol, beige, navy, grey.")
    if not _write_env("OSPRIME_WALLPAPER", c):
        return "ERROR: could not save the setting"
    if shutil.which("swaybg"):
        subprocess.run(["pkill", "swaybg"], capture_output=True)
        # Same reason as the display tools: a service has no Wayland socket
        # of its own, so swaybg would exit immediately and the background
        # would keep its old colour with nothing to say why.
        subprocess.Popen(["swaybg", "-c", c], env=_wayland_env(),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return f"background set to {c}"


def set_language(code: str) -> str:
    code = (code or "").strip().lower()
    if not re.match(r"^[a-z]{2}$", code):
        return f"ERROR: '{code}' is not a language code. Use two letters, such as en or fa."
    if not _write_env("OSPRIME_LANG", code):
        return "ERROR: could not save the setting"
    return f"language set to {code}. Reopen the chat window to see it."


def get_settings() -> str:
    """Everything Settings displays, from the one place that holds it."""
    env = _read_env()
    code, tz, _ = _run(["timedatectl", "show", "--property=Timezone", "--value"])
    return json.dumps({
        "language": env.get("OSPRIME_LANG", "en"),
        "wallpaper": env.get("OSPRIME_WALLPAPER", "#12232E"),
        "timezone": tz if code == 0 else "",
        "cloud_mode": env.get("OSPRIME_CLOUD_MODE",
                              os.environ.get("OSPRIME_CLOUD_MODE", "off")),
        "desktop": env.get("OSPRIME_DESKTOP", "yes") == "yes",
        "scale": env.get("OSPRIME_SCALE", ""),
    })


# --------------------------------------------------------------------------
# display and sound
# --------------------------------------------------------------------------

def set_volume(percent: int) -> str:
    try:
        p = max(0, min(100, int(percent)))
    except (TypeError, ValueError):
        return f"ERROR: '{percent}' is not a number between 0 and 100."
    if shutil.which("wpctl"):
        code, _, err = _run(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{p}%"])
    elif shutil.which("amixer"):
        code, _, err = _run(["amixer", "-q", "sset", "Master", f"{p}%"])
    else:
        return "ERROR: no audio control available"
    return f"volume set to {p}%" if code == 0 else f"ERROR: could not set volume: {err}"


def list_drives() -> str:
    """Removable and mounted storage, so the assistant can find a USB stick.

    Asked where the files on a memory stick are, the assistant had no way to
    look: it could list directories but had no idea the device existed.
    """
    code, out, _ = _run(["lsblk", "-J", "-o",
                         "NAME,SIZE,TYPE,MOUNTPOINT,RM,LABEL,FSTYPE"])
    if code != 0:
        return "ERROR: could not read the drives on this machine."
    try:
        tree = json.loads(out).get("blockdevices", [])
    except json.JSONDecodeError:
        return "ERROR: could not read the drives on this machine."

    drives = []

    def walk(node, removable=False):
        rm = bool(node.get("rm")) or removable
        # Anything carrying a filesystem, whether it is a partition or the
        # whole device. Plenty of USB sticks are formatted with no partition
        # table at all, and only listing partitions made those invisible —
        # which is the same as not supporting them.
        if node.get("fstype") and node.get("type") in ("part", "disk"):
            drives.append({
                "device": "/dev/" + node.get("name", ""),
                "size": node.get("size", ""),
                "label": node.get("label") or "",
                "filesystem": node.get("fstype") or "",
                "mounted_at": node.get("mountpoint") or "",
                "removable": rm,
            })
        for child in node.get("children", []) or []:
            walk(child, rm)

    for dev in tree:
        walk(dev)

    if not drives:
        return "no storage devices found"
    return json.dumps(drives)


def mount_drive(device: str) -> str:
    """Mount a partition under /media so its files can be reached."""
    dev = (device or "").strip()
    if not re.match(r"^/dev/[a-zA-Z0-9]+$", dev):
        return f"ERROR: '{device}' is not a device name. Use something like /dev/sdb1."

    # Already mounted somewhere? Say where instead of mounting it twice.
    code, out, _ = _run(["findmnt", "-n", "-o", "TARGET", "--source", dev])
    if code == 0 and out.strip():
        return f"{dev} is already available at {out.strip().splitlines()[0]}"

    if shutil.which("udisksctl"):
        code, out, err = _run(["udisksctl", "mount", "-b", dev], timeout=45)
        if code == 0:
            m = re.search(r"at (\S+)", out)
            return f"{dev} is available at {m.group(1).rstrip('.') if m else '/run/media'}"

    if not pathlib.Path(dev).exists():
        # The commonest failure by far, and the kernel's own wording for it —
        # "Can't lookup blockdev" — tells a user nothing at all.
        return (f"ERROR: there is no device called {dev}. Use list_drives to "
                "see what is actually connected; the name changes depending "
                "on what was plugged in first.")

    point = "/media/" + dev.rsplit("/", 1)[-1]
    _sudo(["mkdir", "-p", point])
    code, _, err = _sudo(["mount", dev, point])
    if code != 0:
        low = (err or "").lower()
        if "unknown filesystem" in low or "wrong fs type" in low:
            return (f"ERROR: {dev} is formatted in a way this system cannot "
                    "read yet. Tell the user which format it is if you know.")
        return f"ERROR: could not open {dev}: {err or 'unknown reason'}"
    return f"{dev} is available at {point}"


def compress_pdf(path: str, quality: str = "ebook") -> str:
    """Shrink a PDF, writing a new file beside the original.

    A tool rather than a shell command the model composes. Asked to do this
    with `run_shell` it produced a ghostscript line with a bare filename, no
    directory, and repeated it unchanged after being given the full path.
    Quoting, paths and flags are exactly the parts a small model gets wrong,
    and they are all fixed here.
    """
    src = pathlib.Path(os.path.expanduser((path or "").strip()))
    if not src.is_absolute():
        return (f"ERROR: '{path}' is not a full path. Give the whole path "
                "starting with /, such as /home/osprime/Desktop/file.pdf.")
    if not src.is_file():
        return f"ERROR: there is no file at {src}."
    if src.suffix.lower() != ".pdf":
        return f"ERROR: {src.name} is not a PDF."
    if not shutil.which("gs"):
        return "ERROR: ghostscript is not installed, so PDFs cannot be compressed yet."

    presets = {"screen": "/screen", "ebook": "/ebook",
               "printer": "/printer", "prepress": "/prepress"}
    preset = presets.get((quality or "ebook").strip().lower())
    if not preset:
        return (f"ERROR: '{quality}' is not a quality setting. Use screen, "
                "ebook, printer or prepress.")

    dest = src.with_name(src.stem + "-small.pdf")
    before = src.stat().st_size
    code, _, err = _run(["gs", "-sDEVICE=pdfwrite", "-dCompatibilityLevel=1.4",
                         f"-dPDFSETTINGS={preset}", "-dNOPAUSE", "-dQUIET",
                         "-dBATCH", f"-sOutputFile={dest}", str(src)],
                        timeout=600)
    if code != 0 or not dest.is_file():
        return f"ERROR: could not compress {src.name}: {err[:200] or 'unknown reason'}"

    after = dest.stat().st_size

    def mb(n):
        return f"{n / 1024 / 1024:.1f} MB" if n >= 1024 * 1024 else f"{n // 1024} KB"

    if after >= before:
        dest.unlink(missing_ok=True)
        return (f"{src.name} is already about as small as it goes "
                f"({mb(before)}). Removing pages would be the other way to "
                "get under a size limit.")
    pct = round((1 - after / before) * 100)
    return (f"{src.name}: {mb(before)} -> {mb(after)}, {pct}% smaller. "
            f"Saved as {dest.name} next to the original.")


def get_display() -> str:
    """Screens, their resolution and their scale."""
    if not shutil.which("wlr-randr"):
        return "ERROR: the display tool is not installed on this system yet."
    code, out, err = _run(["wlr-randr"], env=_wayland_env())
    if code != 0:
        return _no_display_error() or f"ERROR: could not read the display: {err}"

    screens, cur = [], None
    for line in out.splitlines():
        if line and not line[0].isspace():
            cur = {"name": line.split()[0], "modes": [], "current": "", "scale": ""}
            screens.append(cur)
        elif cur is not None:
            t = line.strip()
            if t.startswith("Scale:"):
                cur["scale"] = t.split(":", 1)[1].strip()
            elif "current" in t:
                cur["current"] = t.split()[0]
                cur["modes"].append(t.split()[0])
            elif "px," in t or re.match(r"^\d+x\d+", t):
                cur["modes"].append(t.split()[0])
    for s in screens:
        # Only the distinct sizes matter to a person choosing one.
        seen, keep = set(), []
        for m in s["modes"]:
            if m not in seen:
                seen.add(m)
                keep.append(m)
        s["modes"] = keep[:12]
    return json.dumps(screens) if screens else "no screens found"


def set_display(scale: str = "", resolution: str = "", output: str = "") -> str:
    """Change how large everything looks, or the resolution.

    Scale is the one people actually want: a 1920x1080 panel on a 14-inch
    laptop renders everything too small at 1.0, and lowering the resolution
    to compensate makes it blurry. 1.25 or 1.5 keeps it sharp.
    """
    if not shutil.which("wlr-randr"):
        return "ERROR: the display tool is not installed on this system yet."
    if not scale and not resolution:
        return "ERROR: tell me a scale (such as 1.25) or a resolution (such as 1920x1080)."

    env = _wayland_env()
    if not output:
        code, out, err = _run(["wlr-randr"], env=env)
        if code != 0 or not out.strip():
            return (_no_display_error()
                    or f"ERROR: could not find the screen: {err[:160]}")
        output = out.splitlines()[0].split()[0]

    args = ["wlr-randr", "--output", output]
    if resolution:
        if not re.match(r"^\d{3,5}x\d{3,5}$", resolution.strip()):
            return f"ERROR: '{resolution}' is not a resolution. Use a form like 1920x1080."
        args += ["--mode", resolution.strip()]
    if scale:
        try:
            s = float(str(scale).strip().rstrip("x%"))
            if s > 4:            # someone typed 125 meaning 125%
                s = s / 100
            if not 0.5 <= s <= 4:
                raise ValueError
        except ValueError:
            return f"ERROR: '{scale}' is not a scale. Use something between 1 and 2, such as 1.25."
        args += ["--scale", f"{s:g}"]

    code, _, err = _run(args, timeout=20, env=env)
    if code != 0:
        return f"ERROR: could not change the display: {err[:160]}"

    # Persist it, or it is gone at the next login.
    if scale:
        _write_env("OSPRIME_SCALE", f"{s:g}")
    if resolution:
        _write_env("OSPRIME_RESOLUTION", resolution.strip())
    _write_env("OSPRIME_OUTPUT", output)

    what = []
    if resolution:
        what.append(f"resolution {resolution}")
    if scale:
        what.append(f"scale {s:g}")
    return f"{output}: {' and '.join(what)}"


def take_screenshot(area: bool = False) -> str:
    """Save a picture of the screen.

    Every X11 screenshot program the model reached for is absent here; this
    is the one that works, and naming it removes the guessing.
    """
    if not shutil.which("grim"):
        return "ERROR: the screenshot tool is not installed on this system yet."
    home = os.path.expanduser("~" + (os.environ.get("SUDO_USER") or "osprime"))
    folder = pathlib.Path(home) / "Pictures" / "Screenshots"
    try:
        folder.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return f"ERROR: could not create {folder}: {e}"

    dest = folder / (_dt.datetime.now().strftime("%Y-%m-%d_%H-%M-%S") + ".png")
    env = _wayland_env()
    args = ["grim", str(dest)]
    if area and shutil.which("slurp"):
        code, region, _ = _run(["slurp"], timeout=60, env=env)
        if code != 0 or not region:
            return "the selection was cancelled, so nothing was saved"
        args = ["grim", "-g", region, str(dest)]

    code, _, err = _run(args, timeout=60, env=env)
    if code != 0 or not dest.is_file():
        return (_no_display_error()
                or f"ERROR: could not take the screenshot: {err[:160]}")
    if shutil.which("wl-copy"):
        subprocess.run(["sh", "-c", f"wl-copy < '{dest}'"],
                       capture_output=True, env=env)
    return f"screenshot saved to {dest}"


# --------------------------------------------------------------------------
# files
#
# Asked how many pictures were in a folder that held two, the assistant
# answered "10" and listed ten made-up names. It never looked. There was a
# list_dir tool, but nothing that described itself as the way to count or
# find files, so the model filled the gap with invention — the same failure
# mode as the timezone, the ghostscript command and the screenshot tools.
# The cure has been the same every time: a tool whose description matches
# the words a person actually uses.
# --------------------------------------------------------------------------

_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif",
              ".tiff", ".heic", ".svg"}
_VIDEO_EXT = {".mp4", ".mkv", ".webm", ".avi", ".mov", ".m4v"}
_AUDIO_EXT = {".mp3", ".wav", ".flac", ".ogg", ".m4a", ".opus"}
_DOC_EXT = {".pdf", ".odt", ".doc", ".docx", ".txt", ".md", ".rtf", ".ods",
            ".xls", ".xlsx", ".odp", ".ppt", ".pptx"}

_KINDS = {
    "images": _IMAGE_EXT, "image": _IMAGE_EXT, "pictures": _IMAGE_EXT,
    "picture": _IMAGE_EXT, "photos": _IMAGE_EXT, "photo": _IMAGE_EXT,
    "videos": _VIDEO_EXT, "video": _VIDEO_EXT, "movies": _VIDEO_EXT,
    "music": _AUDIO_EXT, "audio": _AUDIO_EXT, "songs": _AUDIO_EXT,
    "documents": _DOC_EXT, "document": _DOC_EXT, "docs": _DOC_EXT,
}

# What people say -> where it actually is.
_FOLDER_ALIASES = {
    "": "", "home": "", "my files": "",
    "desktop": "Desktop", "pictures": "Pictures", "photos": "Pictures",
    "images": "Pictures", "downloads": "Downloads", "download": "Downloads",
    "documents": "Documents", "docs": "Documents", "music": "Music",
    "videos": "Videos", "screenshots": "Pictures/Screenshots",
}


def _user_home() -> pathlib.Path:
    return pathlib.Path(os.path.expanduser(
        "~" + (os.environ.get("SUDO_USER") or "osprime")))


def _case_walk(p: pathlib.Path) -> pathlib.Path:
    """Find the real path when only the capitalisation is wrong.

    Desktop and desktop are two different directories here, and one wrong
    capital already cost a whole session of the assistant insisting a folder
    did not exist.
    """
    try:
        cur = pathlib.Path(p.anchor) if p.anchor else pathlib.Path(".")
        parts = p.parts[1:] if p.anchor else p.parts
        for part in parts:
            if (cur / part).exists():
                cur = cur / part
                continue
            match = next((c for c in cur.iterdir()
                          if c.name.lower() == part.lower()), None)
            if match is None:
                return p
            cur = match
        return cur
    except Exception:
        return p


def _resolve_folder(folder: str) -> pathlib.Path:
    home = _user_home()
    raw = (folder or "").strip().strip("\"'")
    key = raw.lower().strip("/").lstrip("~").strip("/")
    if key in _FOLDER_ALIASES:
        rel = _FOLDER_ALIASES[key]
        return home / rel if rel else home
    p = pathlib.Path(os.path.expanduser(raw)) if raw else home
    if not p.is_absolute():
        p = home / raw
    return p if p.is_dir() else _case_walk(p)


def list_files(folder: str = "", kind: str = "") -> str:
    """What is actually in a folder — with an exact count."""
    d = _resolve_folder(folder)
    if not d.exists():
        return (f"ERROR: there is no folder at {d}. Do not guess what is in "
                "it; ask the user where it is.")
    if not d.is_dir():
        return f"ERROR: {d} is a file, not a folder."
    try:
        entries = sorted(d.iterdir(), key=lambda x: x.name.lower())
    except PermissionError:
        return f"ERROR: not allowed to read {d}."
    except Exception as e:
        return f"ERROR: could not read {d}: {e}"

    k = (kind or "").strip().lower().lstrip("*").lstrip(".")
    exts = _KINDS.get(k)
    if exts is None and k:
        exts = {"." + k}

    files, folders = [], []
    for e in entries:
        if e.name.startswith("."):
            continue
        if e.is_dir():
            folders.append(e.name)
            continue
        if exts is not None and e.suffix.lower() not in exts:
            continue
        try:
            size = e.stat().st_size
        except Exception:
            size = 0
        files.append({"name": e.name, "size": size, "path": str(e)})

    # The count is a field of its own rather than something to be worked out
    # from the length of a list. Counting was the part it got wrong.
    return json.dumps({
        "folder": str(d),
        "looking_for": kind or "everything",
        "number_of_matching_files": len(files),
        "number_of_folders": len(folders),
        "files": files[:200],
        "folder_names": folders[:100],
    })


# Never deletable, whatever anyone asks. Not a security boundary — the
# shell is still there for someone who means it — but a tool that can be
# pointed at /etc by a model that misread a sentence should not exist.
_UNTOUCHABLE = (
    "/", "/bin", "/boot", "/dev", "/etc", "/lib", "/lib64", "/opt", "/proc",
    "/root", "/run", "/sbin", "/srv", "/sys", "/usr", "/var",
    "/opt/osprime", "/var/lib/osprime", "/etc/osprime",
)


def delete_files(files="", permanent: bool = False) -> str:
    """Move files or folders to the trash.

    Asked three times to delete a folder, the assistant would not touch it
    and told the user to open a terminal and run `rm -rf` themselves. It was
    right to refuse: `rm -rf` is a bad instrument for an everyday job, and a
    model that mis-parses one sentence deletes the wrong thing permanently.
    But "open a terminal" is a failure of the whole premise on an operating
    system whose promise is that you do not need one.

    So deleting becomes a named, reversible operation, the way it already is
    on the desktop's right-click menu. The trash is the point: an assistant
    that can undo its own mistakes is one you can let near your files.
    """
    home = _user_home()
    targets = []
    for raw in _as_list(files):
        p = pathlib.Path(os.path.expanduser(raw))
        if not p.is_absolute():
            p = home / raw
        if not p.exists():
            p = _case_walk(p)
        # Checked before existence, so /etc gets the right refusal rather
        # than a confusing "there is nothing there" on a machine where the
        # path happens to be missing.
        resolved = p.resolve() if p.exists() else pathlib.Path(
            os.path.abspath(str(p)))
        if str(resolved) in _UNTOUCHABLE:
            return (f"ERROR: {resolved} is part of the operating system and "
                    "is not something to delete. If that is really what the "
                    "user wants, they can do it themselves.")
        if not p.exists():
            return (f"ERROR: there is nothing at {p}. Use list_files to see "
                    "what the folder really contains — do not guess a name.")
        targets.append(resolved)

    if not targets:
        return "ERROR: say which file or folder to delete."

    if permanent:
        done, failed = [], []
        for t in targets:
            try:
                shutil.rmtree(t) if t.is_dir() else t.unlink()
                done.append(t.name)
            except Exception as e:
                failed.append(f"{t.name} ({type(e).__name__})")
        if not done:
            return "ERROR: could not delete " + ", ".join(failed)
        msg = f"permanently deleted: {', '.join(done)}. This cannot be undone."
        if failed:
            msg += " Could not delete: " + ", ".join(failed)
        return msg

    # `gio trash` follows the desktop trash specification, so anything sent
    # there shows up in the file manager's Trash and can be put back.
    if not shutil.which("gio"):
        return ("ERROR: the trash is not available on this system, and "
                "deleting without it would be permanent. Not doing that.")

    done, failed, no_trash = [], [], []
    for t in targets:
        code, _, err = _run(["gio", "trash", str(t)], timeout=120)
        if code == 0:
            done.append(t.name)
        elif "not supported" in err.lower() or "internal mount" in err.lower():
            # /tmp is usually a tmpfs, and a filesystem with no trash
            # directory cannot have things moved into one. This is the case
            # that would otherwise come back as an unreadable gio error.
            no_trash.append(str(t))
        else:
            failed.append(f"{t.name} ({err.strip()[:60] or 'unknown reason'})")

    if no_trash and not done:
        return ("ERROR: these are on a disk with no trash, so deleting them "
                "would be permanent and could not be undone: "
                + ", ".join(no_trash)
                + ". Ask the user whether to delete them permanently, and "
                "only if they say yes, call delete_files again with "
                "permanent set to true.")
    if not done:
        return "ERROR: could not delete " + ", ".join(failed)

    msg = (f"moved to the trash: {', '.join(done)}. "
           "Nothing is gone for good — it can be put back from the Trash in "
           "Files.")
    if no_trash:
        msg += (" These are on a disk with no trash and were left alone: "
                + ", ".join(no_trash))
    if failed:
        msg += " Could not move: " + ", ".join(failed)
    return msg


def open_file(path: str = "") -> str:
    """Open one file, or one folder, in whichever program suits it.

    open_app takes the name of a program, so 'show me a picture' had nowhere
    to put the picture. The model invented https://example.com/picture.jpg
    and opened the browser on it.
    """
    home = _user_home()
    raw = (path or "").strip().strip("\"'")
    if not raw:
        return "ERROR: give the path of the file to open."
    p = pathlib.Path(os.path.expanduser(raw))
    if not p.is_absolute():
        p = home / raw
    if not p.exists():
        p = _case_walk(p)
    if not p.exists():
        return (f"ERROR: there is nothing at {p}. Use list_files to see what "
                "the folder really contains — do not guess a filename.")

    ext = p.suffix.lower()
    if p.is_dir():
        argv = ["thunar", str(p)]
    elif ext in _IMAGE_EXT and shutil.which("imv"):
        argv = ["imv", str(p)]
    elif ext in (_VIDEO_EXT | _AUDIO_EXT) and shutil.which("mpv"):
        argv = ["mpv", str(p)]
    elif shutil.which("gio"):
        argv = ["gio", "open", str(p)]
    elif shutil.which("xdg-open"):
        argv = ["xdg-open", str(p)]
    else:
        return f"ERROR: nothing here knows how to open {p.name}."

    try:
        subprocess.Popen(argv, env=_wayland_env(), start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        return f"ERROR: could not open {p.name}: {e}"
    # The full path is returned deliberately: the chat window shows an image
    # inline when a result names one that really exists.
    return f"opened {p}"


_NOISE_DIRS = (".cache", ".local/share/Trash", ".git", "node_modules",
               ".venv", "__pycache__", ".mozilla", ".config/chromium")


def search_files(name: str = "", folder: str = "", days: str = "") -> str:
    """Find a file anywhere, by part of its name and/or how recent it is.

    'I saved it yesterday and I can't find it' is one of the most common
    things anyone asks a computer, and listing one folder at a time does not
    answer it.
    """
    if not (name or "").strip() and not str(days or "").strip():
        return ("ERROR: give part of the file's name, or how many days ago it "
                "was saved. Searching for nothing returns everything.")

    root = _resolve_folder(folder) if folder else _user_home()
    if not root.is_dir():
        return f"ERROR: there is no folder at {root}."

    args = ["find", str(root)]
    for d in _NOISE_DIRS:
        args += ["-path", f"*/{d}", "-prune", "-o"]
    args += ["-type", "f"]
    frag = (name or "").strip().strip("\"'*")
    if frag:
        args += ["-iname", f"*{frag}*"]
    if str(days or "").strip():
        try:
            n = max(1, int(float(str(days).strip())))
        except ValueError:
            return f"ERROR: '{days}' is not a number of days."
        args += ["-mtime", f"-{n}"]
    args += ["-print"]

    code, out, err = _run(args, timeout=90)
    # find exits non-zero when it could not read some directory, having
    # searched the rest perfectly well. Throwing away good results because
    # of an unreadable folder would be the wrong call.
    lines = [l for l in out.splitlines() if l.strip()]
    if code != 0 and not lines:
        return f"ERROR: the search failed: {err[:200]}"

    hits = []
    for p in lines[:200]:
        try:
            st = os.stat(p)
            hits.append({"path": p, "name": os.path.basename(p),
                         "size": st.st_size,
                         "modified": _dt.datetime.fromtimestamp(
                             st.st_mtime).strftime("%Y-%m-%d %H:%M")})
        except Exception:
            continue
    hits.sort(key=lambda h: h["modified"], reverse=True)
    return json.dumps({
        "searched_in": str(root),
        "looked_for": frag or f"anything from the last {days} days",
        "number_found": len(lines),
        "results": hits[:60],
    })


def disk_usage() -> str:
    """Where the space went, and what is safe to delete.

    A build died here with 'no space left on device'. Answering that needs
    two things a person cannot easily get: what is large, and what of it can
    go without losing anything.
    """
    info = {}
    code, out, _ = _run(["df", "-B1", "--output=size,used,avail,pcent", "/"])
    if code == 0 and len(out.splitlines()) > 1:
        size, used, avail, pcent = out.splitlines()[1].split()
        info["disk"] = {"total": _human(int(size)), "used": _human(int(used)),
                        "free": _human(int(avail)), "used_percent": pcent}

    home = _user_home()
    big = []
    code, out, _ = _run(["du", "-x", "-d", "1", "-B1", str(home)], timeout=120)
    if code == 0 or out:
        for line in out.splitlines():
            parts = line.split("\t", 1)
            if len(parts) != 2 or parts[1] == str(home):
                continue
            try:
                big.append({"folder": os.path.basename(parts[1]),
                            "path": parts[1], "size": _human(int(parts[0])),
                            "bytes": int(parts[0])})
            except ValueError:
                continue
        big.sort(key=lambda b: b["bytes"], reverse=True)
    info["largest_folders_in_home"] = big[:10]

    # Named explicitly, because "delete some files" is not advice. These are
    # the places where deleting costs nothing.
    reclaimable = []
    for path, what in ((home / ".cache", "cached data programs will rebuild"),
                       (home / ".local/share/Trash", "the trash"),
                       (pathlib.Path("/var/cache/pacman/pkg"),
                        "downloaded installer packages, already installed"),
                       (pathlib.Path("/var/lib/osprime/backups"),
                        "backups of previous OSprime versions")):
        code, out, _ = _run(["du", "-sx", "-B1", str(path)], timeout=60)
        if code == 0 and out.split("\t"):
            try:
                n = int(out.split("\t")[0])
            except ValueError:
                continue
            if n > 10 * 1024 * 1024:
                reclaimable.append({"path": str(path), "size": _human(n),
                                    "what_it_is": what})
    info["safe_to_delete"] = reclaimable
    return json.dumps(info)


def _human(n: int) -> str:
    f = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if f < 1024 or unit == "TB":
            return f"{f:.0f} {unit}" if unit == "B" else f"{f:.1f} {unit}"
        f /= 1024
    return f"{n} B"


def _as_list(value) -> list:
    """Small models send a list sometimes and a comma-separated string other
    times. Both mean the same thing; refusing one of them is pedantry that
    costs the user an answer."""
    if isinstance(value, (list, tuple)):
        return [str(v).strip().strip("\"'") for v in value if str(v).strip()]
    text = str(value or "")
    sep = "," if "," in text else ("\n" if "\n" in text else None)
    parts = text.split(sep) if sep else ([text] if text.strip() else [])
    return [p.strip().strip("\"'") for p in parts if p.strip()]


def merge_pdfs(files="", output: str = "") -> str:
    """Join several PDFs into one, in the order given."""
    if not shutil.which("qpdf"):
        return "ERROR: the PDF tool is not installed on this system yet."
    home = _user_home()
    paths = []
    for raw in _as_list(files):
        p = pathlib.Path(os.path.expanduser(raw))
        if not p.is_absolute():
            p = home / raw
        if not p.exists():
            p = _case_walk(p)
        if not p.is_file():
            return (f"ERROR: there is no file at {p}. Use list_files on the "
                    "folder and merge the names it actually returns.")
        paths.append(p)

    if len(paths) < 2:
        return ("ERROR: give at least two PDF files to join, in the order "
                "they should appear.")

    if output:
        dest = pathlib.Path(os.path.expanduser(output))
        if not dest.is_absolute():
            dest = paths[0].parent / output
    else:
        dest = paths[0].parent / "merged.pdf"
    if dest.suffix.lower() != ".pdf":
        dest = dest.with_suffix(".pdf")
    n = 2
    while dest.exists():
        dest = dest.with_name(f"{dest.stem} ({n}).pdf")
        n += 1

    args = ["qpdf", "--empty", "--pages"] + [str(p) for p in paths] + \
           ["--", str(dest)]
    code, _, err = _run(args, timeout=300)
    if code != 0 or not dest.is_file():
        return f"ERROR: could not join them: {err[:200] or 'unknown reason'}"
    return (f"{len(paths)} files joined into {dest} "
            f"({_human(dest.stat().st_size)}).")


def remove_background(path: str = "", output: str = "") -> str:
    """Cut the subject out of a photo and leave the background transparent."""
    home = _user_home()
    raw = (path or "").strip().strip("\"'")
    if not raw:
        return "ERROR: give the full path of the picture."
    src = pathlib.Path(os.path.expanduser(raw))
    if not src.is_absolute():
        src = home / raw
    if not src.exists():
        src = _case_walk(src)
    if not src.is_file():
        return (f"ERROR: there is no picture at {src}. Use list_files to see "
                "what is really in the folder.")
    if src.suffix.lower() not in _IMAGE_EXT:
        return f"ERROR: {src.name} is not a picture."

    exe = shutil.which("rembg") or "/opt/osprime/venv/bin/rembg"
    if not os.path.isfile(exe) and not shutil.which("rembg"):
        # A one-time download, named exactly, rather than "install rembg".
        return ("ERROR: background removal needs a one-time setup — it uses a "
                "model that is too large to ship in the system. Tell the user "
                "to run this once in a terminal, then ask again:\n"
                "    sudo bash /opt/osprime/shell/setup-background.sh")

    dest = pathlib.Path(os.path.expanduser(output)) if output else \
        src.with_name(src.stem + "-cutout.png")
    if not dest.is_absolute():
        dest = src.parent / dest
    dest = dest.with_suffix(".png")     # transparency needs PNG

    code, _, err = _run([exe, "i", str(src), str(dest)], timeout=600)
    if code != 0 or not dest.is_file():
        return f"ERROR: could not remove the background: {err[-200:] or 'unknown reason'}"
    return f"background removed — saved as {dest}"


def _magick(*args) -> list:
    """ImageMagick 7 renamed `convert` to `magick`, and `convert` on a
    Windows-adjacent PATH is a different program entirely. Ask for whichever
    one is here rather than assuming a version."""
    exe = shutil.which("magick") or shutil.which("convert")
    return ([exe] + list(args)) if exe else []


def _resolve_file(raw: str, must_exist: bool = True):
    """One path, resolved the way a person meant it. Returns a path or an
    ERROR string — callers check with isinstance."""
    home = _user_home()
    raw = (raw or "").strip().strip("\"'")
    if not raw:
        return "ERROR: give the full path of the file."
    p = pathlib.Path(os.path.expanduser(raw))
    if not p.is_absolute():
        p = home / raw
    if not p.exists():
        p = _case_walk(p)
    if must_exist and not p.is_file():
        return (f"ERROR: there is no file at {p}. Use list_files to see what "
                "the folder really contains — do not guess a filename.")
    return p


def _unique(dest: pathlib.Path) -> pathlib.Path:
    n = 2
    while dest.exists():
        dest = dest.with_name(f"{dest.stem} ({n}){dest.suffix}")
        n += 1
    return dest


# --------------------------------------------------------------------------
# OCR
# --------------------------------------------------------------------------

# What people call a language -> what tesseract calls it.
_OCR_LANGS = {
    "english": "eng", "en": "eng", "eng": "eng",
    "persian": "fas", "farsi": "fas", "fa": "fas", "fas": "fas",
    "arabic": "ara", "ar": "ara", "ara": "ara",
    "german": "deu", "de": "deu", "french": "fra", "fr": "fra",
    "spanish": "spa", "es": "spa", "turkish": "tur", "tr": "tur",
    "russian": "rus", "ru": "rus",
}


def ocr_pdf(path: str = "", language: str = "english") -> str:
    """Make a scanned PDF searchable — text you can select, copy and find.

    Deliberately does not depend on ocrmypdf being available. If it is, it
    is the better route and is used. If it is not, tesseract, ghostscript
    and qpdf between them do the same job, and all three are already here.
    Making the feature depend on one package name nobody could verify would
    be the `llama.cpp` mistake again.
    """
    src = _resolve_file(path)
    if isinstance(src, str):
        return src
    if src.suffix.lower() != ".pdf":
        return f"ERROR: {src.name} is not a PDF."

    lang = _OCR_LANGS.get((language or "").strip().lower(), "")
    if not lang:
        known = ", ".join(sorted(set(_OCR_LANGS.values())))
        return f"ERROR: '{language}' is not a language I can read. Try: {known}."

    if shutil.which("tesseract"):
        code, out, _ = _run(["tesseract", "--list-langs"], timeout=30)
        installed = {l.strip() for l in out.splitlines()[1:]} if code == 0 else set()
        if installed and lang not in installed:
            return (f"ERROR: the {language} text data is not installed, so "
                    f"that language cannot be read yet. Installed: "
                    f"{', '.join(sorted(installed)) or 'none'}.")

    dest = _unique(src.with_name(src.stem + "-searchable.pdf"))

    if shutil.which("ocrmypdf"):
        # --skip-text leaves pages that already have text alone, so running
        # this on a mixed document does not destroy the good pages.
        code, _, err = _run(["ocrmypdf", "-l", lang, "--skip-text",
                             str(src), str(dest)], timeout=1800)
        if code == 0 and dest.is_file():
            return (f"{src.name} is now searchable — saved as {dest.name}."
                    + _ocr_evidence(dest))
        # fall through and try the long way rather than giving up

    if not (shutil.which("tesseract") and shutil.which("gs")
            and shutil.which("qpdf")):
        return ("ERROR: the text-recognition tools are not installed on this "
                "system yet.")

    import tempfile
    tmp = tempfile.mkdtemp(prefix="osprime-ocr-")
    try:
        # 300 dpi is the floor for reliable recognition; below it letters
        # merge and the output is confident nonsense.
        code, _, err = _run(["gs", "-sDEVICE=png16m", "-r300", "-dNOPAUSE",
                             "-dBATCH", "-dQUIET",
                             f"-sOutputFile={tmp}/page-%04d.png", str(src)],
                            timeout=1800)
        pages = sorted(pathlib.Path(tmp).glob("page-*.png"))
        if code != 0 or not pages:
            return f"ERROR: could not read the pages of that PDF: {err[:160]}"

        made = []
        for page in pages:
            stem = str(page.with_suffix(""))
            code, _, err = _run(["tesseract", str(page), stem, "-l", lang,
                                 "pdf"], timeout=600)
            if code == 0 and os.path.isfile(stem + ".pdf"):
                made.append(stem + ".pdf")
        if not made:
            return f"ERROR: no text could be recognised: {err[:160]}"

        code, _, err = _run(["qpdf", "--empty", "--pages"] + made +
                            ["--", str(dest)], timeout=600)
        if code != 0 or not dest.is_file():
            return f"ERROR: could not assemble the result: {err[:160]}"
        return (f"{src.name} is now searchable — {len(made)} of {len(pages)} "
                f"pages recognised, saved as {dest.name}."
                + _ocr_evidence(dest))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _ocr_evidence(dest: pathlib.Path) -> str:
    """Read the text back out of the result.

    Recognition that produced nothing still writes a perfectly valid PDF, so
    "the file exists" proves only that a file exists. Reading the text back
    is the difference between reporting a job done and reporting a job that
    worked, and it costs one command.
    """
    if not shutil.which("pdftotext"):
        return " Open it and try selecting a word to confirm."
    code, out, _ = _run(["pdftotext", str(dest), "-"], timeout=120)
    if code != 0:
        return " Open it and try selecting a word to confirm."
    text = " ".join(out.split())
    if not text:
        return (" WARNING: no text could be read back out of the result, so "
                "the recognition found nothing. Tell the user it did not "
                "work — the file exists but is no more searchable than "
                "before. A clearer or straighter scan is what is needed.")
    return (f" {len(text)} characters recognised. It begins: "
            f"\"{text[:120]}\".")


# --------------------------------------------------------------------------
# pictures
# --------------------------------------------------------------------------

def make_signature(path: str = "") -> str:
    """Turn a photo of a signature on paper into a clean transparent PNG."""
    src = _resolve_file(path)
    if isinstance(src, str):
        return src
    if src.suffix.lower() not in _IMAGE_EXT:
        return f"ERROR: {src.name} is not a picture."

    dest = _unique(src.with_name(src.stem + "-signature.png"))
    args = _magick(str(src), "-colorspace", "Gray", "-normalize",
                   "-level", "45%,75%", "-fuzz", "30%",
                   "-transparent", "white", "-trim", "+repage", str(dest))
    if not args:
        return "ERROR: the image tools are not installed on this system yet."
    code, _, err = _run(args, timeout=180)
    if code != 0 or not dest.is_file():
        return f"ERROR: could not clean up the signature: {err[:180]}"
    return (f"signature saved as {dest} with a transparent background. "
            "Have the user look at it — a photo taken in poor light can lose "
            "thin strokes, and only they can tell.")


# name -> (width mm, height mm, who uses it)
_PHOTO_SIZES = {
    "35x45": (35, 45, "UK, EU, Schengen and most of the world"),
    "51x51": (51, 51, "United States and Canada (2 x 2 inches)"),
    "40x60": (40, 60, "Iran, passport (4 x 6 cm)"),
    "30x40": (30, 40, "Iran, identity documents (3 x 4 cm)"),
    "33x48": (33, 48, "China"),
}


def passport_photo(path: str = "", size: str = "35x45",
                   sheet: bool = True) -> str:
    """Cut a photo to an official size, and lay out a sheet to print."""
    src = _resolve_file(path)
    if isinstance(src, str):
        return src
    if src.suffix.lower() not in _IMAGE_EXT:
        return f"ERROR: {src.name} is not a picture."

    key = (size or "").strip().lower().replace(" ", "").replace("*", "x")
    spec = _PHOTO_SIZES.get(key)
    if spec is None:
        opts = ", ".join(f"{k} ({v[2]})" for k, v in _PHOTO_SIZES.items())
        return f"ERROR: '{size}' is not a size I know. Choose one of: {opts}."
    mm_w, mm_h, who = spec

    dpi = 300
    px_w = round(mm_w / 25.4 * dpi)
    px_h = round(mm_h / 25.4 * dpi)

    single = _unique(src.with_name(f"{src.stem}-{key}.jpg"))
    args = _magick(str(src), "-auto-orient",
                   "-resize", f"{px_w}x{px_h}^",
                   "-gravity", "center", "-extent", f"{px_w}x{px_h}",
                   "-background", "white", "-flatten",
                   "-units", "PixelsPerInch", "-density", str(dpi),
                   "-quality", "95", str(single))
    if not args:
        return "ERROR: the image tools are not installed on this system yet."
    code, _, err = _run(args, timeout=180)
    if code != 0 or not single.is_file():
        return f"ERROR: could not cut the photo to size: {err[:180]}"

    result = (f"{mm_w}x{mm_h} mm photo saved as {single} ({who}).")

    if sheet and shutil.which("montage"):
        # A 10x15 cm print is what every photo shop and kiosk produces, and
        # filling it costs the same as printing one.
        sheet_w, sheet_h = round(15 / 2.54 * dpi), round(10 / 2.54 * dpi)
        cols, rows = max(1, sheet_w // (px_w + 24)), max(1, sheet_h // (px_h + 24))
        sheet_path = _unique(src.with_name(f"{src.stem}-{key}-print.jpg"))
        code, _, _ = _run(["montage"] + [str(single)] * (cols * rows) +
                          ["-tile", f"{cols}x{rows}", "-geometry", "+12+12",
                           "-background", "white",
                           "-units", "PixelsPerInch", "-density", str(dpi),
                           str(sheet_path)], timeout=180)
        if code == 0 and sheet_path.is_file():
            result += (f" A 10x15 cm sheet with {cols * rows} copies is at "
                       f"{sheet_path} — print it at actual size, not "
                       "'fit to page', or the photos come out the wrong size.")
    return result


def convert_images(folder: str = "", width: str = "", format: str = "",
                   quality: str = "") -> str:
    """Resize or convert every picture in a folder, into a new folder."""
    d = _resolve_folder(folder) if folder else _user_home()
    if not d.is_dir():
        return f"ERROR: there is no folder at {d}."
    if not (width or format or quality):
        return ("ERROR: say what to change — a width in pixels, a format "
                "such as jpg, or a quality from 1 to 100.")

    fmt = (format or "").strip().lower().lstrip(".")
    if fmt and fmt not in ("jpg", "jpeg", "png", "webp"):
        return f"ERROR: '{format}' is not a format I can write. Use jpg, png or webp."
    if width:
        try:
            w = int(float(str(width).strip().rstrip("px")))
            if not 16 <= w <= 20000:
                raise ValueError
        except ValueError:
            return f"ERROR: '{width}' is not a width in pixels."
    if quality:
        try:
            q = int(float(str(quality).strip().rstrip("%")))
            if not 1 <= q <= 100:
                raise ValueError
        except ValueError:
            return f"ERROR: '{quality}' is not a quality between 1 and 100."

    pics = [p for p in sorted(d.iterdir())
            if p.is_file() and p.suffix.lower() in _IMAGE_EXT
            and not p.name.startswith(".")]
    if not pics:
        return f"ERROR: there are no pictures in {d}."

    # Never in place. An irreversible batch operation on someone's photos is
    # the one mistake here that cannot be undone.
    out = d / "converted"
    out.mkdir(exist_ok=True)

    done, failed = 0, []
    for p in pics:
        suffix = ("." + ("jpg" if fmt == "jpeg" else fmt)) if fmt else p.suffix
        target = out / (p.stem + suffix)
        args = [str(p), "-auto-orient"]
        if width:
            args += ["-resize", f"{w}x"]
        if quality:
            args += ["-quality", str(q)]
        cmd = _magick(*(args + [str(target)]))
        if not cmd:
            return "ERROR: the image tools are not installed on this system yet."
        code, _, _ = _run(cmd, timeout=300)
        if code == 0 and target.is_file():
            done += 1
        else:
            failed.append(p.name)

    msg = f"{done} of {len(pics)} pictures written to {out}. Originals untouched."
    if failed:
        msg += " Could not convert: " + ", ".join(failed[:5])
    return msg


# --------------------------------------------------------------------------
# documents
# --------------------------------------------------------------------------

_DOC_CSS = """
body { font-family: 'Liberation Sans', Arial, sans-serif; font-size: 11pt;
       line-height: 1.45; color: #111; }
h1 { font-size: 20pt; margin: 0 0 2pt 0; }
h2 { font-size: 12pt; margin: 16pt 0 4pt 0; border-bottom: 1px solid #999;
     padding-bottom: 2pt; text-transform: uppercase; letter-spacing: 0.5pt; }
h3 { font-size: 11pt; margin: 10pt 0 2pt 0; }
p, li { margin: 0 0 4pt 0; }
ul { margin: 0 0 6pt 0; padding-left: 16pt; }
"""


def _markdown_to_html(text: str) -> str:
    """A deliberately small subset: headings, bullets, bold, italic.

    Not a Markdown implementation. It exists so the assistant can write a
    document in the format it writes everything else in, and have it come
    out as a real file the user can edit.
    """
    def inline(s):
        s = (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
        s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
        s = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<i>\1</i>", s)
        return s

    out, in_list = [], False
    for raw in (text or "").splitlines():
        line = raw.rstrip()
        bullet = re.match(r"^\s*[-*+]\s+(.*)$", line)
        if bullet:
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append(f"<li>{inline(bullet.group(1))}</li>")
            continue
        if in_list:
            out.append("</ul>")
            in_list = False
        if not line.strip():
            continue
        head = re.match(r"^(#{1,3})\s+(.*)$", line)
        if head:
            n = len(head.group(1))
            out.append(f"<h{n}>{inline(head.group(2))}</h{n}>")
        elif re.match(r"^\s*([-=_])\1{2,}\s*$", line):
            out.append("<hr/>")
        else:
            out.append(f"<p>{inline(line)}</p>")
    if in_list:
        out.append("</ul>")
    return "\n".join(out)


def make_document(title: str = "", content: str = "", format: str = "odt",
                  folder: str = "") -> str:
    """Write a real document file the user can open, edit and send.

    Answers in a chat window cannot be edited, printed or emailed. A CV
    especially is not an answer — it is a file somebody keeps.
    """
    if not (content or "").strip():
        return "ERROR: there is nothing to put in the document."
    fmt = (format or "odt").strip().lower().lstrip(".")
    if fmt == "doc":
        fmt = "docx"
    if fmt not in ("odt", "docx", "pdf", "html"):
        return f"ERROR: '{format}' is not a format I can write. Use odt, docx or pdf."

    home = _user_home()
    d = _resolve_folder(folder) if folder else (home / "Documents")
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return f"ERROR: could not use {d}: {e}"

    safe = re.sub(r"[^\w\s.-]", "", (title or "document")).strip() or "document"
    html_path = d / (safe + ".html")
    page = (f"<!DOCTYPE html><html><head><meta charset='utf-8'>"
            f"<title>{safe}</title><style>{_DOC_CSS}</style></head><body>"
            f"{_markdown_to_html(content)}</body></html>")
    try:
        html_path.write_text(page, encoding="utf-8")
    except Exception as e:
        return f"ERROR: could not write the document: {e}"

    if fmt == "html":
        return f"document saved as {html_path}"

    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return (f"ERROR: the office suite is not installed, so only the web "
                f"version could be written. It is at {html_path}.")

    env = os.environ.copy()
    # LibreOffice needs a home it can write its profile into; a service that
    # has none exits without a message.
    env.setdefault("HOME", str(home))
    code, _, err = _run([soffice, "--headless", "--norestore",
                         "--convert-to", fmt, "--outdir", str(d),
                         str(html_path)], timeout=300)
    dest = d / (safe + "." + fmt)
    if code != 0 or not dest.is_file():
        return (f"ERROR: could not convert it to {fmt}: {err[:180]}. "
                f"The web version is at {html_path}.")
    html_path.unlink(missing_ok=True)
    return (f"{dest} written ({_human(dest.stat().st_size)}). "
            "Open it to check it before sending — a document nobody looked "
            "at is not finished.")


# --------------------------------------------------------------------------
# keyboard shortcuts
#
# Asked to make Super+S take a screenshot, the assistant had no tool for it
# and reached for the nearest screenshot-shaped thing instead: it tried to
# take a screenshot. A missing capability does not read as missing to a
# model — it reads as an invitation to improvise.
#
# The shortcuts a person adds live in their own settings file, not in the
# compositor config, because that config ships in /opt and every update
# would overwrite it. The session merges the two at startup.
# --------------------------------------------------------------------------

SHORTCUTS_PATH = pathlib.Path(os.environ.get("OSPRIME_SHORTCUTS",
                                             "/etc/osprime/shortcuts.json"))

# What a shortcut is allowed to do. Named actions, not arbitrary commands:
# a keypress that runs anything the model wrote is a standing instruction
# nobody reviews again.
SHORTCUT_ACTIONS = {
    "screenshot": ("take a picture of part of the screen",
                   "bash /opt/osprime/shell/osprime-screenshot.sh area"),
    "full screenshot": ("take a picture of the whole screen",
                        "bash /opt/osprime/shell/osprime-screenshot.sh full"),
    "chat": ("open the assistant",
             "bash /opt/osprime/shell/osprime-toggle.sh"),
    "terminal": ("open a terminal", "foot"),
    "apps": ("open the apps menu",
             "bash /opt/osprime/shell/osprime-apps.sh"),
    "browser": ("open the web browser",
                "bash /opt/osprime/shell/osprime-browser.sh"),
    "files": ("open the file manager", "thunar"),
    "settings": ("open Settings",
                 "bash /opt/osprime/shell/osprime-settings.sh"),
}

_MODIFIERS = {"super": "W", "win": "W", "windows": "W", "meta": "W", "cmd": "W",
              "ctrl": "C", "control": "C", "alt": "A", "shift": "S"}
_NAMED_KEYS = {"space": "space", "enter": "Return", "return": "Return",
               "tab": "Tab", "escape": "Escape", "esc": "Escape",
               "print": "Print", "printscreen": "Print", "delete": "Delete",
               "backspace": "BackSpace", "up": "Up", "down": "Down",
               "left": "Left", "right": "Right"}


def _to_labwc_key(keys: str):
    """Turn "Super+S" into labwc's "W-s". Returns None if it cannot."""
    parts = [p.strip().lower() for p in re.split(r"[+\-\s]+", keys or "")
             if p.strip()]
    if not parts:
        return None
    mods, main = [], None
    for p in parts:
        if p in _MODIFIERS:
            if _MODIFIERS[p] not in mods:
                mods.append(_MODIFIERS[p])
        else:
            main = p
    if main is None:
        return None
    if main in _NAMED_KEYS:
        key = _NAMED_KEYS[main]
    elif len(main) == 1:
        key = main            # labwc wants a bare lowercase letter
    elif re.fullmatch(r"f\d{1,2}", main):
        key = main.upper()
    else:
        return None
    # labwc's order is W C A S; keeping it stable means two spellings of
    # the same shortcut produce the same binding and replace each other.
    order = {"W": 0, "C": 1, "A": 2, "S": 3}
    mods.sort(key=lambda m: order.get(m, 9))
    return "-".join(mods + [key]) if mods else key


def _read_shortcuts() -> dict:
    try:
        data = json.loads(SHORTCUTS_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


_KEY_NAMES = {"W": "Super", "C": "Ctrl", "A": "Alt", "S": "Shift"}


def _spell(binding: str) -> str:
    """Turn labwc's "W-S-s" back into "Super+Shift+S"."""
    parts = binding.split("-")
    out = [_KEY_NAMES.get(p, p) for p in parts[:-1]]
    last = parts[-1]
    # A lone modifier is a real binding here — Super on its own summons the
    # assistant — and it was being reported as the letter "W".
    if not out and last in _KEY_NAMES:
        return _KEY_NAMES[last]
    out.append(last.upper() if len(last) == 1 else last)
    return "+".join(out)


def list_shortcuts() -> str:
    """Every shortcut that works, read from the config that defines them.

    Parsed out of rc.xml rather than listed here, because a second copy of
    the list is a copy that goes stale.
    """
    built_in = []
    try:
        text = pathlib.Path(
            "/opt/osprime/shell/labwc/rc.xml").read_text(encoding="utf-8")
        for m in re.finditer(
                r'<keybind key="([^"]+)">.*?(?:<command>(.*?)</command>|'
                r'<action name="([^"]+)"\s*/>)', text, re.S):
            binding, cmd, action = m.group(1), m.group(2), m.group(3)
            if cmd:
                what = next((label for label, (label2, c)
                             in SHORTCUT_ACTIONS.items() if c == cmd.strip()),
                            None)
                what = SHORTCUT_ACTIONS[what][0] if what else _describe(cmd)
            else:
                what = {"Close": "close the window",
                        "NextWindow": "switch windows",
                        "ToggleFullscreen": "make the window fullscreen",
                        "Exit": "log out"}.get(action, action)
            built_in.append(f"{_spell(binding)} — {what}")
    except Exception:
        pass

    mine = [f"{_spell(k)} — {SHORTCUT_ACTIONS.get(v, (v,))[0]}"
            for k, v in sorted(_read_shortcuts().items())]
    return json.dumps({
        "already_built_in": built_in,
        "ones_you_added": mine,
        "a_shortcut_can_do": list(SHORTCUT_ACTIONS),
    })


def _describe(cmd: str) -> str:
    """What a raw command in rc.xml does, in words.

    The specific cases come first. Matching the generic list first made
    `foot -F python3 chat.py` read as "open a terminal", because it does
    start a terminal — and that is exactly the wrong half of the sentence.
    """
    c = cmd.strip()
    if "chat.py" in c:
        return "open the assistant in a terminal"
    if "localhost:8080" in c or "osprime-toggle" in c:
        return "open the assistant"
    for _label, (nice, known) in SHORTCUT_ACTIONS.items():
        if known.split()[-1] in c:
            return nice
    return c.split()[-1]


def set_shortcut(keys: str = "", does: str = "") -> str:
    """Bind a key combination to one of the things OSprime can do."""
    # Called with nothing: say what the shortcuts already are. Somebody
    # asked to create Super+Shift+S for screenshots, which had worked since
    # the day it was written — the shortcuts that exist are invisible, and
    # "what are my shortcuts" is the question that fixes that.
    if not (keys or "").strip() and not (does or "").strip():
        return list_shortcuts()

    if not (keys or "").strip():
        return ("ERROR: say which keys, for example 'Super+S'. The things a "
                "shortcut can do are: " + ", ".join(SHORTCUT_ACTIONS) + ".")
    binding = _to_labwc_key(keys)
    if not binding:
        return (f"ERROR: '{keys}' is not a key combination I can set. Use "
                "something like Super+S, Ctrl+Alt+T, or F9.")

    current = _read_shortcuts()
    action = (does or "").strip().lower()

    if not action:
        if binding not in current:
            return f"ERROR: there is no shortcut on {keys} to remove."
        current.pop(binding)
        what = f"{keys} no longer does anything"
    else:
        if action not in SHORTCUT_ACTIONS:
            return (f"ERROR: '{does}' is not something a shortcut can do. "
                    "Choose one of: " + ", ".join(SHORTCUT_ACTIONS) + ".")
        current[binding] = action
        what = f"{keys} now {SHORTCUT_ACTIONS[action][0]}s".replace("s s", "s")
        what = f"{keys} will {SHORTCUT_ACTIONS[action][0]}"

    try:
        SHORTCUTS_PATH.parent.mkdir(parents=True, exist_ok=True)
        SHORTCUTS_PATH.write_text(json.dumps(current, indent=2) + "\n",
                                  encoding="utf-8")
    except Exception as e:
        return f"ERROR: could not save the shortcut: {e}"

    applied = _apply_shortcuts()
    if applied.startswith("ERROR:"):
        return applied
    listing = ", ".join(f"{k} → {v}" for k, v in sorted(current.items()))
    return f"{what}. Your shortcuts now: {listing or '(none)'}"


def _apply_shortcuts() -> str:
    """Rebuild the compositor config and reload it, so it works now.

    Writing the file and telling the user to log out would be the kind of
    half-done that this project keeps finding. labwc re-reads its config on
    demand, so there is no reason to make anyone wait.
    """
    base = pathlib.Path("/opt/osprime/shell/labwc/rc.xml")
    if not base.is_file():
        return "ERROR: the compositor config is missing; cannot apply shortcuts."
    out_dir = pathlib.Path(_wayland_env().get("XDG_RUNTIME_DIR", "/tmp"))
    out_dir = out_dir / "osprime-labwc"
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
        text = base.read_text(encoding="utf-8")
        extra = []
        for binding, action in sorted(_read_shortcuts().items()):
            cmd = SHORTCUT_ACTIONS.get(action, (None, None))[1]
            if cmd:
                extra.append(f'    <keybind key="{binding}"><action '
                             f'name="Execute"><command>{cmd}</command>'
                             f'</action></keybind>')
        if extra:
            # Last wins in labwc, so the user's bindings go after ours.
            text = text.replace("</keyboard>",
                                "\n".join(extra) + "\n  </keyboard>", 1)
        for name in ("rc.xml", "menu.xml", "autostart", "environment"):
            src = base.parent / name
            if src.is_file() and name != "rc.xml":
                shutil.copy2(src, out_dir / name)
        (out_dir / "rc.xml").write_text(text, encoding="utf-8")
    except Exception as e:
        return f"ERROR: could not write the shortcut config: {e}"

    if shutil.which("labwc"):
        _run(["labwc", "--reconfigure"], timeout=20, env=_wayland_env())
    return "applied"


# --------------------------------------------------------------------------
# power
# --------------------------------------------------------------------------

_POWER = {
    "shutdown": (["systemctl", "poweroff"], "Shutting down"),
    "power off": (["systemctl", "poweroff"], "Shutting down"),
    "poweroff": (["systemctl", "poweroff"], "Shutting down"),
    "off": (["systemctl", "poweroff"], "Shutting down"),
    "turn off": (["systemctl", "poweroff"], "Shutting down"),
    "restart": (["systemctl", "reboot"], "Restarting"),
    "reboot": (["systemctl", "reboot"], "Restarting"),
    "sleep": (["systemctl", "suspend"], "Going to sleep"),
    "suspend": (["systemctl", "suspend"], "Going to sleep"),
    "hibernate": (["systemctl", "hibernate"], "Hibernating"),
    "log out": (["pkill", "-x", "labwc"], "Logging out"),
    "logout": (["pkill", "-x", "labwc"], "Logging out"),
    "sign out": (["pkill", "-x", "labwc"], "Logging out"),
}


def power(action: str = "") -> str:
    """Turn the computer off, restart it, put it to sleep, or log out.

    Asked to shut the laptop down, the assistant answered "I'm sorry, but I
    can't assist with that" — not because it was forbidden but because there
    was no way to do it. A computer you cannot turn off by asking is not an
    operating system you talk to.
    """
    key = (action or "").strip().lower().replace("-", " ").replace("_", " ")
    entry = _POWER.get(key)
    if entry is None:
        return ("ERROR: say which one — shutdown, restart, sleep, or log out.")
    argv, doing = entry

    if not shutil.which(argv[0]):
        return f"ERROR: {argv[0]} is not available on this system."
    if argv[0] == "systemctl" and os.geteuid() != 0:
        if not shutil.which("sudo"):
            return "ERROR: this needs root and sudo is not available."
        # No permission probe here. The obvious one — `sudo -n true` — asks
        # whether `true` is allowed, and it is not: the sudoers file lists
        # the exact power commands and nothing else. Probing with a
        # different command than the one being run answers a different
        # question, and would have reported that shutting down was
        # forbidden while shutting down was in fact permitted.
        argv = ["sudo", "-n"] + argv

    # A few seconds' delay so the answer reaches the screen before the screen
    # goes away.
    cmd = " ".join(shlex.quote(a) for a in argv)
    try:
        subprocess.Popen(["sh", "-c", f"sleep 3; {cmd}"], start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        return f"ERROR: could not do that: {e}"
    return f"{doing} in a few seconds."


def model_status() -> str:
    """Which model is running, and whether this machine could do better."""
    try:
        import hardware
    except Exception as e:
        return f"ERROR: could not read the hardware profile: {e}"
    try:
        r = hardware.report()
    except Exception as e:
        return f"ERROR: could not profile this machine: {e}"
    now, rec = r["running_now"], r["recommended"]
    r["can_do_better"] = (now.get("tier") != rec.get("tier"))
    r["how_to_change_it"] = (
        "sudo bash /opt/osprime/shell/osprime-profile.sh --install"
        if r["can_do_better"] else "")
    return json.dumps(r)


def system_summary() -> str:
    """Facts about this machine, for answering 'what am I running on'."""
    out = {}
    code, o, _ = _run(["uname", "-r"])
    out["kernel"] = o if code == 0 else ""
    try:
        mem = pathlib.Path("/proc/meminfo").read_text()
        kb = int(re.search(r"MemTotal:\s+(\d+)", mem).group(1))
        out["memory_gb"] = round(kb / 1024 / 1024, 1)
    except Exception:
        pass
    out["cpu_cores"] = os.cpu_count()
    code, o, _ = _run(["df", "-h", "--output=avail,pcent", "/"])
    if code == 0 and len(o.splitlines()) > 1:
        avail, pcent = o.splitlines()[1].split()
        out["disk_free"] = avail
        out["disk_used"] = pcent
    return json.dumps(out)
