#!/usr/bin/env bash
# Move the model onto the graphics card.
#
#   sudo bash /opt/osprime/shell/setup-gpu.sh          install, then reboot
#   sudo bash /opt/osprime/shell/setup-gpu.sh          again after the reboot
#   sudo bash /opt/osprime/shell/setup-gpu.sh --undo   put everything back
#
# The shipped engine runs on the processor, on purpose: that works on any
# machine that boots the ISO. But reading a long prompt is what keeps people
# waiting — about twenty seconds of the first answer — and that is precisely
# what a graphics card is good at.
#
# The engine itself is never replaced. Arch ships one llama-cpp and supplies
# acceleration as a separate package that ggml loads at run time, so all
# this does is add a backend and set one variable.
#
# Two things this learned the hard way. NVIDIA cards do not want the Vulkan
# route; they want their own driver, which is a kernel module and therefore
# needs a reboot before it can be judged. And a machine whose driver is not
# installed cannot be asked what graphics it has by any tool that ships with
# a driver — so the card is found on the PCI bus instead.
#
# Nothing is kept that cannot be shown to be faster. The speed of reading a
# long prompt is measured before, and again after, and if the card did not
# win the whole thing is put back.
set -u

MODEL_ENV=/etc/osprime/model.env
STATE=/var/lib/osprime/gpu-setup.state
PORT="${MODEL_PORT:-8087}"
LOG=/tmp/osprime-gpu-setup.log
AGENT=/opt/osprime/agent

[ "$EUID" -eq 0 ] || { echo "Run this with sudo."; exit 1; }
mkdir -p "$(dirname "$STATE")"

# --------------------------------------------------------------------------

undo() {
    echo "> going back to the processor"
    sed -i '/^OSPRIME_GPU_LAYERS=/d' "$MODEL_ENV" 2>/dev/null
    # Remove only the backend that was added. The engine itself was never
    # replaced, so there is nothing to reinstall and nothing to break.
    if [ -f "$STATE" ]; then
        # shellcheck disable=SC1090
        . "$STATE"
        [ -n "${BACKEND:-}" ] && pacman -Rns --noconfirm "$BACKEND" >>"$LOG" 2>&1
    fi
    rm -f "$STATE"
    systemctl restart osprime-model
    echo "Back on the processor. The graphics driver was left installed;"
    echo "remove it with 'sudo pacman -Rns nvidia-open' if you want it gone."
    exit 0
}
[ "${1:-}" = "--undo" ] && undo

# Which acceleration backend this system can install.
#
# Two package names were guessed here — llama-cpp-cuda and llama-cpp-vulkan
# — and neither exists. Asking pacman showed why: Arch does not ship a
# separate engine per backend at all. There is one llama-cpp, and the
# acceleration arrives as its own package — ggml-cuda, ggml-vulkan,
# ggml-hip, ggml-sycl — which ggml loads at run time.
#
# That is a much better shape than the one that was guessed at. The engine
# is never replaced, so undoing this is removing one package, and a backend
# that does not work leaves a working computer behind it.
available() {
    pacman -Ssq '^ggml-' 2>/dev/null
}

pick_backend() {             # pick_backend <name> [next] ...
    local list want
    list="$(available)"
    for want in "$@"; do
        if printf '%s\n' "$list" | grep -qx "$want"; then
            printf '%s\n' "$want"; return 0
        fi
    done
    return 0
}

show_available() {
    echo
    echo "What this system does offer:"
    available | sed 's/^/    /'
}

wait_up() {
    for _ in $(seq 1 180); do
        sleep 1
        curl -fsS --max-time 5 "http://127.0.0.1:$PORT/v1/models" >/dev/null 2>&1 \
            && return 0
    done
    return 1
}

# Reading a long prompt is the thing being fixed, so it is the thing timed.
measure() {
    local filler start end
    filler="$(head -c 6000 /dev/urandom | base64 | tr -d '\n' | head -c 6000)"
    start="$(date +%s%N)"
    curl -fsS --max-time 300 -X POST \
        "http://127.0.0.1:$PORT/v1/chat/completions" \
        -H 'Content-Type: application/json' \
        -d "{\"messages\":[{\"role\":\"user\",\"content\":\"Reply with OK only. Ignore this: $filler\"}],\"max_tokens\":4}" \
        >/dev/null 2>&1 || { echo 0; return; }
    end="$(date +%s%N)"
    echo $(( (end - start) / 1000000 ))
}

# --------------------------------------------------------------------------
# second run: the reboot has happened, so judge it
# --------------------------------------------------------------------------

if [ -f "$STATE" ]; then
    # shellcheck disable=SC1090
    . "$STATE"
    echo "> the driver is installed; checking the card is actually in use"
    wait_up || {
        echo "The engine is not answering at all. Putting everything back."
        undo; }

    # Ask the engine, not the clock. The first version of this compared two
    # timings and kept the change when the second was 31 ms out of 21,500
    # faster — noise, on a machine where the card was never used at all.
    # The launch ladder had quietly dropped back to the processor because
    # the GPU rung would not start, and a timing test cannot tell the
    # difference between "no faster" and "not running".
    WHERE="$(PYTHONPATH="$AGENT" python3 -c "
import hardware
s = hardware.engine_status()
print(s['running_on'])
print(s.get('evidence',''))
print(s.get('startup_settings',''))
" 2>/dev/null)"
    RUNNING_ON="$(printf '%s\n' "$WHERE" | sed -n 1p)"
    echo "  the engine says it is running on: ${RUNNING_ON:-unknown}"
    printf '%s\n' "$WHERE" | sed -n '2,3p' | sed '/^$/d;s/^/    /'

    if [ "$RUNNING_ON" != "graphics card" ]; then
        echo
        echo "The backend is installed but the engine is not using it — it"
        echo "fell back to the processor at startup. Putting everything back"
        echo "so nothing is left half-applied."
        echo
        echo "What the engine logged, for working out why:"
        journalctl -u osprime-model -b --no-pager 2>/dev/null \
            | grep -iE "attempt:|running \(|ggml_|cuda|vulkan|error|failed" \
            | tail -15 | sed 's/^/    /'
        undo
    fi

    AFTER="$(measure)"
    echo "  before, on the processor : ${BEFORE} ms"
    echo "  now, on the card         : ${AFTER} ms"

    # A margin, not a difference. Two runs of the same thing vary by a few
    # percent; anything inside that is not an improvement, it is weather.
    if [ "$AFTER" -gt 0 ] && [ "$AFTER" -lt $(( BEFORE * 85 / 100 )) ]; then
        echo
        echo "Keeping it: $(( (BEFORE - AFTER) * 100 / BEFORE ))% faster at reading a prompt."
        echo "To undo at any time:  sudo bash $0 --undo"
        rm -f "$STATE"
        exit 0
    fi
    echo
    echo "The card is in use but no meaningfully faster (less than 15%),"
    echo "so it is not worth the extra moving parts. Going back."
    undo
fi

# --------------------------------------------------------------------------
# first run
# --------------------------------------------------------------------------

VENDOR="$(PYTHONPATH="$AGENT" python3 -c "
import hardware
g = hardware._gpu()
print(g.get('vendor') or ('NVIDIA' if 'nvidia' in g.get('kind','').lower() else ''))
" 2>/dev/null)"
KIND="$(PYTHONPATH="$AGENT" python3 -c "
import hardware; print(hardware._gpu().get('kind',''))" 2>/dev/null)"

if [ -z "$VENDOR" ]; then
    echo "No graphics card found on the PCI bus. Nothing to do."
    exit 1
fi
echo "Graphics found: ${KIND:-$VENDOR}"

echo "> timing the current setup"
wait_up || { echo "The engine is not answering. Fix that first:"; \
             echo "    systemctl status osprime-model"; exit 1; }
BEFORE="$(measure)"
[ "$BEFORE" -gt 0 ] || { echo "Could not time it — nothing changed."; exit 1; }
echo "  reading a long prompt takes ${BEFORE} ms on the CPU"
echo

case "$VENDOR" in
NVIDIA)
    # Installing a second graphics driver on a laptop changes which DRM
    # device wlroots finds first, and it once chose the card with no screen
    # attached — the desktop simply stopped appearing. The session script
    # now pins the display to the card with a connected panel. Refuse to
    # install a driver on a system that does not yet have that protection.
    if ! grep -q 'WLR_DRM_DEVICES' /opt/osprime/shell/osprime-session.sh 2>/dev/null; then
        echo "This version of OSprime cannot safely install a graphics"
        echo "driver: the desktop does not yet pin itself to the screen's"
        echo "own card, so a second driver can leave you with no desktop."
        echo
        echo "Install the latest OSprime update first, then run this again."
        exit 1
    fi

    cat <<'WARN'
This installs NVIDIA's own driver. Three honest warnings first:

  * It upgrades the whole system before installing anything. A kernel
    module only loads into the kernel it was built for, and installing one
    without upgrading is exactly what broke this machine before.
  * It is a kernel module, so the machine has to restart before the card
    can be used. Nothing is measured or kept until after that.
  * The driver is removed again automatically if it turns out not to match
    the kernel, because a half-installed NVIDIA driver leaves an EGL entry
    behind that stops the desktop starting at all.

If the desktop ever fails to appear, switch to a text console with
Ctrl+Alt+F2 and run:
    sudo pacman -Rns --noconfirm $(pacman -Qq | grep '^nvidia')
    sudo reboot

WARN
    printf 'Type yes to continue: '
    read -r answer
    [ "$answer" = "yes" ] || { echo "Nothing was changed."; exit 0; }

    # This used to be `pacman -Sy --needed nvidia-open`, and that one flag
    # is what broke the desktop three times over.
    #
    # -Sy refreshes the package list without upgrading anything, so the
    # driver that gets installed is the one built for the repository's
    # current kernel, while the machine is still running an older one. Its
    # modules land in a directory for a kernel that is not booted, and
    # `modprobe nvidia_drm` answers "Module not found". The kernel driver is
    # therefore absent — but nvidia-utils has already registered NVIDIA as
    # an EGL vendor, so the compositor asks EGL to enumerate devices, the
    # NVIDIA vendor library fails because there is no driver behind it, and
    # labwc dies with EGL_BAD_ALLOC before it can draw anything.
    #
    # That is why the desktop disappeared, and why choosing the right
    # graphics card did not save it: the card was never the problem. A
    # half-installed driver is worse than no driver, because the EGL entry
    # it leaves behind breaks the machine that was working.
    echo "> upgrading the system first"
    echo "  (a kernel module has to match the kernel that boots, and"
    echo "   installing one without upgrading is what broke this before)"
    pacman -Syu --noconfirm >>"$LOG" 2>&1 || {
        echo "The system upgrade failed. Nothing else was changed."
        tail -8 "$LOG"; exit 1; }

    echo "> installing the NVIDIA driver"
    # nvidia-open covers every RTX card and is what Arch now recommends for
    # them; the older proprietary package is the fallback for anything else.
    pacman -S --noconfirm --needed nvidia-open nvidia-utils >>"$LOG" 2>&1 ||
    pacman -S --noconfirm --needed nvidia nvidia-utils >>"$LOG" 2>&1 || {
        echo "Could not install the driver. Nothing else was changed."
        tail -8 "$LOG"; exit 1; }

    # Prove the module exists for the kernel that will actually boot, before
    # telling anyone to restart into it. Comparing the two directories the
    # packages installed into is exact: if they differ, the module cannot
    # load, and leaving it there would take the desktop with it.
    NV_DIR="$(pacman -Ql nvidia-open nvidia 2>/dev/null \
              | grep -m1 -o '/usr/lib/modules/[^/]*')"
    K_DIR="$(pacman -Ql linux 2>/dev/null \
             | grep -m1 -o '/usr/lib/modules/[^/]*')"
    echo "  driver built for : ${NV_DIR:-unknown}"
    echo "  kernel installed : ${K_DIR:-unknown}"
    if [ -z "$NV_DIR" ] || [ "$NV_DIR" != "$K_DIR" ]; then
        echo
        echo "The driver does not match the kernel, so it would not load and"
        echo "the desktop would not come back. Removing it again now."
        pacman -Rns --noconfirm nvidia-open nvidia nvidia-utils >>"$LOG" 2>&1
        echo "Nothing was kept. The machine is as it was."
        exit 1
    fi

    echo "> installing the CUDA backend"
    # CUDA first; Vulkan works on NVIDIA too and is the fallback.
    BACKEND="$(pick_backend ggml-cuda ggml-vulkan)"
    [ -n "$BACKEND" ] || {
        echo "The driver is installed, but this system has no acceleration"
        echo "backend to offer. Nothing else was changed and everything"
        echo "still works on the processor."
        show_available
        exit 1; }
    pacman -S --noconfirm --needed "$BACKEND" >>"$LOG" 2>&1 || {
        echo "Could not install $BACKEND. Nothing else was changed."
        tail -8 "$LOG"; exit 1; }
    echo "  using $BACKEND"
    ;;

AMD|Intel)
    echo "> installing the graphics driver and an acceleration backend"
    pacman -Sy --noconfirm --needed vulkan-tools mesa \
        $([ "$VENDOR" = "AMD" ] && echo vulkan-radeon || echo vulkan-intel) \
        >>"$LOG" 2>&1 || {
        echo "Could not install the graphics driver. Nothing was changed."
        tail -8 "$LOG"; exit 1; }
    if ! vulkaninfo --summary >>"$LOG" 2>&1; then
        echo "Vulkan cannot use this hardware (it crashed or found nothing)."
        echo "Nothing was changed; the CPU build is untouched."
        exit 1
    fi
    # HIP for AMD and SYCL for Intel are the vendors' own routes and are
    # faster where they work; Vulkan is the one that works everywhere.
    if [ "$VENDOR" = "AMD" ]; then
        BACKEND="$(pick_backend ggml-hip ggml-vulkan)"
    else
        BACKEND="$(pick_backend ggml-sycl ggml-vulkan)"
    fi
    [ -n "$BACKEND" ] || {
        echo "This system has no acceleration backend to offer."
        echo "Nothing was changed."
        show_available
        exit 1; }
    pacman -S --noconfirm --needed "$BACKEND" >>"$LOG" 2>&1 || {
        echo "Could not install $BACKEND. Nothing was changed."
        tail -8 "$LOG"; exit 1; }
    echo "  using $BACKEND"
    ;;
*)
    echo "Unknown graphics vendor '$VENDOR'. Nothing was changed."
    exit 1
    ;;
esac

# 99 means "all the layers". The launch script's ladder means a driver that
# cannot cope drops back to the CPU rather than leaving no assistant at all.
touch "$MODEL_ENV"
sed -i '/^OSPRIME_GPU_LAYERS=/d' "$MODEL_ENV"
echo 'OSPRIME_GPU_LAYERS="99"' >> "$MODEL_ENV"

printf 'BEFORE=%s\nBACKEND=%s\n' "$BEFORE" "$BACKEND" > "$STATE"

if [ "$VENDOR" = "NVIDIA" ]; then
    echo
    echo "Installed. Restart the computer, then run this again:"
    echo "    sudo bash $0"
    echo "It will time the card and keep the change only if it was faster."
else
    systemctl restart osprime-model
    exec "$0"
fi
