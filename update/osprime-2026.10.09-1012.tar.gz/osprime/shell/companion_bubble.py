"""The panel beside the companion: ask something right where it lives.

Clicking the character opens it; Esc or the character again hides it.

Since 9 October it is a panel with three pages (docs/HELPERS.md):

  * Home — the helpers as small coloured Brainies (General, Researcher,
    Trader, Engineer, and any a person made), and the chosen one's glance
    card (a watchlist's prices, the projects' state…), data only, no model;
  * Chat — the chosen helper's own conversation (each helper keeps its own,
    on its own socket, so switching does not mix them);
  * + — make your own helper (a name and what it is for).

The helper used last is the one it opens with (helpers.last()).

Each conversation is a small one, not a second chat app:

  * it talks to the same assistant over the same socket as the terminal
    chat (agent/agent.py's JSON lines), so tools, confirmations, memory and
    the cloud switch all behave exactly as in the chat window;
  * the conversation lasts until "New" or until the companion closes; hiding
    the bubble keeps it, so a second question has the first one's context;
  * "Open the chat" is one click away for anything long.

It opens with the keyboard (EXCLUSIVE) so you can type at once, and lets go
of it (ON_DEMAND) once you have sent something, so you can click back into
your work while the answer arrives. A click on the bubble takes it again.

The character's mouth moves while the answer streams in (Companion.set_talking).
"""
import json
import os
import socket
import threading
import time
import unicodedata

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("GtkLayerShell", "0.1")
from gi.repository import Gtk, Gdk, GLib, GtkLayerShell, Pango  # noqa: E402

import paths  # noqa: E402

WIDTH = 380
MAX_HEIGHT = 420

CSS = b"""
#bubble { background-color: transparent; }
.card { background-color: #161b22; border: 1px solid #30363d; border-radius: 14px;
        padding: 10px; }
.card label { color: #e6edf3; }
.head { color: #8b949e; font-size: 11px; }
.you { background-color: #1f6feb; color: #ffffff; border-radius: 10px; padding: 6px 10px; }
.it { background-color: #21262d; border-radius: 10px; padding: 6px 10px; }
.dim { color: #8b949e; font-size: 11px; }
.err { color: #ff7b72; }
entry { background-color: #0d1117; color: #e6edf3; border: 1px solid #30363d;
        border-radius: 8px; padding: 6px 8px; }
button { background-image: none; background-color: #21262d; color: #e6edf3;
         border: 1px solid #30363d; border-radius: 7px; padding: 2px 8px; }
button:hover { background-color: #30363d; }
button.go { background-color: #238636; border-color: #238636; }
button.no { background-color: #21262d; }
button.tab { border-color: transparent; background-color: transparent; color: #8b949e; }
button.tab.on { background-color: #21262d; border-color: #30363d; color: #e6edf3; }
button.pill { padding: 2px 6px; }
button.pill.on { border-color: #58a6ff; background-color: #1c2a3d; }
.glance { background-color: #0d1117; border: 1px solid #30363d; border-radius: 10px;
          padding: 8px 10px; }
.up { color: #3fb950; }
.down { color: #f85149; }
"""


def is_rtl(text: str) -> bool:
    """Persian or Arabic first: the line reads right to left."""
    for ch in text or "":
        d = unicodedata.bidirectional(ch)
        if d in ("R", "AL"):
            return True
        if d == "L":
            return False
    return False


class AgentLink:
    """One conversation with the assistant over its socket. Messages come
    back on a thread and are handed to the GTK loop with GLib.idle_add."""

    def __init__(self, on_message):
        self.on_message = on_message
        self.sock = None
        self.f = None

    def connected(self) -> bool:
        return self.f is not None

    def connect(self):
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(str(paths.socket_path()))
        self.sock, self.f = s, s.makefile("rwb")
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        f = self.f
        try:
            for line in f:
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue
                GLib.idle_add(self.on_message, msg)
        except Exception:
            pass
        GLib.idle_add(self.on_message, {"type": "_closed"})

    def send(self, obj: dict):
        if not self.f:
            self.connect()
        self.f.write((json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8"))
        self.f.flush()

    def close(self):
        """Ends the conversation: the assistant keeps what it learned."""
        try:
            if self.sock:
                self.sock.close()
        except Exception:
            pass
        self.sock = self.f = None


class Conv:
    """One helper's conversation: its own lines, its own socket (so the
    assistant keeps a separate history for it) and its own turn state."""

    def __init__(self, hid, on_message):
        self.hid = hid
        self.list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.link = AgentLink(lambda msg: on_message(self, msg))
        self.answer = None          # the label the current answer streams into
        self.answer_text = ""
        self.busy = False
        self.spoken = False          # was the question asked out loud?


def _conv_attr(name):
    """self.list, self.link… are the conversation being worked on."""
    return property(lambda self: getattr(self.conv, name),
                    lambda self, v: setattr(self.conv, name, v))


def _helpers():
    import helpers
    return helpers


class Bubble:
    list = _conv_attr("list")
    link = _conv_attr("link")
    answer = _conv_attr("answer")
    answer_text = _conv_attr("answer_text")
    busy = _conv_attr("busy")
    spoken = _conv_attr("spoken")

    def __init__(self, companion):
        self.c = companion
        self._quiet_id = None
        self.convs = {}
        try:
            self.hid = _helpers().last()
        except Exception:
            self.hid = "general"
        # self.conv is the conversation being acted on: the shown one, or for
        # a moment the one whose socket just spoke (see _route).
        self.conv = self.shown = self._conv(self.hid)
        self.page = "home"
        self.glances = {}            # hid -> (time, card)
        self.guide_conv = None

        prov = Gtk.CssProvider()
        prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        self.win = Gtk.Window()
        self.win.set_name("bubble")
        GtkLayerShell.init_for_window(self.win)
        GtkLayerShell.set_layer(self.win, GtkLayerShell.Layer.TOP)
        GtkLayerShell.set_namespace(self.win, "osprime-companion-bubble")
        GtkLayerShell.set_exclusive_zone(self.win, 0)
        visual = self.win.get_screen().get_rgba_visual()
        if visual is not None:
            self.win.set_visual(visual)
        self.win.set_app_paintable(True)
        self.win.connect("draw", self._clear)
        self.win.connect("key-press-event", self.on_key)
        self.win.connect("button-press-event", lambda *_: self.keyboard(True))

        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        card.get_style_context().add_class("card")
        card.set_size_request(WIDTH, -1)
        self.win.add(card)

        # The tabs: Home | Chat · <helper> | +        ✕
        tabs = Gtk.Box(spacing=4)
        self.tab_btns = {}
        for page, label, tip in (("home", "Home", "Your helpers and what matters now"),
                                 ("chat", "Chat", "The conversation"),
                                 ("add", "+", "Make your own helper")):
            b = Gtk.Button(label=label)
            b.set_tooltip_text(tip)
            b.get_style_context().add_class("tab")
            b.connect("clicked", lambda _b, p=page: self.go(p))
            tabs.pack_start(b, False, False, 0)
            self.tab_btns[page] = b
        x = Gtk.Button(label="✕")
        x.set_tooltip_text("Hide (Esc)")
        x.connect("clicked", lambda *_: self.hide())
        tabs.pack_end(x, False, False, 0)
        card.pack_start(tabs, False, False, 0)

        self.stack = Gtk.Stack()
        self.stack.set_homogeneous(False)
        self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
        card.pack_start(self.stack, True, True, 0)

        # -- Home --
        home = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.pills = Gtk.FlowBox()
        self.pills.set_selection_mode(Gtk.SelectionMode.NONE)
        self.pills.set_max_children_per_line(3)
        self.pills.set_min_children_per_line(2)
        self.pills.set_column_spacing(4)
        self.pills.set_row_spacing(4)
        home.pack_start(self.pills, False, False, 0)
        self.glance_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.glance_box.get_style_context().add_class("glance")
        home.pack_start(self.glance_box, False, False, 0)
        self.stack.add_named(home, "home")

        # -- Chat --
        chat = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        head = Gtk.Box(spacing=6)
        self.who = Gtk.Label(label="", xalign=0)
        self.who.get_style_context().add_class("head")
        self.who.set_ellipsize(Pango.EllipsizeMode.END)
        head.pack_start(self.who, True, True, 0)
        for text, tip, fn in (("Open the chat", "Continue in the chat window", self.open_chat),
                              ("New", "Start a new conversation with this helper", self.new)):
            b = Gtk.Button(label=text)
            b.set_tooltip_text(tip)
            b.connect("clicked", fn)
            head.pack_start(b, False, False, 0)
        chat.pack_start(head, False, False, 0)
        self.scroll = Gtk.ScrolledWindow()
        self.scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.scroll.set_max_content_height(MAX_HEIGHT)
        self.scroll.set_min_content_height(0)     # empty: no gap
        self.viewport = Gtk.Viewport()
        self.viewport.set_shadow_type(Gtk.ShadowType.NONE)
        self.viewport.add(self.shown.list)
        self.scroll.add(self.viewport)
        chat.pack_start(self.scroll, True, True, 0)
        self.stack.add_named(chat, "chat")

        # -- + : make your own --
        add = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        t = Gtk.Label(label="Make your own helper", xalign=0)
        add.pack_start(t, False, False, 0)
        hint = Gtk.Label(label="A name and what it is for. It becomes a note in "
                               "Memory/Helpers that you can change any time.", xalign=0)
        hint.set_line_wrap(True)
        hint.set_max_width_chars(46)
        hint.get_style_context().add_class("dim")
        add.pack_start(hint, False, False, 0)
        self.add_name = Gtk.Entry()
        self.add_name.set_placeholder_text("Name — e.g. Accountant")
        self.add_name.set_max_length(40)
        add.pack_start(self.add_name, False, False, 0)
        self.add_purpose = Gtk.TextView()
        self.add_purpose.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.add_purpose.set_size_request(-1, 80)
        pf = Gtk.Frame()
        pf.add(self.add_purpose)
        add.pack_start(pf, False, False, 0)
        ph = Gtk.Label(label="What it is for and how it should answer — e.g. \u201cHelps me keep "
                             "my shop's accounts; short answers; asks before guessing a number.\u201d",
                       xalign=0)
        ph.set_line_wrap(True)
        ph.set_max_width_chars(46)
        ph.get_style_context().add_class("dim")
        add.pack_start(ph, False, False, 0)
        arow = Gtk.Box(spacing=6)
        self.add_msg = Gtk.Label(label="", xalign=0)
        self.add_msg.set_line_wrap(True)
        self.add_msg.set_max_width_chars(34)
        self.add_msg.get_style_context().add_class("dim")
        arow.pack_start(self.add_msg, True, True, 0)
        mk = Gtk.Button(label="Make it")
        mk.get_style_context().add_class("go")
        mk.connect("clicked", self.make_helper)
        arow.pack_end(mk, False, False, 0)
        add.pack_start(arow, False, False, 0)
        self.stack.add_named(add, "add")

        # Listening (phase 2): a live level meter and the way out.
        self.listen_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.wave = Gtk.DrawingArea()
        self.wave.set_size_request(-1, 34)
        self.wave.connect("draw", self._draw_wave)
        self.listen_label = Gtk.Label(label="", xalign=0)
        self.listen_label.get_style_context().add_class("dim")
        lrow = Gtk.Box(spacing=6)
        lrow.pack_start(self.listen_label, True, True, 0)
        self.stop_btn = Gtk.Button(label="Stop")
        self.stop_btn.get_style_context().add_class("go")
        self.stop_btn.connect("clicked", lambda *_: self.stop_listening("done"))
        cancel = Gtk.Button(label="Cancel")
        cancel.connect("clicked", lambda *_: self.stop_listening("cancelled"))
        lrow.pack_start(self.stop_btn, False, False, 0)
        lrow.pack_start(cancel, False, False, 0)
        self.listen_box.pack_start(self.wave, False, False, 0)
        self.listen_box.pack_start(lrow, False, False, 0)
        self.listen_box.set_no_show_all(True)
        card.pack_start(self.listen_box, False, False, 0)

        # Point and ask (phase 3): the selected area, waiting for a question.
        self.point_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.point_img = Gtk.Image()
        self.point_box.pack_start(self.point_img, False, False, 0)
        self.point_btns = Gtk.Box(spacing=6)
        self.point_box.pack_start(self.point_btns, False, False, 0)
        self.point_box.set_no_show_all(True)
        card.pack_start(self.point_box, False, False, 0)
        self.point_path = None

        row = Gtk.Box(spacing=6)
        self.entry_row = row
        self.entry = Gtk.Entry()
        self.entry.connect("activate", self.on_send)
        row.pack_start(self.entry, True, True, 0)
        mic = Gtk.Button()
        mic.set_image(Gtk.Image.new_from_icon_name("audio-input-microphone-symbolic",
                                                   Gtk.IconSize.BUTTON))
        mic.set_tooltip_text("Talk (Super+Space)")
        mic.connect("clicked", lambda *_: self.listen_toggle())
        row.pack_start(mic, False, False, 0)
        pt = Gtk.Button()
        pt.set_image(Gtk.Image.new_from_icon_name("edit-select-symbolic", Gtk.IconSize.BUTTON))
        pt.set_tooltip_text("Ask about part of the screen (Super+T)")
        pt.connect("clicked", lambda *_: self.start_point())
        row.pack_start(pt, False, False, 0)
        gd = Gtk.Button()
        gd.set_image(Gtk.Image.new_from_icon_name("find-location-symbolic", Gtk.IconSize.BUTTON))
        gd.set_tooltip_text("Show me how — type what you want to do, then press this")
        gd.connect("clicked", lambda *_: self.guide_from_entry())
        row.pack_start(gd, False, False, 0)
        self.guide = None
        self.guide_box = None
        card.pack_start(row, False, False, 0)
        self.recording = None
        self.levels = []
        self._placeholder()
        self.update_who()

    # ---- helpers and pages ------------------------------------------------
    def _conv(self, hid):
        if hid not in self.convs:
            self.convs[hid] = Conv(hid, self._route)
        return self.convs[hid]

    def _route(self, conv, msg):
        """A message from one conversation's socket is handled as that
        conversation, whichever one is on screen."""
        prev, self.conv = self.conv, conv
        try:
            self.on_message(msg)
        finally:
            self.conv = prev
        return False

    def helper(self, hid=None):
        try:
            return _helpers().get(hid or self.hid) or {}
        except Exception:
            return {}

    def helper_name(self, hid=None):
        h = self.helper(hid)
        return h.get("name") or "General"

    def _placeholder(self):
        if self.point_path:
            self.entry.set_placeholder_text("Ask about this…")
        elif self.hid == "general":
            self.entry.set_placeholder_text("Ask anything…  (Esc to hide)")
        else:
            self.entry.set_placeholder_text(f"Ask the {self.helper_name()}…")

    def go(self, page):
        """Show a page. The tabs light up; the window shrinks to fit."""
        self.page = page
        self.stack.set_visible_child_name(page)
        for p, b in self.tab_btns.items():
            ctx = b.get_style_context()
            (ctx.add_class if p == page else ctx.remove_class)("on")
        self.tab_btns["chat"].set_label("Chat · " + self.helper_name())
        if page == "home":
            self.fill_home()
        if page == "add":
            self.entry_row.hide()
            self.add_name.grab_focus()
        else:
            self.entry_row.show_all()
            self.entry.grab_focus()
        if page == "chat":
            self.deliver_alerts()
            GLib.idle_add(self._to_bottom)
        self.win.resize(WIDTH, 1)

    # ---- what the helpers were asked to watch (agent/watchers.py) ----------
    def _unseen(self):
        try:
            import watchers
            return watchers.unseen()
        except Exception:
            return []

    def deliver_alerts(self, hid=None):
        """A watcher's alert becomes a line in its helper's conversation when
        that conversation is opened; then it is read, and when nothing is
        left unread the dot on Brainy goes."""
        hid = hid or self.hid
        mine = [a for a in self._unseen() if a.get("helper") == hid]
        if not mine:
            return
        conv = self._conv(hid)
        for a in mine:
            when = time.strftime("%H:%M", time.localtime(a.get("at", time.time())))
            self._in(conv, lambda a=a, when=when: self._line(f"🔔 {when}  {a['text']}", "it"))
        try:
            import watchers
            watchers.mark_seen(hid)
            if not watchers.unseen():
                import companion
                companion.attention(False)
        except Exception:
            pass

    def select(self, hid, page=None):
        """Change helper: its own conversation comes on screen, and it is
        the one the panel opens with next time."""
        if hid != self.hid:
            if self.recording:
                return
            self.hid = hid
            new = self._conv(hid)
            self.viewport.remove(self.shown.list)
            self.conv = self.shown = new
            self.viewport.add(new.list)
            new.list.show_all()
            self.entry.set_sensitive(not new.busy)
            self._placeholder()
            self.update_who()
            try:
                _helpers().set_last(hid)
            except Exception:
                pass
        self.go(page or self.page)

    def fill_home(self):
        for child in self.pills.get_children():
            self.pills.remove(child)
        try:
            hs = _helpers().all_helpers()
        except Exception:
            hs = {"general": {"id": "general", "name": "General", "color": "#8b949e"}}
        if self.hid not in hs:
            self.hid = "general"
        waiting = {}
        for a in self._unseen():
            waiting[a.get("helper")] = waiting.get(a.get("helper"), 0) + 1
        for hid, h in hs.items():
            b = Gtk.Button()
            box = Gtk.Box(spacing=4)
            pb = self._mini(h.get("color") if hid != "general" else None)
            if pb is not None:
                box.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)
            lab = Gtk.Label(label=h.get("name", hid) + (f" 🔔{waiting[hid]}" if waiting.get(hid) else ""))
            lab.set_ellipsize(Pango.EllipsizeMode.END)
            lab.set_max_width_chars(11)
            box.pack_start(lab, False, False, 0)
            b.add(box)
            ctx = b.get_style_context()
            ctx.add_class("pill")
            if hid == self.hid:
                ctx.add_class("on")
            tip = h.get("name", hid) + (f" — {h['name_fa']}" if h.get("name_fa") else "")
            conv = self.convs.get(hid)
            if conv is not None and conv.busy:
                tip += " (answering…)"
            b.set_tooltip_text(tip + ("\nClick again to talk to it." if hid == self.hid else ""))
            # First click chooses (and shows its card); a click on the
            # chosen one opens its conversation.
            b.connect("clicked", lambda _b, i=hid: self.select(i, "chat" if i == self.hid else "home"))
            self.pills.add(b)
        self.pills.show_all()
        self.show_glance()

    _minis = {}

    def _mini(self, color):
        """The character, small, tinted with the helper's colour."""
        key = (getattr(self.c.character, "id", None), color)
        if key in Bubble._minis:
            return Bubble._minis[key]
        pb = None
        try:
            import companion_art
            if self.c.character is not None:
                pb = companion_art.mini_pixbuf(self.c.character, 26, color)
        except Exception:
            pb = None
        Bubble._minis[key] = pb
        return pb

    def show_glance(self, force=False):
        hid = self.hid
        for child in self.glance_box.get_children():
            self.glance_box.remove(child)
        cached = self.glances.get(hid)
        if cached and not force and time.time() - cached[0] < 120:
            self._draw_glance(hid, cached[1])
            return
        wait = Gtk.Label(label=f"{self.helper_name()}: looking…", xalign=0)
        wait.get_style_context().add_class("dim")
        self.glance_box.pack_start(wait, False, False, 0)
        self.glance_box.show_all()

        def work():
            try:
                g = _helpers().card(hid)
            except Exception as e:
                g = {"title": "", "lines": [[f"Could not load: {e}", "", "dim"]]}
            GLib.idle_add(self._glance_ready, hid, g)
        threading.Thread(target=work, daemon=True).start()

    def _glance_ready(self, hid, g):
        self.glances[hid] = (time.time(), g)
        if hid == self.hid and self.page == "home":
            for child in self.glance_box.get_children():
                self.glance_box.remove(child)
            self._draw_glance(hid, g)
        return False

    def _draw_glance(self, hid, g):
        top = Gtk.Box(spacing=6)
        title = Gtk.Label(label=g.get("title") or self.helper_name(hid), xalign=0)
        title.get_style_context().add_class("head")
        top.pack_start(title, True, True, 0)
        if g.get("lines"):
            r = Gtk.Button(label="↻")
            r.set_tooltip_text("Refresh")
            r.connect("clicked", lambda *_: self.show_glance(force=True))
            top.pack_end(r, False, False, 0)
        self.glance_box.pack_start(top, False, False, 0)
        grid = Gtk.Grid()
        grid.set_column_spacing(10)
        grid.set_row_spacing(2)
        for i, line in enumerate(g.get("lines") or []):
            left, right, tone = (list(line) + ["", "", ""])[:3]
            a = Gtk.Label(label=str(left), xalign=0)
            a.set_ellipsize(Pango.EllipsizeMode.END)
            a.set_max_width_chars(26)
            a.set_hexpand(True)
            bl = Gtk.Label(label=str(right), xalign=1)
            for lab in (a, bl) if tone == "dim" else (bl,):
                if tone:
                    lab.get_style_context().add_class(tone)
            grid.attach(a, 0, i, 1, 1)
            grid.attach(bl, 1, i, 1, 1)
        self.glance_box.pack_start(grid, False, False, 0)
        if not g.get("lines"):
            h = self.helper(hid)
            body = (h.get("body") or "Ask me anything.").split("\n")[0][:160]
            d = Gtk.Label(label=body, xalign=0)
            d.set_line_wrap(True)
            d.set_max_width_chars(46)
            d.get_style_context().add_class("dim")
            self.glance_box.pack_start(d, False, False, 0)
        if g.get("alerts"):
            al = Gtk.Label(label=f"🔔 {g['alerts']} new — open the conversation to read", xalign=0)
            al.get_style_context().add_class("up")
            self.glance_box.pack_start(al, False, False, 0)
        for wtext in g.get("watching") or []:
            wl = Gtk.Label(label="👁 " + wtext, xalign=0)
            wl.set_ellipsize(Pango.EllipsizeMode.END)
            wl.set_max_width_chars(46)
            wl.get_style_context().add_class("dim")
            wl.set_tooltip_text("Watching. Pause or remove it in Settings → Watchers.")
            self.glance_box.pack_start(wl, False, False, 0)
        if g.get("foot"):
            f = Gtk.Label(label=g["foot"], xalign=0)
            f.set_line_wrap(True)
            f.set_max_width_chars(46)
            f.get_style_context().add_class("dim")
            self.glance_box.pack_start(f, False, False, 0)
        talk = Gtk.Button(label=f"Talk to the {self.helper_name(hid)} →" if hid != "general"
                          else "Open the conversation →")
        talk.connect("clicked", lambda *_: self.go("chat"))
        talk.set_halign(Gtk.Align.END)
        self.glance_box.pack_start(talk, False, False, 0)
        self.glance_box.show_all()

    def make_helper(self, *_):
        name = self.add_name.get_text().strip()
        buf = self.add_purpose.get_buffer()
        purpose = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False).strip()
        try:
            r = _helpers().create(name, purpose)
        except Exception as e:
            r = {"ok": False, "message": f"Could not make it ({e})."}
        self.add_msg.set_text(r.get("message", ""))
        self.add_msg.get_style_context().remove_class("err")
        if not r.get("ok"):
            self.add_msg.get_style_context().add_class("err")
            return
        self.add_name.set_text("")
        buf.set_text("")
        Bubble._minis.clear()
        self.select(r["id"], "home")

    # ---- window ---------------------------------------------------------
    def _clear(self, _w, cr):
        import cairo
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        return False

    def reposition(self):
        """Beside the character, on the side that faces the middle of the
        screen, its bottom (or top) edge level with the character's."""
        c = self.c
        for e in (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.BOTTOM,
                  GtkLayerShell.Edge.LEFT, GtkLayerShell.Edge.RIGHT):
            GtkLayerShell.set_anchor(self.win, e, False)
        v, h = c.CORNERS[c.corner]
        GtkLayerShell.set_anchor(self.win, v, True)
        GtkLayerShell.set_anchor(self.win, h, True)
        GtkLayerShell.set_margin(self.win, h, max(0, c.mx + c.w + 6))
        GtkLayerShell.set_margin(self.win, v, max(0, c.my + int(c.h * 0.12)))

    def keyboard(self, on: bool):
        mode = getattr(GtkLayerShell.KeyboardMode, "EXCLUSIVE" if on else "ON_DEMAND", None)
        try:
            if mode is not None:
                GtkLayerShell.set_keyboard_mode(self.win, mode)
            else:
                GtkLayerShell.set_keyboard_interactivity(self.win, True)
        except Exception:
            pass
        return False

    def toggle(self):
        if self.win.get_visible():
            self.hide()
        else:
            self.show()

    def show(self, page=None):
        self.reposition()
        self.update_who()
        self.win.show_all()
        # A conversation under way opens on itself; otherwise Home. An alert
        # waiting for another helper opens Home, where its pill shows it.
        if page is None:
            page = "chat" if (self.page == "chat" or self.shown.list.get_children()) else "home"
            if any(a.get("helper") != self.hid for a in self._unseen()):
                page = "home"
            if self.page == "add":
                page = "add"
        self.go(page)
        self.keyboard(True)
        if page != "add":
            self.entry.grab_focus()

    def hide(self):
        self.keyboard(False)
        self.win.hide()

    def on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            if self.guide and self.guide.active:
                self.guide.stop()
            elif self.recording:
                self.stop_listening("cancelled")
            else:
                self.hide()
            return True
        return False

    # ---- listening (shell/companion_voice.py) ----------------------------
    def listen_toggle(self):
        """Super+Space or the microphone button: start, or stop and send."""
        if self.recording:
            self.stop_listening("done")
            return
        if self.busy:
            return
        import companion_voice as cv
        if not self.win.get_visible():
            self.show()
        ok, why = cv.can_listen()
        if not ok:
            self._line("🎤 " + why, "err")
            return
        self.levels = []
        self.listen_label.set_text("Listening… stops when you pause. Esc cancels.")
        self._show_listen()
        self.c.set_local_state("listening")
        self.recording = cv.Recording(
            on_level=lambda lv: GLib.idle_add(self._on_level, lv),
            on_end=lambda r, pcm, d: GLib.idle_add(self._on_end, r, pcm, d))
        try:
            self.recording.start()
        except Exception as e:
            self.recording = None
            self.listen_box.hide()
            self.c.set_local_state(None)
            self._line(f"🎤 The microphone could not open ({e}).", "err")

    def _show_listen(self):
        # show_all() skips a widget marked no_show_all — which this one is,
        # so the window's own show_all() does not open it uninvited.
        self.listen_box.show()
        for child in self.listen_box.get_children():
            child.show_all()

    # ---- point and ask (shell/companion_point.py) -------------------------
    def start_point(self):
        """Super+T: the bubble steps aside, you drag over what you mean, and
        it comes back with that picture and three ways to ask."""
        import companion_point as cp
        if self.busy or self.recording:
            return
        ok, why = cp.can_point()
        if not ok:
            self.show()
            self._line(why, "err")
            return
        was_open = self.win.get_visible()
        self.win.hide()             # out of the way of the selection
        self.c.set_local_state("reading")

        def work():
            geom, why = cp.select_area()
            path = None
            if geom:
                path, why = cp.capture(geom)
            GLib.idle_add(self._pointed, path, why, was_open)
        threading.Thread(target=work, daemon=True).start()

    def _pointed(self, path, why, was_open):
        self.c.set_local_state(None)
        if not path:
            if why or was_open:
                self.show()
            if why:
                self._line("Could not select: " + why, "err")
            return False
        self.drop_point()
        self.point_path = str(path)
        try:
            from gi.repository import GdkPixbuf
            pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(self.point_path, WIDTH - 40, 200, True)
            self.point_img.set_from_pixbuf(pb)
        except Exception:
            self.point_img.clear()
        import companion_point as cp
        for child in self.point_btns.get_children():
            self.point_btns.remove(child)
        for i, (label, question) in enumerate(cp.presets()):
            b = Gtk.Button(label=label)
            b.connect("clicked", lambda _b, q=question, g=(i == 2): self.ask(q, guide=g))
            self.point_btns.pack_start(b, False, False, 0)
        x = Gtk.Button(label="✕")
        x.set_tooltip_text("Forget this picture")
        x.connect("clicked", lambda *_: self.drop_point())
        self.point_btns.pack_end(x, False, False, 0)
        self.point_box.show()
        for child in self.point_box.get_children():
            child.show_all()
        self.entry.set_placeholder_text("Ask about this…")
        self.show()
        return False

    def drop_point(self, delete=True):
        """The picture leaves the bubble (and the disk)."""
        if self.point_path and delete:
            try:
                os.unlink(self.point_path)
            except OSError:
                pass
        self.point_path = None
        self.point_box.hide()
        self._placeholder()

    def ask(self, question, guide=False):
        if guide:
            # "Guide me" under a selected area: what to do is still needed.
            typed = self.entry.get_text().strip()
            if typed:
                self.drop_point()
                self.entry.set_text("")
                self.start_guide(typed)
            else:
                self._line("Type what you want to do here, then press Guide me again.", "dim")
                self.entry.grab_focus()
            return
        self.entry.set_text(question)
        self.on_send(None)

    # ---- a file dropped on Brainy (shell/companion_drop.py) -----------------
    def file_dropped(self, files):
        import companion_drop as cd
        acts = cd.actions(files)
        if not acts or self.busy or self.recording:
            return
        if acts[0][2] == "point":
            # A picture becomes the selected area of point-and-ask: the same
            # private folder, the same three questions.
            try:
                import companion_point as cp
                from gi.repository import GdkPixbuf
                cp.sweep()
                dest = cp.folder() / f"drop-{int(time.time() * 1000)}.png"
                pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(str(files[0]), 2048, 2048, True)
                pb.savev(str(dest), "png", [], [])
                os.chmod(dest, 0o600)
            except Exception as e:
                self.show("chat")
                self._line(f"Could not open that picture ({e}).", "err")
                return
            self._pointed(str(dest), None, True)
            return
        self.show("chat")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.get_style_context().add_class("it")
        names = ", ".join(f.name for f in files)
        lab = Gtk.Label(label="📄 " + names, xalign=0)
        lab.set_line_wrap(True)
        lab.set_max_width_chars(46)
        box.pack_start(lab, False, False, 0)
        row = Gtk.FlowBox()
        row.set_selection_mode(Gtk.SelectionMode.NONE)
        row.set_max_children_per_line(3)
        for label, text, how in acts:
            b = Gtk.Button(label=label)
            if how == "send":
                b.get_style_context().add_class("go")

            def act(_b, text=text, how=how):
                for child in row.get_children():
                    child.set_sensitive(False)
                self.entry.set_text(text)
                if how == "send":
                    self.on_send(None)
                else:
                    self.entry.grab_focus()
                    self.entry.set_position(-1)
            b.connect("clicked", act)
            row.add(b)
        box.pack_start(row, False, False, 0)
        self.list.pack_start(box, False, False, 0)
        box.show_all()
        GLib.idle_add(self._to_bottom)

    # ---- the guide (shell/companion_guide.py) ------------------------------
    def guide_from_entry(self):
        goal = self.entry.get_text().strip()
        if not goal:
            self._line("Type what you want to do (\u201cchange the wallpaper\u201d), then "
                       "press the pin.", "dim")
            self.entry.grab_focus()
            return
        self.entry.set_text("")
        self.start_guide(goal)

    def start_guide(self, goal):
        import companion_guide
        if self.busy:
            self._line("One thing at a time — I'm still answering.", "dim")
            return
        if self.guide is None:
            self.guide = companion_guide.GuideSession(self.c, self)
        # The guide talks, and its steps are kept, in the conversation it
        # was started from, even if another helper is opened meanwhile.
        self.guide_conv = self.conv
        self.show("chat")
        self._line(goal, "you")
        self.keyboard(False)        # your clicks go to the app, not to me
        self.guide.start(goal)

    def guide_card(self, text, buttons, final=False):
        """The current step, replaced as the guide moves on; the steps that
        are done stay above it as plain lines."""
        gc = self.guide_conv or self.conv
        lst = gc.list
        if self.guide_box is not None:
            old = self.guide_box
            self.guide_box = None
            first = old.get_children()[0] if old.get_children() else None
            prev = first.get_text() if isinstance(first, Gtk.Label) else ""
            lst.remove(old)
            if prev and not prev.endswith("looking…"):
                self._in(gc, lambda: self._line(prev, "dim"))
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.get_style_context().add_class("it")
        lab = Gtk.Label(label=text, xalign=0)
        lab.set_line_wrap(True)
        lab.set_max_width_chars(46)
        rtl = is_rtl(text.split(": ", 1)[-1])
        lab.set_direction(Gtk.TextDirection.RTL if rtl else Gtk.TextDirection.LTR)
        box.pack_start(lab, False, False, 0)
        if buttons:
            row = Gtk.Box(spacing=6)
            for label, fn in buttons:
                b = Gtk.Button(label=label)
                if label in ("Next", "Try again"):
                    b.get_style_context().add_class("go")
                b.connect("clicked", lambda _b, fn=fn: fn())
                row.pack_start(b, False, False, 0)
            box.pack_start(row, False, False, 0)
        lst.pack_start(box, False, False, 0)
        box.show_all()
        self.guide_box = None if final else box
        if not self.win.get_visible():
            self.win.show_all()
        GLib.idle_add(self._to_bottom)

    def _in(self, conv, fn):
        prev, self.conv = self.conv, conv
        try:
            return fn()
        finally:
            self.conv = prev

    def guide_link(self):
        """The socket of the conversation the guide was started from."""
        return (self.guide_conv or self.conv).link

    def stop_listening(self, why="done"):
        if self.recording:
            self.recording.stop(why)

    def _on_level(self, lv):
        self.levels = (self.levels + [lv])[-60:]
        self.c.set_level(lv)
        self.wave.queue_draw()
        return False

    def _draw_wave(self, w, cr):
        width, height = w.get_allocated_width(), w.get_allocated_height()
        n = 60
        bw = width / n
        for i, lv in enumerate(self.levels[-n:]):
            h = max(2, min(1.0, lv * 9) * height)
            cr.rectangle(i * bw + 1, (height - h) / 2, max(1, bw - 2), h)
        cr.set_source_rgba(0.35, 0.85, 0.85, 0.9)
        cr.fill()
        return False

    def _on_end(self, result, pcm, detail):
        self.recording = None
        self.c.set_level(0)
        if result != "done":
            self.listen_box.hide()
            self.c.set_local_state(None)
            if result == "nothing":
                self._line("🎤 I didn't hear anything.", "dim")
            elif result == "error":
                self._line("🎤 The microphone stopped" + (f": {detail}" if detail else "."), "err")
            return False
        self.listen_label.set_text("Writing down what you said…")
        self.stop_btn.set_sensitive(False)
        self.c.set_local_state("working")

        def work():
            # Whatever happens, the bubble hears back: an exception here
            # used to leave it on "Writing down what you said…" for ever.
            try:
                import companion_voice as cv
                text = cv.transcribe(pcm)
            except Exception as e:
                text = f"ERROR: could not turn the recording into words ({e})"
            GLib.idle_add(self._heard, text)
        threading.Thread(target=work, daemon=True).start()
        return False

    def _heard(self, text):
        import companion_voice as cv
        self.listen_box.hide()
        self.stop_btn.set_sensitive(True)
        self.c.set_local_state(None)
        if text.startswith("ERROR:"):
            self._line("🎤 " + text[6:].strip(), "err")
            return False
        text = cv.clean(text)
        if not text:
            self._line("🎤 I didn't catch any words.", "dim")
            return False
        self.spoken = True
        self.entry.set_text(text)
        self.on_send(None)
        return False

    def update_who(self):
        try:
            import cloud
            e = cloud.current()
            where = ("☁ " + cloud.label(e)) if e else "⌂ This computer"
        except Exception:
            where = "⌂ This computer"
        self.who.set_text(f"{self.helper_name()} · {where}")

    # ---- the conversation -----------------------------------------------
    def _line(self, text, cls, wrap=True):
        lab = Gtk.Label(label=text)
        lab.set_line_wrap(wrap)
        lab.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        lab.set_selectable(True)
        lab.set_max_width_chars(46)
        lab.set_xalign(0)
        rtl = is_rtl(text)
        lab.set_direction(Gtk.TextDirection.RTL if rtl else Gtk.TextDirection.LTR)
        lab.get_style_context().add_class(cls)
        # Yours on the right, its on the left, whatever the language. GTK
        # mirrors START and END for a right-to-left widget, so the side is
        # chosen after the direction.
        right = cls == "you"
        lab.set_halign(Gtk.Align.START if right == rtl else Gtk.Align.END)
        self.list.pack_start(lab, False, False, 0)
        lab.show()
        GLib.idle_add(self._to_bottom)
        return lab

    def _to_bottom(self):
        # The window grows with the conversation up to MAX_HEIGHT, then
        # scrolls. GTK3 will not do "natural height, but at most" for a
        # scrolled window on its own, so it is measured here.
        nat = self.shown.list.get_preferred_height()[1]
        self.scroll.set_min_content_height(min(nat, MAX_HEIGHT))
        adj = self.scroll.get_vadjustment()
        adj.set_value(adj.get_upper())
        return False

    def on_send(self, _entry):
        text = self.entry.get_text().strip()
        if not text or self.busy:
            return
        self.entry.set_text("")
        self._line(text, "you")
        self.busy = True
        self.entry.set_sensitive(False)
        self.answer, self.answer_text = None, ""
        if self.page != "chat":
            self.go("chat")
        msg = {"type": "user_message", "text": text}
        if self.hid and self.hid != "general":
            msg["helper"] = self.hid
        if self.point_path:
            # Sent once, with the first question about it; after that the
            # conversation already holds what it showed. The file goes two
            # minutes later (companion_point.KEEP_SECONDS).
            msg["image"] = self.point_path
            self._line("🖼 the area you selected", "dim")
            path = self.point_path
            self.drop_point(delete=False)
            GLib.timeout_add_seconds(120, lambda: (os.path.exists(path) and os.unlink(path)) and False)
        try:
            self.link.send(msg)
        except OSError:
            self._line("The assistant is not running. It starts with the "
                       "desktop; give it a moment, or open the chat.", "err")
            self.done()
            return
        # Let go of the keyboard while it works: the person can carry on.
        self.keyboard(False)

    def done(self):
        self.busy = False
        self.c.set_talking(False)
        if self.conv is not self.shown:
            return               # answered in the background; its pill says so
        self.entry.set_sensitive(True)
        if self.win.get_visible():
            self.entry.grab_focus()

    def _quiet(self):
        self._quiet_id = None
        self.c.set_talking(False)
        return False

    def on_message(self, msg):
        t = msg.get("type")
        if t == "guide_reply":
            if self.guide:
                self.guide.on_reply(msg)
            return False
        if t == "delta":
            if self.answer is None:
                self.answer = self._line("", "it")
            self.answer_text += msg.get("text", "")
            self.answer.set_text(self.answer_text)
            rtl = is_rtl(self.answer_text)
            self.answer.set_direction(Gtk.TextDirection.RTL if rtl else Gtk.TextDirection.LTR)
            self.answer.set_halign(Gtk.Align.END if rtl else Gtk.Align.START)
            self.c.set_talking(True)
            if self._quiet_id:
                GLib.source_remove(self._quiet_id)
            self._quiet_id = GLib.timeout_add(450, self._quiet)
            GLib.idle_add(self._to_bottom)
        elif t == "tool_use":
            self.answer = None
            self.answer_text = ""
            self._line(f"⚙ {msg.get('name', '')}: {msg.get('detail', '')}"[:160], "dim")
        elif t == "remembered":
            self._line("Remembered: " + str(msg.get("fact", "")), "dim")
        elif t == "forgotten":
            self._line("Forgot from " + str(msg.get("note", "your notes")), "dim")
        elif t == "image":
            self._line("🖼 " + str(msg.get("path", "")), "dim")
        elif t == "status":
            self._line(str(msg.get("text", "")), "dim")
        elif t == "confirm":
            self.ask_confirm(msg)
        elif t == "assistant":
            text = msg.get("text") or ""
            if self.answer is None:
                self.answer = self._line(text, "it")
            else:
                self.answer.set_text(text)
            if self.spoken:
                self.spoken = False
                self.say(text)
            elif not self.win.get_visible() or self.conv is not self.shown:
                # Ready while you were looking elsewhere (step 5B; off unless
                # sounds are switched on).
                try:
                    self.c.sound("answer")
                except Exception:
                    pass
            if (msg.get("label") or msg.get("backend")) and self.conv is self.shown:
                where = ("☁ " + msg["label"]) if msg.get("backend") == "cloud" else "⌂ This computer"
                self.who.set_text(f"{self.helper_name()} · {where}")
            self.done()
        elif t == "error":
            self._line("⚠ " + str(msg.get("text", "")), "err")
            if msg.get("action") == "use_local":
                b = Gtk.Button(label="Use the local model")
                b.connect("clicked", self.use_local)
                self.list.pack_start(b, False, False, 0)
                b.show()
            self.done()
        elif t == "_closed":
            if self.busy:
                self._line("The assistant stopped. Try again in a moment.", "err")
                self.done()
            self.link.close()
        return False

    def say(self, text):
        """An answer to a spoken question is read aloud, if this computer
        can speak (piper) and Settings has not turned it off."""
        import companion_voice as cv
        try:
            import paths as _p
            if _p.read_desktop_env().get("OSPRIME_COMPANION_SPEAK", "yes").strip('"') == "no":
                return
        except Exception:
            pass
        if not cv.can_speak():
            return
        cv.speak(text,
                 on_start=lambda: GLib.idle_add(self.c.set_local_state, "speaking"),
                 on_end=lambda: GLib.idle_add(self.c.set_local_state, None))

    def ask_confirm(self, msg):
        """A risky step, asked here, the same way the chat asks."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.get_style_context().add_class("it")
        q = Gtk.Label(label="🔒 " + str(msg.get("text", "")), xalign=0)
        q.set_line_wrap(True)
        q.set_max_width_chars(46)
        box.pack_start(q, False, False, 0)
        if msg.get("detail"):
            d = Gtk.Label(label=str(msg["detail"])[:600], xalign=0)
            d.set_line_wrap(True)
            d.set_max_width_chars(46)
            d.get_style_context().add_class("dim")
            box.pack_start(d, False, False, 0)
        row = Gtk.Box(spacing=6)
        for text, ok, cls in (("Allow", True, "go"), ("Don't", False, "no")):
            b = Gtk.Button(label=text)
            b.get_style_context().add_class(cls)

            def answer(_b, ok=ok):
                for child in row.get_children():
                    child.set_sensitive(False)
                try:
                    self.link.send({"type": "confirm_response", "id": msg.get("id"),
                                    "approved": ok})
                except OSError:
                    pass
            b.connect("clicked", answer)
            row.pack_start(b, False, False, 0)
        box.pack_start(row, False, False, 0)
        self.list.pack_start(box, False, False, 0)
        box.show_all()
        self.keyboard(True)          # an answer is needed: take the focus back
        GLib.idle_add(self._to_bottom)

    def use_local(self, button):
        button.set_sensitive(False)

        def go():
            try:
                import cloud
                import engines
                cloud.set_on(False)
                engines.start_main(wait=False)
            except Exception:
                pass
        threading.Thread(target=go, daemon=True).start()
        self._line("Cloud model off. The local model is starting — about 10 to 30 seconds.", "dim")
        self.update_who()

    def new(self, *_):
        """A fresh start for this helper only; the others keep theirs."""
        if self.guide and self.guide_conv is self.conv:
            self.guide.stop(quiet=True)
            self.guide_box = None
        self.link.close()
        self.drop_point()
        try:
            import companion_point as cp
            cp.sweep(0)
        except Exception:
            pass
        for child in self.list.get_children():
            self.list.remove(child)
        self.answer, self.answer_text = None, ""
        self.done()

    def open_chat(self, *_):
        self.hide()
        self.c.toggle_chat()
