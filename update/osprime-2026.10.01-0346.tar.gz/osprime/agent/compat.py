"""Is this computer ready for OSprime? docs/INSTALL.md.

Run from the live USB, before anything is installed: the "Check this
computer" window (shell/osprime-compat.py) and the Install launcher both ask
this. Read-only — it looks at the hardware and changes nothing.

    python3 compat.py           JSON
    python3 compat.py --text    the same, for a terminal

The verdict (thresholds agreed 28 September):
  green   graphics with >= 7.5 GB, memory >= 8 GB, a disk >= 64 GB
          -> the full assistant: Qwen3.5 9B, which also sees
  yellow  memory >= 8 GB (or >= 4 GB) but weaker or no graphics
          -> it works, with a smaller assistant that answers more slowly
  red     memory < 4 GB, no disk of 32 GB, or not a 64-bit PC
          -> not recommended

`assess(facts)` is pure, so every kind of machine can be tested without
owning it; `gather()` reads this one.
"""
import glob
import json
import os
import pathlib
import platform
import re
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

GREEN_VRAM, GREEN_RAM, GREEN_DISK = 7.5, 8, 64
RED_RAM, RED_DISK = 4, 32
# Memory is reported after the firmware and graphics take their share: an
# "8 GB" laptop says 7.6, a "4 GB" one 3.8. The thresholds are the sizes on
# the box, so they are compared with this much slack.
RAM_SLACK = 0.7
EFI_GUID = "8be4df61-93ca-11d2-aa0d-00e098032b8c"

# NVIDIA cards on the live USB have no driver, so nothing reports their
# memory. The usual amount by model — (pattern, desktop GB, laptop GB) —
# is said as "usually", never as measured.
_NVIDIA_VRAM = [
    (r"RTX\s*5090", 32, 24), (r"RTX\s*5080", 16, 16), (r"RTX\s*5070\s*Ti", 16, 12),
    (r"RTX\s*5070", 12, 8), (r"RTX\s*5060", 8, 8), (r"RTX\s*5050", 8, 8),
    (r"RTX\s*4090", 24, 16), (r"RTX\s*4080", 16, 12), (r"RTX\s*4070\s*Ti", 12, 12),
    (r"RTX\s*4070", 12, 8), (r"RTX\s*4060\s*Ti", 8, 8), (r"RTX\s*4060", 8, 8),
    (r"RTX\s*4050", 6, 6), (r"RTX\s*3090", 24, 24), (r"RTX\s*3080\s*Ti", 12, 16),
    (r"RTX\s*3080", 10, 8), (r"RTX\s*3070", 8, 8), (r"RTX\s*3060\s*Ti", 8, 8),
    (r"RTX\s*3060", 12, 6), (r"RTX\s*3050", 8, 4), (r"RTX\s*2080", 8, 8),
    (r"RTX\s*2070", 8, 8), (r"RTX\s*2060", 6, 6), (r"GTX\s*1660", 6, 6),
    (r"GTX\s*1650", 4, 4), (r"GTX\s*1080", 8, 8), (r"GTX\s*1070", 8, 8),
    (r"GTX\s*1060", 6, 6),
]
_LAPTOP = re.compile(r"laptop|mobile|max-q|\b\w+\d{3}M\b", re.I)


def nvidia_usual_vram(name: str):
    for pat, desk, lap in _NVIDIA_VRAM:
        if re.search(pat, name or "", re.I):
            return lap if _LAPTOP.search(name) else desk
    return None


# ---------------------------------------------------------------------------
def _efivar(name: str) -> str:
    try:
        with open(f"/sys/firmware/efi/efivars/{name}-{EFI_GUID}", "rb") as f:
            return "1" if f.read()[4:5] == b"\x01" else "0"
    except OSError:
        return ""


def _disks() -> list:
    try:
        out = subprocess.run(["lsblk", "-J", "-b", "-d", "-o", "NAME,SIZE,TYPE,RM,MOUNTPOINTS"],
                             capture_output=True, text=True, timeout=10).stdout
        data = json.loads(out).get("blockdevices", [])
    except Exception:
        return []
    disks = []
    for d in data:
        if d.get("type") != "disk" or d["name"].startswith(("loop", "sr", "ram", "zram")):
            continue
        disks.append({"name": d["name"], # decimal GB, the unit on the box: a "64 GB" disk is
                      # 59.6 GiB and must not fall under the 64 line
                      "size_gb": round(int(d.get("size") or 0) / 1e9, 1),
                      "removable": bool(int(d.get("rm") or 0))})
    return disks


def gather() -> dict:
    import hardware
    try:
        cpuinfo = pathlib.Path("/proc/cpuinfo").read_text()
    except OSError:
        cpuinfo = ""
    m = re.search(r"model name\s*:\s*(.+)", cpuinfo)
    return {
        "arch": platform.machine(),
        "cpu": m.group(1).strip() if m else "unknown",
        "cores": os.cpu_count() or 1,
        "avx2": " avx2" in cpuinfo,
        "ram_gb": hardware._ram_gb(),
        "gpu": hardware._gpu(),
        "disks": _disks(),
        "uefi": os.path.isdir("/sys/firmware/efi"),
        "tpm": os.path.exists("/dev/tpmrm0") or bool(glob.glob("/sys/class/tpm/tpm*")),
        "secure_boot": _efivar("SecureBoot") == "1",
        "setup_mode": _efivar("SetupMode") == "1",
        "wifi": any(os.path.isdir(p + "/wireless") for p in glob.glob("/sys/class/net/*")),
        "camera": bool(glob.glob("/dev/video*")),
        "mic": bool(glob.glob("/proc/asound/card*/pcm*c")),
    }


# ---------------------------------------------------------------------------
def assess(f: dict) -> dict:
    items, bad, warn = [], [], []

    def item(key, status, title, text):
        items.append({"key": key, "status": status, "title": title, "text": text})
        (bad if status == "bad" else warn if status == "warn" else []).append(key)

    # processor
    if f.get("arch") not in ("x86_64", "amd64"):
        item("cpu", "bad", "Processor", f"{f.get('arch')} — OSprime needs a 64-bit PC processor.")
    elif not f.get("avx2"):
        item("cpu", "warn", "Processor", f"{f.get('cpu')} ({f.get('cores')} cores) — an older "
             "processor without AVX2: the assistant will be noticeably slower.")
    else:
        item("cpu", "ok", "Processor", f"{f.get('cpu')} ({f.get('cores')} cores)")

    # memory
    ram = float(f.get("ram_gb") or 0)
    if ram < RED_RAM - RAM_SLACK:
        item("ram", "bad", "Memory", f"{ram:g} GB — at least {RED_RAM} GB is needed; "
             f"{GREEN_RAM} GB or more is recommended.")
    elif ram < GREEN_RAM - RAM_SLACK:
        item("ram", "warn", "Memory", f"{ram:g} GB — enough for a small assistant; "
             f"{GREEN_RAM} GB or more is recommended.")
    else:
        item("ram", "ok", "Memory", f"{ram:g} GB")

    # graphics
    gpu = f.get("gpu") or {}
    vram, estimated = float(gpu.get("vram_gb") or 0), False
    if gpu.get("driver_missing") and not vram and "nvidia" in (gpu.get("vendor", "") + gpu.get("kind", "")).lower():
        usual = nvidia_usual_vram(gpu.get("kind", ""))
        if usual:
            vram, estimated = float(usual), True
    if not gpu.get("present"):
        item("gpu", "warn", "Graphics", "No graphics card for the assistant — it runs on the "
             "processor, with a smaller model that answers more slowly.")
    elif vram >= GREEN_VRAM:
        how = (f"usually {vram:g} GB for this card — measured after installing" if estimated
               else f"{vram:g} GB")
        item("gpu", "ok", "Graphics", f"{gpu.get('kind')} ({how})")
    elif vram:
        how = f"usually {vram:g} GB" if estimated else f"{vram:g} GB"
        item("gpu", "warn", "Graphics", f"{gpu.get('kind')} ({how}) — less than "
             f"{GREEN_VRAM:g} GB, so a smaller assistant; it will not see pictures by itself.")
    else:
        item("gpu", "warn", "Graphics", f"{gpu.get('kind')} — its memory cannot be read before "
             "installing, or it shares the computer's memory: a smaller assistant.")

    # disk
    disks = [d for d in (f.get("disks") or []) if not d.get("removable")] or (f.get("disks") or [])
    biggest = max((d["size_gb"] for d in disks), default=0)
    if not disks:
        item("disk", "bad", "Disk", "No disk found to install on.")
    elif biggest < RED_DISK:
        item("disk", "bad", "Disk", f"The largest disk is {biggest:g} GB — at least {RED_DISK} GB "
             f"is needed, {GREEN_DISK} GB or more recommended.")
    elif biggest < GREEN_DISK:
        item("disk", "warn", "Disk", f"{biggest:g} GB — it fits, with little room for your own "
             f"files; {GREEN_DISK} GB or more is recommended.")
    else:
        item("disk", "ok", "Disk", f"{biggest:g} GB")

    # firmware and security
    if not f.get("uefi"):
        item("firmware", "warn", "Start-up", "The computer starts in BIOS (legacy) mode: OSprime "
             "installs, but without disk encryption or Secure Boot. Switching the firmware to UEFI "
             "before installing gives you both.")
    else:
        item("firmware", "ok", "Start-up", "UEFI")
    if f.get("uefi"):
        if f.get("tpm"):
            item("tpm", "ok", "Security chip (TPM 2.0)", "Present — the encrypted disk opens by "
                 "itself at start-up; only your login password is asked.")
        else:
            item("tpm", "warn", "Security chip (TPM 2.0)", "Not found — the disk can still be "
                 "encrypted, but it asks for a disk password at every start.")
        if f.get("setup_mode"):
            sb = "Ready: OSprime puts its own keys in during installation."
        elif f.get("secure_boot"):
            sb = "On, with the manufacturer's keys — after installing, OSprime switches it " \
                 "to this computer's own keys (Settings → System → Secure Boot)."
        else:
            sb = "Off — OSprime turns it on with this computer's own keys after installing " \
                 "(Settings → System → Secure Boot)."
        item("secureboot", "ok", "Secure Boot", sb)

    # the rest: good to know, never a reason to stop
    extras = [("wifi", "Wi-Fi", f.get("wifi")), ("camera", "Camera", f.get("camera")),
              ("mic", "Microphone", f.get("mic"))]
    for key, title, present in extras:
        item(key, "ok" if present else "warn", title,
             "Found" if present else "Not found — the features that need it will not work.")

    # the verdict and what the assistant will be
    if bad:
        verdict = "red"
        headline = "Not recommended on this computer"
    elif ram >= GREEN_RAM - RAM_SLACK and vram >= GREEN_VRAM and biggest >= GREEN_DISK:
        verdict = "green"
        headline = "Ready — the full OSprime experience"
    else:
        verdict = "yellow"
        headline = "Works, with a smaller assistant"
    try:
        import hardware
        # the size on the box, as recommend() thinks in those too
        prof = {"cpu": f.get("cpu", ""), "cores": f.get("cores", 1),
                "ram_gb": round(ram + RAM_SLACK),
                "disk_free_mb": 0, "gpu": dict(gpu, vram_gb=vram,
                                               useful=bool(gpu.get("useful") or estimated))}
        spec = hardware.recommend(prof)
        assistant = spec.get("label") or spec.get("tier", "")
    except Exception:
        assistant = ""
    return {"verdict": verdict, "headline": headline, "assistant": assistant,
            "estimated_vram": estimated, "items": items}


def as_text(r: dict) -> str:
    mark = {"ok": "✓", "warn": "!", "bad": "✗"}
    lines = [f"{ {'green': '🟢', 'yellow': '🟡', 'red': '🔴'}[r['verdict']] } {r['headline']}"]
    if r.get("assistant"):
        lines.append(f"  The assistant on this computer: {r['assistant']}")
    lines.append("")
    for it in r["items"]:
        lines.append(f"  {mark[it['status']]} {it['title']}: {it['text']}")
    return "\n".join(lines)


if __name__ == "__main__":
    result = assess(gather())
    print(as_text(result) if "--text" in sys.argv else json.dumps(result, indent=2))
