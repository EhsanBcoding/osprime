"""Who is on the other end of a loopback connection. docs/SECURITY.md, #11.

Loopback says "this computer", not "this person". With accounts
(docs/ACCOUNTS.md) several people share the computer, and every one of
their programs can reach 127.0.0.1 — so "the request came from localhost"
let one person's program drive another person's assistant (review, 27
September: an /api/chat request with no credentials at all passed).

The kernel knows which account owns every TCP socket, and says so in
/proc/net/tcp: the connecting socket's line has its own address as local,
ours as remote, and the uid of the account that opened it. The web server
answers only when that uid is its own. Nothing to type, nothing to steal:
it is the same fact that makes a person's files theirs.

The same table answers the reverse question for the scripts that open the
chat: is the thing listening on that port really mine? (`python3
peercred.py url`), so no other account can put up a look-alike page on the
port first.
"""
import ipaddress
import os
import pathlib
import sys

PROC = pathlib.Path(os.environ.get("OSPRIME_PROC_NET", "/proc/net"))
LISTEN = "0A"


def _hex_addr(ip: str, port: int, v6: bool) -> str:
    """How /proc/net/tcp writes an address: the IP as the kernel's
    native-endian 32-bit words in hex, then the port in big-endian hex."""
    addr = ipaddress.ip_address(ip)
    if v6:
        if addr.version == 4:
            addr = ipaddress.IPv6Address("::ffff:" + ip)
        raw = addr.packed
        words = [raw[i:i + 4][::-1].hex().upper() for i in range(0, 16, 4)]
        return "".join(words) + f":{port:04X}"
    return addr.packed[::-1].hex().upper() + f":{port:04X}"


def _rows(name: str):
    try:
        lines = (PROC / name).read_text().splitlines()[1:]
    except OSError:
        return
    for line in lines:
        f = line.split()
        if len(f) >= 8:
            yield f[1], f[2], f[3], f[7]      # local, remote, state, uid


def peer_uid(client_ip: str, client_port: int, server_port: int):
    """The uid that owns the client end of this connection, or None."""
    for name, v6 in (("tcp", False), ("tcp6", True)):
        try:
            local = _hex_addr(client_ip, client_port, v6)
        except ValueError:
            continue
        for loc, _rem, state, uid in _rows(name):
            # the client end: its local address is the client's, and it is
            # connected (not listening). The remote port must be ours.
            if loc == local and state != LISTEN and _rem.endswith(f":{server_port:04X}"):
                try:
                    return int(uid)
                except ValueError:
                    return None
    return None


def listener_uid(port: int, ip: str = "127.0.0.1"):
    """The uid that owns the socket listening on ip:port, or None."""
    for name, v6 in (("tcp", False), ("tcp6", True)):
        try:
            want = _hex_addr(ip, port, v6)
        except ValueError:
            continue
        for loc, _rem, state, uid in _rows(name):
            if loc == want and state == LISTEN:
                return int(uid)
    return None


def url_file() -> pathlib.Path:
    runtime = os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.geteuid()}"
    return pathlib.Path(runtime) / "osprime" / "web.url"


def my_url() -> str:
    """The address of MY web interface, checked: '' if it is not running,
    or if what listens there belongs to someone else."""
    port = 0
    try:
        text = url_file().read_text().strip()
        port = int(text.rsplit(":", 1)[1])
    except Exception:
        port = int(os.environ.get("OSPRIME_WEB_PORT", "8080"))
    if listener_uid(port) != os.geteuid():
        return ""
    return f"http://127.0.0.1:{port}"


def selftest() -> list:
    bad = []
    if _hex_addr("127.0.0.1", 8080, False) != "0100007F:1F90":
        bad.append(f"peercred: IPv4 encoding {_hex_addr('127.0.0.1', 8080, False)}")
    if not _hex_addr("127.0.0.1", 8080, True).endswith("0100007F:1F90"):
        bad.append("peercred: IPv4-mapped IPv6 encoding")
    return bad


if __name__ == "__main__":
    if sys.argv[1:] == ["url"]:
        u = my_url()
        if not u:
            print("the assistant's web interface is not running for this account",
                  file=sys.stderr)
            sys.exit(1)
        print(u)
    else:
        print("usage: peercred.py url", file=sys.stderr)
        sys.exit(2)
