#!/usr/bin/env bash
# Try an OSprime ISO in a virtual machine: UEFI, an emulated TPM 2.0, KVM.
# docs/ENCRYPTION.md — the one test that proves an encrypted install boots.
#
#   bash osprime-vm-test.sh install /path/to/osprime.iso   boot the ISO, install to the VM disk
#   bash osprime-vm-test.sh install --secure-boot ISO       the same, on firmware that can do
#                                                           Secure Boot (plan C); it starts in
#                                                           Setup Mode, like a laptop whose
#                                                           keys were cleared
#   bash osprime-vm-test.sh boot                            start the installed VM
#   bash osprime-vm-test.sh reset                           delete the VM and start over
#
# Needs (once, with sudo — names checked with pacman -Ssq first):
#   qemu-desktop edk2-ovmf swtpm
#
# Plain QEMU on purpose, not a VM manager: nothing to configure, no system
# service, the same flags every time — so a result can be repeated exactly.
# Everything lives in ~/osprime-vm; nothing outside it is touched.
set -u
VM="${OSPRIME_VM_DIR:-$HOME/osprime-vm}"
DISK="$VM/disk.qcow2"
MEM="${OSPRIME_VM_MEM:-6G}"
CPUS="${OSPRIME_VM_CPUS:-4}"

die() { echo "$*"; exit 1; }
need() { command -v "$1" >/dev/null || die "$1 is missing: sudo pacman -S --needed qemu-desktop edk2-ovmf swtpm"; }

SB_FLAG="$VM/secure-boot"

firmware() {
    # Arch moved these once already; look rather than assume. The Secure
    # Boot build is a different file (and needs SMM, below); its empty
    # variable store is the same one — which is exactly Setup Mode.
    local codes="OVMF_CODE.4m.fd OVMF_CODE.fd"
    [ -f "$SB_FLAG" ] && codes="OVMF_CODE.secboot.4m.fd OVMF_CODE.secboot.fd"
    for d in /usr/share/edk2/x64 /usr/share/edk2-ovmf/x64 /usr/share/ovmf/x64 /usr/share/OVMF; do
        for c in $codes; do
            v="${c/CODE.secboot/VARS}"; v="${v/CODE/VARS}"
            [ -f "$d/$c" ] && [ -f "$d/$v" ] && { echo "$d/$c $d/$v"; return 0; }
        done
    done
    return 1
}

start_tpm() {
    mkdir -p "$VM/tpm"
    rm -f "$VM/tpm.sock"
    swtpm socket --tpm2 --tpmstate dir="$VM/tpm" \
        --ctrl type=unixio,path="$VM/tpm.sock" --daemon \
        --log file="$VM/tpm.log" || die "swtpm did not start (see $VM/tpm.log)"
    for _ in 1 2 3 4 5; do [ -S "$VM/tpm.sock" ] && return 0; sleep 0.5; done
    die "the TPM socket did not appear"
}

run_qemu() {   # run_qemu [extra args…]
    fw="$(firmware)" || die "UEFI firmware (edk2-ovmf) not found"
    read -r CODE VARS_SRC <<<"$fw"
    # The VM's own copy of the UEFI variables: where the boot entry the
    # installer writes is kept between runs.
    [ -f "$VM/vars.fd" ] || cp "$VARS_SRC" "$VM/vars.fd"
    start_tpm
    [ -r /dev/kvm ] || echo "note: no /dev/kvm access — this will be very slow"
    local machine="q35,accel=kvm:tcg" sb=()
    if [ -f "$SB_FLAG" ]; then
        machine="q35,accel=kvm:tcg,smm=on"
        sb=(-global driver=cfi.pflash01,property=secure,value=on)
    fi
    qemu-system-x86_64 \
        -name OSprime-test -machine "$machine" "${sb[@]}" -cpu host -smp "$CPUS" -m "$MEM" \
        -drive if=pflash,format=raw,readonly=on,file="$CODE" \
        -drive if=pflash,format=raw,file="$VM/vars.fd" \
        -chardev socket,id=chrtpm,path="$VM/tpm.sock" \
        -tpmdev emulator,id=tpm0,chardev=chrtpm -device tpm-crb,tpmdev=tpm0 \
        -drive file="$DISK",if=virtio,format=qcow2 \
        -nic user,model=virtio-net-pci \
        -device virtio-vga -display gtk \
        "$@"
    # QEMU closes the TPM when it exits; swtpm goes with it.
}

case "${1:-}" in
    install)
        ISO="${2:-}"
        if [ "$ISO" = --secure-boot ]; then
            ISO="${3:-}"
            [ -f "$DISK" ] && [ ! -f "$SB_FLAG" ] && die "This VM was made without Secure Boot firmware: $0 reset first"
            mkdir -p "$VM" && touch "$SB_FLAG"
        fi
        [ -n "$ISO" ] || die "Usage: $0 install [--secure-boot] /path/to/osprime.iso"
        [ -f "$ISO" ] || die "No ISO at: $ISO  (from your home folder the path usually starts ~/Documents/…)"
        need qemu-system-x86_64; need swtpm
        mkdir -p "$VM"
        [ -f "$DISK" ] || qemu-img create -f qcow2 "$DISK" 40G >/dev/null
        echo "Booting $ISO. In the VM, install to /dev/vda; then close the window"
        echo "and run:  bash $0 boot"
        run_qemu -cdrom "$ISO" -boot order=d ;;
    boot)
        [ -f "$DISK" ] || die "No VM yet: $0 install /path/to/osprime.iso"
        need qemu-system-x86_64; need swtpm
        run_qemu -boot order=c ;;
    reset)
        [ -d "$VM" ] || { echo "Nothing to reset."; exit 0; }
        read -r -p "Delete $VM (the VM disk, its TPM and firmware state)? [y/N] " a
        [ "$a" = y ] && rm -rf "$VM" && echo "Deleted." ;;
    *)
        sed -n '2,15p' "$0"; exit 2 ;;
esac
