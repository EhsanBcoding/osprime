#!/usr/bin/env python3
"""The "Check this computer" window on the live USB. docs/INSTALL.md.

Shows agent/compat.py's answer — one headline, then each part — and offers
to install. Checking can take a few seconds (the graphics probe), so the
window opens at once and fills in when the answer is ready.
"""
import pathlib
import subprocess
import sys
import threading

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "agent"))
LAUNCH = str(HERE / "osprime-install-launch.sh")

import gi  # noqa: E402
gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk  # noqa: E402

COLOUR = {"green": "#2e9d57", "yellow": "#c99a06", "red": "#c83c3c"}
MARK = {"ok": ("✓", "#2e9d57"), "warn": ("!", "#c99a06"), "bad": ("✗", "#c83c3c")}


class Window(Gtk.Window):
    def __init__(self, install_button=True):
        super().__init__(title="Is this computer ready for OSprime?")
        self.set_default_size(640, 560)
        self.set_position(Gtk.WindowPosition.CENTER)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin=18)
        self.add(outer)
        self.head = Gtk.Label(xalign=0)
        self.head.set_markup("<span size='x-large' weight='bold'>Checking this computer…</span>")
        outer.pack_start(self.head, False, False, 0)
        self.sub = Gtk.Label(xalign=0, wrap=True)
        outer.pack_start(self.sub, False, False, 0)
        scroll = Gtk.ScrolledWindow(vexpand=True)
        self.list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        scroll.add(self.list)
        outer.pack_start(scroll, True, True, 0)
        buttons = Gtk.Box(spacing=8, halign=Gtk.Align.END)
        close = Gtk.Button(label="Close")
        close.connect("clicked", lambda *_: self.destroy())
        buttons.pack_start(close, False, False, 0)
        self.install = Gtk.Button(label="Install OSprime", sensitive=False)
        self.install.connect("clicked", self.on_install)
        if install_button:
            buttons.pack_start(self.install, False, False, 0)
        outer.pack_start(buttons, False, False, 0)
        self.result = None
        threading.Thread(target=self.check, daemon=True).start()

    def check(self):
        import compat
        try:
            r = compat.assess(compat.gather())
        except Exception as e:
            r = {"verdict": "yellow", "headline": "Could not check everything",
                 "assistant": "", "items": [{"status": "warn", "title": "Check",
                                              "text": str(e)}]}
        GLib.idle_add(self.show_result, r)

    def show_result(self, r):
        self.result = r
        self.head.set_markup(f"<span size='x-large' weight='bold' foreground='{COLOUR[r['verdict']]}'>"
                             f"{GLib.markup_escape_text(r['headline'])}</span>")
        if r.get("assistant"):
            self.sub.set_text(f"The assistant on this computer: {r['assistant']}")
        for it in r["items"]:
            mark, colour = MARK.get(it["status"], MARK["warn"])
            row = Gtk.Box(spacing=10)
            m = Gtk.Label(yalign=0)
            m.set_markup(f"<span size='large' weight='bold' foreground='{colour}'>{mark}</span>")
            row.pack_start(m, False, False, 0)
            t = Gtk.Label(xalign=0, yalign=0, wrap=True, selectable=True)
            t.set_markup(f"<b>{GLib.markup_escape_text(it['title'])}</b>\n"
                         f"{GLib.markup_escape_text(it['text'])}")
            t.set_max_width_chars(70)
            row.pack_start(t, True, True, 0)
            self.list.pack_start(row, False, False, 0)
        self.list.show_all()
        self.install.set_sensitive(True)
        return False

    def on_install(self, *_):
        if self.result and self.result["verdict"] == "red":
            d = Gtk.MessageDialog(transient_for=self, message_type=Gtk.MessageType.WARNING,
                                  buttons=Gtk.ButtonsType.NONE,
                                  text="OSprime is not recommended on this computer")
            d.format_secondary_text("It may be too slow to use, or not fit. Install anyway?")
            d.add_button("Cancel", Gtk.ResponseType.CANCEL)
            d.add_button("Install anyway", Gtk.ResponseType.OK)
            ok = d.run() == Gtk.ResponseType.OK
            d.destroy()
            if not ok:
                return
        subprocess.Popen(["bash", LAUNCH, "--checked"], start_new_session=True)
        self.destroy()


if __name__ == "__main__":
    w = Window(install_button="--no-install" not in sys.argv)
    w.connect("destroy", Gtk.main_quit)
    w.show_all()
    Gtk.main()
