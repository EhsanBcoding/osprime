# Sourced, not run: where THIS account's OSprime lives. docs/SECURITY.md, #11.
#
#   osprime_web_url    the address of my own web interface, checked — the
#                      process listening there must be mine (peercred.py);
#                      prints nothing if it is not running or not mine
#   OSPRIME_PRIV       a folder only I can read: browser profiles, locks and
#                      logs that used to sit in /tmp, shared by every account
#                      (the chat's Chromium profile was one profile for
#                      everybody on the computer)
_OSP_HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
osprime_web_url() {
    [ -n "${OSPRIME_URL:-}" ] && { echo "$OSPRIME_URL"; return 0; }
    python3 "$_OSP_HERE/../ui/peercred.py" url 2>/dev/null
}
if [ -n "${XDG_RUNTIME_DIR:-}" ] && [ -d "$XDG_RUNTIME_DIR" ] && [ -O "$XDG_RUNTIME_DIR" ]; then
    OSPRIME_PRIV="$XDG_RUNTIME_DIR/osprime"
else
    OSPRIME_PRIV="$HOME/.cache/osprime/run"
fi
mkdir -p "$OSPRIME_PRIV" 2>/dev/null && chmod 700 "$OSPRIME_PRIV" 2>/dev/null
