#!/usr/bin/env python3
"""OSprime first-boot onboarding: runs once, interviews the user,
writes the profile the agent uses to personalize itself."""

import json
import os
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "ui"))
import i18n

PROFILE_PATH = pathlib.Path(os.environ.get("OSPRIME_PROFILE", "/etc/osprime/profile.json"))

QUESTIONS = [
    ("name",     "ob_name"),
    ("language", "ob_lang"),
    ("skill",    "ob_skill"),
    ("usage",    "ob_usage"),
    ("autonomy", "ob_autonomy"),
]

DEFAULTS = {"language": "en", "autonomy": "yes"}



def fix_text(s: str) -> str:
    """Recover Persian text mangled by a non-UTF-8 locale (surrogate escapes)."""
    try:
        return s.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    except Exception:
        return s.encode("utf-8", "replace").decode("utf-8")

def main():
    if PROFILE_PATH.exists():
        print(i18n.t("ob_done"))
        return
    os.system("clear")
    print(i18n.t("ob_hello"))
    print(i18n.t("ob_intro") + "\n")
    profile = {}
    for key, qkey in QUESTIONS:
        ans = fix_text(input("  " + i18n.t(qkey)).strip())
        profile[key] = ans or DEFAULTS.get(key, "")
    PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
    PROFILE_PATH.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n" + i18n.t("ob_thanks").format(name=profile["name"]))


if __name__ == "__main__":
    main()
