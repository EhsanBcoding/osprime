"""OSprime UI strings.

English is the factory default. OSprime ships in English everywhere and the
user picks another language during onboarding or in settings — the opposite
of how this started, and the right way round for a product meant to ship
outside Iran.

Resolution order:
    1. OSPRIME_LANG environment variable
    2. "language" in /etc/osprime/profile.json  (what onboarding writes)
    3. "en"

One override survives all of that: the raw Linux virtual console
(TERM=linux) has a 256-glyph font and physically cannot draw Persian, so a
non-Latin locale falls back to English there rather than printing boxes.
"""

import json
import os
import pathlib
import sys

DEFAULT_LANG = "en"
LATIN_SAFE = {"en"}

PROFILE_PATH = pathlib.Path(
    os.environ.get("OSPRIME_PROFILE", "/etc/osprime/profile.json"))


def is_raw_console() -> bool:
    """True on the kernel's virtual console, which cannot render non-Latin text."""
    if os.environ.get("TERM", "") == "linux":
        return True
    try:
        name = os.ttyname(sys.stdin.fileno())
        return name.startswith("/dev/tty") and name[8:].isdigit()
    except Exception:
        return False


def _profile_lang() -> str:
    try:
        return json.loads(PROFILE_PATH.read_text(encoding="utf-8")).get("language", "")
    except Exception:
        return ""


def lang() -> str:
    """The active language code."""
    chosen = os.environ.get("OSPRIME_LANG") or _profile_lang() or DEFAULT_LANG
    if chosen not in STRINGS_BY_LANG:
        chosen = DEFAULT_LANG
    if chosen not in LATIN_SAFE and is_raw_console():
        return DEFAULT_LANG
    return chosen


def is_rtl(code: str = "") -> bool:
    return (code or lang()) in {"fa", "ar", "he", "ur"}


EN = {
    "banner_hint": "Type 'exit' to quit — emergency shell: tty2 (Ctrl+Alt+F2)",
    "prompt": "You > ",
    "bye": "Goodbye.",
    "not_running": "osprime-agent is not running. Start the daemon first:",
    "error": "error",
    "confirm_q": "Allow this? (y/n) ",
    "ob_hello": "Hello! I'm OSprime — your operating system.",
    "ob_intro": "A few quick questions so I know you, then I'll take it from here.",
    "ob_name": "What's your name? ",
    "ob_lang": "Preferred language? (en/fa) [en] ",
    "ob_skill": "Technical level? (beginner/intermediate/expert) ",
    "ob_usage": "What do you mostly use this computer for? ",
    "ob_autonomy": "Ask permission before changing the system? (yes/no) [yes] ",
    "ob_thanks": "Thanks {name}! I'm at your service now.",
    "ob_done": "Profile already exists — onboarding not needed.",
}

FA = {
    "banner_hint": "برای خروج: exit — برای شل اضطراری: tty2 (Ctrl+Alt+F2)",
    "prompt": "شما ⮞ ",
    "bye": "خداحافظ",
    "not_running": "osprime-agent در حال اجرا نیست. اول daemon را روشن کن:",
    "error": "خطا",
    "confirm_q": "اجازه می‌دی؟ (y/n) ",
    "ob_hello": "سلام! من OSprime هستم — سیستم‌عامل تو.",
    "ob_intro": "چند تا سوال کوتاه می‌پرسم تا بشناسمت، بعدش همه‌چیز دست منه.",
    "ob_name": "اسمت چیه؟ ",
    "ob_lang": "زبان اصلی گفتگو؟ (en/fa) [en] ",
    "ob_skill": "سطح فنی‌ات؟ (مبتدی/متوسط/حرفه‌ای) ",
    "ob_usage": "بیشتر با کامپیوتر چیکار می‌کنی؟ ",
    "ob_autonomy": "قبل از هر تغییری در سیستم ازت اجازه بگیرم؟ (بله/نه) [بله] ",
    "ob_thanks": "ممنون {name}! از این به بعد من در خدمتتم.",
    "ob_done": "پروفایل از قبل ساخته شده — onboarding لازم نیست.",
}

STRINGS_BY_LANG = {"en": EN, "fa": FA}


def t(key: str) -> str:
    table = STRINGS_BY_LANG.get(lang(), EN)
    return table.get(key) or EN.get(key, key)
