#!/usr/bin/env python3
"""OSprime full-screen chat client. Pure stdlib — connects to the agent
daemon over its Unix socket. This is what tty1 boots into."""

import json
import os
import socket
import sys

sys.path.insert(0, __import__('os').path.dirname(__file__))
import i18n

SOCKET_PATH = os.environ.get("OSPRIME_SOCKET", "/run/osprime/agent.sock")

BANNER = r"""
   ___  ____             _
  / _ \/ ___| _ __  _ __(_)_ __ ___   ___
 | | | \___ \| '_ \| '__| | '_ ` _ \ / _ \
 | |_| |___) | |_) | |  | | | | | | |  __/
  \___/|____/| .__/|_|  |_|_| |_| |_|\___|
             |_|   your OS, thinking.
"""

CYAN, DIM, GREEN, RESET = "\033[96m", "\033[2m", "\033[92m", "\033[0m"


def main():
    os.system("clear")
    print(CYAN + BANNER + RESET)
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
    except OSError:
        print("⚠  " + i18n.t("not_running"))
        print("   python3 agent/agent.py &")
        sys.exit(1)
    f = sock.makefile("rwb")
    print(DIM + i18n.t("banner_hint") + RESET + "\n")

    while True:
        try:
            text = input(GREEN + i18n.t("prompt") + RESET).strip()
            text = text.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
        except (EOFError, KeyboardInterrupt):
            break
        if not text:
            continue
        if text.lower() in ("exit", "خروج"):
            break
        f.write((json.dumps({"type": "user_message", "text": text}) + "\n").encode())
        f.flush()
        streaming = False
        for line in f:
            msg = json.loads(line)
            t = msg.get("type")
            if t == "confirm":
                if streaming:
                    print(); streaming = False
                print(f"\n🔒 {msg['text']}")
                if msg.get("detail"):
                    print(DIM + "   " + msg["detail"] + RESET)
                ans = input("   " + i18n.t("confirm_q")).strip().lower()
                f.write((json.dumps({"type": "confirm_response", "id": msg["id"],
                                     "approved": ans in ("y", "yes", "بله")}) + "\n").encode())
                f.flush()
                continue
            if t == "delta":
                if not streaming:
                    print(f"\n{CYAN}OSprime ⮞{RESET} ", end="", flush=True)
                    streaming = True
                print(msg["text"], end="", flush=True)
            elif t == "tool_use":
                if streaming:
                    print()
                    streaming = False
                print(DIM + f"  ⚙ {msg['name']}: {msg['detail']}" + RESET)
            elif t == "assistant":
                tag = "☁" if msg.get("backend") == "claude" else "⌂"
                if streaming:
                    print(DIM + f"  [{tag}]" + RESET + "\n")
                else:
                    print(f"\n{CYAN}OSprime {tag} ⮞{RESET} {msg['text']}\n")
                break
            elif t == "error":
                print(f"\n⚠ {i18n.t('error')}: {msg['text']}\n")
                break
    print("\n" + i18n.t("bye"))


if __name__ == "__main__":
    main()
