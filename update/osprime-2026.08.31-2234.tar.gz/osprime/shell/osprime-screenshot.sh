#!/usr/bin/env bash
# Take a screenshot.
#
#   Print        select an area
#   Super+Print  the whole screen
#   Super+Shift+S  select an area (the shortcut people arrive with)
#
# Saved to ~/Pictures/Screenshots and copied to the clipboard, so it can be
# pasted straight into a message without hunting for the file.

MODE="${1:-area}"
DIR="$HOME/Pictures/Screenshots"
mkdir -p "$DIR"
FILE="$DIR/$(date +%Y-%m-%d_%H-%M-%S).png"

notify() {
    command -v notify-send >/dev/null && notify-send "OSprime" "$1" 2>/dev/null
    echo "$1" >> /tmp/osprime-screenshot.log
}

if ! command -v grim >/dev/null; then
    notify "Screenshots need the grim tool, which is not installed yet."
    exit 1
fi

if [ "$MODE" = "area" ] && command -v slurp >/dev/null; then
    REGION="$(slurp 2>/dev/null)" || exit 0     # cancelled with Escape
    [ -n "$REGION" ] || exit 0
    grim -g "$REGION" "$FILE" || exit 1
else
    grim "$FILE" || exit 1
fi

command -v wl-copy >/dev/null && wl-copy < "$FILE" 2>/dev/null
notify "Screenshot saved to ${FILE/#$HOME/~}"
echo "$FILE"
