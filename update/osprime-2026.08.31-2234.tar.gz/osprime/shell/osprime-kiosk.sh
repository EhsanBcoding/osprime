#!/usr/bin/env bash
# Launch the OSprime chat UI full-screen inside the compositor.
# Falls back through: browser -> terminal chat in a window -> nothing lost.
URL="${OSPRIME_URL:-http://localhost:8080}"
LOG=/tmp/osprime-kiosk.log
: > "$LOG"

log() { echo "[$(date +%T)] $*" >> "$LOG"; }

# Flags that make Chromium work inside VMs / minimal sessions.
CHROME_FLAGS=(
  --ozone-platform=wayland
  --kiosk
  --no-first-run
  --no-default-browser-check
  --no-sandbox                 # required when running without a full user session
  --disable-dev-shm-usage      # /dev/shm is tiny in VMs
  --disable-gpu-sandbox
  --disable-features=TranslateUI
  --password-store=basic
  --user-data-dir=/tmp/osprime-chrome
)
# software rendering when there is no real GPU
if [ ! -e /dev/dri/renderD128 ]; then
    CHROME_FLAGS+=(--disable-gpu --use-gl=swiftshader --in-process-gpu)
    log "no render node — using software rendering"
fi

for b in chromium chromium-browser google-chrome-stable google-chrome; do
    if command -v "$b" >/dev/null; then
        log "starting $b"
        "$b" "${CHROME_FLAGS[@]}" "$URL" >>"$LOG" 2>&1 &
        BPID=$!
        sleep 6
        if kill -0 "$BPID" 2>/dev/null; then
            log "$b is running (pid $BPID)"
            wait "$BPID"
            log "$b exited with $?"
        else
            log "$b died within 6s — trying next option"
        fi
        break
    fi
done

if command -v firefox >/dev/null && ! pgrep -x chromium >/dev/null; then
    log "trying firefox"
    firefox --kiosk "$URL" >>"$LOG" 2>&1 && exit 0
fi

# Last resort: a terminal window with the chat, so the screen is never empty.
log "falling back to terminal chat inside the compositor"
if command -v foot >/dev/null; then
    exec foot -F python3 /opt/osprime/ui/chat.py
fi
exec python3 /opt/osprime/ui/chat.py
