#!/usr/bin/env bash
# Install local voice engines for OSprime: whisper.cpp (STT) + piper (TTS).
# Usage: sudo ./shell/setup-voice.sh [fa|en]
set -e
LANG_CODE="${1:-en}"
MODELS="${OSPRIME_MODELS:-/var/lib/osprime/models}"
[ "$EUID" -eq 0 ] || { echo "Run this with sudo."; exit 1; }

mkdir -p "$MODELS"

# --- dependencies ---------------------------------------------------------
if command -v apt >/dev/null; then
    apt update -qq && apt install -y ffmpeg build-essential cmake git wget
elif command -v pacman >/dev/null; then
    pacman -S --noconfirm ffmpeg base-devel cmake git wget
fi

# --- whisper.cpp ----------------------------------------------------------
if ! command -v whisper-cli >/dev/null; then
    echo "> building whisper.cpp ..."
    tmp=$(mktemp -d)
    git clone --depth 1 https://github.com/ggml-org/whisper.cpp "$tmp/whisper.cpp"
    cmake -S "$tmp/whisper.cpp" -B "$tmp/build" -DCMAKE_BUILD_TYPE=Release >/dev/null
    cmake --build "$tmp/build" -j"$(nproc)" --target whisper-cli >/dev/null
    install -m755 "$tmp/build/bin/whisper-cli" /usr/local/bin/whisper-cli
    rm -rf "$tmp"
fi

# --- whisper model (multilingual base ~148MB, understands Persian) --------
if [ ! -f "$MODELS/ggml-base.bin" ]; then
    echo "> downloading whisper model ..."
    wget -q --show-progress -O "$MODELS/ggml-base.bin" \
      https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin
fi

# --- piper ----------------------------------------------------------------
if ! command -v piper >/dev/null; then
    echo "> installing piper ..."
    tmp=$(mktemp -d)
    wget -q --show-progress -O "$tmp/piper.tar.gz" \
      https://github.com/rhasspy/piper/releases/latest/download/piper_linux_x86_64.tar.gz
    tar -xzf "$tmp/piper.tar.gz" -C /opt/
    ln -sf /opt/piper/piper /usr/local/bin/piper
    rm -rf "$tmp"
fi

# --- piper voice ----------------------------------------------------------
if ! ls "$MODELS"/*.onnx >/dev/null 2>&1; then
    echo "> downloading piper voice ($LANG_CODE) ..."
    BASE=https://huggingface.co/rhasspy/piper-voices/resolve/main
    if [ "$LANG_CODE" = "fa" ]; then
        V="fa/fa_IR/amir/medium/fa_IR-amir-medium"
    else
        V="en/en_US/lessac/medium/en_US-lessac-medium"
    fi
    wget -q --show-progress -O "$MODELS/voice.onnx"      "$BASE/$V.onnx"
    wget -q --show-progress -O "$MODELS/voice.onnx.json" "$BASE/$V.onnx.json"
fi

chgrp -R osprime "$MODELS" 2>/dev/null || true
chmod -R 775 "$MODELS"
systemctl restart osprime-agent osprime-web 2>/dev/null || true

echo ""
echo "Voice is ready. Refresh the web UI — the mic and speaker buttons will appear."
