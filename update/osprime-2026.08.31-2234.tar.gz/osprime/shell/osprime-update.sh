#!/usr/bin/env bash
# OSprime OTA update CLI.
#   sudo ./osprime-update.sh              update to latest
#   sudo ./osprime-update.sh --status     show version & backups
#   sudo ./osprime-update.sh --rollback   revert to previous version
exec python3 - "$@" << 'PY'
import sys
sys.path.insert(0, "/opt/osprime/agent")
import updater
a = sys.argv[1] if len(sys.argv) > 1 else ""
if a == "--status":
    import json; print(json.dumps(updater.status(), ensure_ascii=False, indent=2))
elif a == "--rollback":
    print(updater.restore(sys.argv[2] if len(sys.argv) > 2 else ""))
    print(updater.restart_services())
else:
    print(updater.update(sys.argv[1] if len(sys.argv) > 1 else ""))
PY
