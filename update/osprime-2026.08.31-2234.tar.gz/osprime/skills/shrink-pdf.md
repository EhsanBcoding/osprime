---json
{
  "name": "shrink-pdf",
  "title": "Make a PDF small enough to send",
  "type": "shared",
  "teachable": true,
  "triggers": [
    "pdf is too big", "compress a pdf", "reduce pdf size",
    "shrink this pdf", "email attachment too large", "make this pdf smaller"
  ],
  "tools": ["run_shell", "list_dir", "open_app"],
  "packages": ["ghostscript"],
  "sources": [
    {"what": "Ghostscript pdfwrite parameters", "licence": "AGPL-3.0",
     "note": "invoked as a program, not linked — no obligation on OSprime"}
  ]
}
---

## Do it

1. Confirm which file. If the user said "this PDF" without naming one, list
   the likely folder rather than guessing a filename.
2. Note the original size so the result can be compared.
3. Run, writing to a **new** file — never over the original:

   ```
   gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 \
      -dPDFSETTINGS=/ebook -dNOPAUSE -dQUIET -dBATCH \
      -sOutputFile="<name>-small.pdf" "<name>.pdf"
   ```

4. Compare the sizes and report both, in plain units.

`/ebook` is the right default: roughly 150 dpi, readable on screen, usually a
large reduction. `/screen` is smaller but visibly degrades scans. `/printer`
is for something that will be printed. Move to another setting only if the
first result does not meet the need.

If the file barely shrinks, it is probably already compressed. Say so rather
than trying repeatedly — and mention that splitting out unneeded pages is the
other way to get under a limit.

## Teach it

The user wants to do this themselves next time.

1. Ask what they are trying to get under — most email limits are 25 MB, many
   upload forms are 10 MB. The target decides the setting.
2. Show them the command once, with their own file in it. A command they have
   seen work on their own file is remembered; a generic example is not.
3. Explain only the part that changes: `-dPDFSETTINGS` is the quality dial,
   and `/ebook` is the setting to reach for first.
4. Point out the output filename is separate on purpose, so a bad result
   never costs them the original.
5. Have them run it on a second file unaided, and check the result.

## Check

The output file exists, is smaller than the input, and still opens. Open it
with `open_app` and ask the user to confirm it is still readable — a PDF that
is small and unreadable has not solved their problem.

Report the before and after sizes. "12 MB → 2.4 MB" is the answer to the
question they actually asked.

## Common mistakes

- Overwriting the original. Always write to a new filename.
- Reaching for `/screen` first because it is smallest; scanned text becomes
  unreadable.
- Reporting success without checking the file opens.
- Repeatedly recompressing a file that is already compressed.
