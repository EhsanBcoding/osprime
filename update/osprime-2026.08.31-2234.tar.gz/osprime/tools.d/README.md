# پلاگین‌های OSprime

هر فایل `.py` توی این پوشه خودکار به یک ابزار agent تبدیل می‌شود — مثل درایور.

## قرارداد

```python
TOOL = {
    "name": "my_tool",                      # یکتا، نباید با ابزارهای داخلی یکی باشد
    "description": "توضیح کاری که می‌کند (به انگلیسی، برای مدل).",
    "input_schema": {                        # JSON Schema ورودی
        "type": "object",
        "properties": {"x": {"type": "string"}},
        "required": ["x"],
    },
}

def run(args):                # یا run(args, send) اگر بخواهی پیام پیشرفت بفرستی
    return "نتیجه به‌صورت رشته"
```

- فایل‌هایی که با `_` شروع شوند نادیده گرفته می‌شوند.
- اگر `TOOL` یا `run` نداشته باشد، یا اسمش رزرو/تکراری باشد، رد می‌شود.
- پلاگین‌ها ریسک `moderate` دارند، پس طبق `confirm_level` ممکن است تایید بخواهند.
- نمونه‌ها: `calc.py` (ماشین‌حساب امن) و `weather.py` (آب‌وهوا).

## فعال‌سازی

پلاگین را اینجا بگذار و سرویس را ری‌استارت کن:

```bash
sudo cp my_tool.py /opt/osprime/tools.d/
sudo systemctl restart osprime-agent
```
