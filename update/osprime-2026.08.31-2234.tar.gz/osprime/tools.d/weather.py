"""Example OSprime plugin: current weather via the free wttr.in service."""
import urllib.parse
import urllib.request

TOOL = {
    "name": "weather",
    "description": "Get the current weather for a city (uses wttr.in, no API key).",
    "input_schema": {
        "type": "object",
        "properties": {"city": {"type": "string"}},
        "required": ["city"],
    },
}


def run(args, send=None):
    city = args["city"]
    if send:
        send({"type": "tool_use", "name": "weather", "detail": city})
    url = "https://wttr.in/" + urllib.parse.quote(city) + "?format=3&m"
    req = urllib.request.Request(url, headers={"User-Agent": "curl/8"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read().decode("utf-8", "replace").strip()
