"""Example OSprime plugin: a safe arithmetic calculator."""
import ast
import operator

TOOL = {
    "name": "calc",
    "description": "Evaluate a basic arithmetic expression (+ - * / ** %). "
                   "Use for quick math instead of shelling out.",
    "input_schema": {
        "type": "object",
        "properties": {"expression": {"type": "string"}},
        "required": ["expression"],
    },
}

_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
    ast.USub: operator.neg,
}


def _ev(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp):
        return _OPS[type(node.op)](_ev(node.left), _ev(node.right))
    if isinstance(node, ast.UnaryOp):
        return _OPS[type(node.op)](_ev(node.operand))
    raise ValueError("unsupported expression")


def run(args):
    expr = args["expression"]
    return str(_ev(ast.parse(expr, mode="eval").body))
