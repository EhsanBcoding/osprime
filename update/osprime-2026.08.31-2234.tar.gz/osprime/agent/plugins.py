"""OSprime plugin system: drop a .py file in tools.d/ and it becomes an agent
tool automatically — like a driver.

A plugin file must define:
    TOOL = {"name": "...", "description": "...", "input_schema": {...}}
    def run(args: dict) -> str: ...

Optionally run(args, send) if it wants to emit progress via send(obj).
"""

import importlib.util
import inspect
import pathlib
import traceback


def load(plugin_dir, reserved_names=()) -> dict:
    """Load every valid plugin. Returns {name: {"schema":..., "run":...}}."""
    out = {}
    d = pathlib.Path(plugin_dir)
    if not d.is_dir():
        return out
    for f in sorted(d.glob("*.py")):
        if f.name.startswith("_"):
            continue
        try:
            spec = importlib.util.spec_from_file_location(f"osprime_plugin_{f.stem}", f)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tool = getattr(mod, "TOOL", None)
            run = getattr(mod, "run", None)
            if not isinstance(tool, dict) or not callable(run):
                print(f"plugin {f.name}: missing TOOL dict or run() — skipped")
                continue
            name = tool.get("name")
            if not name or name in reserved_names or name in out:
                print(f"plugin {f.name}: name '{name}' missing/reserved/duplicate — skipped")
                continue
            tool.setdefault("input_schema", {"type": "object", "properties": {}})
            out[name] = {"schema": tool, "run": run}
            print(f"plugin loaded: {name}  ({f.name})")
        except Exception:
            print(f"plugin {f.name} failed to load:\n{traceback.format_exc()}")
    return out


def call(entry: dict, args: dict, send) -> str:
    """Invoke a plugin's run(), passing send if it accepts a second arg."""
    run = entry["run"]
    try:
        params = inspect.signature(run).parameters
        if len(params) >= 2:
            return str(run(args, send))
        return str(run(args))
    except Exception as e:
        return f"plugin error: {e}"
