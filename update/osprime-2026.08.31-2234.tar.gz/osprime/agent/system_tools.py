"""OSprime system control.

Narrow, named operations instead of asking the model to compose shell
commands. A 1.5B model cannot reliably remember that setting the clock means
`timedatectl set-time "2026-08-15 14:30:00"` — it can reliably pick
`set_time` from a list and fill one field. That difference is why asking
OSprime to fix the clock failed.

Every function here also has a second consumer: Settings. Both read and write
through this module so the two can never disagree about what the system
currently is.

Each returns a short human sentence, because the result is shown to the user.
"""

import json
import os
import pathlib
import re
import shutil
import subprocess

CONFIG_PATH = pathlib.Path(os.environ.get("OSPRIME_DESKTOP_ENV",
                                          "/etc/osprime/desktop.env"))
TIMEOUT = 30


def _run(args, timeout: int = TIMEOUT):
    """Run a command directly — no shell, so nothing can be injected."""
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", f"{args[0]} is not installed"
    except subprocess.TimeoutExpired:
        return 124, "", f"{args[0]} timed out"


def _sudo(args):
    """These actions need root. The agent runs unprivileged by design."""
    if os.geteuid() == 0:
        return _run(args)
    if shutil.which("sudo"):
        return _run(["sudo", "-n"] + args)
    return 1, "", "root privileges are required and sudo is unavailable"


# --------------------------------------------------------------------------
# time
# --------------------------------------------------------------------------

_DT = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$")


def get_time() -> str:
    code, out, _ = _run(["timedatectl", "show", "--property=Timezone",
                         "--property=NTP", "--property=TimeUSec", "--value"])
    if code != 0:
        return "ERROR: could not read the clock"
    parts = out.splitlines()
    return json.dumps({"timezone": parts[0] if parts else "",
                       "auto_sync": (parts[1] if len(parts) > 1 else "") == "yes",
                       "time": parts[2] if len(parts) > 2 else ""})


def set_time(datetime: str) -> str:
    """Set the clock. Expects `YYYY-MM-DD HH:MM` or with seconds.

    The parameter is named to match the tool schema exactly — the dispatcher
    passes arguments through by keyword, so a mismatch here is a runtime
    failure the model cannot recover from.
    """
    s = (datetime or "").strip().replace("T", " ")
    if not _DT.match(s):
        return ("ERROR: I need the time as YYYY-MM-DD HH:MM, "
                f"and I was given '{datetime}'.")
    if len(s) == 16:
        s += ":00"
    # Automatic sync overrides any manual setting, so it has to go first.
    _sudo(["timedatectl", "set-ntp", "false"])
    code, _, err = _sudo(["timedatectl", "set-time", s])
    if code != 0:
        return f"ERROR: could not set the clock: {err}"
    return f"clock set to {s}" + _host_clock_note()


def _host_clock_note() -> str:
    """Warn when something outside this system owns the clock.

    A virtual machine's guest agent resets the guest clock from the host on
    every boot, so a manually set time silently reverts and the user is left
    thinking the setting did not save. Saying so is better than letting them
    set it again and again.
    """
    for agent in ("vmtoolsd", "qemu-ga", "VBoxService"):
        if subprocess.run(["pgrep", "-x", agent],
                          capture_output=True).returncode == 0:
            return (" — note: this machine is a virtual machine and its host "
                    "resets the clock on every restart, so this will not "
                    "survive a reboot. On real hardware it will.")
    return ""


def resolve_timezone(text: str):
    """Turn what a person types into an IANA zone name.

    Nobody living in Irvine knows their timezone is called
    America/Los_Angeles. Requiring the exact name made a correct request look
    like a user error, so the city is resolved here instead — the tz database
    already lists every city it knows.

    Returns (zone, candidates). Exactly one of them is meaningful.
    """
    want = (text or "").strip()
    if not want:
        return None, []
    code, out, _ = _run(["timedatectl", "list-timezones", "--no-pager"])
    if code != 0:
        return want, []          # cannot check; let timedatectl decide
    zones = out.split()

    if want in zones:
        return want, []

    norm = want.replace(" ", "_").lower()
    exact = [z for z in zones if z.lower() == norm]
    if exact:
        return exact[0], []

    # A bare city: match the last component of the zone name.
    city = [z for z in zones if z.rsplit("/", 1)[-1].lower() == norm.rsplit("/", 1)[-1]]
    if len(city) == 1:
        return city[0], []
    if city:
        return None, city[:6]

    loose = [z for z in zones if norm.rsplit("/", 1)[-1] in z.lower()]
    if len(loose) == 1:
        return loose[0], []
    return None, loose[:6]


def set_timezone(zone: str) -> str:
    resolved, options = resolve_timezone(zone)
    if not resolved:
        if options:
            return (f"ERROR: '{zone}' matches several timezones. "
                    f"Which one: {', '.join(options)}?")
        return (f"ERROR: '{zone}' does not match any timezone. Give me the "
                "nearest large city, or a name like Europe/Berlin.")
    code, _, err = _sudo(["timedatectl", "set-timezone", resolved])
    if code != 0:
        return f"ERROR: could not set timezone: {err}"
    if resolved != (zone or "").strip():
        return f"timezone set to {resolved} (matched from '{zone}')"
    return f"timezone set to {resolved}"


def set_auto_time(enabled: bool = True) -> str:
    code, _, err = _sudo(["timedatectl", "set-ntp", "true" if enabled else "false"])
    if code != 0:
        return f"ERROR: could not change automatic time: {err}"
    return "clock now syncs automatically" if enabled else "automatic clock sync off"


# --------------------------------------------------------------------------
# network
# --------------------------------------------------------------------------

def _tsplit(line: str) -> list:
    """Split one line of `nmcli -t` output.

    nmcli separates fields with a colon and escapes any colon inside a value
    as `\\:`. Splitting naively tore apart every network whose name contains
    one, which is common enough on phone hotspots.
    """
    fields, cur, esc = [], [], False
    for ch in line:
        if esc:
            cur.append(ch)
            esc = False
        elif ch == "\\":
            esc = True
        elif ch == ":":
            fields.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    fields.append("".join(cur))
    return fields


def wifi_radio(on: bool = True) -> str:
    code, _, err = _sudo(["nmcli", "radio", "wifi", "on" if on else "off"])
    if code != 0:
        return f"ERROR: could not turn the Wi-Fi radio {'on' if on else 'off'}: {err}"
    return f"Wi-Fi radio {'on' if on else 'off'}"


def _has_wifi_device() -> bool:
    code, out, _ = _run(["nmcli", "-t", "-f", "TYPE", "device", "status"])
    return code == 0 and any(l.strip() == "wifi" for l in out.splitlines())


def list_wifi() -> str:
    if not shutil.which("nmcli"):
        return "ERROR: NetworkManager is not available on this system."
    if not _has_wifi_device():
        return ("ERROR: this machine has no Wi-Fi adapter. If it is connected "
                "by cable, it may already be online.")

    # A blocked radio reports zero networks, which reads as "nothing nearby"
    # rather than "the switch is off" — so turn it on rather than mislead.
    code, out, _ = _run(["nmcli", "-t", "-f", "WIFI", "radio"])
    if code == 0 and out.strip().endswith("disabled"):
        r = wifi_radio(True)
        if r.startswith("ERROR"):
            return r

    # Without an explicit rescan the list is whatever was cached, which on a
    # freshly booted machine is usually nothing at all.
    _run(["nmcli", "device", "wifi", "rescan"], timeout=30)

    code, out, err = _run(["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY,IN-USE",
                           "device", "wifi", "list"], timeout=45)
    if code != 0:
        return f"ERROR: could not scan for networks: {err}"

    known = _saved_networks()
    seen, rows = set(), []
    for line in out.splitlines():
        p = _tsplit(line)
        ssid = (p[0] if p else "").strip()
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        rows.append({
            "ssid": ssid,
            "signal": p[1].strip() if len(p) > 1 else "",
            "secured": bool(p[2].strip()) if len(p) > 2 else True,
            "active": (p[3].strip() == "*") if len(p) > 3 else False,
            "saved": ssid in known,
        })
    if not rows:
        return "no networks found"
    rows.sort(key=lambda r: int(r["signal"] or 0), reverse=True)
    return json.dumps(rows[:20])


def _saved_networks() -> set:
    code, out, _ = _run(["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"])
    if code != 0:
        return set()
    names = set()
    for line in out.splitlines():
        p = _tsplit(line)
        if len(p) > 1 and "wireless" in p[1]:
            names.add(p[0])
    return names


def connect_wifi(ssid: str, password: str = "") -> str:
    if not ssid:
        return "ERROR: I need the network name."
    if not shutil.which("nmcli"):
        return "ERROR: NetworkManager is not available on this system."

    # -w is a global option and must come before the object. Appending it
    # after the command made nmcli reject every connection attempt outright,
    # which is why joining a network never once worked.
    base = ["nmcli", "-w", "30"]

    # A network joined before has its password stored; asking for it again
    # would be a worse experience than simply bringing the profile up.
    if not password and ssid in _saved_networks():
        code, _, err = _sudo(base + ["connection", "up", "id", ssid])
        if code == 0:
            return f"connected to {ssid}"

    args = base + ["device", "wifi", "connect", ssid]
    if password:
        args += ["password", password]
    code, _, err = _sudo(args)
    if code != 0:
        low = (err or "").lower()
        if "secrets" in low or "no key available" in low or "802-11" in low:
            return f"ERROR: '{ssid}' needs a password, or the password was wrong."
        if "not found" in low or "no network" in low:
            return f"ERROR: '{ssid}' is not in range. Scan again and pick it from the list."
        return f"ERROR: could not connect to {ssid}: {err or 'unknown reason'}"
    return f"connected to {ssid}"


def forget_wifi(ssid: str) -> str:
    if not ssid:
        return "ERROR: I need the network name."
    code, _, err = _sudo(["nmcli", "connection", "delete", "id", ssid])
    if code != 0:
        return f"ERROR: could not forget {ssid}: {err}"
    return f"forgot {ssid}"


def network_status() -> str:
    code, out, _ = _run(["nmcli", "-t", "-f", "TYPE,STATE,CONNECTION",
                         "device", "status"])
    if code != 0:
        return "ERROR: could not read network status"
    active = [l for l in out.splitlines() if ":connected:" in l]
    if not active:
        return "not connected to any network"
    return json.dumps([{"type": l.split(":")[0], "name": l.split(":")[2]}
                       for l in active])


# --------------------------------------------------------------------------
# appearance and locale — shared with Settings through desktop.env
# --------------------------------------------------------------------------

def _read_env() -> dict:
    out = {}
    try:
        for line in CONFIG_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except Exception:
        pass
    return out


def _write_env(key: str, value: str) -> bool:
    """Update one key, preserving comments and the rest of the file."""
    try:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        lines = (CONFIG_PATH.read_text(encoding="utf-8").splitlines()
                 if CONFIG_PATH.exists() else [])
        done = False
        for i, line in enumerate(lines):
            if line.strip().startswith(f"{key}="):
                lines[i] = f"{key}={value}"
                done = True
                break
        if not done:
            lines.append(f"{key}={value}")
        CONFIG_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return True
    except Exception:
        return False


_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")


def set_wallpaper(color: str) -> str:
    """Solid colour only for now — no image support yet."""
    c = (color or "").strip()
    named = {"petrol": "#12232E", "beige": "#D9CFBC", "black": "#0B0B0B",
             "navy": "#101A2E", "grey": "#2B2E33", "gray": "#2B2E33"}
    c = named.get(c.lower(), c)
    if not _HEX.match(c):
        return (f"ERROR: '{color}' is not a colour I understand. "
                "Give me a hex value like #12232E, or: petrol, beige, navy, grey.")
    if not _write_env("OSPRIME_WALLPAPER", c):
        return "ERROR: could not save the setting"
    if shutil.which("swaybg"):
        subprocess.run(["pkill", "swaybg"], capture_output=True)
        subprocess.Popen(["swaybg", "-c", c],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return f"background set to {c}"


def set_language(code: str) -> str:
    code = (code or "").strip().lower()
    if not re.match(r"^[a-z]{2}$", code):
        return f"ERROR: '{code}' is not a language code. Use two letters, such as en or fa."
    if not _write_env("OSPRIME_LANG", code):
        return "ERROR: could not save the setting"
    return f"language set to {code}. Reopen the chat window to see it."


def get_settings() -> str:
    """Everything Settings displays, from the one place that holds it."""
    env = _read_env()
    code, tz, _ = _run(["timedatectl", "show", "--property=Timezone", "--value"])
    return json.dumps({
        "language": env.get("OSPRIME_LANG", "en"),
        "wallpaper": env.get("OSPRIME_WALLPAPER", "#12232E"),
        "timezone": tz if code == 0 else "",
        "cloud_mode": os.environ.get("OSPRIME_CLOUD_MODE", "off"),
    })


# --------------------------------------------------------------------------
# display and sound
# --------------------------------------------------------------------------

def set_volume(percent: int) -> str:
    try:
        p = max(0, min(100, int(percent)))
    except (TypeError, ValueError):
        return f"ERROR: '{percent}' is not a number between 0 and 100."
    if shutil.which("wpctl"):
        code, _, err = _run(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{p}%"])
    elif shutil.which("amixer"):
        code, _, err = _run(["amixer", "-q", "sset", "Master", f"{p}%"])
    else:
        return "ERROR: no audio control available"
    return f"volume set to {p}%" if code == 0 else f"ERROR: could not set volume: {err}"


def list_drives() -> str:
    """Removable and mounted storage, so the assistant can find a USB stick.

    Asked where the files on a memory stick are, the assistant had no way to
    look: it could list directories but had no idea the device existed.
    """
    code, out, _ = _run(["lsblk", "-J", "-o",
                         "NAME,SIZE,TYPE,MOUNTPOINT,RM,LABEL,FSTYPE"])
    if code != 0:
        return "ERROR: could not read the drives on this machine."
    try:
        tree = json.loads(out).get("blockdevices", [])
    except json.JSONDecodeError:
        return "ERROR: could not read the drives on this machine."

    drives = []

    def walk(node, removable=False):
        rm = bool(node.get("rm")) or removable
        # Anything carrying a filesystem, whether it is a partition or the
        # whole device. Plenty of USB sticks are formatted with no partition
        # table at all, and only listing partitions made those invisible —
        # which is the same as not supporting them.
        if node.get("fstype") and node.get("type") in ("part", "disk"):
            drives.append({
                "device": "/dev/" + node.get("name", ""),
                "size": node.get("size", ""),
                "label": node.get("label") or "",
                "filesystem": node.get("fstype") or "",
                "mounted_at": node.get("mountpoint") or "",
                "removable": rm,
            })
        for child in node.get("children", []) or []:
            walk(child, rm)

    for dev in tree:
        walk(dev)

    if not drives:
        return "no storage devices found"
    return json.dumps(drives)


def mount_drive(device: str) -> str:
    """Mount a partition under /media so its files can be reached."""
    dev = (device or "").strip()
    if not re.match(r"^/dev/[a-zA-Z0-9]+$", dev):
        return f"ERROR: '{device}' is not a device name. Use something like /dev/sdb1."

    # Already mounted somewhere? Say where instead of mounting it twice.
    code, out, _ = _run(["findmnt", "-n", "-o", "TARGET", "--source", dev])
    if code == 0 and out.strip():
        return f"{dev} is already available at {out.strip().splitlines()[0]}"

    if shutil.which("udisksctl"):
        code, out, err = _run(["udisksctl", "mount", "-b", dev], timeout=45)
        if code == 0:
            m = re.search(r"at (\S+)", out)
            return f"{dev} is available at {m.group(1).rstrip('.') if m else '/run/media'}"

    if not pathlib.Path(dev).exists():
        # The commonest failure by far, and the kernel's own wording for it —
        # "Can't lookup blockdev" — tells a user nothing at all.
        return (f"ERROR: there is no device called {dev}. Use list_drives to "
                "see what is actually connected; the name changes depending "
                "on what was plugged in first.")

    point = "/media/" + dev.rsplit("/", 1)[-1]
    _sudo(["mkdir", "-p", point])
    code, _, err = _sudo(["mount", dev, point])
    if code != 0:
        low = (err or "").lower()
        if "unknown filesystem" in low or "wrong fs type" in low:
            return (f"ERROR: {dev} is formatted in a way this system cannot "
                    "read yet. Tell the user which format it is if you know.")
        return f"ERROR: could not open {dev}: {err or 'unknown reason'}"
    return f"{dev} is available at {point}"


def system_summary() -> str:
    """Facts about this machine, for answering 'what am I running on'."""
    out = {}
    code, o, _ = _run(["uname", "-r"])
    out["kernel"] = o if code == 0 else ""
    try:
        mem = pathlib.Path("/proc/meminfo").read_text()
        kb = int(re.search(r"MemTotal:\s+(\d+)", mem).group(1))
        out["memory_gb"] = round(kb / 1024 / 1024, 1)
    except Exception:
        pass
    out["cpu_cores"] = os.cpu_count()
    code, o, _ = _run(["df", "-h", "--output=avail,pcent", "/"])
    if code == 0 and len(o.splitlines()) > 1:
        avail, pcent = o.splitlines()[1].split()
        out["disk_free"] = avail
        out["disk_used"] = pcent
    return json.dumps(out)
