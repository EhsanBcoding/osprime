"""OSprime proactivity: a background monitor that watches system conditions
and runs scheduled tasks, pushing messages the agent can raise on its own."""

import datetime
import json
import pathlib
import shutil
import threading
import time


class ProactiveMonitor:
    def __init__(self, notify, run_agent, config_path,
                 disk_usage=None, clock=None):
        """
        notify(dict)      -> queue a proactive message  {"kind":"message","text":...}
        run_agent(prompt) -> run one headless agent turn, return text
        config_path       -> JSON with thresholds + schedules
        disk_usage/clock  -> injectable for testing
        """
        self.notify = notify
        self.run_agent = run_agent
        self.config_path = pathlib.Path(config_path)
        self._disk_usage = disk_usage or (lambda: shutil.disk_usage("/"))
        self._clock = clock or datetime.datetime.now
        self._cooldowns = {}          # check name -> last-fired epoch
        self._done = set()            # (date, schedule-time) already run

    # ---- config -----------------------------------------------------------
    def _config(self) -> dict:
        try:
            return json.loads(self.config_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _cooled(self, key: str, seconds: int) -> bool:
        now = time.time()
        if now - self._cooldowns.get(key, 0) >= seconds:
            self._cooldowns[key] = now
            return True
        return False

    # ---- checks -----------------------------------------------------------
    def check_disk(self):
        cfg = self._config()
        threshold = cfg.get("disk_threshold", 85)
        total, used, free = self._disk_usage()
        pct = used * 100 // total
        if pct >= threshold and self._cooled("disk", 6 * 3600):
            gb = free / (1024 ** 3)
            self.notify({"kind": "message", "text":
                f"\u26a0 Your disk is {pct}% full — only {gb:.1f} GB free. "
                "Want me to find the largest files you haven't opened in a while?"})

    def check_schedules(self):
        cfg = self._config()
        now = self._clock()
        hhmm = now.strftime("%H:%M")
        today = now.strftime("%Y-%m-%d")
        for task in cfg.get("schedules", []):
            key = (today, task.get("time"))
            if task.get("time") == hhmm and key not in self._done:
                self._done.add(key)
                try:
                    answer = self.run_agent(task["prompt"])
                except Exception as e:
                    answer = f"(scheduled task failed: {e})"
                label = task.get("label", "scheduled task")
                self.notify({"kind": "message",
                             "text": f"⏰ {label}:\n{answer}"})

    def tick(self):
        for check in (self.check_disk, self.check_schedules):
            try:
                check()
            except Exception as e:
                print(f"proactive check error: {e}")

    def loop(self, interval: int = 60):
        while True:
            self.tick()
            time.sleep(interval)

    def start(self):
        threading.Thread(target=self.loop, daemon=True).start()


def add_schedule(config_path, time_str: str, prompt: str, label: str = "") -> bool:
    p = pathlib.Path(config_path)
    try:
        cfg = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    cfg.setdefault("schedules", []).append(
        {"time": time_str, "prompt": prompt, "label": label or prompt[:30]})
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return True
