"""OSprime web tools: search (DuckDuckGo HTML, no API key) and page fetch.
Stdlib only."""

import html as htmllib
import re
import urllib.parse
import urllib.request

UA = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) OSprime/1.0"}


def _http_get(url: str, timeout: int = 15) -> str:
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def _real_url(href: str) -> str:
    """DDG wraps results in redirect links: //duckduckgo.com/l/?uddg=<real>"""
    if "uddg=" in href:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
        if q.get("uddg"):
            return q["uddg"][0]
    return href


def parse_search_results(page: str, max_results: int = 6) -> str:
    results = []
    for m in re.finditer(
            r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', page, re.S):
        href = _real_url(htmllib.unescape(m.group(1)))
        title = htmllib.unescape(re.sub(r"<[^>]+>", "", m.group(2))).strip()
        if title and href.startswith("http"):
            results.append(f"- {title}\n  {href}")
        if len(results) >= max_results:
            break
    return "\n".join(results) or "no results found"


def web_search(query: str) -> str:
    page = _http_get("https://html.duckduckgo.com/html/?q="
                     + urllib.parse.quote(query))
    return parse_search_results(page)


def html_to_text(page: str, limit: int = 8000) -> str:
    page = re.sub(r"(?s)<(script|style|nav|footer|header)[^>]*>.*?</\1>", " ", page)
    page = re.sub(r"(?s)<[^>]+>", " ", page)
    page = htmllib.unescape(page)
    page = re.sub(r"[ \t]+", " ", page)
    page = re.sub(r"\n\s*\n+", "\n", page)
    return page.strip()[:limit]


def fetch_url(url: str) -> str:
    if not url.startswith(("http://", "https://")):
        return "ERROR: only http(s) URLs are supported"
    return html_to_text(_http_get(url))
