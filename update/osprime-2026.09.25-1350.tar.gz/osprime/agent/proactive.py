"""OSprime proactivity: what the machine may say when nobody asked it
anything.

This file used to be a monitor with cooldowns. A cooldown is not a memory of
refusal — it is a promise to interrupt again in six hours — and that is the
difference between an assistant and Clippy. The rules from
docs/COMPANION.md are implemented here, in this order:

  1. It may only raise something the user already has a stake in. Enforced
     structurally: a message can only be sent under a kind registered in
     STAKES below, with a written answer to "could the user have asked for
     this?". An unregistered kind is dropped, so adding a new interruption
     means writing that answer down where a reviewer will see it.
  2. Never during work. See busy().
  3. It never opens anything. The only output of this file is a queued
     message and a dot on the companion. There is no code here that raises
     a window, plays a sound or takes focus, and there should never be.
  4. A refusal is permanent for that kind of thing. See dismiss().
  5. At most two a day, and when more qualify the rarest wins. See adjudicate().
  6. Silence is the default and the safe failure. Every uncertain case in
     this file resolves to saying nothing — note that enabled() returns
     False when it cannot read the setting and busy() returns True when it
     cannot tell, which look like opposite defaults and are the same one.
  7. Off means the monitor stops, not that its messages are hidden.

Two things deliberately stay OUTSIDE all of this, because they are not the
machine speaking on its own:

  * a schedule the user created — their own alarm, at a time they chose. It
    keeps running with the switch off.
  * the result of a job the user started, which arrives through JOBS.

The rule to hold on to when adding anything here: a missed notification
costs a little, and a wrong one costs the feature.
"""

import datetime
import json
import os
import pathlib
import shutil
import subprocess
import threading
import time

# Rule 1, written down. The key is the kind; the value is the answer to
# "could the user have asked for this?" — and it has to be a real answer,
# not a restatement of the message. Nothing not listed here can be sent.
#
# The test that keeps this honest: if the sentence does not describe
# something the user set up, asked about or is already waiting on, it does
# not belong in this dictionary. "It looks like you're writing a letter"
# fails that test, which is the entire point.
STAKES = {
    "disk": "The user's own disk is filling up. They could have asked 'am I "
            "running out of space?', and they will be stopped by it when it "
            "runs out. Nothing here is inferred from watching what they do.",
}

MAX_PER_DAY = 2          # rule 5
QUIET_SECONDS = 300      # rule 2: how long after the user's last word to wait
HISTORY_DAYS = 30        # how far back rarity is measured


class ProactiveMonitor:
    def __init__(self, notify, run_agent, config_path,
                 disk_usage=None, clock=None, env_path=None,
                 state_path=None, last_activity=None, busy_signals=None):
        """
        notify(dict)      -> queue a proactive message  {"kind":"message","text":...}
        run_agent(prompt) -> run one headless agent turn, return text
        config_path       -> JSON with thresholds + schedules
        env_path          -> the same /etc/osprime/desktop.env Settings writes
        state_path        -> where refusals and the daily budget are remembered
        last_activity()   -> epoch of the user's last message, or 0
        busy_signals()    -> list of reasons the user is mid-something
        disk_usage/clock  -> injectable for testing
        """
        self.env_path = env_path or os.environ.get(
            "OSPRIME_DESKTOP_ENV", "/etc/osprime/desktop.env")
        import paths
        self.state_path = pathlib.Path(state_path or paths.proactive_state())
        self.notify = notify
        self.run_agent = run_agent
        self.config_path = pathlib.Path(config_path)
        self._disk_usage = disk_usage or (lambda: shutil.disk_usage("/"))
        self._clock = clock or datetime.datetime.now
        self._last_activity = last_activity or (lambda: 0.0)
        self._busy_signals = busy_signals or self._default_busy_signals
        self._done = set()            # (date, schedule-time) already run

    # ---- config and state -------------------------------------------------
    def _config(self) -> dict:
        try:
            return json.loads(self.config_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _state(self) -> dict:
        """Refusals and history. On disk, not in memory.

        In memory it would last until the next update restarted the service,
        and then the machine would cheerfully raise something the user had
        already told it to stop raising. A refusal that a restart undoes is
        not a refusal.
        """
        try:
            s = json.loads(self.state_path.read_text(encoding="utf-8"))
            if isinstance(s, dict):
                return s
        except Exception:
            pass
        return {}

    def _save_state(self, s: dict) -> bool:
        """Returns whether it actually saved. The caller must care.

        This is the failure that nearly shipped: a save that fails quietly
        leaves _state() returning {} for ever, which reads as "nothing has
        been dismissed and nothing has been said today" — so a machine that
        cannot remember refusals would repeat every one of them, once a
        minute, for ever. The safe failure is silence, and silence here
        means not speaking at all, which is what _record() enforces by
        refusing to let anything through when this returns False.
        """
        try:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.state_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(s, indent=2), encoding="utf-8")
            tmp.replace(self.state_path)
            return True
        except Exception as e:
            # Once, not every tick. A line a minute for ever buries whatever
            # else the journal was going to say, and the machine that is
            # failing to write this file is usually failing to write others.
            if not getattr(self, "_warned_state", False):
                self._warned_state = True
                print(f"proactive: cannot remember what it has said ({e}); "
                      "staying quiet until that is fixed")
            return False

    # ---- rule 7: the switch -----------------------------------------------
    def enabled(self) -> bool:
        """Whether the assistant may start a conversation on its own.

        Read every tick rather than at startup, so flipping the switch in
        Settings takes effect now instead of at the next restart.

        Default no. A machine that starts talking to a new owner unprompted
        has already broken rule 2 on its first day.

        Off means the checks STOP, not that their messages are hidden. A
        monitor still running with its output discarded is a machine doing
        work nobody asked for, and it is the version that quietly starts
        talking again after an update.
        """
        try:
            for line in pathlib.Path(self.env_path).read_text(
                    encoding="utf-8").splitlines():
                if line.strip().startswith("OSPRIME_PROACTIVE="):
                    return line.split("=", 1)[1].strip().strip('"') == "yes"
        except Exception:
            pass
        return False

    # ---- rule 2: never during work ----------------------------------------
    @staticmethod
    def _default_busy_signals():
        """Things that mean the user is in the middle of something.

        Measured, not guessed. Each of these is a fact about the machine
        right now, not an inference about what the person is thinking:

          * the chat window is open — they are in a conversation, and rule 2
            says not while the chat is focused. Open is not the same as
            focused, and the difference resolves towards silence, which is
            the right direction;
          * the camera or the microphone is in use — a call, a recording.
            The single worst moment to be interrupted, and the one Ehsan
            asked for first.

        What is deliberately NOT here: any check for a full-screen window.
        The design says not to interrupt one, and there is no reliable way
        to ask labwc whether a surface is full-screen from a system service.
        A guard that measures something adjacent is worse than no guard,
        because it is believed. The capture check covers the case that
        matters most — a video call — and the rest is honestly missing
        rather than dishonestly approximated.
        """
        busy = []
        try:
            if subprocess.run(["pgrep", "-f", "user-data-dir=/tmp/osprime-chrome"],
                              capture_output=True, timeout=5).returncode == 0:
                busy.append("the chat is open")
        except Exception:
            # Cannot tell, so assume yes. Uncertain resolves to silence.
            busy.append("could not tell whether the chat is open")
        try:
            import system_tools
            state = json.loads(system_tools.capture_state())
            # .get("camera")["in_use"], not .get("camera"). capture_state
            # reports {"camera": {"in_use": false, "by": []}} — a dict, and
            # a dict is truthy, so the obvious version of this line says the
            # camera is in use on a machine with no camera and the assistant
            # goes permanently, inexplicably silent. Read the shape, do not
            # assume it.
            if (state.get("camera", {}).get("in_use")
                    or state.get("microphone", {}).get("in_use")):
                busy.append("the camera or microphone is in use")
        except Exception:
            pass          # no capture info is not a reason to assume a call
        return busy

    def busy(self):
        """Why now is a bad moment, or an empty list if it is not."""
        reasons = []
        try:
            quiet = int(self._config().get("quiet_seconds", QUIET_SECONDS))
        except (TypeError, ValueError):
            quiet = QUIET_SECONDS
        try:
            last = float(self._last_activity() or 0)
        except Exception:
            last = time.time()        # cannot tell -> treat as just now
        if last and time.time() - last < quiet:
            reasons.append("the user was typing a moment ago")
        try:
            reasons += list(self._busy_signals() or [])
        except Exception:
            reasons.append("could not tell what the user is doing")
        return reasons

    # ---- rule 4: a refusal is permanent -----------------------------------
    # The three below are thin wrappers over the module-level functions, so
    # the chat and Settings can record a refusal without holding the live
    # monitor — they run in the web process, the monitor runs in the agent.
    # A refusal is a fact on disk, not a message to a running object.
    def dismiss(self, kind: str) -> bool:
        return dismiss(kind, self.state_path)

    def restore(self, kind: str) -> bool:
        return restore(kind, self.state_path)

    def dismissed(self) -> list:
        return dismissed(self.state_path)

    # ---- rule 5: the budget, and who wins ---------------------------------
    def _spoken_today(self, s: dict) -> int:
        today = self._clock().strftime("%Y-%m-%d")
        return int(s.get("spoken", {}).get(today, 0))

    def _rarity(self, s: dict, kind: str) -> int:
        """How many times this kind has spoken recently. Lower is rarer."""
        cutoff = time.time() - HISTORY_DAYS * 86400
        return len([t for t in s.get("history", {}).get(kind, [])
                    if t >= cutoff])

    def adjudicate(self, candidates):
        """Pick which of this tick's candidates may speak, if any.

        Rule 5: at most two a day, and when more qualify the rarest wins and
        the rest are DROPPED, not queued. Queuing is how a quiet day becomes
        a loud one — the machine saves up and then interrupts five times
        tomorrow morning about things that stopped being true overnight.
        """
        s = self._state()
        refused = set(s.get("dismissed", []))
        allowed = [c for c in candidates
                   if c["kind"] in STAKES and c["kind"] not in refused]
        # Rarest first: something that speaks weekly yields to something
        # that has never spoken, because the rare one is the one carrying
        # information.
        allowed.sort(key=lambda c: self._rarity(s, c["kind"]))
        room = max(0, MAX_PER_DAY - self._spoken_today(s))
        return allowed[:room]

    def _record(self, kind: str) -> bool:
        """Spend one of today's two, and remember it. False means it could
        not be remembered — in which case nothing may be said."""
        s = self._state()
        today = self._clock().strftime("%Y-%m-%d")
        spoken = s.setdefault("spoken", {})
        spoken[today] = int(spoken.get(today, 0)) + 1
        # Yesterday's counts are not evidence of anything. Keep the last few
        # days so a clock that jumps backwards cannot resurrect a budget.
        for day in list(spoken):
            if day < (self._clock() - datetime.timedelta(days=7)
                      ).strftime("%Y-%m-%d"):
                spoken.pop(day, None)
        hist = s.setdefault("history", {}).setdefault(kind, [])
        hist.append(time.time())
        cutoff = time.time() - HISTORY_DAYS * 86400
        s["history"][kind] = [t for t in hist if t >= cutoff]
        return self._save_state(s)

    # ---- what the checks produce ------------------------------------------
    def candidates(self) -> list:
        """Everything that WOULD be worth saying, before any rule is applied.

        Checks return candidates rather than sending. That separation is the
        whole design: a check decides whether something is true, and this
        file alone decides whether it may be said. A check that could notify
        directly would eventually be written by someone who had not read the
        rules.
        """
        out = []
        for check in (self.check_disk,):
            try:
                out += list(check() or [])
            except Exception as e:
                print(f"proactive check error: {e}")
        return out

    def check_disk(self) -> list:
        cfg = self._config()
        threshold = cfg.get("disk_threshold", 85)
        total, used, free = self._disk_usage()
        if not total:
            return []
        pct = used * 100 // total
        if pct < threshold:
            return []
        gb = free / (1024 ** 3)
        return [{"kind": "disk", "text":
                 f"⚠ Your disk is {pct}% full — only {gb:.1f} GB free. "
                 "Want me to find the largest files you haven't opened in a "
                 "while?"}]

    # ---- the user's own alarms, outside all of the above ------------------
    def check_schedules(self):
        """A schedule the user created is not proactivity.

        It is a thing they asked for, at a time they chose. It runs with the
        switch off, it is not counted against the daily budget, and it is
        not subject to the quiet window — a 7am briefing the user set for
        7am is not an interruption at 7am.
        """
        cfg = self._config()
        now = self._clock()
        hhmm = now.strftime("%H:%M")
        today = now.strftime("%Y-%m-%d")
        for i, task in enumerate(cfg.get("schedules", [])):
            # The key identifies the TASK, not just the minute.
            #
            # It was (date, time), so two tasks set for the same time were
            # one key: the first marked the minute done and the second never
            # ran again, on any day. Nothing errored — the user simply had a
            # reminder that silently did not exist.
            #
            # The index is in the key because nothing else identifies a task
            # uniquely: labels can repeat, and prompts can too. It means
            # reordering the list can re-run something already run today,
            # which is the harmless direction — a duplicate reminder against
            # a missing one.
            key = (today, task.get("time"), i, task.get("label", ""))
            if task.get("time") == hhmm and key not in self._done:
                self._done.add(key)
                try:
                    answer = self.run_agent(task["prompt"])
                except Exception as e:
                    answer = f"(scheduled task failed: {e})"
                label = task.get("label", "scheduled task")
                self.notify({"kind": "message",
                             "text": f"⏰ {label}:\n{answer}"})

    # ---- the tick ---------------------------------------------------------
    def tick(self):
        try:
            self.check_schedules()
        except Exception as e:
            print(f"proactive schedule error: {e}")

        if not self.enabled():          # rule 7
            return
        if self.busy():                 # rule 2
            return
        chosen = self.adjudicate(self.candidates())   # rules 1, 4, 5
        for c in chosen:
            # Recorded BEFORE sending, and only sent if the record stuck.
            #
            # Both halves matter. Recording first means a notify that raises
            # after delivering cannot let the same warning through again on
            # the next tick — the budget is spent and the message is lost,
            # which is the harmless direction. And refusing to send when the
            # record failed means a machine that cannot remember what it has
            # said does not say anything, instead of saying everything once
            # a minute for ever.
            if not self._record(c["kind"]):
                return
            self.notify({"kind": "message", "text": c["text"],
                         # so the chat can offer "don't tell me this again"
                         # and the refusal can be made permanent
                         "proactive": c["kind"]})

    def loop(self, interval: int = 60):
        while True:
            self.tick()
            time.sleep(interval)

    def start(self):
        threading.Thread(target=self.loop, daemon=True).start()


# --------------------------------------------------------------------------
# Rule 4, standalone: a refusal is permanent.
#
# "Don't tell me this again" means never, not "not for six hours". The user
# said no to disk warnings, so disk warnings are over — undone in Settings,
# never by us and never by an update. This is the rule that separates a
# machine that learns from one that is merely waiting for its cooldown.
#
# Module-level so the web process can record a refusal the moment the user
# clicks it, without a round trip to the agent. A refusal is a fact on disk.
# --------------------------------------------------------------------------

def _state_file(path=None) -> pathlib.Path:
    import paths
    return pathlib.Path(path or paths.proactive_state())


def _load(path=None) -> dict:
    try:
        s = json.loads(_state_file(path).read_text(encoding="utf-8"))
        return s if isinstance(s, dict) else {}
    except Exception:
        return {}


def _store(s: dict, path=None) -> bool:
    p = _state_file(path)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(s, indent=2), encoding="utf-8")
        tmp.replace(p)
        return True
    except Exception:
        return False


def dismiss(kind: str, path=None) -> bool:
    """Stop raising this kind of thing. For good."""
    if kind not in STAKES:
        return False
    s = _load(path)
    s["dismissed"] = sorted(set(s.get("dismissed", [])) | {kind})
    return _store(s, path)


def restore(kind: str, path=None) -> bool:
    """Undo a refusal. Settings calls this; nothing else may — a refusal
    that the machine can reverse on its own is not a refusal."""
    s = _load(path)
    s["dismissed"] = [k for k in s.get("dismissed", []) if k != kind]
    return _store(s, path)


def dismissed(path=None) -> list:
    return list(_load(path).get("dismissed", []))


def add_schedule(config_path, time_str: str, prompt: str, label: str = "") -> bool:
    p = pathlib.Path(config_path)
    try:
        cfg = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    cfg.setdefault("schedules", []).append(
        {"time": time_str, "prompt": prompt, "label": label or prompt[:30]})
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return True
