#!/usr/bin/env python3
"""Step 0 of docs/MODELS.md: where can a vision model live on this machine?

For every vision model on disk and every place it could run — the NVIDIA
card, the Intel GPU inside the processor, the CPU — this starts a temporary
engine on a spare port, measures, and shuts it down again. It changes
nothing: no service is stopped, no setting is written, nothing is
downloaded. The conversation keeps working throughout, only slower while a
test is running.

What it measures, and why each one:

  load       seconds until the engine answers — what a user would wait if
             vision were loaded only when needed
  describe   seconds to describe one photo — what a user waits every time
  RAM left   free system memory with it loaded — the Intel GPU has no
             memory of its own, so it spends this too
  NVIDIA     memory in use on the card, next to the main engine
  main       the main engine's speed while the photo is being described —
             the point of the whole design is that it must not suffer

The result goes to ~/osprime-model-measure.txt.
"""

import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request

MODELS = pathlib.Path(os.environ.get("OSPRIME_MODELS", "/var/lib/osprime/models"))
MAIN = os.environ.get("OSPRIME_MAIN_URL", "http://127.0.0.1:8087")
PORT = int(os.environ.get("OSPRIME_MEASURE_PORT", "8093"))
BIN = shutil.which("llama-server") or shutil.which("llama-cpp-server")
LOAD_LIMIT = 300
DESCRIBE_LIMIT = 300

VISION = [  # (label, model file, projector names to try, in order)
    ("Qwen2.5-VL 3B", "Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf",
     ["vision-medium.mmproj-F16.gguf", "mmproj-F16.gguf"]),
    ("Qwen2.5-VL 7B", "Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf",
     ["vision-large.mmproj-F16.gguf", "mmproj-F16.gguf"]),
]
TEXT_7B = "qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf"

out_lines = []


def say(line=""):
    print(line, flush=True)
    out_lines.append(line)


def http(url, body=None, timeout=10):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, json.loads(r.read() or b"{}")


def ram_free_gb():
    for line in open("/proc/meminfo"):
        if line.startswith("MemAvailable:"):
            return int(line.split()[1]) / 1024 / 1024
    return 0.0


def nvidia_used_gb():
    if not shutil.which("nvidia-smi"):
        return None
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=memory.used",
                              "--format=csv,noheader,nounits"],
                             capture_output=True, text=True, timeout=10).stdout
        return int(out.strip().splitlines()[0]) / 1024
    except Exception:
        return None


def help_has(flag):
    try:
        h = subprocess.run([BIN, "--help"], capture_output=True, text=True,
                           timeout=20)
        return flag in (h.stdout + h.stderr)
    except Exception:
        return False


def devices():
    """What llama.cpp itself can see. Its answer, not ours."""
    if not help_has("--list-devices"):
        return None
    r = subprocess.run([BIN, "--list-devices"], capture_output=True, text=True,
                       timeout=60)
    found = []
    for line in (r.stdout + r.stderr).splitlines():
        m = re.match(r"\s*([A-Za-z]+\d+)\s*:\s*(.+)", line)
        if m and not m.group(1).lower().startswith("available"):
            found.append((m.group(1), m.group(2).strip()))
    return found


def main_speed():
    """Tokens per second from the main engine, as it reports them."""
    try:
        _, r = http(f"{MAIN}/completion",
                    {"prompt": "Write two sentences about the sea.",
                     "n_predict": 48, "cache_prompt": False}, timeout=120)
        return r.get("timings", {}).get("predicted_per_second")
    except Exception:
        return None


def test_image():
    home = pathlib.Path(os.path.expanduser("~"))
    for folder in (home / "Pictures" / "Camera", home / "Pictures"):
        pics = sorted([p for p in folder.glob("*")
                       if p.suffix.lower() in (".jpg", ".jpeg", ".png")],
                      key=lambda p: p.stat().st_mtime, reverse=True)
        if pics:
            return pics[0]
    made = pathlib.Path("/tmp/osprime-measure.png")
    if shutil.which("magick"):
        subprocess.run(["magick", "-size", "640x480", "xc:skyblue", "-fill",
                        "red", "-draw", "circle 320,240 320,140", str(made)],
                       capture_output=True)
    return made if made.exists() else None


def run_one(label, model, proj, place, flags, image):
    size_gb = (model.stat().st_size + proj.stat().st_size) / 1024 ** 3
    if place != "NVIDIA" and ram_free_gb() < size_gb + 1.5:
        return {"result": f"skipped — needs {size_gb + 1.5:.1f} GB free RAM, "
                          f"{ram_free_gb():.1f} GB free"}
    log = pathlib.Path(f"/tmp/osprime-measure-{PORT}.log")
    cmd = [BIN, "-m", str(model), "--mmproj", str(proj), "--host", "127.0.0.1",
           "--port", str(PORT), "--ctx-size", "4096"] + flags
    t0 = time.time()
    proc = subprocess.Popen(cmd, stdout=open(log, "w"), stderr=subprocess.STDOUT)
    try:
        while time.time() - t0 < LOAD_LIMIT:
            if proc.poll() is not None:
                text = log.read_text(errors="replace")
                why = "exited while loading"
                if re.search(r"mismatch|n_embd", text):
                    why = "the projector file does not belong to this model"
                elif re.search(r"out of memory|failed to allocate|OOM", text, re.I):
                    why = "does not fit in memory"
                return {"result": why}
            try:
                if http(f"http://127.0.0.1:{PORT}/health", timeout=2)[0] == 200:
                    break
            except Exception:
                pass
            time.sleep(1)
        else:
            return {"result": f"did not finish loading in {LOAD_LIMIT}s"}
        load = time.time() - t0
        ram, nv = ram_free_gb(), nvidia_used_gb()

        import base64, mimetypes
        mime = mimetypes.guess_type(str(image))[0] or "image/jpeg"
        b64 = base64.b64encode(image.read_bytes()).decode()
        body = {"model": "local", "temperature": 0, "max_tokens": 96,
                "messages": [{"role": "user", "content": [
                    {"type": "text", "text": "Describe this photo in two sentences."},
                    {"type": "image_url",
                     "image_url": {"url": f"data:{mime};base64,{b64}"}}]}]}
        main_during = {}
        th = threading.Thread(target=lambda: main_during.update(v=main_speed()))
        t1 = time.time()
        th.start()
        try:
            _, r = http(f"http://127.0.0.1:{PORT}/v1/chat/completions", body,
                        timeout=DESCRIBE_LIMIT)
            answer = r["choices"][0]["message"]["content"].strip()
        except Exception as e:
            th.join(120)
            return {"load": load, "ram": ram, "nv": nv,
                    "result": f"could not describe the photo ({type(e).__name__})"}
        describe = time.time() - t1
        th.join(120)
        return {"load": load, "describe": describe, "ram": ram, "nv": nv,
                "main": main_during.get("v"), "answer": answer}
    finally:
        proc.terminate()
        try:
            proc.wait(20)
        except subprocess.TimeoutExpired:
            proc.kill()
        time.sleep(2)


def main():
    say(f"OSprime model measurement — {time.strftime('%Y-%m-%d %H:%M')}")
    say("docs/MODELS.md, step 0. Nothing on this machine was changed.")
    say()
    if not BIN:
        say("No llama-server on this machine. Nothing to measure.")
        return
    image = test_image()
    if not image:
        say("No photo to test with, and ImageMagick could not make one.")
        return
    say(f"Test photo: {image}")
    say(f"Text 7B on disk (the planned main model): "
        f"{'yes' if (MODELS / TEXT_7B).is_file() else 'NO — step 2 needs it downloaded'}")
    base = main_speed()
    say(f"Main engine now: {f'{base:.1f} tokens/s' if base else 'not answering'}"
        f" | RAM free {ram_free_gb():.1f} GB"
        + (f" | NVIDIA in use {nvidia_used_gb():.1f} GB" if nvidia_used_gb() is not None else ""))
    say()

    devs = devices()
    places = []
    if devs is None:
        say("This llama.cpp build cannot list its devices; testing the CPU only.")
    else:
        say("Devices llama.cpp can see: "
            + (", ".join(f"{d} ({n})" for d, n in devs) or "none besides the CPU"))
        for d, n in devs:
            if d.upper().startswith("CUDA"):
                places.append(("NVIDIA", ["--n-gpu-layers", "99", "--device", d]))
        intel = [(d, n) for d, n in devs if "intel" in n.lower()]
        for d, n in intel[:1]:
            places.append(("Intel GPU", ["--n-gpu-layers", "99", "--device", d]))
        if not intel:
            say("  No Intel GPU in that list. The engine needs its Vulkan backend "
                "for it; see which package provides it with:  pacman -Ssq ggml")
    cpu = ["--n-gpu-layers", "0"] + (["--device", "none"] if devs is not None else [])
    places.append(("CPU", cpu))
    say()

    rows = []
    for label, fname, projs in VISION:
        model = MODELS / fname
        if not model.is_file():
            say(f"{label}: not on disk — skipped")
            continue
        proj = next((MODELS / p for p in projs if (MODELS / p).is_file()), None)
        if not proj:
            say(f"{label}: no projector file on disk — skipped")
            continue
        for place, flags in places:
            say(f"testing {label} on {place} …")
            r = run_one(label, model, proj, place, flags, image)
            rows.append((label, place, proj.name, r))
            say("   " + (r.get("result") or
                         f"load {r['load']:.0f}s, describe {r['describe']:.0f}s"))

    say()
    say("RESULTS")
    say(f"{'model':15} {'where':10} {'load':>6} {'describe':>9} {'RAM left':>9} "
        f"{'NVIDIA':>7} {'main t/s':>9}")
    for label, place, proj, r in rows:
        if "describe" not in r:
            say(f"{label:15} {place:10} {r['result']}")
            continue
        nv = f"{r['nv']:.1f}G" if r.get("nv") is not None else "-"
        mn = f"{r['main']:.1f}" if r.get("main") else "-"
        say(f"{label:15} {place:10} {r['load']:5.0f}s {r['describe']:8.0f}s "
            f"{r['ram']:8.1f}G {nv:>7} {mn:>9}")
    say(f"(main engine alone: {f'{base:.1f}' if base else '-'} tokens/s)")
    say()
    say("What each one said about the photo:")
    for label, place, proj, r in rows:
        if r.get("answer"):
            say(f"  {label} on {place} ({proj}): {r['answer'][:160]}")
    if any("projector" in (r.get("result") or "") for _, _, _, r in rows):
        say()
        say("NOTE: a projector file belonged to the other vision model. Until "
            "24 September both were saved as mmproj-F16.gguf in one folder, so "
            "installing the second kept the first one's. Fixed for new "
            "installs; this machine needs the right file downloaded, which is "
            "step 2's job, not this script's.")
    say()
    say("The rule agreed in docs/MODELS.md: the fastest place where describing "
        "a photo takes under about 20 seconds, the main engine does not slow "
        "down, and at least 4 GB of RAM stays free.")


if __name__ == "__main__":
    try:
        main()
    finally:
        dest = pathlib.Path(os.path.expanduser("~")) / "osprime-model-measure.txt"
        dest.write_text("\n".join(out_lines) + "\n", encoding="utf-8")
        print(f"\nSaved to {dest}")
