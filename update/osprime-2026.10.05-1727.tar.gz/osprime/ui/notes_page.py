"""The Notes app — ~/Memory, the person's notes and the assistant's memory
in one place (agent/vault.py). Asked for by Ehsan, 4 October: "like
Obsidian", a simple built-in app whose folder Obsidian can also open.

Served by web.py at /notes, opened as its own window by
shell/osprime-notes.sh. Plain Markdown on disk; this page only reads and
writes files through /api/notes/*, which go through agent/vault.py.

What it does: a list of notes (About me first, then People, Projects,
Places, the rest, the Journal newest first), search, an editor that saves
by itself, a reading view where [[links]] are clickable, completion when
typing [[, and "Linked from" — the notes that point here. A paired phone
gets the same page read-only.

Every name and every line is put on the page with textContent or through
esc(): a note says whatever its author wrote, and the assistant writes too.
"""

PAGE = r"""<!DOCTYPE html>
<html lang="{{LANG}}" dir="ltr">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Notes — OSprime</title>
<style>
  :root { --bg:#0d1117; --panel:#161b22; --line:#21262d; --text:#e6edf3;
          --dim:#8b949e; --accent:#2d6cdf; --link:#7aa2f7; --missing:#8b949e; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--text); height:100vh;
         display:flex; flex-direction:column;
         font-family:system-ui,'Noto Sans','Noto Sans Arabic',sans-serif; }
  header { padding:10px 16px; background:var(--panel); border-bottom:1px solid var(--line);
           display:flex; align-items:center; gap:10px; }
  header .logo { font-size:17px; font-weight:700; color:var(--accent); }
  header .sub { color:var(--dim); font-size:12px; flex:1; }
  button { background:#21262d; color:var(--text); border:1px solid #30363d; border-radius:7px;
           padding:5px 12px; font-size:13px; cursor:pointer; }
  button:hover { background:#2a313c; }
  button.primary { background:var(--accent); border-color:var(--accent); color:#fff; }
  button:disabled { opacity:.5; cursor:default; }
  #body { flex:1; display:flex; min-height:0; }
  aside { width:260px; flex:none; background:var(--panel); border-inline-end:1px solid var(--line);
          display:flex; flex-direction:column; min-height:0; }
  #search { margin:10px; padding:7px 10px; border-radius:7px; border:1px solid #30363d;
            background:var(--bg); color:var(--text); font-size:13px; }
  #list { flex:1; overflow-y:auto; padding:0 6px 10px; }
  .group { color:var(--dim); font-size:11px; text-transform:uppercase; letter-spacing:.05em;
           margin:12px 8px 4px; cursor:pointer; user-select:none; }
  .item { padding:6px 10px; border-radius:6px; font-size:13px; cursor:pointer;
          white-space:nowrap; overflow:hidden; text-overflow:ellipsis; unicode-bidi:plaintext; }
  .item:hover { background:#1c2330; }
  .item.on { background:var(--accent); color:#fff; }
  .item .line { display:block; color:var(--dim); font-size:11px; overflow:hidden; text-overflow:ellipsis; }
  .item.on .line { color:#dde6ff; }
  main { flex:1; display:flex; flex-direction:column; min-width:0; }
  #bar { display:flex; align-items:center; gap:8px; padding:10px 18px; border-bottom:1px solid var(--line); }
  #title { flex:1; font-size:18px; font-weight:600; unicode-bidi:plaintext; cursor:text;
           white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  #state { color:var(--dim); font-size:12px; }
  #pane { flex:1; display:flex; min-height:0; }
  #edit { flex:1; resize:none; border:0; outline:none; background:var(--bg); color:var(--text);
          padding:18px 22px; font:14px/1.6 ui-monospace,Consolas,'Noto Sans Mono','Noto Sans Arabic',monospace;
          unicode-bidi:plaintext; }
  #view { flex:1; overflow-y:auto; padding:18px 26px; font-size:15px; line-height:1.65; }
  #view p, #view li, #view h1, #view h2, #view h3 { unicode-bidi:plaintext; }
  #view h1 { font-size:22px; } #view h2 { font-size:18px; } #view h3 { font-size:16px; }
  #view code { background:#1c2330; padding:1px 5px; border-radius:4px; font-size:13px; }
  #view pre { background:#1c2330; padding:10px 12px; border-radius:8px; overflow-x:auto; }
  #view a, .wl { color:var(--link); cursor:pointer; text-decoration:none; }
  .wl.missing { color:var(--missing); border-bottom:1px dashed var(--missing); }
  #view ul { padding-inline-start:22px; }
  #side { width:250px; flex:none; border-inline-start:1px solid var(--line); overflow-y:auto;
          padding:14px; font-size:13px; }
  #side h3 { font-size:12px; color:var(--dim); text-transform:uppercase; letter-spacing:.05em; margin:0 0 8px; }
  #side .bl { padding:6px 8px; border-radius:6px; cursor:pointer; margin-bottom:4px; background:#161b22; }
  #side .bl .t { color:var(--link); } #side .bl .l { color:var(--dim); font-size:12px; unicode-bidi:plaintext; }
  #empty { margin:auto; color:var(--dim); text-align:center; max-width:420px; line-height:1.6; }
  #complete { position:fixed; display:none; background:var(--panel); border:1px solid #30363d;
              border-radius:8px; box-shadow:0 8px 24px #0008; max-height:220px; overflow-y:auto;
              min-width:200px; z-index:10; }
  #complete div { padding:6px 12px; font-size:13px; cursor:pointer; unicode-bidi:plaintext; }
  #complete div.on, #complete div:hover { background:var(--accent); color:#fff; }
  #toast { position:fixed; bottom:16px; left:50%; transform:translateX(-50%); background:#21262d;
           border:1px solid #30363d; padding:8px 14px; border-radius:8px; font-size:13px; display:none; }
  .ro #edit, .ro #editbtn, .ro #newbtn, .ro #delbtn { display:none; }
</style>
<header>
  <span class="logo">Notes</span>
  <span class="sub" id="where">~/Memory</span>
  <button id="newbtn" class="primary">New note</button>
</header>
<div id="body">
  <aside>
    <input id="search" placeholder="Search notes" autocomplete="off">
    <div id="list"></div>
  </aside>
  <main>
    <div id="bar">
      <div id="title"></div>
      <span id="state"></span>
      <button id="editbtn">Edit</button>
      <button id="delbtn" title="Move this note to the trash">Delete</button>
    </div>
    <div id="pane">
      <div id="empty">Choose a note on the left, or make a new one.<br><br>
        This is your memory and the assistant's: what it keeps about you is
        written here, and what you write here it knows. Link notes with
        <b>[[a name]]</b>.</div>
      <textarea id="edit" spellcheck="false" style="display:none" dir="auto"></textarea>
      <div id="view" style="display:none" dir="auto"></div>
      <div id="side" style="display:none">
        <h3>Linked from</h3><div id="backlinks"></div>
        <h3 style="margin-top:16px">Links to</h3><div id="links"></div>
      </div>
    </div>
  </main>
</div>
<div id="complete"></div>
<div id="toast"></div>
<script>
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c =>
  ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
let NOTES = [], CUR = null, MTIME = 0, DIRTY = false, EDITING = false, RO = false, timer = null;

function toast(msg, ms = 2600) {
  const t = $("toast"); t.textContent = msg; t.style.display = "block";
  clearTimeout(t._h); t._h = setTimeout(() => t.style.display = "none", ms);
}
async function api(path, body) {
  const opt = body === undefined ? {} : {method: "POST",
    headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)};
  return (await fetch(path, opt)).json();
}

// ---- the list ---------------------------------------------------------
const ORDER = ["", "People", "Projects", "Places"];
async function loadList() {
  const d = await api("/api/notes");
  NOTES = d.notes || [];
  if (d.root) $("where").textContent = d.root + " — plain Markdown; Obsidian can open this folder too";
  drawList();
}
function drawList() {
  const q = $("search").value.trim();
  if (q) return searchList(q);
  const box = $("list"); box.textContent = "";
  const groups = {};
  for (const n of NOTES) (groups[n.folder] = groups[n.folder] || []).push(n);
  const names = Object.keys(groups).sort((a, b) => {
    const ia = ORDER.indexOf(a), ib = ORDER.indexOf(b);
    if (a === "Journal") return 1; if (b === "Journal") return -1;
    return (ia < 0 ? 9 : ia) - (ib < 0 ? 9 : ib) || a.localeCompare(b);
  });
  for (const g of names) {
    let items = groups[g];
    if (g === "Journal") items = items.slice().sort((a, b) => b.title.localeCompare(a.title));
    else items = items.slice().sort((a, b) => a.title === "About me" ? -1 : b.title === "About me" ? 1
                                     : a.title.localeCompare(b.title));
    const h = document.createElement("div"); h.className = "group";
    h.textContent = g || "Notes";
    box.append(h);
    const wrap = document.createElement("div");
    if (g === "Journal" && items.length > 7) {
      wrap.dataset.more = "1";
      h.textContent += " (" + items.length + ")";
    }
    items.forEach((n, i) => {
      const it = itemEl(n.title, "", n.path);
      if (wrap.dataset.more && i >= 7) it.style.display = "none";
      wrap.append(it);
    });
    h.onclick = () => wrap.querySelectorAll(".item").forEach(e => e.style.display = "");
    box.append(wrap);
  }
}
function itemEl(title, line, path) {
  const it = document.createElement("div");
  it.className = "item" + (CUR === path ? " on" : "");
  it.textContent = title;
  if (line) { const l = document.createElement("span"); l.className = "line"; l.textContent = line; it.append(l); }
  it.onclick = () => openNote(path);
  return it;
}
async function searchList(q) {
  const d = await api("/api/notes/search?q=" + encodeURIComponent(q));
  const box = $("list"); box.textContent = "";
  if (!(d.results || []).length) {
    const e = document.createElement("div"); e.className = "group"; e.textContent = "Nothing found";
    box.append(e); return;
  }
  for (const r of d.results) box.append(itemEl(r.title, r.line, r.path));
}
$("search").oninput = () => { clearTimeout($("search")._t); $("search")._t = setTimeout(drawList, 200); };

// ---- one note -------------------------------------------------------------
async function openNote(path, edit) {
  if (DIRTY && !(await save())) return;
  const d = await api("/api/notes/read?path=" + encodeURIComponent(path));
  if (!d.ok) { toast(d.message || "Could not open it"); return; }
  CUR = d.path; MTIME = d.mtime; DIRTY = false;
  location.hash = encodeURIComponent(CUR);
  $("empty").style.display = "none"; $("side").style.display = "";
  $("title").textContent = d.title;
  $("edit").value = d.text;
  $("state").textContent = "";
  drawSide(d);
  setMode(!RO && (edit || false));
  drawList();
}
function drawSide(d) {
  const bl = $("backlinks"); bl.textContent = "";
  if (!d.backlinks.length) bl.append(dimText("No note links here yet."));
  for (const b of d.backlinks) {
    const e = document.createElement("div"); e.className = "bl";
    const t = document.createElement("div"); t.className = "t"; t.textContent = b.title;
    const l = document.createElement("div"); l.className = "l"; l.textContent = b.line;
    e.append(t, l); e.onclick = () => openNote(b.path); bl.append(e);
  }
  const lk = $("links"); lk.textContent = "";
  if (!d.links.length) lk.append(dimText("None."));
  for (const l of d.links) {
    const e = document.createElement("div"); e.className = "bl";
    const t = document.createElement("span"); t.className = "wl" + (l.exists ? "" : " missing");
    t.textContent = l.title; e.append(t); e.onclick = () => follow(l.title); lk.append(e);
  }
}
function dimText(s) { const e = document.createElement("div"); e.style.color = "var(--dim)"; e.textContent = s; return e; }

function setMode(edit) {
  EDITING = edit;
  $("edit").style.display = edit ? "" : "none";
  $("view").style.display = edit ? "none" : "";
  $("editbtn").textContent = edit ? "Done" : "Edit";
  if (!edit) render();
  else $("edit").focus();
}
$("editbtn").onclick = async () => { if (EDITING && DIRTY) await save(); setMode(!EDITING); };
$("view").ondblclick = () => { if (!RO) setMode(true); };

// ---- Markdown, small and safe: everything escaped first --------------------
function inline(s) {
  s = esc(s);
  s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
  s = s.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>").replace(/(^|[^*])\*([^*\s][^*]*)\*/g, "$1<i>$2</i>");
  s = s.replace(/\[\[([^\]|#]+)(?:#[^\]|]*)?(?:\|([^\]]+))?\]\]/g, (m, t, label) => {
    const exists = NOTES.some(n => n.title.toLowerCase() === t.trim().toLowerCase());
    return '<span class="wl' + (exists ? "" : " missing") + '" data-note="' + t.trim() + '">' +
           (label || t) + "</span>";
  });
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a data-url="$2">$1</a>');
  return s;
}
function render() {
  let text = $("edit").value.replace(/^---\n[\s\S]*?\n---\n/, "");
  const out = []; let list = null, code = null;
  for (const line of text.split("\n")) {
    if (code !== null) {
      if (line.startsWith("```")) { out.push("<pre><code>" + esc(code.join("\n")) + "</code></pre>"); code = null; }
      else code.push(line);
      continue;
    }
    if (line.startsWith("```")) { if (list) { out.push("</" + list + ">"); list = null; } code = []; continue; }
    const m = line.match(/^\s*([-*]|\d+\.)\s+(.*)$/);
    if (m) {
      const kind = /\d/.test(m[1]) ? "ol" : "ul";
      if (list !== kind) { if (list) out.push("</" + list + ">"); out.push("<" + kind + ">"); list = kind; }
      out.push("<li>" + inline(m[2]) + "</li>"); continue;
    }
    if (list) { out.push("</" + list + ">"); list = null; }
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) out.push("<h" + h[1].length + ">" + inline(h[2]) + "</h" + h[1].length + ">");
    else if (line.trim()) out.push("<p>" + inline(line) + "</p>");
  }
  if (list) out.push("</" + list + ">");
  if (code !== null) out.push("<pre><code>" + esc(code.join("\n")) + "</code></pre>");
  $("view").innerHTML = out.join("\n") || '<p style="color:var(--dim)">Empty. Double-click to write.</p>';
}
$("view").onclick = async ev => {
  const wl = ev.target.closest(".wl");
  if (wl) return follow(wl.dataset.note);
  const a = ev.target.closest("a[data-url]");
  if (a) { await api("/api/open", {url: a.dataset.url}); }
};
async function follow(title) {
  const n = NOTES.find(n => n.title.toLowerCase() === title.toLowerCase());
  if (n) return openNote(n.path);
  if (RO) { toast("There is no note called " + title + " yet."); return; }
  const r = await api("/api/notes/new", {title});
  if (!r.ok) { toast(r.message); return; }
  await loadList(); openNote(r.path, true);
}

// ---- saving ----------------------------------------------------------------
$("edit").oninput = () => {
  DIRTY = true; $("state").textContent = "Editing…";
  clearTimeout(timer); timer = setTimeout(save, 900);
  complete();
};
async function save(force) {
  if (!CUR || !DIRTY) return true;
  clearTimeout(timer);
  const r = await api("/api/notes/save", {path: CUR, text: $("edit").value, base_mtime: force ? 0 : MTIME});
  if (r.ok) { MTIME = r.mtime; DIRTY = false; $("state").textContent = "Saved"; return true; }
  if (r.conflict) {
    const keep = confirm("This note changed while you were writing — the assistant may have " +
                         "added to it.\n\nOK keeps YOUR version (theirs stays in the history).\n" +
                         "Cancel loads THEIR version.");
    if (keep) return save(true);
    $("edit").value = r.text; MTIME = r.mtime; DIRTY = false; $("state").textContent = "Reloaded";
    if (!EDITING) render();
    return true;
  }
  $("state").textContent = "Not saved: " + (r.message || "error");
  return false;
}
window.addEventListener("beforeunload", () => { if (DIRTY) save(); });

// ---- [[ completion ----------------------------------------------------------
let CHOICES = [], PICK = 0;
function complete() {
  const ta = $("edit"), before = ta.value.slice(0, ta.selectionStart);
  const m = before.match(/\[\[([^\]\n|]*)$/);
  const box = $("complete");
  if (!m) { box.style.display = "none"; return; }
  const q = m[1].toLowerCase();
  CHOICES = NOTES.filter(n => n.folder !== "Journal" && n.title.toLowerCase().includes(q)).slice(0, 8)
                 .map(n => n.title);
  if (m[1] && !CHOICES.some(c => c.toLowerCase() === q)) CHOICES.push(m[1]);
  if (!CHOICES.length) { box.style.display = "none"; return; }
  PICK = 0; box.textContent = "";
  CHOICES.forEach((c, i) => {
    const d = document.createElement("div"); d.textContent = c + (NOTES.some(n => n.title === c) ? "" : "  (new)");
    if (i === 0) d.className = "on";
    d.onmousedown = e => { e.preventDefault(); accept(i); };
    box.append(d);
  });
  const r = ta.getBoundingClientRect();
  box.style.left = (r.left + 30) + "px"; box.style.top = (r.top + 40) + "px";
  box.style.display = "block";
}
function accept(i) {
  const ta = $("edit"), pos = ta.selectionStart, before = ta.value.slice(0, pos);
  const start = before.lastIndexOf("[[") + 2;
  const after = ta.value.slice(pos).replace(/^[^\]\n]*\]\]/, "");
  ta.value = ta.value.slice(0, start) + CHOICES[i] + "]]" + after;
  ta.selectionStart = ta.selectionEnd = start + CHOICES[i].length + 2;
  $("complete").style.display = "none";
  ta.oninput();
}
$("edit").onkeydown = e => {
  const box = $("complete");
  if (box.style.display !== "block") return;
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault();
    PICK = (PICK + (e.key === "ArrowDown" ? 1 : CHOICES.length - 1)) % CHOICES.length;
    [...box.children].forEach((c, i) => c.className = i === PICK ? "on" : "");
  } else if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); accept(PICK); }
  else if (e.key === "Escape") box.style.display = "none";
};

// ---- new, rename, delete ----------------------------------------------------
$("newbtn").onclick = async () => {
  const title = prompt("Name of the new note (a person's name goes into People/ if you start it with @):");
  if (!title) return;
  const person = title.startsWith("@");
  const r = await api("/api/notes/new", {title: person ? title.slice(1) : title, folder: person ? "People" : ""});
  if (!r.ok) { toast(r.message); return; }
  await loadList(); openNote(r.path, true);
};
$("title").ondblclick = async () => {
  if (RO || !CUR) return;
  const old = $("title").textContent;
  const t = prompt("Rename this note. Links to it in other notes are updated too.", old);
  if (!t || t === old) return;
  if (DIRTY && !(await save())) return;
  const r = await api("/api/notes/rename", {path: CUR, title: t});
  if (!r.ok) { toast(r.message); return; }
  toast(r.relinked ? "Renamed, and " + r.relinked + " note(s) updated" : "Renamed");
  await loadList(); openNote(r.path);
};
$("delbtn").onclick = async () => {
  if (!CUR || !confirm("Move “" + $("title").textContent + "” to the trash?")) return;
  const r = await api("/api/notes/delete", {path: CUR});
  toast(r.message || "Deleted");
  CUR = null; DIRTY = false; location.hash = "";
  ["edit", "view", "side"].forEach(i => $(i).style.display = "none");
  $("empty").style.display = ""; $("title").textContent = "";
  loadList();
};

// ---- keeping up with the assistant ---------------------------------------------
// When it writes to the note that is open and you have not changed it,
// show its version.
setInterval(async () => {
  if (document.hidden) return;
  const before = NOTES.length;
  await loadList();
  const n = NOTES.find(n => n.path === CUR);
  if (n && !DIRTY && Math.abs(n.mtime - MTIME) > 0.001) openNote(CUR, EDITING);
  else if (NOTES.length !== before) drawList();
}, 8000);

(async () => {
  try {
    const who = await api("/api/remote/whoami");
    RO = !!who.remote;
  } catch (e) { RO = false; }
  if (RO) document.body.classList.add("ro");
  await loadList();
  const want = decodeURIComponent(location.hash.slice(1));
  if (want) openNote(want);
  else { const about = NOTES.find(n => n.title === "About me"); if (about) openNote(about.path); }
})();
</script>
"""
