"""Run a shell command without letting its output fill the memory.

subprocess.run(capture_output=True) keeps EVERYTHING a command prints until
it ends, and only then was it cut to 8,000 characters (review, 17 October:
an 8-million-character output reached the cutting whole). Here the output is
read as it comes and only the last KEEP bytes are held; the beginning is
dropped as it is read. Used by run_shell and by background jobs.
"""
import os
import select
import signal
import subprocess
import time

KEEP = 64 * 1024          # the tail kept; callers show at most 8,000 characters of it


def run(cmd: str, timeout: int, env=None, cwd=None, keep: int = KEEP):
    """-> (exit code, text, dropped bytes). Exit code 124 on timeout."""
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL, env=env, cwd=cwd, start_new_session=True)
    buf = bytearray()
    dropped = 0
    deadline = time.monotonic() + timeout
    fd = p.stdout.fileno()
    timed_out = False
    try:
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                timed_out = True
                break
            ready, _, _ = select.select([fd], [], [], min(left, 1.0))
            if not ready:
                if p.poll() is not None:
                    # Exited; whatever is left in the pipe is read next round.
                    ready = [fd]
                else:
                    continue
            chunk = os.read(fd, 65536)
            if not chunk:
                break
            buf += chunk
            if len(buf) > keep:
                dropped += len(buf) - keep
                del buf[:len(buf) - keep]
    finally:
        if timed_out or p.poll() is None:
            try:
                os.killpg(p.pid, signal.SIGKILL)     # the whole group: shell and children
            except OSError:
                pass
        try:
            p.stdout.close()
        except OSError:
            pass
        p.wait()
    text = buf.decode("utf-8", "replace")
    if dropped:
        text = f"[… {dropped:,} earlier bytes of output not kept …]\n" + text
    if timed_out:
        return 124, text + f"\n[stopped after {timeout} s]", dropped
    return p.returncode, text, dropped
