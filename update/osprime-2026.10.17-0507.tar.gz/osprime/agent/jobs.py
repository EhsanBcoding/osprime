"""OSprime background jobs: run long shell tasks async, track status,
and queue a notification when each finishes."""

import os
import subprocess
import threading

import permissions
import time
import uuid


class JobManager:
    def __init__(self, on_finish=None):
        self._jobs = {}
        self._lock = threading.Lock()
        self._notifications = []
        self._on_finish = on_finish  # optional callback(job)

    MAX_RUNNING = 4           # at once (review, 17 October: no limit)
    KEEP_FINISHED = 30        # finished jobs remembered, newest first
    FINISHED_TTL = 24 * 3600  # and for at most a day

    def _prune(self):
        """Under the lock: forget old finished jobs (201 stayed with their output)."""
        now = time.time()
        done = sorted((j for j in self._jobs.values() if j["status"] != "running"),
                      key=lambda j: j.get("finished") or 0, reverse=True)
        for i, j in enumerate(done):
            if i >= self.KEEP_FINISHED or now - (j.get("finished") or now) > self.FINISHED_TTL:
                self._jobs.pop(j["id"], None)
        del self._notifications[:-100]

    def start(self, command: str, label: str = "") -> str:
        with self._lock:
            self._prune()
            if sum(1 for j in self._jobs.values() if j["status"] == "running") >= self.MAX_RUNNING:
                raise RuntimeError(f"{self.MAX_RUNNING} background jobs are already running; "
                                   "wait for one to finish")
        jid = uuid.uuid4().hex[:8]
        job = {
            "id": jid, "command": command, "label": label or command[:40],
            "status": "running", "output": "", "code": None,
            "started": time.time(), "finished": None,
        }
        with self._lock:
            self._jobs[jid] = job
        try:
            import activity       # beside Brainy while it runs (agent/activity.py)
            job["activity"] = activity.begin(job["label"], "job")
        except Exception:
            job["activity"] = None
        threading.Thread(target=self._run, args=(job,), daemon=True).start()
        return jid

    def _run(self, job):
        try:
            # The same environment as run_shell (docs/SECURITY.md #22): programs
            # from the system's folders only, from the person's home.
            try:
                import paths
                import pyenv
                env = pyenv.shell_env(command=job["command"])
                home = str(paths.home())
                cwd = home if os.path.isdir(home) else None
            except Exception:
                env, cwd = {"PATH": "/usr/local/sbin:/usr/local/bin:/usr/bin:/usr/sbin"}, None
            import bounded
            code, text, _ = bounded.run(job["command"], timeout=3600, env=env, cwd=cwd)
            # Redacted when stored (docs/SECURITY.md, #14): job_status
            # returned the raw output, keys and all, to the model.
            out = permissions.redact(text)[-8000:]
            if code == 124:
                out = (out + "\njob timed out after 1h")[-8000:]
        except Exception as e:
            out, code = f"job error: {e}", 1
        with self._lock:
            self._prune()
            job.update(status="done" if code == 0 else "failed",
                       output=out, code=code, finished=time.time())
            self._notifications.append({
                "id": job["id"], "label": job["label"],
                "status": job["status"], "code": code,
            })
        if job.get("activity"):
            try:
                import activity
                activity.end(job["activity"], ok=code == 0)
            except Exception:
                pass
        if self._on_finish:
            try:
                self._on_finish(job)
            except Exception:
                pass

    def status(self, jid: str) -> dict:
        with self._lock:
            job = self._jobs.get(jid)
            return dict(job) if job else {}

    def list(self) -> list:
        with self._lock:
            return [
                {k: j[k] for k in ("id", "label", "status", "code")}
                for j in self._jobs.values()
            ]

    def drain_notifications(self) -> list:
        """Return and clear pending finish-notifications."""
        with self._lock:
            n, self._notifications = self._notifications, []
            return n
