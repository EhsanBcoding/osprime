"""OSprime local inference backend.

Speaks the OpenAI-compatible /v1/chat/completions API, which BOTH
llama.cpp's llama-server and Ollama serve. That means the engine choice
stays swappable and nothing here is locked to one of them.

Why this module exists: router.chat_ollama() could only chat. Every tool
(run_shell, read_file, remember, ...) lived in the Claude path, so an
offline OSprime degraded into a plain chatbot that could not touch the
machine. This gives the local model the same tools.

Small models are unreliable at tool calling, so we use two tiers:
  1. native `tools` parameter, if the server and model support it
  2. a text protocol the model is drilled on, parsed out of the reply

Tier 2 is the safety net that makes 1-3B models usable.
"""

import json
import os
import pathlib
import re
import urllib.error
import urllib.request

# Candidate endpoints, tried in order. llama-server first (leaner, ships
# in the ISO), Ollama second (common on a developer's machine).
# 8087, not 8080 — the OSprime web UI already owns 8080.
ENDPOINTS = [
    os.environ.get("OSPRIME_LOCAL_URL", "http://127.0.0.1:8087/v1"),
    "http://127.0.0.1:11434/v1",
]

MODEL = os.environ.get("OSPRIME_LOCAL_MODEL", "local")
TIMEOUT = int(os.environ.get("OSPRIME_LOCAL_TIMEOUT", "300"))

_ENDPOINT_CACHE = {"url": None}


# --------------------------------------------------------------------------
# endpoint discovery
# --------------------------------------------------------------------------

def _probe(url: str, timeout: float = 1.5) -> bool:
    try:
        urllib.request.urlopen(f"{url}/models", timeout=timeout)
        return True
    except urllib.error.HTTPError:
        return True          # responded, just not with a model list
    except Exception:
        return False


def endpoint(refresh: bool = False):
    """Return the first reachable local endpoint, or None if none is up."""
    if _ENDPOINT_CACHE["url"] and not refresh:
        return _ENDPOINT_CACHE["url"]
    for url in ENDPOINTS:
        if _probe(url):
            _ENDPOINT_CACHE["url"] = url
            return url
    _ENDPOINT_CACHE["url"] = None
    return None


def available() -> bool:
    return endpoint() is not None


def _shrunk(p: pathlib.Path, long_side: int = 1280):
    """The photo at most `long_side` pixels on its long side, as bytes.

    Measured on 24 September (docs/MODELS.md, round 2): a 1920x1080 photo
    costs ~2,700 image tokens, a 12-megapixel phone photo ~15,000 — more
    than the vision engine's whole window. 768 px was fast but called a
    white top "gray"; 1280 keeps the detail and bounds the cost.

    Uses ImageMagick when it is there; otherwise sends the original, which
    is what happened before and still works for ordinary screenshots.
    """
    import shutil
    import subprocess
    import tempfile
    tool = shutil.which("magick") or shutil.which("convert")
    if tool:
        with tempfile.TemporaryDirectory(prefix="osprime-img-") as d:
            out = pathlib.Path(d) / "small.jpg"
            try:
                subprocess.run([tool, str(p), "-auto-orient", "-resize",
                                f"{long_side}x{long_side}>", "-quality", "88",
                                str(out)], capture_output=True, timeout=30)
                if out.is_file() and out.stat().st_size > 0:
                    return out.read_bytes(), "image/jpeg"
            except Exception:
                pass
    import mimetypes
    return p.read_bytes(), (mimetypes.guess_type(str(p))[0] or "image/jpeg")


def _ask_image(url: str, data: bytes, mime: str, ask: str, timeout: int):
    import base64
    b64 = base64.b64encode(data).decode("ascii")
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": [
            {"type": "text", "text": ask},
            {"type": "image_url",
             "image_url": {"url": f"data:{mime};base64,{b64}"}},
        ]}],
        "max_tokens": 400,
    }
    r = _urlpost(url, "/chat/completions", payload, timeout)
    try:
        return (r["choices"][0]["message"]["content"] or "").strip() \
               or "ERROR: the model returned nothing"
    except Exception:
        return "ERROR: the model's answer was not in the expected shape"


def describe_image(path: str, question: str = "",
                   timeout: int = 180) -> str:
    """Ask a model that can see what is in an image.

    Two arrangements (docs/MODELS.md):

    * A separate vision engine is installed (/etc/osprime/vision.env) —
      the normal one from step 2 on. The main engine lends it the graphics
      card: engines.gpu_slot() stops the main engine, starts vision, and
      always brings the main engine back, even when this fails.
    * The main model is itself a vision model — the older single-engine
      setup. The image goes to the same engine the conversation uses.

    Returns a string starting with 'ERROR:' when it cannot be done, and
    that includes the case where nothing can see. A model without a
    projector does not refuse an image: it ignores it and describes
    something plausible instead, which is the worst possible answer. So
    this checks BEFORE asking, rather than trusting whatever comes back.

    The user's own question goes to the vision model with the image, never
    just "describe this": the main model can only pass on what vision saw.
    """
    import engines

    p = pathlib.Path(path)
    if not p.is_file():
        return f"ERROR: there is no file at {path}"

    ask = (question or "").strip() or "Describe what you see in this image."
    cfg = engines.vision_config()
    try:
        # 768 where vision runs on the processor: 26 s against 154 s for a
        # full photo there (MODELS.md, round 2). add-vision writes it.
        data, mime = _shrunk(p, cfg["max_px"] if cfg else 1280)
    except Exception as e:
        return f"ERROR: could not read {path}: {e}"

    if cfg:
        try:
            with engines.gpu_slot() as url:
                return _ask_image(url + "/v1", data, mime, ask, timeout)
        except Exception as e:
            # gpu_slot has already brought the main engine back by now.
            _ENDPOINT_CACHE["url"] = None
            return (f"ERROR: the vision model could not look at it ({e}). "
                    "The conversation is unaffected.")
        finally:
            _ENDPOINT_CACHE["url"] = None     # re-probe the main engine

    if not engines.main_sees():
        return ("ERROR: nothing on this computer can see images. Add a "
                "vision model: sudo bash /opt/osprime/shell/"
                "osprime-add-vision.sh")
    with engines.main_engine():
        url = endpoint()
        if not url:
            return "ERROR: the local model is not running"
        try:
            return _ask_image(url, data, mime, ask, timeout)
        except Exception as e:
            return f"ERROR: the model could not look at it: {e}"


def _urlpost(url: str, path: str, payload: dict, timeout: int):
    req = urllib.request.Request(
        f"{url}{path}", data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def _post(path: str, payload: dict, timeout: int = TIMEOUT):
    """One request to the main engine.

    Inside engines.main_engine(): while a specialist has the graphics card
    the main engine is off, and this waits for it to come back instead of
    failing. Held for this one request only — never around a whole turn —
    so a photo in the middle of a conversation never deadlocks against it.
    """
    import engines
    with engines.main_engine():
        url = endpoint()
        if not url:
            raise RuntimeError("No local model engine is reachable.")
        return _urlpost(url, path, payload, timeout)


# --------------------------------------------------------------------------
# tool schema translation
# --------------------------------------------------------------------------

def to_openai_tools(tools: list) -> list:
    """Convert Anthropic-style tool defs (as used in agent.TOOLS) to OpenAI."""
    return [{
        "type": "function",
        "function": {
            "name": t["name"],
            "description": t.get("description", ""),
            "parameters": t.get("input_schema", {"type": "object", "properties": {}}),
        },
    } for t in tools]


def _protocol_prompt(tools: list) -> str:
    """Tier-2 instructions: teach the model an explicit call format."""
    lines = []
    for t in tools:
        props = t.get("input_schema", {}).get("properties", {})
        lines.append(f"- {t['name']}({', '.join(props)}): {t.get('description', '')[:120]}")
    return (
        "\n\nYou can call tools. To call one, reply with NOTHING but a single "
        "line in this exact format:\n"
        "<tool>{\"name\": \"tool_name\", \"args\": {...}}</tool>\n"
        "Do not explain the call, do not wrap it in code fences, do not invent "
        "results. After you receive the result you may answer normally.\n"
        # The call line is not language. Asked in Persian, a 7B model kept
        # the conversation in Persian — correctly — and "translated" the call
        # into a Persian sentence about the tool instead: "I should use the
        # system_info tool, please instruct me to". It did this three times
        # in a row, including after being told explicitly to do it. Said
        # plainly here, with an example in Persian, because an example in
        # the conversation's own language is what a small model copies.
        "The call line is the same in every language. When the user writes "
        "in Persian or any other language, you still reply with the call "
        "line itself, not a sentence about it, and you do not ask their "
        "permission first — asking you is the permission. For example:\n"
        "User: اطلاعات سیستمم رو بگو\n"
        "You: <tool>{\"name\": \"system_info\", \"args\": {}}</tool>\n"
        "Only after the result arrives do you answer, in their language.\n"
        "Available tools:\n" + "\n".join(lines)
    )


_TOOL_RE = re.compile(r"<tool>\s*(\{.*?\})\s*</tool>", re.S)


def _json_objects(text: str):
    """Every complete {...} in the text, found by counting braces.

    The old code took everything between the FIRST '{' and the LAST '}',
    which is one blob and usually not valid JSON. Qwen2.5-VL answered:

        take_photo{"name": "take_photo", "args": {"camera": "webcam"}}
        <tool>{"name": "take_photo", "args": {"camera": "webcam"}}

    — two calls, one per line, and neither tag closed. The greedy span ran
    from the first brace of line one to the last brace of line two, failed
    to parse, and the whole thing was printed to the user as the answer.

    Counting braces gives each object separately, so a malformed second
    attempt cannot spoil a perfectly good first one. Strings are tracked so
    a '}' inside a value does not end the object early.
    """
    out = []
    depth = start = 0
    in_str = esc = False
    for i, ch in enumerate(text or ""):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            if depth:
                depth -= 1
                if depth == 0:
                    out.append(text[start:i + 1])
    return out


def _as_call(blob: str):
    try:
        obj = json.loads(blob)
    except json.JSONDecodeError:
        return None
    if not isinstance(obj, dict):
        return None
    name = obj.get("name") or obj.get("tool")
    if not isinstance(name, str) or not name:
        return None
    args = obj.get("args") or obj.get("arguments") or obj.get("input") or {}
    if isinstance(args, str):
        try:
            args = json.loads(args)
        except json.JSONDecodeError:
            args = {}
    return (name, args if isinstance(args, dict) else {})


def _named_tag_calls(text: str, names):
    """Find <tool_name>{args}</tool_name>, the format models invent.

    Qwen2.5-VL, asked to take a photo, replied:

        <take_screenshot>{"area": true}</take_screenshot>

    — its own tag scheme, and the JSON has no "name" key because the name
    is the tag. It is a perfectly reasonable format; it simply is not the
    one we asked for.

    Matched ONLY against tools that actually exist. Without that, any
    `<b>{...}</b>` in a reply would become a tool call, which would be a
    far worse bug than the one this fixes.
    """
    found = []
    for name in names:
        for m in re.finditer(r"<" + re.escape(name) + r"\s*>(.*?)</"
                             + re.escape(name) + r"\s*>", text or "", re.S):
            blob = m.group(1).strip()
            args = {}
            if blob:
                try:
                    v = json.loads(blob)
                    args = v if isinstance(v, dict) else {}
                except json.JSONDecodeError:
                    objs = _json_objects(blob)
                    if objs:
                        try:
                            v = json.loads(objs[0])
                            args = v if isinstance(v, dict) else {}
                        except json.JSONDecodeError:
                            args = {}
            found.append((m.span(), name, args))
    return found


def parse_protocol_call(text: str, names=None):
    """Extract a tier-2 tool call from model text. Returns (name, args) or None.

    Forgiving on purpose. A model that means to call a tool and closes the
    tag badly has still told us what it wants, and refusing to read it
    means printing raw JSON at somebody instead of taking their photo.
    Every shape handled here was produced by a model actually running on
    this machine.
    """
    text = text or ""
    known = set(names or ())

    def ok(call):
        # A name we do not have is not a call.
        #
        # The bare-JSON fallback below reads any object with a "name" key,
        # so `<div>{"name":"x"}</div>` in ordinary prose became a call to a
        # tool named "x". Harmless today because the dispatcher rejects it,
        # but it means the model's real answer gets thrown away and
        # replaced by a failed call to nothing. Checked against the real
        # list whenever the caller passes one.
        return call and (not known or call[0] in known)

    # Properly tagged first — that is the shape we asked for.
    for m in _TOOL_RE.finditer(text):
        call = _as_call(m.group(1))
        if ok(call):
            return call
    # A tag named after the tool itself.
    tagged = _named_tag_calls(text, known)
    if tagged:
        tagged.sort(key=lambda t: t[0][0])
        return (tagged[0][1], tagged[0][2])
    # Then any complete JSON object that looks like a call, tagged or not.
    for blob in _json_objects(text):
        call = _as_call(blob)
        if ok(call):
            return call
    return None


def strip_protocol(text: str, names=None) -> str:
    """Remove the call and any now-empty code fence the model wrapped it in.

    Also removes the untagged and half-tagged forms, because whatever the
    parser was willing to read, the user must not be shown. Leaving the raw
    JSON behind was the visible half of the bug above.
    """
    out = _TOOL_RE.sub("", text or "")
    for name in (names or ()):
        out = re.sub(r"<" + re.escape(name) + r"\s*>.*?</"
                     + re.escape(name) + r"\s*>", "", out, flags=re.S)
    for blob in _json_objects(out):
        if _as_call(blob):
            out = out.replace(blob, "")
    out = re.sub(r"<tool>\s*", "", out)
    out = re.sub(r"</tool>\s*", "", out)
    # A bare tool name left on its own line by "take_photo{...}".
    out = re.sub(r"^\s*[a-z_]{3,30}\s*$", "", out, flags=re.M)
    out = re.sub(r"```[a-zA-Z]*\s*```", "", out)
    return out.strip()


def _flatten_for_protocol(messages: list) -> list:
    """Turn OpenAI tool messages into plain conversation.

    The text protocol exists so tools work on a model whose chat template
    knows nothing about them. But the HISTORY was still being sent in the
    OpenAI shape — an assistant turn carrying `tool_calls`, then a message
    with role "tool". Qwen2.5's template converts those into a tool_response
    inside a user turn; Qwen2.5-VL's template has no idea, and renders
    `<|im_start|>tool` with an empty assistant turn before it.

    The result was a model that worked once and then fell apart: after one
    photo it answered "I cannot take photos as I don't have a camera",
    because the turn where it had just taken one had been rendered as
    nonsense it was never trained on.

    So the protocol carries its own history too. Every template can render
    a user turn.
    """
    out = []
    for m in messages:
        role = m.get("role")
        if role == "assistant" and m.get("tool_calls"):
            parts = [m.get("content") or ""]
            for c in m["tool_calls"]:
                fn = c.get("function", {}) or {}
                parts.append("<tool>" + json.dumps(
                    {"name": fn.get("name", ""),
                     "args": _loads(fn.get("arguments"))},
                    ensure_ascii=False) + "</tool>")
            out.append({"role": "assistant",
                        "content": "\n".join(p for p in parts if p)})
        elif role == "tool":
            out.append({"role": "user",
                        "content": f"Result of {m.get('name', 'the tool')}:\n"
                                   f"{m.get('content', '')}"})
        else:
            out.append(m)
    return out


def _loads(raw):
    if isinstance(raw, dict):
        return raw
    try:
        v = json.loads(raw or "{}")
        return v if isinstance(v, dict) else {}
    except (json.JSONDecodeError, TypeError):
        return {}


# --------------------------------------------------------------------------
# chat
# --------------------------------------------------------------------------

def chat(messages: list, system: str, tools: list = None, native: bool = True):
    """One local completion.

    Returns (text, tool_calls) where tool_calls is a list of
    {"id", "name", "args"}. Falls back to the text protocol when the
    server rejects the native `tools` parameter or the model ignores it.
    """
    sys_text = system
    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": sys_text}] + messages,
        "stream": False,
        "temperature": 0.3,
    }

    if tools and native:
        payload["tools"] = to_openai_tools(tools)
        payload["tool_choice"] = "auto"
        try:
            data = _post("/chat/completions", payload)
        except urllib.error.HTTPError:
            # server or model does not understand `tools` -> tier 2
            return chat(messages, system, tools, native=False)
    else:
        if tools:
            payload["messages"][0]["content"] = sys_text + _protocol_prompt(tools)
        # The history goes in a shape every chat template can render, not
        # only the ones that know about tool roles. See _flatten_for_protocol.
        payload["messages"] = ([payload["messages"][0]]
                               + _flatten_for_protocol(payload["messages"][1:]))
        data = _post("/chat/completions", payload)

    choice = (data.get("choices") or [{}])[0]
    msg = choice.get("message", {}) or {}
    text = msg.get("content") or ""

    calls = []
    for c in msg.get("tool_calls") or []:
        fn = c.get("function", {}) or {}
        raw = fn.get("arguments") or "{}"
        try:
            args = json.loads(raw) if isinstance(raw, str) else raw
        except json.JSONDecodeError:
            args = {}
        calls.append({"id": c.get("id", fn.get("name", "call")),
                      "name": fn.get("name", ""),
                      "args": args if isinstance(args, dict) else {}})

    # tier 2: model replied in text even though tools were offered natively
    if not calls and tools:
        names = [t.get("name", "") for t in tools if t.get("name")]
        parsed = parse_protocol_call(text, names)
        if parsed:
            calls = [{"id": "call_0", "name": parsed[0], "args": parsed[1]}]
            text = strip_protocol(text, names)

    # tier 3: the server accepted `tools` and the model ignored them.
    #
    # This gap was found with Qwen2.5-VL. Its chat template contains no
    # tool handling at all — no <tools>, no <tool_call>, nothing — while
    # the text model's template begins with `{%- if tools %}`. So
    # llama-server rendered the prompt with a template that silently drops
    # the tools, the model never saw them, and it answered in prose.
    #
    # Nothing failed. The server returned 200, the answer was fine, and the
    # tool simply never got called. The old code only fell back to the text
    # protocol when the server REJECTED `tools` with an HTTP error, so this
    # case fell through the gap: the parse above looks for a protocol call
    # that was never asked for, because the protocol prompt is only added
    # on the native=False path.
    #
    # One retry, with the protocol actually in the system prompt. That path
    # needs no template support, which is the whole reason it exists.
    if not calls and tools and native:
        return chat(messages, system, tools, native=False)

    return text, calls


def chat_stream(messages: list, system: str, on_delta):
    """Plain streaming chat, no tools — used once the model is done calling."""
    import engines
    with engines.main_engine():
        return _chat_stream(messages, system, on_delta)


def _chat_stream(messages: list, system: str, on_delta):
    url = endpoint()
    if not url:
        raise RuntimeError("No local model engine is reachable.")
    payload = json.dumps({
        "model": MODEL,
        "messages": [{"role": "system", "content": system}] + messages,
        "stream": True,
        "temperature": 0.3,
    }).encode()
    req = urllib.request.Request(
        f"{url}/chat/completions", data=payload,
        headers={"Content-Type": "application/json"})
    out = []
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        for raw in r:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            body = line[5:].strip()
            if body == "[DONE]":
                break
            try:
                delta = json.loads(body)["choices"][0].get("delta", {})
            except (json.JSONDecodeError, KeyError, IndexError):
                continue
            piece = delta.get("content") or ""
            if piece:
                out.append(piece)
                on_delta(piece)
    return "".join(out)
