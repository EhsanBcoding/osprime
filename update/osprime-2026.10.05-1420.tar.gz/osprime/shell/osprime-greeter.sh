#!/usr/bin/env bash
# The login screen: ReGreet in the cage kiosk compositor, with the machine's
# keyboard languages (agent/keyboard.py) so a
# password can be typed in either. English first; Alt+Shift switches —
# here with xkb's own toggle, as the login screen has no panel to keep in
# step. Run by greetd as the greeter user.
# /etc/greetd/osprime-keyboard holds the list, e.g. "en,fa": written by the
# installer and post_install.sh, readable by the greeter user (which cannot
# read /etc/osprime).
LIST="$(head -c 100 /etc/greetd/osprime-keyboard 2>/dev/null | tr -cd 'a-z,-')"
LAYOUT="us"; VARIANT=""
if out="$(python3 /opt/osprime/agent/keyboard.py greeter-env "${LIST:-en}" 2>/dev/null)"; then
    eval "$out"
fi
export XKB_DEFAULT_LAYOUT="$LAYOUT" XKB_DEFAULT_VARIANT="$VARIANT"
case "$LAYOUT" in *,*) export XKB_DEFAULT_OPTIONS="grp:alt_shift_toggle" ;; esac
exec cage -s -- regreet
