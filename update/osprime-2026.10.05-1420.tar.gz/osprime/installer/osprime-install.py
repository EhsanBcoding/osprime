#!/usr/bin/env python3
"""OSprime installer — copies the running live system onto a disk.

Guided and deliberately loud about destructive steps. Run from the live ISO:
    sudo python3 /opt/osprime/installer/osprime-install.py
    sudo python3 ... --dry-run          # show the plan, touch nothing
"""

import argparse
import json
import os
import shutil
import subprocess
import sys

RSYNC_EXCLUDES = [
    "/dev/*", "/proc/*", "/sys/*", "/tmp/*", "/run/*", "/mnt/*", "/media/*",
    "/lost+found", "/var/cache/pacman/pkg/*", "/run/archiso/*",
]

MOUNT = "/mnt/osprime-target"
# The live USB's one desktop icon, and the menu entry that only means
# something there (docs/INSTALL.md). Both removed from every disk.
INSTALL_ICON = "/home/osprime/Desktop/check-system-and-install.desktop"
CHECK_ICON = "/usr/share/osprime/live/osprime-install.desktop"
NAME_RE = r"^[a-z_][a-z0-9_-]{0,30}$"


def sh(cmd, dry=False, check=True):
    print(("[dry] " if dry else "  $ ") + (cmd if isinstance(cmd, str) else " ".join(cmd)))
    if dry:
        return ""
    r = subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"command failed: {cmd}\n{r.stderr.strip()}")
    return r.stdout


def disks_in_use() -> set:
    """Disks holding anything mounted right now — the running system's own
    disk above all. 26 September: the installer was started on an installed
    laptop instead of inside the test VM, and offered that laptop's own
    system disk as a target. Only typing ERASE stood between it and the
    machine's data. A disk with a mounted partition is never offered."""
    busy = set()
    try:
        out = subprocess.run(["lsblk", "-J", "-o", "NAME,PKNAME,MOUNTPOINTS,TYPE"],
                             capture_output=True, text=True, check=True).stdout
        def walk(dev, top):
            mps = [m for m in (dev.get("mountpoints") or []) if m]
            if mps:
                busy.add(top)
            for c in dev.get("children") or []:
                walk(c, top)
        for d in json.loads(out).get("blockdevices", []):
            walk(d, d["name"])
    except Exception:
        pass
    return busy


def list_disks() -> list:
    """Physical disks only — no partitions, loops, the live ISO media, or a
    disk that is in use (disks_in_use)."""
    busy = disks_in_use()
    try:
        out = subprocess.run(
            ["lsblk", "-J", "-b", "-d", "-o", "NAME,SIZE,TYPE,MODEL,RM"],
            capture_output=True, text=True, check=True).stdout
        data = json.loads(out)
    except Exception:
        return []
    disks = []
    for d in data.get("blockdevices", []):
        if d.get("type") != "disk":
            continue
        if d["name"].startswith(("loop", "sr", "ram")) or d["name"] in busy:
            continue
        disks.append({
            "name": d["name"], "path": f"/dev/{d['name']}",
            "size_gb": round(int(d.get("size") or 0) / 1024 ** 3, 1),
            "model": (d.get("model") or "").strip(),
            "removable": bool(int(d.get("rm") or 0)),
        })
    return disks


def is_uefi() -> bool:
    return os.path.isdir("/sys/firmware/efi")


def partition_plan(disk: str, uefi: bool) -> list:
    """Return the sequence of commands that will wipe and lay out the disk."""
    if uefi:
        return [
            f"sgdisk --zap-all {disk}",
            f"sgdisk -n1:0:+512M -t1:ef00 -c1:EFI {disk}",
            f"sgdisk -n2:0:0 -t2:8300 -c2:OSPRIME {disk}",
        ]
    return [
        f"sgdisk --zap-all {disk}",
        f"sgdisk -n1:0:+1M -t1:ef02 -c1:BIOSBOOT {disk}",
        f"sgdisk -n2:0:0 -t2:8300 -c2:OSPRIME {disk}",
    ]


# ---------------------------------------------------------------------------
# encryption — docs/ENCRYPTION.md
# ---------------------------------------------------------------------------
MAPPER = "osprime-root"
# Unlock modes. "tpm" is the default (Ehsan, 26 September): one password —
# the TPM opens the disk, the login screen asks who you are. It does NOT
# stop an "evil maid" who replaces the unencrypted initramfs until Secure
# Boot with our own keys exists (plan C) — the installer says so. "tpm-pin"
# closes that today at the cost of a short PIN at boot. "password" asks for
# the disk password at every boot. "none" is an unencrypted disk.
ENCRYPT_MODES = ("tpm", "tpm-pin", "password", "none")


def has_tpm() -> bool:
    return os.path.exists("/dev/tpmrm0")


def run_secret(cmd: list, secret_env: dict = None, stdin: str = None,
               dry: bool = False, label: str = "") -> str:
    """Run a command that needs a password — given in the environment or on
    stdin, never on the command line, where every process could read it."""
    shown = " ".join(cmd) + (f"  ({label})" if label else "")
    print(("[dry] " if dry else "  $ ") + shown)
    if dry:
        return ""
    env = dict(os.environ, **(secret_env or {}))
    r = subprocess.run(cmd, input=stdin, text=True, capture_output=True, env=env)
    if r.returncode != 0:
        raise RuntimeError(f"command failed: {shown}\n{r.stderr.strip()}")
    return r.stdout


def encrypt_root(part: str, enc: dict, dry: bool = False) -> str:
    """LUKS2 on the root partition, the recovery key, the TPM. Returns the
    recovery key (shown once, by the caller)."""
    pw = enc["password"]
    run_secret(["cryptsetup", "luksFormat", "--type", "luks2", "--batch-mode",
                "--label", "OSPRIME-LUKS", part, "--key-file=-"],
               stdin=pw, dry=dry, label="disk password on stdin")
    run_secret(["cryptsetup", "open", part, MAPPER, "--key-file=-"],
               stdin=pw, dry=dry, label="disk password on stdin")
    # systemd-cryptenroll takes the existing password from $PASSWORD and a
    # new PIN from $NEWPIN — both environment, both only readable by root.
    out = run_secret(["systemd-cryptenroll", "--recovery-key", part],
                     secret_env={"PASSWORD": pw}, dry=dry,
                     label="password in the environment")
    recovery = next((w for w in out.split() if w.count("-") >= 7), "")
    if enc["mode"] in ("tpm", "tpm-pin"):
        cmd = ["systemd-cryptenroll", "--tpm2-device=auto", "--tpm2-pcrs=7", part]
        env = {"PASSWORD": pw}
        if enc["mode"] == "tpm-pin":
            cmd.insert(-1, "--tpm2-with-pin=yes")
            env["NEWPIN"] = enc["pin"]
        run_secret(cmd, secret_env=env, dry=dry, label="secrets in the environment")
    return recovery


SB_SCRIPT = "/opt/osprime/shell/osprime-secureboot.sh"
EFI_GUID = "8be4df61-93ca-11d2-aa0d-00e098032b8c"


def _read(p: str) -> str:
    try:
        return open(p, encoding="utf-8").read()
    except OSError:
        return ""


def firmware_setup_mode(efivars: str = "/sys/firmware/efi/efivars") -> bool:
    """The firmware accepts new Secure Boot keys without asking (Setup
    Mode): true on a VM's fresh firmware, and on a laptop whose keys were
    cleared in its setup screen. Same firmware for the USB and the disk."""
    try:
        with open(f"{efivars}/SetupMode-{EFI_GUID}", "rb") as f:
            return f.read()[4:5] == b"\x01"
    except OSError:
        return False


def setup_secure_boot(enc: dict, dry: bool = False) -> str:
    """docs/ENCRYPTION.md, plan C — the same script Settings uses.

    Always: this computer's own keys, and the kernel, initramfs and command
    line as one signed file. When the firmware is in Setup Mode, the keys go
    in now and Secure Boot finishes by itself at the first start; otherwise
    Settings -> System -> Secure Boot does that later. Returns what to tell
    the person: "now", "later" or "failed".
    """
    cmd = f"arch-chroot {MOUNT} bash {SB_SCRIPT} prepare"
    print(("[dry] " if dry else "  $ ") + cmd)
    if not dry:
        # Not sh(): a failure here must show WHY. 27 September: sh() with
        # check=False kept the script's error to itself, and the only sign
        # was "turn it on later" — with nothing to say what had gone wrong.
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if r.returncode != 0 or "prepared" not in r.stdout:
            print("   Secure Boot could not be prepared; the disk still starts the old way:")
            for line in ((r.stderr or "") + (r.stdout or "")).strip().splitlines()[-8:]:
                print("     " + line)
            return "failed"
    if not dry and not firmware_setup_mode():
        return "later"
    pin = enc.get("pin", "") if enc.get("mode") == "tpm-pin" else ""
    # Line 2, the disk password: the way in if the TPM refuses (the
    # script's stdin protocol — PIN, then disk password).
    diskpw = enc.get("password", "") if enc.get("mode") in ("tpm", "tpm-pin") else ""
    try:
        run_secret(["arch-chroot", MOUNT, "bash", SB_SCRIPT, "enroll"],
                   stdin=pin + "\n" + diskpw + "\n", dry=dry,
                   label="PIN and disk password on stdin" if pin else "disk password on stdin")
    except RuntimeError as e:
        print(f"   Secure Boot keys were not put in the firmware: {e}")
        return "later"
    return "now"


def crypttab_line(uuid: str, mode: str) -> str:
    opts = "tpm2-device=auto" if mode in ("tpm", "tpm-pin") else "luks"
    return f"{MAPPER} UUID={uuid} none {opts}\n"


HOOKS_PLAIN = ("HOOKS=(base udev autodetect microcode modconf kms keyboard "
               "keymap consolefont block filesystems fsck)\n")
# The systemd initramfs: sd-encrypt reads /etc/crypttab.initramfs and knows
# the TPM, the PIN prompt and the recovery key; the busybox `encrypt` hook
# knows none of those.
HOOKS_ENCRYPTED = ("HOOKS=(base systemd autodetect microcode modconf kms keyboard "
                   "sd-vconsole block sd-encrypt filesystems fsck)\n")


def set_hooks(conf: str, hooks_line: str):
    """Replace the HOOKS= line of a mkinitcpio.conf (append if absent)."""
    import re
    try:
        text = open(conf, encoding="utf-8").read()
    except OSError:
        text = ""
    line = hooks_line.strip()
    if re.search(r"^HOOKS=", text, re.M):
        text = re.sub(r"^HOOKS=.*$", line, text, count=1, flags=re.M)
    else:
        text += ("\n" if text and not text.endswith("\n") else "") + line + "\n"
    with open(conf, "w", encoding="utf-8") as f:
        f.write(text)


def initramfs_files(image: str) -> str:
    try:
        return subprocess.run(["lsinitcpio", image], capture_output=True,
                              text=True, timeout=120).stdout
    except Exception:
        return ""


def normalise_key(typed: str) -> str:
    """The key as systemd wrote it: lowercase, 8 groups of 8 joined by '-'.
    Spaces and missing dashes are forgiven — only the letters matter."""
    letters = "".join(ch for ch in typed.lower() if ch.isalpha())
    return "-".join(letters[i:i + 8] for i in range(0, len(letters), 8))


def key_opens(part: str, key: str) -> bool:
    try:
        run_secret(["cryptsetup", "open", "--test-passphrase", part, "--key-file=-"],
                   stdin=key, label="recovery key on stdin")
        return True
    except Exception:
        return False


def show_recovery_key(key: str, dry: bool = False, part: str = "",
                      ask=input, opens=None):
    """Shown once, then typed back IN FULL and tried against the disk.

    26 September, in the test VM: the key opened the disk — but only on the
    second attempt, because a password prompt shows nothing of what is
    typed and 64 letters of i, l, t, f … are easy to misread. The first
    version asked only for the last group, which proves nothing about the
    other seven. Now the whole key is typed here, where it is visible, and
    tested against the real disk; a key written down wrong is found today,
    not on the day the TPM fails."""
    if dry or not key:
        print("[dry] (the recovery key would be shown and tested here)" if dry else
              "!  No recovery key was printed — check the output above.")
        return
    opens = opens or (lambda k: key_opens(part, k))
    print("\n" + "=" * 64)
    print("  YOUR RECOVERY KEY — write it down now and keep it apart from")
    print("  this computer. Without it, a forgotten password or a changed")
    print("  TPM means the data on this disk is gone for good.\n")
    print("    " + key)
    print("\n  Letters only (no digits, no 'o'); i and l are both used — look")
    print("  closely. When you type it at start-up, type the dashes too.")
    print("=" * 64)
    while True:
        typed = normalise_key(ask("\n  Now type the WHOLE key from what you wrote down: "))
        if typed == key and opens(typed):
            print("  It opens the disk. Keep it safe.")
            return
        if typed != key:
            diff = [i + 1 for i, (x, y) in enumerate(zip(typed.split("-"), key.split("-")))
                    if x != y]
            where = (f"group {', '.join(map(str, diff))}" if diff
                     else "its length")
            print(f"  That does not match ({where}). Compare what you wrote down with the key above.")
        else:
            print("  It matches, but the disk did not accept it — please report this.")

def ask_encryption(uefi: bool) -> dict:
    import getpass
    if not uefi:
        print("\nThis computer starts in BIOS mode. OSprime encrypts the disk")
        print("only on UEFI computers; this one will be installed UNENCRYPTED.")
        return {"mode": "none"}
    print("\nThe disk will be encrypted.")
    tpm = has_tpm()
    if tpm:
        print("  1) Unlock with the TPM — only the login password at start (default).")
        print("     Protects the disk if it is taken out. Against someone who tampers")
        print("     with the startup files it also needs Secure Boot with this")
        print("     computer's own keys: set up now if the firmware allows, otherwise")
        print("     from Settings -> System -> Secure Boot after installing.")
        print("  2) TPM + a short PIN at start — protects against that as well.")
        print("  3) A disk password at every start.")
        print("  4) Do not encrypt.")
        choice = input("  Choose [1]: ").strip() or "1"
        mode = {"1": "tpm", "2": "tpm-pin", "3": "password", "4": "none"}.get(choice, "tpm")
    else:
        print("  No TPM on this computer: the disk password is asked at every start.")
        mode = "password" if input("  Encrypt? [Y/n]: ").strip().lower() != "n" else "none"
    if mode == "none":
        return {"mode": "none"}

    def twice(prompt, ok=lambda v: bool(v), why="it cannot be empty."):
        while True:
            v = getpass.getpass(f"  {prompt}: ")
            if not ok(v):
                print(f"  {why}")
                continue
            if v == getpass.getpass("  again: "):
                return v
            print("  the two did not match.")
    enc = {"mode": mode, "password": twice(
        "disk password (needed with the recovery key if the TPM ever refuses)")}
    if mode == "tpm-pin":
        enc["pin"] = twice("PIN for the start (digits, at least 4)",
                           lambda v: v.isdigit() and len(v) >= 4,
                           "digits only, at least 4.")
    return enc


def part_name(disk: str, n: int) -> str:
    """nvme0n1 -> nvme0n1p1 ; sda -> sda1"""
    base = os.path.basename(disk)
    return f"{disk}p{n}" if base[-1].isdigit() else f"{disk}{n}"


def place_kernel(mount: str, dry: bool = False) -> bool:
    """Put vmlinuz where a normal Arch system keeps it.

    On a live archiso, /boot is empty — the kernel was moved into the ISO's
    boot structure at build time. Copying the running root therefore produces
    a target with no kernel, no initramfs, and no way to boot. The kernel
    image is still on disk under /usr/lib/modules/<version>/vmlinuz.
    """
    if dry:
        print(f"[dry] copy /usr/lib/modules/<version>/vmlinuz -> {mount}/boot/vmlinuz-linux")
        return True

    import glob
    candidates = sorted(glob.glob(f"{mount}/usr/lib/modules/*/vmlinuz"))
    if not candidates:
        # last resort: the mounted ISO still has it while we are running
        candidates = sorted(glob.glob("/run/archiso/bootmnt/arch/boot/*/vmlinuz-linux"))
    if not candidates:
        print("  !  no kernel image found — the target will not boot")
        return False

    src = candidates[-1]          # newest version if several are installed
    os.makedirs(f"{mount}/boot", exist_ok=True)
    sh(f"cp -f {src} {mount}/boot/vmlinuz-linux")
    print(f"  kernel placed from {src}")
    return True


def _encryption_checks(mount: str, enc: dict, root_part: str) -> list:
    """What an encrypted disk needs to boot — each silent if missing."""
    dump = ""
    try:
        dump = subprocess.run(["cryptsetup", "luksDump", root_part],
                              capture_output=True, text=True).stdout
    except Exception:
        pass
    def read(p):
        try:
            return open(p, encoding="utf-8").read()
        except OSError:
            return ""
    hooks = read(f"{mount}/etc/mkinitcpio.conf.d/osprime.conf")
    entry = read(f"{mount}/boot/loader/entries/osprime.conf")
    crypttab = read(f"{mount}/etc/crypttab.initramfs")
    checks = [
        ("disk is LUKS2", bool(__import__("re").search(r"^Version:\s*2\s*$", dump, __import__("re").M))),
        ("recovery key enrolled", "systemd-recovery" in dump),
        ("crypttab.initramfs names the disk", MAPPER in crypttab and "UUID=" in crypttab),
        ("initramfs unlocks it (sd-encrypt)", "sd-encrypt" in hooks and "systemd" in hooks),
        ("boot entry uses the unlocked disk", f"/dev/mapper/{MAPPER}" in entry),
    ]
    # What is INSIDE the image, not what the config says — the config was
    # right on 26 September and the image was not.
    image = initramfs_files(f"{mount}/boot/initramfs-linux.img")
    checks.append(("initramfs contains crypttab", "etc/crypttab" in image))
    checks.append(("initramfs contains systemd-cryptsetup", "systemd-cryptsetup" in image))
    if enc.get("mode") in ("tpm", "tpm-pin"):
        checks.append(("TPM enrolled", "systemd-tpm2" in dump))
        checks.append(("initramfs has the TPM libraries", "libtss2" in image))
        checks.append(("crypttab asks the TPM", "tpm2-device=auto" in crypttab))
    return checks


def verify_target(mount: str, dry: bool = False, account: dict = None,
                  enc: dict = None, root_part: str = "") -> bool:
    """Check the installed system before we unmount and reboot into it.

    Every item here is something that fails *silently* — the install looks
    fine, then the laptop boots to a black screen or a mute chat window.
    Better to find out while the ISO is still running.
    """
    if dry:
        print("\n[dry] Final checks skipped.")
        return True

    checks = [
        ("linux kernel", os.path.exists(f"{mount}/boot/vmlinuz-linux")),
        ("initramfs", os.path.exists(f"{mount}/boot/initramfs-linux.img")),
        ("archiso hooks removed",
         not os.path.exists(f"{mount}/etc/mkinitcpio.conf.d/archiso.conf")),
        ("model engine (llama-server)",
         os.path.exists(f"{mount}/usr/bin/llama-server")),
        ("bootstrap model",
         os.path.exists(f"{mount}/var/lib/osprime/models/bootstrap.gguf")),
        ("model service enabled", os.path.exists(
            f"{mount}/etc/systemd/system/multi-user.target.wants/osprime-model.service")),
        ("agent service enabled", os.path.exists(
            f"{mount}/etc/systemd/system/multi-user.target.wants/osprime-agent.service")),
        *([] if not account else [
            ("login screen enabled (greetd)", os.path.lexists(
                f"{mount}/etc/systemd/system/display-manager.service")),
            ("boots to the login screen (graphical.target)",
             os.path.realpath(f"{mount}/etc/systemd/system/default.target")
             .endswith("graphical.target")),
            ("no automatic login", not os.path.exists(
                f"{mount}/etc/systemd/system/getty@tty1.service.d/autologin.conf")),
            ("accounts switched on", os.path.exists(f"{mount}/etc/osprime/accounts")),
            (f"account {account['name']} created",
             os.path.isdir(f"{mount}/home/{account['name']}")),
        ]),
        *([] if not enc or enc.get("mode") == "none" else _encryption_checks(
            mount, enc, root_part)),
        ("the live ISO's password-free sudo is gone",
         not os.path.exists(f"{mount}/etc/sudoers.d/osprime-live")),
        *([] if not os.path.exists(f"{mount}/var/lib/osprime/secureboot.json") else [
            ("signed startup file (Secure Boot)",
             os.path.exists(f"{mount}/boot/EFI/Linux/osprime.efi")),
            ("signed fallback startup file (the way back)",
             os.path.exists(f"{mount}/boot/EFI/Linux/osprime-fallback.efi")),
            ("boot menu starts the signed file",
             "osprime.efi" in _read(f"{mount}/boot/loader/loader.conf")),
        ]),
        ("the live USB's Install icon is gone",
         not os.path.exists(f"{mount}{INSTALL_ICON}")
         and not os.path.exists(f"{mount}{CHECK_ICON}")),
        ("fstab written",
         os.path.getsize(f"{mount}/etc/fstab") > 0
         if os.path.exists(f"{mount}/etc/fstab") else False),
    ]

    print("\n> Verifying the installed system:")
    bad = []
    for label, ok in checks:
        print(f"   {'✅' if ok else '❌'}  {label}")
        if not ok:
            bad.append(label)

    if bad:
        print("\n!  These are broken and the system probably will not boot:")
        for b in bad:
            print(f"     - {b}")
        print("   Fix these before rebooting.")
        return False
    print("   Everything is in place.")
    return True


def service_groups(mount: str) -> list:
    """The supplementary groups the osprime account has on the new disk
    (video, audio, input …), so the person can use the same hardware."""
    groups = []
    try:
        for line in open(f"{mount}/etc/group", encoding="utf-8"):
            parts = line.strip().split(":")
            if len(parts) == 4 and "osprime" in parts[3].split(",") \
                    and parts[0] != "osprime":
                groups.append(parts[0])
    except OSError:
        pass
    return groups


def create_person(mount: str, account: dict, dry: bool = False):
    """The person the computer belongs to: an administrator, with a login.

    docs/ACCOUNTS.md. New machines start where a migrated one ends up: a
    login screen, the person's own account, the osprime account kept for
    the model engine and locked. The switch itself is the same script the
    migration uses (shell/osprime-accounts-lib.sh), so the two cannot drift.
    """
    name, full, password = account["name"], account["full"], account["password"]
    groups = ",".join(service_groups(mount) + ["wheel", "osprime", "osprime-users"])
    sh(f"arch-chroot {mount} groupadd -rf osprime-users", dry, check=False)
    sh(["arch-chroot", mount, "useradd", "-m", "-c", full, "-G", groups,
        "-s", "/bin/bash", name], dry)
    # The password goes through stdin, never a command line: a command line
    # is visible to every process on the machine while it runs.
    print(("[dry] " if dry else "  $ ") + f"arch-chroot {mount} chpasswd  (password on stdin)")
    if not dry:
        r = subprocess.run(["arch-chroot", mount, "chpasswd"],
                           input=f"{name}:{password}\n", text=True,
                           capture_output=True)
        if r.returncode != 0:
            raise RuntimeError(f"could not set the password: {r.stderr.strip()}")
    sh(["arch-chroot", mount, "bash", "-c",
        '. /opt/osprime/shell/osprime-accounts-lib.sh && osprime_enable_login "$0" "$1"',
        name, f"/home/{name}"], dry)


def ask_account() -> dict:
    """Name, full name and password — asked before anything is erased."""
    import getpass
    import re
    print("\nThe person this computer belongs to (an administrator):")
    while True:
        name = input("  user name (lowercase, e.g. ehsan): ").strip()
        if re.match(NAME_RE, name) and name not in ("osprime", "root", "greeter"):
            break
        print("  lowercase letters, digits, - and _ only, starting with a letter.")
    full = input("  full name (shown on the login screen): ").strip() or name
    while True:
        pw = getpass.getpass("  password: ")
        if not pw:
            print("  a password is required — it is what the login screen asks for.")
            continue
        if pw == getpass.getpass("  again: "):
            break
        print("  the two did not match.")
    return {"name": name, "full": full, "password": pw}


ZONEINFO = "/usr/share/zoneinfo"


def valid_timezone(tz: str, zoneinfo: str = ZONEINFO) -> bool:
    """A real zone name, and nothing that could leave the zoneinfo folder."""
    import re as _re
    if not tz or not _re.fullmatch(r"[A-Za-z0-9_+\-]+(?:/[A-Za-z0-9_+\-]+){0,2}", tz):
        return False
    return os.path.isfile(os.path.join(zoneinfo, tz))


def guess_timezone(timeout: float = 8) -> str:
    """geoip.ubuntu.com's answer, or "" when offline — the same lookup the
    installed system repeats (agent/autotz.py)."""
    import re as _re
    import urllib.request
    try:
        req = urllib.request.Request("https://geoip.ubuntu.com/lookup",
                                     headers={"User-Agent": "OSprime installer"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read(65536).decode("utf-8", "replace")
    except Exception:
        return ""
    m = _re.search(r"<TimeZone>\s*([^<\s]+)\s*</TimeZone>", body)
    tz = m.group(1) if m else ""
    if valid_timezone(tz):
        print(f"\nTime zone: {tz} (found from this network; it follows the computer)")
        return tz
    return ""


def ask_timezone() -> str:
    print("\nYour time zone — as Region/City, for example America/Los_Angeles,")
    print("Europe/London, Asia/Tehran. Press Enter for UTC.")
    for _ in range(3):
        try:
            tz = input("  Time zone: ").strip()
        except EOFError:
            return ""
        if not tz:
            return ""
        if valid_timezone(tz):
            return tz
        # the common mistake: a city without its region
        matches = []
        try:
            for region in os.listdir(ZONEINFO):
                if os.path.isfile(os.path.join(ZONEINFO, region, tz.replace(" ", "_"))):
                    matches.append(f"{region}/{tz.replace(' ', '_')}")
        except OSError:
            pass
        if len(matches) == 1:
            print(f"  → {matches[0]}")
            return matches[0]
        print("  Not a time zone name" + (f" — did you mean {', '.join(matches)}?" if matches else "."))
    return ""


def set_env_line(path: str, key: str, value: str) -> bool:
    """Set KEY=value in an env file, keeping everything else."""
    try:
        lines = open(path, encoding="utf-8").read().splitlines() if os.path.exists(path) else []
        lines = [l for l in lines if not l.strip().startswith(f"{key}=")
                 and not l.strip().startswith(f"#{key}=")]
        lines.append(f"{key}={value}")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        return True
    except OSError:
        return False


def ask_keyboard() -> str:
    """Ehsan, 4 October: ask. Persian is the Windows layout; Settings has
    the national standard and other languages (agent/keyboard.py)."""
    print("\nKeyboard")
    print("  English is always there. Persian can be added; switch between")
    print("  them with Alt+Shift (Settings → Time & language changes this later).")
    try:
        yes = input("  Add a Persian keyboard? [Y/n]: ").strip().lower() not in ("n", "no")
    except EOFError:
        yes = True
    return "en,fa" if yes else "en"


def install(disk: str, dry: bool = False, hostname: str = "osprime",
            no_autologin: bool = False, password: str = "",
            account: dict = None, enc: dict = None, timezone: str = "",
            keyboard: str = "en"):
    uefi = is_uefi()
    esp, root = part_name(disk, 1), part_name(disk, 2)

    print(f"\n> Boot mode: {'UEFI' if uefi else 'BIOS'}")
    print(f"> Target disk: {disk}   (ESP={esp}  ROOT={root})\n")

    for cmd in partition_plan(disk, uefi):
        sh(cmd, dry)
    sh(f"partprobe {disk}", dry, check=False)

    enc = enc if (enc and enc.get("mode") != "none" and uefi) else {"mode": "none"}
    recovery = ""
    fs_dev = root
    if enc["mode"] != "none":
        recovery = encrypt_root(root, enc, dry)
        fs_dev = f"/dev/mapper/{MAPPER}"
    sh(f"mkfs.ext4 -F -L OSPRIME {fs_dev}", dry)
    if uefi:
        sh(f"mkfs.fat -F32 {esp}", dry)

    sh(f"mkdir -p {MOUNT}", dry)
    sh(f"mount {fs_dev} {MOUNT}", dry)
    if uefi:
        sh(f"mkdir -p {MOUNT}/boot", dry)
        sh(f"mount {esp} {MOUNT}/boot", dry)

    excludes = " ".join(f"--exclude={e}" for e in RSYNC_EXCLUDES)
    # check=False on purpose: with the ESP mounted at /boot, rsync cannot set
    # xattrs/ACLs/hardlinks on FAT32 and exits 23 ("partial transfer"). That is
    # expected here and must not abort a working install.
    sh(f"rsync -aAXH {excludes} / {MOUNT}/", dry, check=False)

    # a real root filesystem, not a live image
    sh(f"mkdir -p {MOUNT}/dev {MOUNT}/proc {MOUNT}/sys {MOUNT}/tmp {MOUNT}/run", dry)
    if not dry:
        with open(f"{MOUNT}/etc/hostname", "w") as f:
            f.write(hostname + "\n")
    # The time zone. Never set before 29 September, so every installed
    # machine ran on UTC — the clock, the chat's "what time is it", and the
    # dates on everything built on it (the ISO's name said tomorrow).
    if timezone:
        sh(f"ln -sf /usr/share/zoneinfo/{timezone} {MOUNT}/etc/localtime", dry)
    # The keyboard languages: the machine's default, for every new account
    # and the login screen (agent/keyboard.py).
    print(f"> Keyboard: {keyboard}")
    if not dry:
        set_env_line(f"{MOUNT}/etc/osprime/desktop.env", "OSPRIME_KEYBOARD", keyboard)
        os.makedirs(f"{MOUNT}/etc/greetd", exist_ok=True)
        with open(f"{MOUNT}/etc/greetd/osprime-keyboard", "w") as f:   # the login screen
            f.write(keyboard + "\n")
    # The clock from the network, from the first start (the "Set time and
    # time zone automatically" switch reads this as on).
    sh(f"arch-chroot {MOUNT} systemctl enable systemd-timesyncd", dry, check=False)
    sh(f"genfstab -U {MOUNT} >> {MOUNT}/etc/fstab", dry, check=False)

    # Autologin is kept by default. OSprime is a personal appliance: the tty1
    # autologin is what starts the graphical shell, so removing it drops the
    # user at a bare console login — not something "anyone can use". Pass
    # --no-autologin on a machine that needs a login prompt.
    if no_autologin:
        sh(f"rm -f {MOUNT}/etc/systemd/system/getty@tty1.service.d/autologin.conf",
           dry, check=False)

    # CRITICAL: the live image builds its initramfs with the archiso hooks,
    # which search for the ISO medium at boot. Regenerating with those hooks
    # still present produces an installed system that cannot find its root and
    # drops to an emergency shell.
    #
    # There are TWO archiso-flavoured files, and removing only one leaves
    # mkinitcpio broken:
    #   1. /etc/mkinitcpio.conf.d/archiso.conf   the hook set
    #   2. /etc/mkinitcpio.d/linux.preset        names an 'archiso' preset
    #                                            that points at file 1
    # Deleting 1 without replacing 2 gives:
    #   ERROR: Invalid option -c -- '.../archiso.conf' must be readable
    if not dry:
        os.makedirs(f"{MOUNT}/etc/mkinitcpio.conf.d", exist_ok=True)
        hooks = HOOKS_ENCRYPTED if enc["mode"] != "none" else HOOKS_PLAIN
        with open(f"{MOUNT}/etc/mkinitcpio.conf.d/osprime.conf", "w") as f:
            f.write(hooks)
        # And in mkinitcpio.conf itself. 26 September, first encrypted VM
        # install: the image had no crypttab and no systemd-cryptsetup —
        # the drop-in was not applied (the preset names the config file
        # explicitly), the image was built with the live ISO's hooks, and
        # the boot waited forever for a disk nobody unlocked. The main file
        # is read in every case.
        set_hooks(f"{MOUNT}/etc/mkinitcpio.conf", hooks)
        if enc["mode"] != "none":
            uuid = sh(f"blkid -s UUID -o value {root}", dry).strip()
            with open(f"{MOUNT}/etc/crypttab.initramfs", "w") as f:
                f.write(crypttab_line(uuid, enc["mode"]))
            # What Settings shows, and what osprime-disk-unlock.sh changes.
            os.makedirs(f"{MOUNT}/etc/osprime", exist_ok=True)
            with open(f"{MOUNT}/etc/osprime/disk.json", "w") as f:
                json.dump({"encrypted": True, "unlock": enc["mode"],
                           "mapper": MAPPER}, f)
            # sd-vconsole needs the file to exist, even empty of choices.
            if not os.path.exists(f"{MOUNT}/etc/vconsole.conf"):
                with open(f"{MOUNT}/etc/vconsole.conf", "w") as f:
                    f.write("KEYMAP=us\n")
        os.makedirs(f"{MOUNT}/etc/mkinitcpio.d", exist_ok=True)
        with open(f"{MOUNT}/etc/mkinitcpio.d/linux.preset", "w") as f:
            f.write('ALL_config="/etc/mkinitcpio.conf"\n'
                    'ALL_kver="/boot/vmlinuz-linux"\n\n'
                    "PRESETS=('default')\n\n"
                    'default_image="/boot/initramfs-linux.img"\n')
    sh(f"rm -f {MOUNT}/etc/mkinitcpio.conf.d/archiso.conf", dry, check=False)

    # Leftovers from the live image that mean nothing on a disk.
    #
    # archiso gives root a .zlogin that runs /root/.automated_script.sh, and
    # that script is not copied — so every root login on the installed
    # machine opens with "permission denied: /root/.automated_script.sh".
    # Harmless, and exactly the same shape as the chromium profile lock that
    # still named the host "archiso": something that made sense in the live
    # environment and is only confusing once it is on somebody's disk.
    for leftover in (".zlogin", ".automated_script.sh", ".zprofile"):
        sh(f"rm -f {MOUNT}/root/{leftover}", dry, check=False)
    # The live image's greeting: every text login on the installed machine
    # said "To install Arch Linux follow the installation guide" (28
    # September, a tty login on the laptop). OSprime's own words instead.
    if not dry:
        with open(f"{MOUNT}/etc/motd", "w") as f:
            f.write("")
        with open(f"{MOUNT}/etc/issue", "w") as f:
            f.write("OSprime \\r (\\l)\n\n")
    else:
        print("[dry] write /etc/motd (empty) and /etc/issue (OSprime)")
    # The live ISO's password-free sudo must NEVER reach a disk: on an
    # installed machine it would make every unlocked screen a root shell.
    sh(f"rm -f {MOUNT}/etc/sudoers.d/osprime-live", dry)
    # The "Install OSprime" icon belongs to the USB (docs/INSTALL.md). rsync
    # copied the live /home/osprime with it; on a disk it would offer to
    # install OSprime onto the computer it is already installed on.
    sh(f"rm -f {MOUNT}{INSTALL_ICON} {MOUNT}{CHECK_ICON}", dry)

    # CRITICAL #2: /boot is EMPTY on a live archiso system. mkarchiso lifts
    # the kernel out of airootfs into the ISO's own boot structure, so rsync
    # copies nothing into the ESP and mkinitcpio has no kernel to build for.
    # The kernel does survive at /usr/lib/modules/<version>/vmlinuz — put it
    # back where a normal Arch install expects it before generating initramfs.
    place_kernel(MOUNT, dry)

    # check=True now. 26 September: the first encrypted VM install timed out
    # at boot waiting for /dev/mapper/osprime-root; with check=False any
    # mkinitcpio error (a hook that could not add the TPM libraries, a
    # missing file) scrolled past as a warning and the install "succeeded".
    out = sh(f"arch-chroot {MOUNT} mkinitcpio -P", dry, check=True)
    if not dry and enc["mode"] != "none":
        for w in ("WARNING", "ERROR"):
            for line in (out or "").splitlines():
                if w in line:
                    print("   mkinitcpio: " + line.strip())

    if uefi:
        sh(f"arch-chroot {MOUNT} bootctl --path=/boot install", dry, check=False)
        if not dry:
            os.makedirs(f"{MOUNT}/boot/loader/entries", exist_ok=True)
            with open(f"{MOUNT}/boot/loader/entries/osprime.conf", "w") as f:
                f.write("title OSprime\nlinux /vmlinuz-linux\n"
                        "initrd /initramfs-linux.img\n"
                        f"options root={'/dev/mapper/' + MAPPER if enc['mode'] != 'none' else 'LABEL=OSPRIME'} rw quiet\n")
            with open(f"{MOUNT}/boot/loader/loader.conf", "w") as f:
                f.write("default osprime\ntimeout 3\n")
    else:
        sh(f"arch-chroot {MOUNT} grub-install --target=i386-pc {disk}", dry, check=False)
        sh(f"arch-chroot {MOUNT} grub-mkconfig -o /boot/grub/grub.cfg", dry, check=False)

    # osprime-model MUST be here: it is the local brain. Without it the
    # installed system boots to a chat window that cannot answer anything.
    # (osprime-shell is intentionally absent — it fights the tty1 autologin
    # for the console and causes a boot restart loop.)
    sh(f"arch-chroot {MOUNT} systemctl enable osprime-model osprime-agent osprime-web osprime-embed",
       dry, check=False)

    # A login (docs/ACCOUNTS.md): the person's account, the login screen,
    # the osprime account locked. Without an account — only with
    # --legacy-autologin — the old single-account appliance.
    if account:
        create_person(MOUNT, account, dry)

    sb = setup_secure_boot(enc, dry) if uefi else "bios"

    # the live image ships a known password; do not carry it to a real disk
    if password and not account:
        sh(f"arch-chroot {MOUNT} sh -c 'echo \"osprime:{password}\" | chpasswd'",
           dry, check=False)

    ok = verify_target(MOUNT, dry, account, enc, root)
    sh(f"umount -R {MOUNT}", dry, check=False)
    if enc["mode"] != "none":
        sh(f"cryptsetup close {MAPPER}", dry, check=False)
        show_recovery_key(recovery, dry, root)
    if not ok:
        # Not "complete": the icon's launcher offers a restart only after a
        # success, and restarting into a system that will not boot is the
        # one thing it must never suggest.
        print("\nThe install finished with the problems listed above.")
        return False
    if sb == "now":
        print("\nSecure Boot: this computer's own keys are in the firmware. It turns")
        print("on at the next start (if the firmware asks, switch Secure Boot on).")
    elif sb == "failed":
        print("\nSecure Boot: could not be prepared (the reason is above). Try again after")
        print("installing: Settings -> System -> Secure Boot.")
    elif sb == "later":
        print("\nSecure Boot: turn it on later in Settings -> System -> Secure Boot.")
    print("\nInstall complete. Remove the ISO and reboot.")
    return True


def main():
    ap = argparse.ArgumentParser(description="OSprime disk installer")
    ap.add_argument("--disk", help="target disk, e.g. /dev/sda")
    ap.add_argument("--hostname", default="osprime")
    ap.add_argument("--timezone", default="", help="e.g. America/Los_Angeles (asked if missing)")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-autologin", action="store_true",
                    help=argparse.SUPPRESS)   # the default now; kept so old notes still work
    ap.add_argument("--legacy-autologin", action="store_true",
                    help="no login: the old single-account appliance (testing only)")
    ap.add_argument("--user", default="", help="the person's user name (asked if missing)")
    ap.add_argument("--fullname", default="")
    ap.add_argument("--encrypt", choices=ENCRYPT_MODES, default=None,
                    help="how the disk unlocks (asked if missing; docs/ENCRYPTION.md)")
    ap.add_argument("--password", default="",
                    help="password for the osprime user (default: keep the live one)")
    ap.add_argument("--list", action="store_true", help="list disks and exit")
    ap.add_argument("--keyboard", default="", help="e.g. en,fa (asked if missing)")
    a = ap.parse_args()

    disks = list_disks()
    if a.list:
        for d in disks:
            print(f"{d['path']:14} {d['size_gb']:>8} GB  {d['model']}")
        return 0

    if os.geteuid() != 0 and not a.dry_run:
        print("Run this with sudo."); return 1

    disk = a.disk
    if not disk:
        if not disks:
            print("No disks found."); return 1
        print("Available disks:\n")
        for i, d in enumerate(disks, 1):
            tag = " (removable)" if d["removable"] else ""
            print(f"  {i}) {d['path']:14} {d['size_gb']:>8} GB  {d['model']}{tag}")
        try:
            disk = disks[int(input("\nTarget disk number: ").strip()) - 1]["path"]
        except (ValueError, IndexError, EOFError):
            print("Invalid selection."); return 1

    account = None
    if not a.legacy_autologin:
        if a.dry_run and a.user:
            account = {"name": a.user, "full": a.fullname or a.user, "password": "x"}
        else:
            account = ask_account()

    kb = a.keyboard or ("en,fa" if a.dry_run else ask_keyboard())

    if a.dry_run and a.encrypt:
        enc = {"mode": a.encrypt, "password": "x", "pin": "1234"}
    elif a.encrypt == "none":
        enc = {"mode": "none"}
    else:
        enc = ask_encryption(is_uefi())

    if not a.dry_run and os.path.basename(disk) in disks_in_use():
        print(f"\n{disk} is in use — something on it is mounted, most likely the")
        print("system running right now. The installer never erases a disk in use.")
        print("To test the installer, run it inside the VM (osprime-vm-test.sh).")
        return 1

    if not a.dry_run:
        print(f"\n!  Everything on {disk} will be erased. This cannot be undone.")
        if enc["mode"] != "none":
            print("   The disk will be encrypted. Without the password, the TPM or")
            print("   the recovery key (shown at the end), its data cannot be read —")
            print("   by anyone, including us.")
        if input("Type ERASE exactly to continue: ").strip() != "ERASE":
            print("Cancelled."); return 1

    if a.timezone and not a.dry_run and not valid_timezone(a.timezone):
        print(f"Not a time zone: {a.timezone}"); return 1
    # Not asked any more (1 October): looked up if the USB is online, and in
    # any case set automatically by the installed system once it is.
    tz = a.timezone or ("" if a.dry_run else guess_timezone())
    ok = install(disk, a.dry_run, a.hostname, a.no_autologin, a.password, account, enc, tz,
                 keyboard=kb)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
