"""Keyboard languages. Asked for by Ehsan, 4 October: there was no way to
type Persian on the laptop.

Decisions (Ehsan): switch with Alt+Shift; Persian is the Windows layout by
default (what nearly everyone in Iran learned on) and the national standard,
ISIRI 9147, is an option; the installer asks "Add a Persian keyboard?".

How it works, and why this way:

  * The person's list lives in their desktop.env as OSPRIME_KEYBOARD, e.g.
    "en,fa". The machine's default (/etc/osprime/desktop.env, written by the
    installer) is what a new account and the login screen start with.

  * labwc reads XKB_DEFAULT_LAYOUT/VARIANT from the `environment` file in its
    config directory and re-reads it on `labwc --reconfigure`. Switching
    writes that file with the chosen language FIRST and reconfigures.

    We switch ourselves rather than with xkb's own grp:alt_shift_toggle so
    that we always know which language is active: labwc offers no way to ask
    it, and an EN/FA indicator that can be wrong is worse than none. The
    other languages stay loaded behind the active one, so Ctrl+C, Ctrl+V and
    the rest keep working while typing Persian (programs look for the Latin
    letter in another group).

  * Alt+Shift is two labwc keybinds, A-Shift_L and S-Alt_L, onRelease="yes"
    — a modifier-only combination fires on release, the documented way.

  * The panel (waybar custom/keyboard) shows EN / FA from a small state file
    and is told to refresh with a signal.

Everything here runs as the person, in their own session. Nothing needs root
except the installer's machine default.

    python3 keyboard.py next      switch to the next language (Alt+Shift)
    python3 keyboard.py status    JSON for the panel
    python3 keyboard.py env       the environment lines for labwc
"""
import json
import os
import pathlib
import re
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import paths  # noqa: E402

KEY = "OSPRIME_KEYBOARD"
DEFAULT = "en"
SIGNAL = 9          # waybar: "signal": 9 -> pkill -RTMIN+9 waybar

# id -> (label, short, xkb layout, xkb variant or a callable that finds it)
LANGUAGES = {
    "en": ("English (US)", "EN", "us", ""),
    "fa": ("Persian (Windows layout)", "FA", "ir", "@windows"),
    "fa-isiri": ("Persian (ISIRI 9147 standard)", "FA", "ir", ""),
    "ar": ("Arabic", "AR", "ara", ""),
    "tr": ("Turkish", "TR", "tr", ""),
    "de": ("German", "DE", "de", ""),
    "fr": ("French", "FR", "fr", ""),
    "es": ("Spanish", "ES", "es", ""),
    "ru": ("Russian", "RU", "ru", ""),
    "en-gb": ("English (UK)", "EN", "gb", ""),
}

_RULES = ("/usr/share/xkeyboard-config-2/rules/evdev.lst",
          "/usr/share/X11/xkb/rules/evdev.lst")
_variant_cache = {}


def _windows_variant(layout: str) -> str:
    """The Persian (Windows) variant's name, read from this machine's own
    keyboard database. xkeyboard-config added it in 2024 as pes_winkeys and
    has since called it winkeys; asking the database means either works and a
    machine without it falls back to the standard layout instead of no
    keyboard at all."""
    if layout in _variant_cache:
        return _variant_cache[layout]
    found = ""
    for f in _RULES:
        try:
            text = pathlib.Path(os.environ.get("OSPRIME_XKB_RULES", f)).read_text(errors="replace")
        except OSError:
            continue
        m = re.search(r"^\s+(\S+)\s+" + re.escape(layout) + r":.*\bWindows\b", text, re.M)
        if m:
            found = m.group(1)
            break
    _variant_cache[layout] = found
    return found


def xkb(lang_id: str):
    """(layout, variant) for a language id."""
    _label, _short, layout, variant = LANGUAGES[lang_id]
    if variant == "@windows":
        variant = _windows_variant(layout)
    return layout, variant


def windows_available() -> bool:
    return bool(_windows_variant("ir"))


# ---------------------------------------------------------------------------
# the person's list and the active one
# ---------------------------------------------------------------------------
def languages() -> list:
    raw = paths.read_desktop_env().get(KEY, DEFAULT).strip('"')
    out = []
    for part in raw.split(","):
        part = part.strip().lower()
        if part in LANGUAGES and part not in out:
            out.append(part)
    return out or [DEFAULT]


def _runtime() -> pathlib.Path:
    d = os.environ.get("XDG_RUNTIME_DIR")
    if not d:
        try:
            import system_tools
            d = system_tools._wayland_env().get("XDG_RUNTIME_DIR")
        except Exception:
            d = None
    return pathlib.Path(d or f"/run/user/{os.getuid()}")


def _state() -> pathlib.Path:
    return _runtime() / "osprime-keyboard"


def active() -> str:
    langs = languages()
    try:
        a = _state().read_text().strip()
        if a in langs:
            return a
    except OSError:
        pass
    return langs[0]


def env_lines(first: str = "") -> list:
    """XKB_DEFAULT_* for labwc: the active language first, the rest behind
    it. No grp: option — switching is ours (see the top of this file)."""
    langs = languages()
    first = first if first in langs else active()
    order = [first] + [l for l in langs if l != first]
    pairs = [xkb(l) for l in order]
    return [f"XKB_DEFAULT_LAYOUT={','.join(p[0] for p in pairs)}",
            f"XKB_DEFAULT_VARIANT={','.join(p[1] for p in pairs)}"]


def _merged_dir() -> pathlib.Path:
    return _runtime() / "osprime-labwc"


def write_env(conf_dir: pathlib.Path = None, base_env: pathlib.Path = None, first: str = "") -> bool:
    """Write labwc's environment file: whatever the shipped one says, minus
    any XKB_DEFAULT_ lines, plus ours."""
    conf_dir = conf_dir or _merged_dir()
    if not conf_dir.is_dir():
        return False
    keep = []
    src = base_env if base_env and base_env.is_file() else None
    if src:
        keep = [l for l in src.read_text(encoding="utf-8").splitlines()
                if not l.strip().startswith("XKB_DEFAULT_")]
    (conf_dir / "environment").write_text("\n".join(keep + env_lines(first)) + "\n",
                                          encoding="utf-8")
    return True


def _reconfigure():
    env = dict(os.environ)
    if not env.get("WAYLAND_DISPLAY"):
        try:
            import system_tools
            env.update(system_tools._wayland_env())
        except Exception:
            pass
    for cmd in (["labwc", "--reconfigure"], ["pkill", f"-RTMIN+{SIGNAL}", "-x", "waybar"]):
        try:
            subprocess.run(cmd, env=env, capture_output=True, timeout=10)
        except Exception:
            pass


def _base_env() -> pathlib.Path:
    return pathlib.Path("/opt/osprime/shell/labwc/environment")


def switch_to(lang_id: str) -> str:
    langs = languages()
    if lang_id not in langs:
        return f"ERROR: {lang_id} is not one of this person's keyboard languages ({', '.join(langs)})."
    try:
        _state().write_text(lang_id)
    except OSError as e:
        return f"ERROR: could not save the keyboard state: {e}"
    if not write_env(base_env=_base_env(), first=lang_id):
        return "ERROR: the desktop's configuration folder is missing; log out and back in."
    _reconfigure()
    return f"Keyboard: {LANGUAGES[lang_id][0]}."


def next_language() -> str:
    langs = languages()
    if len(langs) < 2:
        return "Only one keyboard language is set up."
    a = active()
    return switch_to(langs[(langs.index(a) + 1) % len(langs)])


def set_languages(ids) -> str:
    """Set the person's list (the order is the switch order)."""
    if isinstance(ids, str):
        ids = [p for p in re.split(r"[,\s]+", ids) if p]
    clean, unknown = [], []
    for word in ids:
        i = resolve(word)
        if not i:
            unknown.append(word)
        elif i not in clean:
            clean.append(i)
    if "fa" in clean and "fa-isiri" in clean:
        return "ERROR: choose one Persian layout — Windows (fa) or ISIRI 9147 (fa-isiri)."
    if unknown or not clean:
        return (f"ERROR: I do not know the keyboard language {', '.join(unknown) or '(none)'}. "
                "Nothing was changed. Choose from: "
                + ", ".join(f"{k} ({v[0]})" for k, v in LANGUAGES.items()) + ".")
    if not paths.write_desktop_env(KEY, ",".join(clean)):
        return "ERROR: could not save the setting."
    a = active() if active() in clean else clean[0]
    switch_to(a)
    names = ", ".join(LANGUAGES[c][0] for c in clean)
    note = ""
    if "fa" in clean and not windows_available():
        note = (" This system's keyboard database has no Windows Persian layout, so the "
                "standard (ISIRI 9147) layout is used instead.")
    return f"Keyboard languages: {names}. Switch with Alt+Shift.{note}"


_NAMES = {"english": "en", "انگلیسی": "en", "persian": "fa", "farsi": "fa", "فارسی": "fa",
          "iranian": "fa", "isiri": "fa-isiri", "standard persian": "fa-isiri",
          "arabic": "ar", "عربی": "ar", "turkish": "tr", "ترکی": "tr", "german": "de",
          "french": "fr", "spanish": "es", "russian": "ru", "british": "en-gb"}


def resolve(word: str) -> str:
    w = (word or "").strip().lower()
    if w in LANGUAGES:
        return w
    return _NAMES.get(w, "")


def status() -> dict:
    """For the panel: {"text": "FA", "tooltip": ..., "class": ...}."""
    langs, a = languages(), active()
    tip = "Keyboard: " + LANGUAGES[a][0]
    if len(langs) > 1:
        tip += "\nAlt+Shift switches to " + LANGUAGES[langs[(langs.index(a) + 1) % len(langs)]][0]
    return {"text": LANGUAGES[a][1] if len(langs) > 1 else "",
            "tooltip": tip, "class": a, "alt": a}


def info() -> dict:
    """For Settings."""
    return {"languages": languages(), "active": active(), "windows_persian": windows_available(),
            "available": [{"id": k, "name": v[0]} for k, v in LANGUAGES.items()]}


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "next":
        print(next_language())
    elif cmd == "status":
        print(json.dumps(status(), ensure_ascii=False))
    elif cmd == "env":
        print("\n".join(env_lines()))
    elif cmd == "greeter-env":
        # the machine's list, English first, as shell assignments; only
        # known ids reach here, so the values are plain words and commas
        # The list comes from /etc/greetd/osprime-keyboard (the greeter user
        # cannot read /etc/osprime); unknown words are dropped.
        given = [p.strip().lower() for p in (sys.argv[2] if len(sys.argv) > 2 else "en").split(",")]
        langs = [p for p in given if p in LANGUAGES] or ["en"]
        order = (["en"] if "en" in langs else []) + [l for l in langs if l != "en"]
        pairs = [xkb(l) for l in order]
        print(f"LAYOUT={','.join(p[0] for p in pairs)}")
        print(f"VARIANT={','.join(p[1] for p in pairs)}")
    elif cmd == "set" and len(sys.argv) > 2:
        print(set_languages(sys.argv[2:]))
    else:
        print(json.dumps(info(), indent=2))
