"""Who may talk to the OSprime web interface.

The web interface is the machine's control surface: it changes settings,
installs software, drives the assistant, and shows what the assistant
remembers about the user. Until 23 September it listened on every network
interface and asked nobody anything. See docs/SECURITY.md, #1.

This module is the first half of the fix. Every request passes check()
before a handler sees it. It is a pure function of the method, the path and
the headers so it can be tested without a server, and so the rules are in
one place instead of scattered across forty endpoints.

The three things it stops, in the order they are checked:

1. **Anyone else on the network.** Handled by binding to 127.0.0.1 in
   web.py, not here — a request that cannot arrive cannot be refused
   wrongly. Remote access is wanted later; it will come with a device key
   and physical pairing, designed in SECURITY.md, and it will change the
   bind address deliberately rather than by a setting someone flips.

2. **DNS rebinding.** A web page at evil.example can make its own name
   resolve to 127.0.0.1 after it has loaded. From the browser's point of
   view the page is then talking to its own origin, so every same-origin
   protection passes — and it can read /api/memory. The defence is the Host
   header: our pages are served as localhost:PORT or 127.0.0.1:PORT, and a
   request naming any other host was not meant for us.

3. **Other web pages in the browser on this machine.** Binding to
   127.0.0.1 does NOT stop this, which is why the first half of #1 is not
   just a bind address. This computer has a browser; any site open in it
   can send a request to http://localhost:8080/api/settings, including one
   that sets the confirmation level to "never ask". The browser tells us
   where a request came from — Sec-Fetch-Site, Origin, Referer — and a
   request that came from a site that is not us is refused.

What is deliberately allowed: a request with none of those headers. Only a
browser sends them, and a browser always sends at least one of them on a
request from another site. A request carrying none of them is a program on
this machine — the panel's camera indicator polls /api/capture with curl
every two seconds — and a program on this machine can already do anything
the user can.
"""

from urllib.parse import urlsplit


def allowed_hosts(port: int) -> set:
    return {f"localhost:{port}", f"127.0.0.1:{port}", f"[::1]:{port}"}


def _origin_host(value: str) -> str:
    """'http://localhost:8080' -> 'localhost:8080'; '' when unparseable."""
    try:
        parts = urlsplit(value)
    except ValueError:
        return ""
    if parts.scheme not in ("http", "https") or not parts.netloc:
        return ""
    return parts.netloc.lower()


def check(method: str, path: str, headers, port: int, ours: set = None) -> str:
    """"" if the request may proceed, otherwise the reason it may not.

    `headers` is anything with .get(name) — http.server's message object in
    the product, a plain dict in the tests.

    `ours` is the set of host:port names this listener answers to. The
    loopback listener's are fixed; the remote listener passes the machine's
    current network addresses, because on that port the right Host is
    whatever the phone typed or scanned — and anything else is still a
    rebinding attempt.
    """
    ours = {h.lower() for h in ours} if ours is not None else allowed_hosts(port)
    method = (method or "").upper()

    # --- 2. DNS rebinding: the Host header has to be us -----------------------
    host = (headers.get("Host") or "").strip().lower()
    if host not in ours:
        return f"unexpected Host {host!r}"

    # --- 3. requests that came from another site -------------------------------
    # Sec-Fetch-Site is the most direct answer and every current Chromium
    # sends it. "same-origin" is our own page; "none" is the person typing
    # the address or a window we opened ourselves.
    site = (headers.get("Sec-Fetch-Site") or "").strip().lower()
    mode = (headers.get("Sec-Fetch-Mode") or "").strip().lower()
    if site in ("cross-site", "same-site"):
        # One exception: following a link to the chat's front page is just
        # opening the chat. It changes nothing and shows nothing that is not
        # on screen anyway, and framing it is stopped separately by the
        # frame-ancestors header. Nothing under /api/ is ever reachable this
        # way, and no method but GET.
        if not (method == "GET" and mode == "navigate"
                and not path.startswith("/api/")):
            return f"request from another site ({site})"

    # Origin, for anything that changes state. Chromium sends it on every
    # POST, same-origin included, so our own page always passes.
    if method not in ("GET", "HEAD"):
        origin = headers.get("Origin")
        if origin is not None:
            # "null" is what a sandboxed frame or a file:// page sends. Not
            # us, whatever it is.
            if _origin_host(origin) not in ours:
                return f"request from origin {origin!r}"
        else:
            referer = headers.get("Referer")
            if referer and _origin_host(referer) not in ours:
                return f"request from {referer!r}"
    return ""


def selftest(port: int = 8080) -> list:
    """Every rule above, checked. Called by release.sh.

    Both directions on purpose: the requests that must be refused, and the
    ones that must still work. A guard tested only for what it blocks is how
    a release ships that blocks the chat's own page — which, on a machine
    whose whole interface is that page, is a bricked machine.
    """
    us = f"localhost:{port}"
    cases = [
        # (method, path, headers, must_pass, what)
        ("GET", "/", {"Host": us, "Sec-Fetch-Site": "none",
                      "Sec-Fetch-Mode": "navigate"}, True, "opening the chat"),
        ("GET", "/api/settings", {"Host": us, "Sec-Fetch-Site": "same-origin"},
         True, "the page reading its API"),
        ("POST", "/api/settings", {"Host": us, "Origin": f"http://{us}",
                                   "Sec-Fetch-Site": "same-origin"},
         True, "the page changing a setting"),
        ("POST", "/api/end", {"Host": f"127.0.0.1:{port}",
                              "Origin": f"http://127.0.0.1:{port}"},
         True, "sendBeacon via 127.0.0.1"),
        ("GET", "/api/capture", {"Host": us}, True, "the panel's curl poller"),
        ("GET", "/", {"Host": us, "Sec-Fetch-Site": "cross-site",
                      "Sec-Fetch-Mode": "navigate"}, True, "a link to the chat"),

        ("POST", "/api/settings", {"Host": us, "Origin": "https://evil.example"},
         False, "another site changing a setting"),
        ("POST", "/api/settings", {"Host": us, "Origin": "null"},
         False, "a sandboxed frame"),
        ("POST", "/api/settings", {"Host": us,
                                   "Referer": "https://evil.example/"},
         False, "a foreign Referer with no Origin"),
        ("GET", "/api/memory", {"Host": us, "Sec-Fetch-Site": "cross-site",
                                "Sec-Fetch-Mode": "no-cors"},
         False, "another site reading memory"),
        ("GET", "/api/memory", {"Host": us, "Sec-Fetch-Site": "cross-site",
                                "Sec-Fetch-Mode": "navigate"},
         False, "navigating straight to an API URL"),
        ("GET", "/api/memory", {"Host": "evil.example:8080"},
         False, "DNS rebinding"),
        ("GET", "/api/memory", {}, False, "no Host at all"),
    ]
    bad = []
    for method, path, headers, must_pass, what in cases:
        why = check(method, path, headers, port)
        if must_pass and why:
            bad.append(f"webguard refused {what}: {why}")
        if not must_pass and not why:
            bad.append(f"webguard allowed {what}")
    return bad


# Sent on every response.
#
# frame-ancestors 'none' and X-Frame-Options: the chat cannot be put inside
# another site's frame, where a page could lay invisible buttons over
# "Allow" and have the user click them. Both, because older engines only
# understand the second.
#
# nosniff: a file served from /file is shown as what we say it is, never
# re-interpreted by the browser as a script.
SECURITY_HEADERS = (
    ("Content-Security-Policy", "frame-ancestors 'none'"),
    ("X-Frame-Options", "DENY"),
    ("X-Content-Type-Options", "nosniff"),
    ("Referrer-Policy", "same-origin"),
)
