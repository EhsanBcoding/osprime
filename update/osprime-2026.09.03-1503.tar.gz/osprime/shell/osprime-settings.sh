#!/usr/bin/env bash
# Open the Settings window.
# Launched from the Apps menu, and reachable from the chat header.
#
# A separate chromium profile from the chat on purpose: sharing one profile
# means the second window inherits the first one's lock and refuses to start.

SECTION="${1:-}"
URL="${OSPRIME_URL:-http://localhost:8080}/settings${SECTION:+#$SECTION}"
PROFILE=/tmp/osprime-settings-chrome
LOG=/tmp/osprime-settings.log

if pgrep -f "user-data-dir=$PROFILE" >/dev/null 2>&1; then
    exit 0          # already open
fi
rm -f "$PROFILE"/Singleton* 2>/dev/null

FLAGS=(
  --ozone-platform=wayland
  --app="$URL"
  --no-first-run
  --no-default-browser-check
  --no-sandbox
  --test-type
  --disable-dev-shm-usage
  --disable-features=TranslateUI
  --password-store=basic
  --user-data-dir="$PROFILE"
  --window-size=820,760
)
[ -e /dev/dri/renderD128 ] || FLAGS+=(--disable-gpu --use-gl=swiftshader --in-process-gpu)

for b in chromium chromium-browser google-chrome-stable google-chrome; do
    if command -v "$b" >/dev/null; then
        exec "$b" "${FLAGS[@]}" >>"$LOG" 2>&1
    fi
done

echo "no browser found to show Settings" >> "$LOG"
exit 1
