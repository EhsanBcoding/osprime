#!/usr/bin/env bash
# The Apps menu.
#
# archiso's base image drags in a rescue toolkit — xgps, xgpsspeed, Avahi
# browsers, Software Token, Qt V4L2 test utilities, lftp, Vim. Useful on an
# installer ISO, meaningless to someone who wants to open their photos, and
# together they make the menu unusable for the person this OS is for.
#
# So the menu is a curated list rather than whatever happens to be installed.
# Everything else is still installed and still runnable from a terminal; it
# is simply not offered to someone browsing for an application.
#
# Adding an application to the OS means adding its name here too.

ALLOW=(
  osprime-settings
  osprime-browser        # our entry, not chromium's — see the .desktop for why
  osprime-screenshot
  thunar
  mousepad
  imv
  gimp org.gnome.gimp
  libreoffice-writer libreoffice-calc libreoffice-impress libreoffice-startcenter
  galculator
  foot
)
# mpv is deliberately absent. Launched with no arguments it opens nothing and
# exits, so a menu entry for it is a button that appears to do nothing.
# Videos open by double-clicking them in Files, which is how people reach a
# player anyway.

SEARCH=(/usr/share/applications /usr/local/share/applications
        "$HOME/.local/share/applications")

# The real environment, kept so launched applications still get it.
REAL_DIRS="${XDG_DATA_DIRS:-/usr/local/share:/usr/share}"
REAL_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"

# exec replaces this shell, so an EXIT trap would never fire. Clean up the
# previous run's directory instead of leaking one per menu open.
rm -rf /tmp/osprime-menu.* 2>/dev/null
MENU="$(mktemp -d /tmp/osprime-menu.XXXXXX)"
mkdir -p "$MENU/applications"

# XDG_DATA_DIRS is where icon themes live too, not only application entries.
# Narrowing it to the curated directory therefore hid every icon in the menu
# as well as the unwanted applications — the list went plain text and stayed
# that way for several releases. Link the real icon directories back in.
for share in /usr/share /usr/local/share; do
    for kind in icons pixmaps; do
        [ -d "$share/$kind" ] && [ ! -e "$MENU/$kind" ] && ln -s "$share/$kind" "$MENU/$kind"
    done
done
MISSING=/tmp/osprime-apps-missing.log
: > "$MISSING"

# Package name and desktop-entry name are not the same thing. Xfce and GNOME
# applications ship reverse-DNS files — mousepad installs
# org.xfce.mousepad.desktop — so an exact filename match silently dropped
# them from the menu. Match the exact name first, then any entry whose name
# ends with .<name>, which is precise enough not to catch anything unrelated.
find_desktop() {
    local want="$1" dir f
    for dir in "${SEARCH[@]}"; do
        [ -d "$dir" ] || continue
        [ -f "$dir/$want.desktop" ] && { printf '%s\n' "$dir/$want.desktop"; return 0; }
        for f in "$dir"/*."$want".desktop; do
            [ -f "$f" ] && { printf '%s\n' "$f"; return 0; }
        done
    done
    return 1
}

found=0
for name in "${ALLOW[@]}"; do
    if entry="$(find_desktop "$name")"; then
        cp "$entry" "$MENU/applications/"
        found=$((found + 1))
    else
        echo "$name" >> "$MISSING"
    fi
done

# An empty menu is worse than a cluttered one: fall back rather than show
# the user nothing at all.
if [ "$found" -eq 0 ]; then
    exec fuzzel
fi

# fuzzel reads <dir>/applications/*.desktop for each entry in XDG_DATA_DIRS,
# so pointing both variables at the curated directory hides everything else.
#
# But a launched application inherits that environment too — and GTK
# applications need /usr/share for their schemas, icons and mime types.
# Without it thunar, chromium and mpv died the instant they started, so the
# menu appeared to do nothing at all when clicked. --launch-prefix restores
# the real environment for the application while the menu keeps the narrow
# one for itself.
export XDG_DATA_DIRS="$MENU"
export XDG_DATA_HOME="$MENU"
# Our own fuzzel config, kept in /opt so updates reach it —
# anything under /home never gets replaced by an update.
FUZZEL_CONF="$(dirname "$0")/fuzzel.ini"
[ -f "$FUZZEL_CONF" ] && set -- --config "$FUZZEL_CONF"
exec fuzzel "$@" --launch-prefix="env XDG_DATA_DIRS=$REAL_DIRS XDG_DATA_HOME=$REAL_HOME"
