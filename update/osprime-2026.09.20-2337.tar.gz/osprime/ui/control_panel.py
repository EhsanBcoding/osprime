"""The Control Panel window.

Kept separate from web.py only so neither file becomes unreadable; it is
served by the same process on the same port, at /settings.

Three rules this file exists to keep, from docs/CONTROL_PANEL.md:

1. Every control goes through agent/system_tools.py — the same functions
   the assistant calls. There is deliberately no second path to the same
   setting: when a product grows two ways to change one value they drift,
   and the user ends up with an interface that disagrees with itself.

2. Nothing here may depend on the assistant being alive. osprime-web is a
   separate service from osprime-agent, so this window keeps working when
   the model will not load — which is exactly when a person needs to reach
   the network settings and the update button.

3. It earns its place by showing state, by doing what words are bad at,
   and by working when the assistant does not. A control that serves none
   of those belongs in the conversation instead.

The URL stays /settings and the launcher stays osprime-settings.sh. Both
are wired into the desktop menu, the app list and any keyboard shortcut a
user has already saved; renaming them would break those for a word.
"""

PAGE = r"""<!DOCTYPE html>
<html lang="{{LANG}}" dir="{{DIR}}">
<meta charset="utf-8">
<title>Control Panel — OSprime</title>
<style>
  :root { --bg:#0d1117; --panel:#161b22; --line:#21262d; --text:#e6edf3;
          --dim:#8b949e; --accent:#2d6cdf; --ok:#2ea043; --warn:#d29922; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--text); height:100vh;
         display:flex; flex-direction:column;
         font-family:system-ui,'Noto Sans','Noto Sans Arabic',sans-serif; }
  header { padding:14px 22px; background:var(--panel);
           border-bottom:1px solid var(--line); display:flex;
           align-items:center; gap:10px; }
  header .logo { font-size:18px; font-weight:700; color:var(--accent); }
  header .sub { color:var(--dim); font-size:13px; }
  #body { flex:1; display:flex; min-height:0; }
  nav { width:210px; flex:none; background:var(--panel); padding:14px 10px;
        border-inline-end:1px solid var(--line); overflow-y:auto; }
  nav a { display:block; padding:9px 12px; border-radius:8px; font-size:14px;
          color:var(--text); text-decoration:none; cursor:pointer;
          margin-bottom:2px; }
  nav a:hover { background:#1c2330; }
  nav a.on { background:var(--accent); color:#fff; }
  main { flex:1; overflow-y:auto; padding:22px; }
  .page { display:none; max-width:720px; }
  .page.on { display:block; }
  h1 { font-size:20px; font-weight:600; margin:0 0 4px; }
  .lede { color:var(--dim); font-size:13px; margin:0 0 18px; }
  section { background:var(--panel); border:1px solid var(--line);
            border-radius:12px; padding:16px 20px; margin-bottom:16px; }
  h2 { font-size:15px; font-weight:600; margin:0 0 14px; }
  .row { display:flex; align-items:center; gap:12px; padding:9px 0;
         border-top:1px solid var(--line); }
  .row:first-of-type { border-top:0; }
  .row label { flex:1; font-size:14px; }
  .row .hint { display:block; color:var(--dim); font-size:12px; margin-top:2px; }
  input, select { background:#0d1117; color:var(--text);
                  border:1px solid var(--line); border-radius:7px;
                  padding:7px 10px; font-size:13px; min-width:190px;
                  font-family:inherit; }
  input[type=checkbox] { min-width:auto; width:18px; height:18px; }
  button { background:var(--accent); color:#fff; border:0; border-radius:7px;
           padding:7px 16px; font-size:13px; cursor:pointer;
           font-family:inherit; }
  button.ghost { background:transparent; border:1px solid var(--line);
                 color:var(--text); }
  button:disabled { opacity:.5; cursor:default; }
  #note { position:fixed; left:50%; transform:translateX(-50%); bottom:22px;
          background:var(--panel); border:1px solid var(--line);
          border-radius:9px; padding:10px 18px; font-size:13px;
          display:none; z-index:5; }
  .nets { margin-top:10px; display:flex; flex-direction:column; gap:6px; }
  .net { display:flex; align-items:center; gap:10px; padding:8px 10px;
         border:1px solid var(--line); border-radius:8px; font-size:13px;
         cursor:pointer; }
  .net:hover { border-color:var(--accent); }
  .net .sig { color:var(--dim); font-size:12px; margin-inline-start:auto; }
  .facts { display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr));
           gap:12px; }
  .fact { background:#0d1117; border:1px solid var(--line); border-radius:10px;
          padding:12px 14px; }
  .fact .k { color:var(--dim); font-size:12px; }
  .fact .v { font-size:16px; margin-top:3px; }
  .fact .v small { color:var(--dim); font-size:12px; }
  .mems { display:flex; flex-direction:column; gap:6px; }
  .mem { display:flex; align-items:center; gap:10px; padding:9px 12px;
         background:#0d1117; border:1px solid var(--line); border-radius:8px;
         font-size:13px; }
  .mem .txt { flex:1; overflow-wrap:anywhere; }
  .mem .when { color:var(--dim); font-size:12px; flex:none; }
  .mem .x { background:transparent; border:1px solid var(--line);
            color:var(--dim); border-radius:6px; padding:3px 9px;
            font-size:12px; flex:none; }
  .mem .x:hover { border-color:#e05555; color:#e05555; }
  .empty { color:var(--dim); font-size:13px; padding:4px 0; }
</style>
<header>
  <span class="logo">Control Panel</span>
  <span class="sub">OSprime v{{VERSION}}</span>
  <button class="ghost" style="margin-inline-start:auto"
          onclick="location.href='/'">Back to chat</button>
</header>

<div id="body">
<nav>
  <a data-page="machine">This machine</a>
  <a data-page="display">Display</a>
  <a data-page="sound">Sound</a>
  <a data-page="network">Network</a>
  <a data-page="time">Time &amp; language</a>
  <a data-page="assistant">Assistant</a>
  <a data-page="apps">Applications</a>
  <a data-page="storage">Storage</a>
  <a data-page="system">System</a>
</nav>

<main>
  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-machine">
    <h1>This machine</h1>
    <p class="lede">The page the assistant cannot replace. It can tell you
      any one of these if you ask; this shows all of them to someone who did
      not know what to ask.</p>
    <section>
      <h2>Hardware</h2>
      <div class="facts" id="hwfacts"><div class="fact"><div class="k">reading…</div></div></div>
    </section>
    <section>
      <h2>The assistant's model</h2>
      <div class="facts" id="modelfacts"><div class="fact"><div class="k">reading…</div></div></div>
      <div class="row" id="modeladvice" style="display:none">
        <label id="modeladvicetext"></label>
      </div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-display">
    <h1>Display</h1>
    <section>
      <h2>Screen</h2>
      <div class="row">
        <label>Size of everything
          <span class="hint">A 1920×1080 screen on a 14-inch laptop is very
          small at 100%. This keeps text sharp, unlike lowering the
          resolution.</span></label>
        <select id="scale">
          <option value="1">100%</option>
          <option value="1.25">125%</option>
          <option value="1.5">150%</option>
          <option value="1.75">175%</option>
          <option value="2">200%</option>
        </select>
      </div>
      <div class="row">
        <label>Resolution</label>
        <select id="resolution"><option value="">detecting…</option></select>
      </div>
    </section>
    <section>
      <h2>Appearance</h2>
      <div class="row">
        <label>Background
          <span class="hint">Solid colour. Images are not supported yet.</span></label>
        <select id="wallpaper">
          <option value="#12232E">Petrol blue</option>
          <option value="#D9CFBC">Beige</option>
          <option value="#101A2E">Navy</option>
          <option value="#2B2E33">Grey</option>
          <option value="#0B0B0B">Black</option>
        </select>
      </div>
      <div class="row">
        <label>Desktop
          <span class="hint">Icons from your Desktop folder, and the
          right-click menu. Turning this off leaves a plain background. Log
          out and back in after changing it.</span></label>
        <input type="checkbox" id="deskicons">
      </div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-sound">
    <h1>Sound</h1>
    <section>
      <h2>Output</h2>
      <div class="row">
        <label>Volume</label>
        <input type="range" id="volume" min="0" max="100" step="1"
               style="min-width:220px">
        <span id="volval" style="color:var(--dim);font-size:13px">—</span>
      </div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-network">
    <h1>Network</h1>
    <section>
      <h2>Wi-Fi</h2>
      <div class="row">
        <label id="netstate">Checking…</label>
        <button class="ghost" id="scan">Scan for networks</button>
      </div>
      <div class="nets" id="nets"></div>
      <div class="row" style="margin-top:6px">
        <label>Hidden network
          <span class="hint">For a network that does not broadcast its
          name.</span></label>
        <input id="hidden" placeholder="network name">
        <button class="ghost" id="joinhidden">Join</button>
      </div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-time">
    <h1>Time &amp; language</h1>
    <section>
      <h2>Date and time</h2>
      <div class="row">
        <label>Set automatically
          <span class="hint">Needs a network connection.</span></label>
        <input type="checkbox" id="autotime">
      </div>
      <div class="row">
        <label>Time zone</label>
        <input id="timezone" placeholder="Europe/Berlin">
      </div>
      <div class="row">
        <label>Set manually
          <span class="hint">YYYY-MM-DD HH:MM</span></label>
        <input id="clock" placeholder="2026-08-30 14:30">
      </div>
    </section>
    <section>
      <h2>Language</h2>
      <div class="row">
        <label>Language
          <span class="hint">Reopen a window to see the change.</span></label>
        <select id="language">
          <option value="en">English</option>
          <option value="fa">فارسی</option>
        </select>
      </div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-assistant">
    <h1>Assistant</h1>
    <p class="lede">These can all be changed by asking, too. They are here
      because this window works when the assistant does not.</p>
    <section>
      <h2>Cloud model</h2>
      <div class="row">
        <label>Use a cloud model
          <span class="hint">Optional. OSprime works fully without it.
          Your key stays on this machine.</span></label>
        <select id="cloudmode">
          <option value="off">Never</option>
          <option value="ask">Only when I ask</option>
          <option value="auto">When the local model cannot cope</option>
        </select>
      </div>
      <div class="row">
        <label>API key</label>
        <input id="apikey" type="password" placeholder="not set">
      </div>
    </section>
    <section>
      <h2>Asking before acting</h2>
      <div class="row">
        <label>Check with me before
          <span class="hint">Deleting files, shutting down and installing
          software are always treated as risky, whatever this is set
          to.</span></label>
        <select id="confirmlevel">
          <option value="everything">anything at all</option>
          <option value="moderate">anything that changes this computer</option>
          <option value="dangerous">only risky things</option>
          <option value="nothing">never ask</option>
        </select>
      </div>
    </section>
    <section>
      <h2>What it remembers about you</h2>
      <div class="row">
        <label id="memcount">Reading…</label>
        <button class="ghost" id="forgetall">Forget everything</button>
      </div>
      <div id="memlist" class="mems"></div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-apps">
    <h1>Applications</h1>
    <p class="lede">Everything here is published by the people who made it,
      runs in a sandbox, and can be removed completely. You can also just
      ask the assistant for what you need.</p>
    <section>
      <h2>Add something</h2>
      <div class="row">
        <label>What do you need it to do?
          <span class="hint">Describe the job — "edit photos", "play
          videos" — rather than guessing a name.</span></label>
        <input id="appq" placeholder="photo editor">
        <button id="appsearch">Search</button>
      </div>
      <div id="appresults" class="mems"></div>
    </section>
    <section>
      <h2>Installed</h2>
      <div id="applist" class="mems"><div class="empty">reading…</div></div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-storage">
    <h1>Storage</h1>
    <section>
      <h2>This disk</h2>
      <div class="facts" id="diskfacts"><div class="fact"><div class="k">reading…</div></div></div>
    </section>
    <section>
      <h2>Biggest folders in your home</h2>
      <div id="bigfolders" class="mems"><div class="mem">reading…</div></div>
    </section>
    <section>
      <h2>Safe to delete</h2>
      <p class="lede" style="margin:0 0 10px">Caches, the trash, downloaded
        installers and old OSprime backups. Nothing here is your own work.
        Ask the assistant to clear any of them.</p>
      <div id="reclaim" class="mems"></div>
    </section>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <div class="page" id="page-system">
    <h1>System</h1>
    <section>
      <h2>Updates</h2>
      <div class="row">
        <label>Version <span class="hint" id="verline">v{{VERSION}}</span></label>
        <button id="updbtn">Check for updates</button>
      </div>
    </section>
    <section>
      <h2>If an update went wrong</h2>
      <div class="row">
        <label id="rbstate">Checking for a previous version…
          <span class="hint">Puts the code back as it was and restarts.
          Your files and settings are not touched.</span></label>
        <button class="ghost" id="rbbtn" disabled>Go back</button>
      </div>
    </section>
  </div>
</main>
</div>

<div id="note"></div>

<script>
const $ = id => document.getElementById(id);
let saving = false;

function note(msg, ms = 2600) {
  const n = $("note");
  n.textContent = msg; n.style.display = "block";
  clearTimeout(n._t); n._t = setTimeout(() => n.style.display = "none", ms);
}

// ---- navigation -------------------------------------------------------
// The desktop's right-click menu opens this window at a section, and those
// names are already in shipped code and in menu entries. "appearance" was
// its own section before the pages existed; it is part of Display now, and
// an old link must still land somewhere sensible rather than on a blank
// window.
const ALIAS = { appearance: "display", wifi: "network", sound: "sound",
                about: "system", update: "system", clock: "time",
                memory: "assistant", disk: "storage",
                applications: "apps", software: "apps", install: "apps" };
const PAGES = [...document.querySelectorAll("nav a")].map(a => a.dataset.page);
// Every page in the nav must have a panel behind it, and the other way
// round. Getting this wrong shows an empty window rather than an error, so
// it says so in the console instead of failing silently.
(() => {
  const built = [...document.querySelectorAll(".page")].map(p => p.id.slice(5));
  const missing = PAGES.filter(p => !built.includes(p));
  const orphan  = built.filter(p => !PAGES.includes(p));
  if (missing.length) console.error("nav entries with no page:", missing);
  if (orphan.length)  console.error("pages with no nav entry:", orphan);
})();

function show(page) {
  page = ALIAS[page] || page;
  if (!PAGES.includes(page)) page = PAGES[0];
  document.querySelectorAll(".page").forEach(
    p => p.classList.toggle("on", p.id === "page-" + page));
  document.querySelectorAll("nav a").forEach(
    a => a.classList.toggle("on", a.dataset.page === page));
  // Read when the page is opened, not at startup. These change while the
  // window is open — the assistant is still learning things, the disk is
  // still filling — and a number fetched once at load would be a number
  // that was true earlier.
  if (page === "machine")   loadMachine();
  if (page === "network")   $("scan").click();
  if (page === "assistant") loadMemory();
  if (page === "apps")      loadApps();
  if (page === "storage")   loadStorage();
  if (page === "system")    loadBackups();
}

document.querySelectorAll("nav a").forEach(a => {
  a.onclick = () => { location.hash = a.dataset.page; };
});
window.addEventListener("hashchange", () => show(location.hash.slice(1)));

// ---- settings ---------------------------------------------------------
async function apply(key, value) {
  if (saving) return;
  saving = true;
  try {
    const r = await (await fetch("/api/settings", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({key, value})
    })).json();
    note(r.message || (r.ok ? "Saved" : "Could not save"));
  } catch (e) { note("Could not save: " + e); }
  saving = false;
}

async function load() {
  let s;
  try { s = await (await fetch("/api/settings")).json(); }
  catch (e) { return note("Could not read settings"); }
  if (s.wallpaper) $("wallpaper").value = s.wallpaper;
  if (s.language)  $("language").value  = s.language;
  $("deskicons").checked = s.desktop !== false;
  if (s.timezone)  $("timezone").value  = s.timezone;
  $("autotime").checked = !!s.auto_time;
  if (s.volume !== undefined && s.volume !== null) {
    $("volume").value = s.volume; $("volval").textContent = s.volume + "%";
  }
  $("cloudmode").value = s.cloud_mode || "off";
  if (s.confirm_level) $("confirmlevel").value = s.confirm_level;
  if (s.has_api_key) $("apikey").placeholder = "key is set";
  $("netstate").textContent = s.network || "Not connected";
}

async function loadDisplay() {
  let d;
  try { d = await (await fetch("/api/display")).json(); } catch (e) { return; }
  const screen = (d.screens || [])[0];
  if (!screen) { $("resolution").innerHTML = "<option>not available</option>"; return; }
  $("resolution").innerHTML = "";
  (screen.modes || []).forEach(m => {
    const o = document.createElement("option");
    o.value = m; o.textContent = m;
    if (m === screen.current) o.selected = true;
    $("resolution").appendChild(o);
  });
  const sc = parseFloat(screen.scale || "1");
  if (!isNaN(sc)) {
    const opt = [...$("scale").options].find(o => parseFloat(o.value) === sc);
    if (opt) opt.selected = true;
  }
}

// ---- this machine -----------------------------------------------------
function fact(k, v, sub) {
  return '<div class="fact"><div class="k">' + k + '</div><div class="v">' +
         v + (sub ? ' <small>' + sub + '</small>' : '') + '</div></div>';
}

async function loadMachine() {
  let d;
  try { d = await (await fetch("/api/overview")).json(); }
  catch (e) { $("hwfacts").innerHTML = fact("Could not read this machine", "—"); return; }

  const m = d.machine || {}, gpu = m.gpu || {};
  $("hwfacts").innerHTML =
    fact("Processor", m.cpu || "unknown", (m.cores ? m.cores + " cores" : "")) +
    fact("Memory", m.ram_gb ? m.ram_gb + " GB" : "unknown") +
    fact("Free space", d.disk_free || "unknown",
         d.disk_used ? d.disk_used + " used" : "") +
    fact("Graphics", gpu.present ? (gpu.kind || "present") : "none found",
         gpu.present && gpu.vram_gb ? gpu.vram_gb + " GB" : "") +
    fact("Network", d.network || "not connected") +
    fact("System", "OSprime v" + (d.version || "?"),
         d.kernel ? "Linux " + d.kernel : "");

  const now = d.running_now || {}, eng = d.engine || {};
  $("modelfacts").innerHTML =
    fact("Model", now.label || now.tier || "not running") +
    fact("Running on", eng.running_on === "gpu" ? "the graphics card"
                     : eng.running_on === "cpu" ? "the processor"
                     : "not running",
         eng.running_on === "unknown" ? "" : "") +
    fact("Context", (now.context || "?") + " tokens");

  // Only shown when it is actionable. A permanent "you could do better"
  // that the user cannot act on is noise.
  if (d.can_do_better && (d.recommended || {}).label) {
    $("modeladvice").style.display = "";
    $("modeladvicetext").innerHTML =
      "This machine could run <b>" + d.recommended.label +
      "</b>. Ask the assistant to upgrade its model.";
  } else {
    $("modeladvice").style.display = "none";
  }
}

// ---- what the assistant remembers -------------------------------------
// Shown in the user's own words, as the assistant stored them, with a way
// to take each one back. A product that remembers you and gives you no way
// to see or erase what it remembers is not one worth selling.
function esc(s) {
  const d = document.createElement("div");
  d.textContent = s == null ? "" : String(s);
  return d.innerHTML;
}

async function loadMemory() {
  let d;
  try { d = await (await fetch("/api/memory")).json(); }
  catch (e) { $("memcount").textContent = "Could not read its memory"; return; }

  if (!d.ok) {
    $("memcount").textContent = "Could not read its memory";
    $("memlist").innerHTML = '<div class="empty">' +
      esc(d.message || "") + "</div>";
    $("forgetall").disabled = true;
    return;
  }
  $("memcount").textContent = d.count === 0 ? "It has not kept anything yet"
    : d.count === 1 ? "It has kept 1 thing" : "It has kept " + d.count + " things";
  $("forgetall").disabled = d.count === 0;

  if (!d.memories.length) {
    $("memlist").innerHTML =
      '<div class="empty">Things it learns from your conversations will ' +
      'appear here. A conversation has to end before it keeps anything.</div>';
    return;
  }
  $("memlist").innerHTML = d.memories.map(m =>
    '<div class="mem" data-id="' + m.id + '">' +
      '<span class="txt">' + esc(m.fact) + '</span>' +
      '<span class="when">' + esc(m.t || "") + '</span>' +
      '<button class="x">Forget</button>' +
    '</div>').join("");
}

$("memlist").onclick = async ev => {
  if (!ev.target.classList.contains("x")) return;
  const row = ev.target.closest(".mem");
  const r = await (await fetch("/api/memory/forget", {
    method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ id: parseInt(row.dataset.id, 10) })
  })).json();
  note(r.message || "Forgotten");
  loadMemory();
};

$("forgetall").onclick = async () => {
  // A real confirm(), because this one cannot be undone. Everything else in
  // this window is a setting you can set back.
  if (!confirm("Forget everything the assistant has learned about you?\n\n" +
               "This cannot be undone.")) return;
  const r = await (await fetch("/api/memory/forget", {
    method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ all: true })
  })).json();
  note(r.message || "Forgotten", 4000);
  loadMemory();
};

// ---- applications -----------------------------------------------------
// The same functions the assistant calls, through the same endpoints. A
// button here cannot do anything a person could not also ask for.
async function loadApps() {
  let d;
  try { d = await (await fetch("/api/apps")).json(); }
  catch (e) { $("applist").innerHTML = '<div class="empty">Could not read ' +
              'the list of applications.</div>'; return; }

  const apps = d.apps || [];
  if (!apps.length) {
    $("applist").innerHTML = '<div class="empty">Nothing installed yet.</div>';
    return;
  }
  $("applist").innerHTML = apps.map(a =>
    '<div class="mem" data-id="' + esc(a.id) + '">' +
      '<span class="txt">' + esc(a.name) + '</span>' +
      '<span class="when">' + esc(a.size || "") + '</span>' +
      (a.removable
        ? '<button class="x">Remove</button>'
        : '<span class="when">part of OSprime</span>') +
    '</div>').join("");
}

$("applist").onclick = async ev => {
  if (!ev.target.classList.contains("x")) return;
  const row = ev.target.closest(".mem");
  const name = row.querySelector(".txt").textContent;
  if (!confirm("Remove " + name + " from this computer?")) return;
  ev.target.disabled = true; ev.target.textContent = "…";
  const r = await (await fetch("/api/apps/uninstall", {
    method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ app_id: row.dataset.id })
  })).json();
  note(r.message || "Removed", 6000);
  loadApps();
};

async function searchApps() {
  const q = $("appq").value.trim();
  if (!q) return;
  const b = $("appsearch");
  b.disabled = true; b.textContent = "Searching…";
  $("appresults").innerHTML = '<div class="empty">Looking…</div>';
  let d;
  try {
    d = await (await fetch("/api/apps/search", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ query: q })
    })).json();
  } catch (e) { d = { results: [], note: "" + e }; }
  b.disabled = false; b.textContent = "Search";

  const rs = d.results || [];
  if (!rs.length) {
    // No second catalogue to offer, so do not imply there is one.
    $("appresults").innerHTML = '<div class="empty">' +
      esc(d.note || d.message || "Nothing in the catalogue matches that.") +
      "</div>";
    return;
  }
  $("appresults").innerHTML = rs.map(a =>
    '<div class="mem" data-id="' + esc(a.id) + '">' +
      '<span class="txt"><b>' + esc(a.name) + '</b><br>' +
        '<span style="color:var(--dim);font-size:12px">' +
        esc(a.what_it_is || "") + '</span></span>' +
      '<button class="x add">Install</button>' +
    '</div>').join("");
}

$("appsearch").onclick = searchApps;
$("appq").onkeydown = e => { if (e.key === "Enter") searchApps(); };

$("appresults").onclick = async ev => {
  if (!ev.target.classList.contains("add")) return;
  const row = ev.target.closest(".mem");
  ev.target.disabled = true; ev.target.textContent = "Installing…";
  // Said out loud, because the first install pulls a shared runtime and
  // can take minutes. A button that looks stuck is how people conclude it
  // is broken and click it again.
  note("Installing — the first one takes a few minutes.", 30000);
  let r;
  try {
    r = await (await fetch("/api/apps/install", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ app_id: row.dataset.id })
    })).json();
  } catch (e) { r = { ok: false, message: "" + e }; }
  note(r.message || (r.ok ? "Installed" : "Could not install"), 10000);
  if (r.ok) { row.remove(); loadApps(); }
  else { ev.target.disabled = false; ev.target.textContent = "Install"; }
};

// ---- storage ----------------------------------------------------------
async function loadStorage() {
  let d;
  try { d = await (await fetch("/api/storage")).json(); }
  catch (e) { $("diskfacts").innerHTML = fact("Could not read the disk", "—"); return; }

  const u = (d.usage || {}).disk || {};
  const apps = (d.usage || {}).applications_size;
  $("diskfacts").innerHTML =
    fact("Free", u.free || "unknown") +
    fact("Used", u.used || "unknown", u.used_percent || "") +
    fact("Total", u.total || "unknown") +
    // A fact, not a suggestion. These are the user's own applications.
    (apps ? fact("Applications", apps, "programs you installed") : "");

  const big = (d.usage || {}).largest_folders_in_home || [];
  $("bigfolders").innerHTML = big.length
    ? big.map(b => '<div class="mem"><span class="txt">' + esc(b.folder) +
        '</span><span class="when">' + esc(b.size) + '</span></div>').join("")
    : '<div class="empty">Nothing large enough to be worth listing.</div>';

  const rec = (d.usage || {}).safe_to_delete || [];
  $("reclaim").innerHTML = rec.length
    ? rec.map(r => '<div class="mem"><span class="txt">' + esc(r.what_it_is) +
        '</span><span class="when">' + esc(r.size) + '</span></div>').join("")
    : '<div class="empty">Nothing worth clearing right now.</div>';
}

// ---- rollback ---------------------------------------------------------
async function loadBackups() {
  let d;
  try { d = await (await fetch("/api/backups")).json(); } catch (e) { d = {}; }
  const b = (d.backups || [])[0];
  if (!b) {
    $("rbstate").innerHTML = "No previous version is kept on this machine " +
      '<span class="hint">There will be one after the next update.</span>';
    $("rbbtn").disabled = true;
    return;
  }
  $("rbstate").innerHTML = "Previous version, saved " + esc(b) +
    '<span class="hint">Puts the code back as it was and restarts. ' +
    'Your files and settings are not touched.</span>';
  $("rbbtn").disabled = false;
}

$("rbbtn").onclick = async () => {
  if (!confirm("Go back to the previous version of OSprime?\n\n" +
               "The screen will restart in a moment.")) return;
  const b = $("rbbtn");
  b.disabled = true; b.textContent = "Going back…";
  let r;
  try {
    r = await (await fetch("/api/rollback", {method: "POST"})).json();
  } catch (e) { r = {ok: false, message: "" + e}; }
  note(r.message || (r.ok ? "Done" : "Could not roll back"), 8000);
  if (r.ok) setTimeout(() => location.reload(), 4000);
  else { b.disabled = false; b.textContent = "Go back"; }
};

// ---- wiring -----------------------------------------------------------
$("scale").onchange      = e => apply("scale", e.target.value);
$("resolution").onchange = e => apply("resolution", e.target.value);
$("wallpaper").onchange  = e => apply("wallpaper", e.target.value);
$("language").onchange   = e => apply("language", e.target.value);
$("deskicons").onchange  = e => apply("desktop", e.target.checked);
$("timezone").onchange   = e => apply("timezone", e.target.value.trim());
$("autotime").onchange   = e => apply("auto_time", e.target.checked);
$("clock").onchange      = e => apply("time", e.target.value.trim());
$("cloudmode").onchange  = e => apply("cloud_mode", e.target.value);
$("confirmlevel").onchange = e => apply("confirm_level", e.target.value);
$("apikey").onchange     = e => { apply("api_key", e.target.value); e.target.value = ""; };
$("volume").oninput      = e => $("volval").textContent = e.target.value + "%";
$("volume").onchange     = e => apply("volume", parseInt(e.target.value, 10));

async function joinNetwork(ssid, password, row) {
  note("Connecting to " + ssid + "…", 20000);
  let r;
  try {
    r = await (await fetch("/api/wifi/connect", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ssid, password: password || ""})
    })).json();
  } catch (e) { r = {ok: false, message: "" + e}; }
  note(r.message || (r.ok ? "Connected" : "Could not connect"), 6000);
  if (r.ok) { if (row) row.remove(); load(); $("scan").click(); }
  return r.ok;
}

// Asking for the password inline rather than through a browser prompt():
// prompt() is blocked or suppressed in an app window, which left clicking a
// secured network doing nothing at all with no way to tell why.
function askPassword(el, ssid) {
  if (el.querySelector("input[type=password]")) return;
  const box = document.createElement("div");
  box.style.cssText = "display:flex;gap:8px;margin-top:8px;width:100%";
  const inp = document.createElement("input");
  inp.type = "password"; inp.placeholder = "Password for " + ssid;
  inp.style.flex = "1";
  const go = document.createElement("button");
  go.textContent = "Join";
  const submit = async () => {
    if (!inp.value) { inp.focus(); return; }
    go.disabled = true; go.textContent = "…";
    const ok = await joinNetwork(ssid, inp.value, null);
    if (!ok) { go.disabled = false; go.textContent = "Join"; inp.select(); }
  };
  go.onclick = submit;
  inp.onkeydown = e => { if (e.key === "Enter") submit(); };
  box.append(inp, go);
  el.appendChild(box);
  inp.focus();
}

$("scan").onclick = async () => {
  if ($("scan").disabled) return;
  $("scan").disabled = true; $("scan").textContent = "Scanning…";
  const box = $("nets"); box.innerHTML = "";
  try {
    const nets = await (await fetch("/api/wifi/scan")).json();
    (nets.networks || []).forEach(n => {
      const el = document.createElement("div");
      el.className = "net";
      el.style.flexWrap = "wrap";
      const tags = [];
      if (n.active) tags.push("connected");
      else if (n.saved) tags.push("saved");
      if (n.secured) tags.push("locked");
      el.innerHTML = "<span>" + n.ssid + "</span>" +
        "<span class='sig'>" + tags.join(" · ") + "</span>" +
        "<span class='sig'>" + (n.signal || "") + "%</span>";
      el.onclick = () => {
        if (n.active) return;
        // A saved network already has its password stored.
        if (!n.secured || n.saved) joinNetwork(n.ssid, "", null);
        else askPassword(el, n.ssid);
      };
      box.appendChild(el);
    });
    if (!(nets.networks || []).length) note(nets.message || "No networks found", 6000);
  } catch (e) { note("Scan failed: " + e); }
  $("scan").disabled = false; $("scan").textContent = "Scan for networks";
};

$("joinhidden").onclick = () => {
  const ssid = $("hidden").value.trim();
  if (!ssid) return;
  askPassword($("joinhidden").parentElement, ssid);
};

$("updbtn").onclick = async () => {
  const b = $("updbtn");
  b.disabled = true; b.textContent = "Checking…";
  let info;
  try { info = await (await fetch("/api/update/check")).json(); }
  catch (e) { note("Could not reach the update server"); b.disabled = false;
              b.textContent = "Check for updates"; return; }
  if (!info.available) {
    note(info.reason ? "Could not reach the update server" : "Already up to date");
    b.disabled = false; b.textContent = "Check for updates"; return;
  }
  b.textContent = "Install " + info.latest;
  b.disabled = false;
  b.onclick = async () => {
    b.disabled = true; b.textContent = "Installing…";
    const r = await (await fetch("/api/update/install", {method: "POST"})).json();
    note(r.message || "Done", 6000);
    if (r.ok) setTimeout(() => location.reload(), 2000);
    else { b.disabled = false; b.textContent = "Retry"; }
  };
};

show(location.hash.slice(1) || "machine");
load();
loadDisplay();
</script>
"""
