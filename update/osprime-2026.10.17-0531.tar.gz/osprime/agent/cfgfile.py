"""One way to change the assistant's config file: read, change and write
under one lock that every process and thread shares.

Review, 17 October: saving a setting and adding a reminder each read the
whole file, changed their part and wrote it all back, with no common lock.
A reminder added while the confirm level was being changed wrote the old
level back — both said they had saved. Replacing the file atomically does
not prevent that; holding one lock for the whole read-change-write does.
"""
import contextlib
import fcntl
import json
import os
import pathlib
import tempfile
import threading

_threads = threading.RLock()
_held = threading.local()


@contextlib.contextmanager
def locked(path):
    """Exclusive across processes (flock) and threads; re-entrant in a thread."""
    p = pathlib.Path(path)
    key = str(p.resolve()) if p.exists() else str(p.absolute())
    depth = getattr(_held, "depth", {})
    _held.depth = depth
    if depth.get(key):
        depth[key] += 1
        try:
            yield
        finally:
            depth[key] -= 1
        return
    with _threads:
        p.parent.mkdir(parents=True, exist_ok=True)
        try:
            fd = os.open(str(p.with_name(p.name + ".lock")), os.O_RDWR | os.O_CREAT, 0o600)
        except OSError:
            fd = os.open(str(p), os.O_RDWR | os.O_CREAT, 0o600)   # a folder we cannot add to
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            depth[key] = 1
            try:
                yield
            finally:
                depth[key] = 0
                fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def read(path) -> dict:
    try:
        d = json.loads(pathlib.Path(path).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def write(path, data: dict):
    """Atomic where the folder allows it; in place where it does not."""
    p = pathlib.Path(path)
    text = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    try:
        mode = p.stat().st_mode & 0o777 if p.exists() else 0o644
        fd, tmp = tempfile.mkstemp(dir=str(p.parent), prefix=p.name + ".", suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.chmod(tmp, mode)
        os.replace(tmp, p)
    except OSError:
        p.write_text(text, encoding="utf-8")


def update(path, change):
    """change(cfg) edits the dict in place; its return value is returned."""
    with locked(path):
        cfg = read(path)
        out = change(cfg)
        write(path, cfg)
        return out
