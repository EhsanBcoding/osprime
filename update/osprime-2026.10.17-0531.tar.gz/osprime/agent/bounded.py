"""Run a shell command without letting its output fill the memory.

subprocess.run(capture_output=True) keeps EVERYTHING a command prints until
it ends, and only then was it cut to 8,000 characters (review, 17 October:
an 8-million-character output reached the cutting whole). Here the output is
read as it comes and only the last KEEP bytes are held; the beginning is
dropped as it is read. Used by run_shell and by background jobs.
"""
import os
import select
import signal
import subprocess
import time

KEEP = 64 * 1024          # the tail kept; callers show at most 8,000 characters of it


def run(cmd: str, timeout: int, env=None, cwd=None, keep: int = KEEP):
    """-> (exit code, text, dropped bytes). Exit code 124 on timeout."""
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL, env=env, cwd=cwd, start_new_session=True)
    buf = bytearray()
    dropped = 0
    deadline = time.monotonic() + timeout
    fd = p.stdout.fileno()
    os.set_blocking(fd, False)
    timed_out = False
    try:
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                timed_out = True
                break
            # Read only what select says is there. The shell ending does not
            # end the output: a child it started may still hold the pipe, and
            # a blocking read would wait for that child past the deadline
            # (review, 17 October: a 0.25 s limit took 2.14 s and reported 0).
            ready, _, _ = select.select([fd], [], [], min(left, 0.25))
            if not ready:
                continue
            try:
                chunk = os.read(fd, 65536)
            except BlockingIOError:
                continue
            if not chunk:
                break
            buf += chunk
            if len(buf) > keep:
                dropped += len(buf) - keep
                del buf[:len(buf) - keep]
        # The output closed, but a program may close it (or send it to a
        # file) and keep working: wait for the program itself, within the
        # time it has left (review, 17 October: it was killed at once).
        if not timed_out:
            try:
                p.wait(timeout=max(0.0, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                timed_out = True
    finally:
        if timed_out or p.poll() is None:
            try:
                os.killpg(p.pid, signal.SIGKILL)     # the whole group: shell and children
            except OSError:
                pass
        try:
            p.stdout.close()
        except OSError:
            pass
        p.wait()
    text = buf.decode("utf-8", "replace")
    if dropped:
        text = f"[… {dropped:,} earlier bytes of output not kept …]\n" + text
    if timed_out:
        return 124, text + f"\n[stopped after {timeout} s]", dropped
    return p.returncode, text, dropped
