"""Everyday jobs that used to go through run_shell (tool check 3, Ehsan, 16 October).

Moving a file, unzipping a download, quitting a frozen program, dimming the
screen and pausing the music are things people ask for every day. Through
run_shell each one was a shell command the model wrote, judged by
permissions.py and — since the reviews of 15 and 16 October — often asked
about. Here each is a named job with fixed rules:

  * manage_files — move, copy, rename, make a folder. Only inside the
    person's home, never in hidden folders, never over an existing file,
    never into a folder programs start from.
  * archive     — make a .zip, look inside or unpack .zip/.tar.* — every
    member checked: no absolute paths, no "..", no links, no device files,
    a ceiling on size and count. Unpacked into a NEW folder.
  * processes   — what is using the computer, and quitting a program by name
    (the person's own programs only, never the desktop or OSprime itself).
  * brightness  — the screen's backlight, through logind (no root needed).
  * media       — play, pause, next, previous, what is playing (MPRIS).

No shell anywhere: every program is run with a fixed argument list.
"""
import json
import os
import pathlib
import re
import shutil
import signal
import stat
import subprocess
import tarfile
import time
import zipfile

import system_tools as st

# ---------------------------------------------------------------- paths --

def _home() -> pathlib.Path:
    return st._user_home().resolve()


def _place(raw, must_exist=True):
    """A path as the person meant it, checked. -> Path, or an 'ERROR: …' string."""
    raw = str(raw or "").strip().strip("\"'")
    if not raw:
        return "ERROR: say which file or folder."
    key = raw.lower().strip("/").lstrip("~").strip("/")
    home = _home()
    if key in st._FOLDER_ALIASES:
        rel = st._FOLDER_ALIASES[key]
        p = home / rel if rel else home
    else:
        p = pathlib.Path(os.path.expanduser(raw))
        if not p.is_absolute():
            p = home / raw
        if not p.exists():
            p = st._case_walk(p)
    if must_exist and not p.exists() and not p.is_symlink():
        return (f"ERROR: there is nothing at {p}. Use list_files to see what the folder "
                "really contains — do not guess a name.")
    why = _not_allowed(p)
    return f"ERROR: {why}" if why else p


def _not_allowed(p: pathlib.Path) -> str:
    """'' when OSprime's file jobs may touch this path, else why not."""
    import permissions
    home = _home()
    try:
        real = p.resolve() if (p.exists() or p.is_symlink()) else \
            p.parent.resolve() / p.name
    except OSError:
        return f"{p} cannot be read"
    if real != home and home not in real.parents:
        return (f"{real} is outside your home folder. These file jobs only work in your own "
                "folders.")
    rel = real.relative_to(home).parts if real != home else ()
    if any(part.startswith(".") for part in rel):
        return (f"{real} is in a hidden folder (settings and programs live there). Not "
                "touched by this job.")
    if permissions.touches_secret(str(real)) or permissions._PERSISTENCE.search(str(real)):
        return f"{real} is a place programs or secrets are kept. Not touched by this job."
    return ""


def _unique(dest: pathlib.Path) -> pathlib.Path:
    n = 2
    base = dest
    while dest.exists() or dest.is_symlink():
        if base.is_dir() or not base.suffix:
            dest = base.with_name(f"{base.name} ({n})")
        else:
            dest = base.with_name(f"{base.stem} ({n}){base.suffix}")
        n += 1
    return dest


def _short(p: pathlib.Path) -> str:
    home = _home()
    try:
        return "~/" + str(p.resolve().relative_to(home))
    except ValueError:
        return str(p)


# --------------------------------------------------------- manage_files --

def manage_files(action: str = "", source="", destination: str = "", name: str = "") -> str:
    """move | copy | rename | make_folder — never overwriting anything."""
    action = str(action or "").strip().lower().replace(" ", "_").replace("-", "_")
    action = {"mv": "move", "cp": "copy", "duplicate": "copy", "mkdir": "make_folder",
              "new_folder": "make_folder", "create_folder": "make_folder", "folder": "make_folder"
              }.get(action, action)
    if action == "make_folder":
        where = destination or name or (source if isinstance(source, str) else "")
        if not where:
            return "ERROR: say where the new folder goes, e.g. destination='Documents/Taxes'."
        p = _place(where, must_exist=False)
        if isinstance(p, str):
            return p
        if p.exists():
            return f"{_short(p)} already exists — nothing to do."
        try:
            p.mkdir(parents=True)
        except OSError as e:
            return f"ERROR: could not make {_short(p)}: {e.strerror or e}"
        return f"made the folder {_short(p)}"

    sources = st._as_list(source)
    if not sources:
        return "ERROR: say which file or folder (source)."
    if action == "rename":
        new = str(name or destination or "").strip().strip("\"'")
        if len(sources) != 1:
            return "ERROR: rename one thing at a time."
        if not new or "/" in new or new in (".", "..") or new.startswith("."):
            return "ERROR: give the new name only (no folder, not starting with a dot)."
        src = _place(sources[0])
        if isinstance(src, str):
            return src
        dest = src.with_name(new)
        if src.suffix and not pathlib.Path(new).suffix and src.is_file():
            dest = src.with_name(new + src.suffix)     # "rename it to report" keeps .pdf
        if dest.exists():
            return (f"ERROR: {_short(dest)} already exists. Nothing renamed — pick another "
                    "name, or move the other one first.")
        why = _not_allowed(dest)
        if why:
            return f"ERROR: {why}"
        src.rename(dest)
        return f"renamed {src.name} to {dest.name} (in {_short(dest.parent)})"

    if action not in ("move", "copy"):
        return "ERROR: action must be move, copy, rename or make_folder."
    if not destination:
        return "ERROR: say where to (destination), e.g. 'Documents' or 'Pictures/Trip'."
    dest_raw = destination
    target = _place(dest_raw, must_exist=False)
    if isinstance(target, str):
        return target
    done = []
    for raw in sources:
        src = _place(raw)
        if isinstance(src, str):
            return src + (f" (done before that: {', '.join(done)})" if done else "")
        if src.resolve() == _home():
            return "ERROR: not the whole home folder."
        if target.is_dir():
            dest = target / src.name
        elif len(sources) > 1 or str(dest_raw).endswith("/") or (
                src.is_file() and src.suffix and not target.suffix):
            # "copy shopping.txt into Documents/Tool check" when that folder is
            # not there: a folder is meant, not a file named "Tool check"
            # (tool check 3, 16 October).
            try:
                target.mkdir(parents=True, exist_ok=True)
            except OSError as e:
                return f"ERROR: could not make {_short(target)}: {e.strerror or e}"
            dest = target / src.name
        else:
            if not target.parent.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
            dest = target
        if src.is_dir() and (dest.resolve() == src.resolve() or src.resolve() in dest.resolve().parents):
            return f"ERROR: cannot put {src.name} inside itself."
        dest = _unique(dest)
        why = _not_allowed(dest)
        if why:
            return f"ERROR: {why}"
        try:
            if action == "copy":
                if src.is_dir():
                    shutil.copytree(src, dest, symlinks=True)
                else:
                    shutil.copy2(src, dest, follow_symlinks=False)
            else:
                shutil.move(str(src), str(dest))
        except OSError as e:
            return (f"ERROR: could not {action} {src.name}: {e.strerror or e}"
                    + (f" (done before that: {', '.join(done)})" if done else ""))
        done.append(f"{src.name} → {_short(dest)}")
    verb = "copied" if action == "copy" else "moved"
    return f"{verb}: " + "; ".join(done)


# -------------------------------------------------------------- archive --

MAX_UNPACKED = 20 * 1024 ** 3      # 20 GB
MAX_MEMBERS = 100_000
_ARCHIVES = (".zip", ".tar", ".tar.gz", ".tgz", ".tar.xz", ".txz", ".tar.bz2", ".tbz2",
             ".tar.zst", ".tzst")


def _kind(p: pathlib.Path) -> str:
    n = p.name.lower()
    if n.endswith(".zip") or zipfile.is_zipfile(p):
        return "zip"
    if any(n.endswith(s) for s in _ARCHIVES):
        return "tar"
    try:
        if tarfile.is_tarfile(p):
            return "tar"
    except (OSError, tarfile.TarError):
        pass
    return ""


def _stem(p: pathlib.Path) -> str:
    n = p.name
    for s in sorted(_ARCHIVES, key=len, reverse=True):
        if n.lower().endswith(s):
            return n[: -len(s)] or "archive"
    return p.stem or "archive"


def _member_problem(name: str) -> str:
    if not name or name.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", name):
        return f"{name!r} has an absolute path"
    if ".." in re.split(r"[/\\]", name):
        return f"{name!r} climbs out of the folder"
    return ""


def archive(action: str = "", source="", destination: str = "") -> str:
    """zip | extract | list."""
    action = str(action or "").strip().lower()
    action = {"unzip": "extract", "unpack": "extract", "open": "extract", "compress": "zip",
              "create": "zip", "make": "zip", "show": "list", "contents": "list"}.get(action, action)
    if action == "zip":
        return _make_zip(st._as_list(source), destination)
    if action not in ("extract", "list"):
        return "ERROR: action must be zip, extract or list."
    files = st._as_list(source)
    if len(files) != 1:
        return "ERROR: name one archive."
    src = _place(files[0])
    if isinstance(src, str):
        return src
    if not src.is_file():
        return f"ERROR: {_short(src)} is not a file."
    kind = _kind(src)
    if not kind:
        if src.suffix.lower() in (".rar", ".7z"):
            return (f"ERROR: {src.suffix} archives are not supported by this job yet; .zip and "
                    ".tar.* are.")
        return f"ERROR: {src.name} is not a .zip or .tar archive."
    try:
        members = _members(src, kind)
    except Exception as e:
        return f"ERROR: {src.name} could not be read as an archive: {e}"
    if isinstance(members, str):
        return members
    if action == "list":
        total = sum(m[1] for m in members)
        shown = "\n".join(f"  {n}  ({_size(s)})" for n, s, _ in members[:40])
        more = f"\n  … and {len(members) - 40} more" if len(members) > 40 else ""
        return f"{src.name}: {len(members)} items, {_size(total)} unpacked\n{shown}{more}"
    base = _place(destination, must_exist=False) if destination else src.parent / _stem(src)
    if isinstance(base, str):
        return base
    out = _unique(base)
    why = _not_allowed(out)
    if why:
        return f"ERROR: {why}"
    out.mkdir(parents=True)
    try:
        if kind == "zip":
            with zipfile.ZipFile(src) as z:
                for info in z.infolist():
                    target = out / info.filename
                    if info.is_dir():
                        target.mkdir(parents=True, exist_ok=True)
                        continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with z.open(info) as fi, open(target, "xb") as fo:
                        shutil.copyfileobj(fi, fo, 1024 * 1024)
                    os.chmod(target, 0o644)
        else:
            with tarfile.open(src, "r:*") as t:
                for m in t.getmembers():
                    target = out / m.name
                    if m.isdir():
                        target.mkdir(parents=True, exist_ok=True)
                        continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    fi = t.extractfile(m)
                    with fi, open(target, "xb") as fo:
                        shutil.copyfileobj(fi, fo, 1024 * 1024)
                    os.chmod(target, 0o755 if m.mode & 0o111 else 0o644)
    except Exception as e:
        return f"ERROR: unpacking stopped: {e}. What was unpacked so far is in {_short(out)}."
    return f"unpacked {len(members)} items from {src.name} into {_short(out)}"


def _members(src, kind):
    """[(name, size, is_dir)] — or an ERROR string if anything is unsafe."""
    out, total = [], 0
    if kind == "zip":
        with zipfile.ZipFile(src) as z:
            infos = z.infolist()
            if len(infos) > MAX_MEMBERS:
                return f"ERROR: {src.name} holds more than {MAX_MEMBERS} items — not unpacked."
            for i in infos:
                bad = _member_problem(i.filename)
                mode = i.external_attr >> 16
                if not bad and stat.S_ISLNK(mode):
                    bad = f"{i.filename!r} is a link"
                if bad:
                    return f"ERROR: {src.name} is not safe to unpack: {bad}."
                total += i.file_size
                out.append((i.filename, i.file_size, i.is_dir()))
    else:
        with tarfile.open(src, "r:*") as t:
            for m in t:
                if len(out) >= MAX_MEMBERS:
                    return f"ERROR: {src.name} holds more than {MAX_MEMBERS} items — not unpacked."
                bad = _member_problem(m.name)
                if not bad and not (m.isfile() or m.isdir()):
                    bad = f"{m.name!r} is a link or a device, not a plain file"
                if bad:
                    return f"ERROR: {src.name} is not safe to unpack: {bad}."
                total += m.size
                out.append((m.name, m.size, m.isdir()))
    if total > MAX_UNPACKED:
        return f"ERROR: {src.name} would unpack to {_size(total)} — more than {_size(MAX_UNPACKED)}."
    return out


# Files that must not end up in an archive someone may share (review, 17
# October: zipping a parent folder put .ssh/id_ed25519 into the zip, while
# the key itself could not be touched directly). Checked for EVERY file,
# not only the folder named.
_PRIVATE_PARTS = {".ssh", ".gnupg", ".password-store", ".pki", ".aws", ".kube", ".docker", ".azure",
                  ".gcloud", "keyrings", ".mozilla", "chromium", "google-chrome", "brave",
                  ".thunderbird", ".electrum", "wallets"}
_PRIVATE_NAMES = re.compile(r"(?:^id_(?:rsa|dsa|ecdsa|ed25519)(?:_sk)?$|\.(?:pem|key|p12|pfx|kdbx|keychain|"
                            r"ovpn|asc|gpg)$|^\.netrc$|^\.pgpass$|^\.git-credentials$|^secrets\.env$|"
                            r"^cloud\.json$|^wallet\.dat$|^credentials(?:\.json)?$|^\.env$)", re.I)


def _private(f: pathlib.Path, base: pathlib.Path) -> bool:
    import permissions
    try:
        rel = f.relative_to(base).parts
    except ValueError:
        rel = f.parts
    return (permissions.touches_secret(str(f)) or bool(_PRIVATE_PARTS & {x.lower() for x in rel})
            or bool(_PRIVATE_NAMES.search(f.name)))


def _make_zip(sources, destination):
    if not sources:
        return "ERROR: say which files or folders to put in the zip (source)."
    paths = []
    for raw in sources:
        p = _place(raw)
        if isinstance(p, str):
            return p
        paths.append(p)
    if destination:
        dest = _place(destination if destination.lower().endswith(".zip") else destination + ".zip",
                      must_exist=False)
        if isinstance(dest, str):
            return dest
    else:
        name = paths[0].name if len(paths) == 1 else "files"
        dest = paths[0].parent / f"{pathlib.Path(name).stem if paths[0].is_file() else name}.zip"
    dest = _unique(dest)
    why = _not_allowed(dest)
    if why:
        return f"ERROR: {why}"
    # Everything that would go in, decided BEFORE the zip is made.
    members = []
    for p in paths:
        if p.is_dir():
            for f in sorted(p.rglob("*")):
                if f.is_symlink() or not f.is_file() or f.resolve() == dest.resolve():
                    continue
                members.append((f, f.relative_to(p.parent), p.parent))
        elif p.is_file():
            members.append((p, pathlib.Path(p.name), p.parent))
    private = [str(arc) for f, arc, base in members if _private(f, base)]
    if private:
        shown = ", ".join(private[:5]) + (f" and {len(private) - 5} more" if len(private) > 5 else "")
        return ("ERROR: not zipped — it would contain private files (keys, passwords or "
                f"browser data): {shown}. Zip the folders that do not hold them, or move those "
                "files out first.")
    count = 0
    try:
        with zipfile.ZipFile(dest, "x", zipfile.ZIP_DEFLATED) as z:
            for f, arc, _base in members:
                z.write(f, arc)
                count += 1
    except OSError as e:
        return f"ERROR: could not make {dest.name}: {e.strerror or e}"
    return f"made {_short(dest)} ({count} files, {_size(dest.stat().st_size)})"


def _size(n: int) -> str:
    for unit in ("bytes", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "bytes" else f"{n:.1f} {unit}"
        n /= 1024


# ------------------------------------------------------------ processes --

# Never quit by this job, whatever it is asked: the desktop, sound, the
# network, the session — and OSprime itself.
_PROTECTED = re.compile(
    r"^(labwc|waybar|xwayland|swaybg|mako|fnott|wireplumber|pipewire.*|dbus.*|systemd.*|"
    r"gnome-keyring.*|xdg-.*portal.*|at-spi.*|tailscaled|sshd|login|agetty|greetd|"
    r"bash|sh|zsh|fish|dash|python3?|osprime.*|polkit.*|networkmanager|nm-.*|wpa_supplicant)$", re.I)
# What people call a program -> its process name(s).
_ALIASES = {
    "browser": ("chromium", "firefox", "brave", "google-chrome", "chrome", "epiphany"),
    "web browser": ("chromium", "firefox", "brave", "google-chrome", "chrome", "epiphany"),
    "chrome": ("chromium", "google-chrome", "chrome"),
    "libreoffice": ("soffice.bin", "soffice", "oosplash"),
    "office": ("soffice.bin", "soffice", "oosplash"),
    "calc": ("soffice.bin",), "writer": ("soffice.bin",), "spreadsheet": ("soffice.bin",),
    "files": ("nautilus", "thunar", "pcmanfm", "pcmanfm-qt", "nemo", "dolphin"),
    "file manager": ("nautilus", "thunar", "pcmanfm", "pcmanfm-qt", "nemo", "dolphin"),
    "terminal": ("foot",), "music": ("rhythmbox", "lollypop", "spotify", "amberol"),
    "video": ("mpv", "vlc", "totem", "celluloid"), "vlc": ("vlc",),
    "gimp": ("gimp", "gimp-2.10", "gimp-3.0"), "image editor": ("gimp", "gimp-2.10", "gimp-3.0"),
}


def _procs():
    """[{pid, uid, name, cpu, mem_mb, exe}] from /proc."""
    out = []
    try:
        clk = os.sysconf("SC_CLK_TCK")
        up = float(pathlib.Path("/proc/uptime").read_text().split()[0])
    except (OSError, ValueError):
        clk, up = 100, 0
    for d in pathlib.Path("/proc").iterdir():
        if not d.name.isdigit():
            continue
        try:
            raw = (d / "stat").read_text()
            name = raw[raw.index("(") + 1: raw.rindex(")")]
            f = raw[raw.rindex(")") + 2:].split()
            utime, stime, start = int(f[11]), int(f[12]), int(f[19])
            rss = int(f[21]) * os.sysconf("SC_PAGE_SIZE")
            uid = d.stat().st_uid
            alive = max(1e-3, up - start / clk)
            cpu = 100.0 * (utime + stime) / clk / alive
            try:
                exe = os.path.basename(os.readlink(d / "exe"))
            except OSError:
                exe = ""
            out.append({"pid": int(d.name), "uid": uid, "name": name, "cpu": cpu,
                        "mem_mb": rss / 1024 / 1024, "exe": exe})
        except (OSError, ValueError, IndexError):
            continue
    return out


def _group(procs):
    """One line per program: browsers run as dozens of processes."""
    by = {}
    for p in procs:
        k = p["exe"] or p["name"]
        g = by.setdefault(k, {"name": k, "cpu": 0.0, "mem_mb": 0.0, "n": 0})
        g["cpu"] += p["cpu"]
        g["mem_mb"] += p["mem_mb"]
        g["n"] += 1
    return list(by.values())


def _alive(pid: int) -> bool:
    """Still running — a process that has ended but not been collected (Z) has quit."""
    try:
        raw = pathlib.Path(f"/proc/{pid}/stat").read_text()
        return raw[raw.rindex(")") + 2] not in "ZX"
    except (OSError, ValueError, IndexError):
        return False


def processes(action: str = "list", app: str = "", force: bool = False) -> str:
    """list — what is using the computer; quit — end a program by its name."""
    action = str(action or "list").strip().lower()
    action = {"kill": "quit", "close": "quit", "stop": "quit", "end": "quit", "force_quit": "quit",
              "top": "list", "show": "list"}.get(action, action)
    if action == "list":
        return _list_procs()
    if action != "quit":
        return "ERROR: action must be list or quit."
    want = str(app or "").strip().lower()
    if not want:
        return "ERROR: say which program to quit."
    names = set(_ALIASES.get(want, ())) | {want, want.replace(" ", "-")}
    me = os.geteuid()
    mine = [p for p in _procs() if p["uid"] == me and p["pid"] != os.getpid()]
    hits = [p for p in mine if p["name"].lower() in names or p["exe"].lower() in names]
    if not hits:
        return (f"ERROR: no program of yours called {app!r} is running. Use processes with "
                "action=list to see what is.")
    blocked = [p for p in hits if _PROTECTED.match(p["name"]) or _PROTECTED.match(p["exe"] or "-")]
    if blocked:
        return (f"ERROR: {blocked[0]['name']} is part of the desktop or of OSprime — quitting it "
                "would break the session. Not done.")
    for p in hits:
        try:
            os.kill(p["pid"], signal.SIGTERM)
        except OSError:
            pass
    deadline = time.monotonic() + 4
    left = hits
    while left and time.monotonic() < deadline:
        time.sleep(0.25)
        left = [p for p in left if _alive(p["pid"])]
    if left and force:
        for p in left:
            try:
                os.kill(p["pid"], signal.SIGKILL)
            except OSError:
                pass
        time.sleep(0.5)
        left = [p for p in left if _alive(p["pid"])]
        if not left:
            return f"{app} did not answer, so it was forced to quit (unsaved work in it is lost)."
    if left:
        return (f"{app} was asked to quit but is still running (it may be showing a 'save your "
                "work?' question). If it is frozen, call processes again with force=true — "
                "unsaved work in it would be lost; say so to the user first.")
    return f"{app} has quit ({len(hits)} process{'es' if len(hits) > 1 else ''})."


def _list_procs() -> str:
    groups = _group(_procs())
    try:
        load = os.getloadavg()[0]
        cores = os.cpu_count() or 1
        mem = {k: int(v.split()[0]) for k, v in (l.split(":", 1) for l in
               pathlib.Path("/proc/meminfo").read_text().splitlines() if ":" in l)}
        used = (mem["MemTotal"] - mem["MemAvailable"]) / 1024 / 1024
        head = (f"Busy: {min(100, load / cores * 100):.0f}% of the processor right now; memory "
                f"{used:.1f} of {mem['MemTotal'] / 1024 / 1024:.1f} GB in use.")
    except (OSError, KeyError, ValueError):
        head = ""
    by_cpu = sorted(groups, key=lambda g: g["cpu"], reverse=True)[:6]
    by_mem = sorted(groups, key=lambda g: g["mem_mb"], reverse=True)[:6]
    lines = [head, "Using the processor most (average since each started):"]
    lines += [f"  {g['name']}: {g['cpu']:.0f}%" + (f" ({g['n']} processes)" if g["n"] > 1 else "")
              for g in by_cpu]
    lines.append("Using the most memory:")
    lines += [f"  {g['name']}: {g['mem_mb']:.0f} MB" for g in by_mem]
    return "\n".join(l for l in lines if l)


# ----------------------------------------------------------- brightness --

BACKLIGHT = pathlib.Path(os.environ.get("OSPRIME_BACKLIGHT", "/sys/class/backlight"))


def _panel():
    """(name, current, max) of the screen's backlight, raw panels first."""
    try:
        devs = [d for d in BACKLIGHT.iterdir() if (d / "max_brightness").exists()]
    except OSError:
        return None
    if not devs:
        return None
    rank = {"raw": 0, "platform": 1, "firmware": 2}

    def key(d):
        try:
            return rank.get((d / "type").read_text().strip(), 3)
        except OSError:
            return 3
    d = sorted(devs, key=key)[0]
    try:
        return d.name, int((d / "brightness").read_text()), int((d / "max_brightness").read_text())
    except (OSError, ValueError):
        return None


def _session_path():
    """logind's object path for this person's graphical session."""
    code, out, _ = st._run(["busctl", "--json=short", "call", "org.freedesktop.login1",
                            "/org/freedesktop/login1", "org.freedesktop.login1.Manager",
                            "ListSessions"], timeout=10)
    if code != 0:
        return None
    try:
        rows = json.loads(out)["data"][0]
    except (ValueError, KeyError, IndexError):
        return None
    mine = [r for r in rows if len(r) >= 5 and int(r[1]) == os.geteuid()]
    mine.sort(key=lambda r: 0 if r[3] else 1)          # one with a seat first
    return mine[0][4] if mine else None


def brightness(percent=None, change: str = "") -> str:
    """No arguments: how bright the screen is. percent: set it. change: up/down."""
    panel = _panel()
    if not panel:
        return ("ERROR: this screen has no brightness this computer can change (an external "
                "monitor is set with its own buttons).")
    name, cur, top = panel
    now = round(cur * 100 / top)
    if percent in (None, "") and not change:
        return f"screen brightness is {now}%"
    try:
        if change:
            step = 10 if str(change).lower() in ("up", "brighter", "more", "+") else -10
            want = now + step
        else:
            want = int(float(str(percent).rstrip("%")))
    except ValueError:
        return f"ERROR: {percent!r} is not a percentage."
    want = max(5, min(100, want))                       # never fully black
    value = max(1, round(top * want / 100))
    sess = _session_path()
    if sess:
        code, _, err = st._run(["busctl", "call", "org.freedesktop.login1", sess,
                                "org.freedesktop.login1.Session", "SetBrightness", "ssu",
                                "backlight", name, str(value)], timeout=10)
        if code == 0:
            return f"screen brightness set to {want}%"
    if shutil.which("brightnessctl"):
        code, _, err = st._run(["brightnessctl", "-q", "-d", name, "set", str(value)], timeout=10)
        if code == 0:
            return f"screen brightness set to {want}%"
    try:
        (BACKLIGHT / name / "brightness").write_text(str(value))
        return f"screen brightness set to {want}%"
    except OSError:
        return "ERROR: the brightness could not be changed from here (logind refused it)."


# ---------------------------------------------------------------- media --

def _bus_env():
    env = dict(st._wayland_env())
    if not env.get("DBUS_SESSION_BUS_ADDRESS"):
        run = env.get("XDG_RUNTIME_DIR") or f"/run/user/{os.geteuid()}"
        env["DBUS_SESSION_BUS_ADDRESS"] = f"unix:path={run}/bus"
    return env


def _busctl(args):
    return st._run(["busctl", "--user", "--json=short"] + args, timeout=10, env=_bus_env())


def _players():
    code, out, _ = _busctl(["call", "org.freedesktop.DBus", "/org/freedesktop/DBus",
                            "org.freedesktop.DBus", "ListNames"])
    if code != 0:
        return []
    try:
        names = json.loads(out)["data"][0]
    except (ValueError, KeyError, IndexError):
        return []
    return sorted(n for n in names if n.startswith("org.mpris.MediaPlayer2."))


def _prop(player, prop):
    code, out, _ = _busctl(["get-property", player, "/org/mpris/MediaPlayer2",
                            "org.mpris.MediaPlayer2.Player", prop])
    if code != 0:
        return None
    try:
        return json.loads(out)["data"]
    except (ValueError, KeyError):
        return None


def _title(player):
    meta = _prop(player, "Metadata") or {}
    t = (meta.get("xesam:title") or {}).get("data") or ""
    a = (meta.get("xesam:artist") or {}).get("data") or []
    who = ", ".join(a) if isinstance(a, list) else str(a)
    app = player.split(".")[3] if player.count(".") >= 3 else player
    return (f"“{t}”" + (f" by {who}" if who else "") + f" in {app}") if t else app


_MEDIA = {"play_pause": "PlayPause", "toggle": "PlayPause", "play": "Play", "resume": "Play",
          "pause": "Pause", "stop": "Stop", "next": "Next", "skip": "Next",
          "previous": "Previous", "back": "Previous", "prev": "Previous"}


def media(action: str = "status") -> str:
    """status | play_pause | play | pause | stop | next | previous."""
    action = str(action or "status").strip().lower().replace(" ", "_").replace("-", "_")
    players = _players()
    if not players:
        return "Nothing is playing — no music or video app is open that can be controlled."
    playing = [p for p in players if _prop(p, "PlaybackStatus") == "Playing"]
    target = (playing or players)[0]
    if action in ("status", "what", "now_playing"):
        state = _prop(target, "PlaybackStatus") or "Stopped"
        return f"{state}: {_title(target)}"
    method = _MEDIA.get(action)
    if not method:
        return "ERROR: action must be status, play_pause, play, pause, stop, next or previous."
    if method == "Play" and playing:
        target = playing[0]
    code, _, err = _busctl(["call", target, "/org/mpris/MediaPlayer2",
                            "org.mpris.MediaPlayer2.Player", method])
    if code != 0:
        return f"ERROR: the player did not accept that: {err or 'no reason given'}"
    time.sleep(0.3)
    return f"{method} sent — now {(_prop(target, 'PlaybackStatus') or '?').lower()}: {_title(target)}"
