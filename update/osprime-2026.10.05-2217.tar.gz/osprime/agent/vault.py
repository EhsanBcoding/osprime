"""Memory as notes — ~/Memory, a folder of Markdown files. Asked for by Ehsan,
4 October ("like Obsidian"); built 5 October.

The old memory was a list of sentences in a hidden SQLite file: nobody could
see it, correct it or link one thing to another. Now it is a folder the
person owns and can open in anything — the Notes app, a text editor, or
Obsidian itself:

    ~/Memory/
      About me.md          the essentials, always given to the assistant
      People/Ali.md        one note per person, project, place
      Projects/OSprime.md
      Places/…
      Journal/2026-10-05.md   what we did together that day
      …and the person's own notes, anywhere in it

Decisions (Ehsan, 4–5 October): a visible ~/Memory; a full second brain —
the person's own notes are memory too; the assistant writes on its own and
shows "Remembered … · Undo"; the cloud model may read it; a daily journal,
on by default; a paired phone may only read.

Plain Markdown, [[wikilinks]], nothing proprietary. The one hidden folder,
.history, keeps every version the assistant replaced, so each of its
changes can be undone — Obsidian ignores dot-folders.
"""
import datetime
import json
import os
import pathlib
import re
import threading
import time

import paths

KEY_JOURNAL = "OSPRIME_JOURNAL"
KEY_AUTO = "OSPRIME_MEMORY_AUTO"
ABOUT = "About me"
KINDS = {"person": "People", "project": "Projects", "place": "Places"}
ABOUT_LIMIT = 2500          # characters of About me.md given every turn
_lock = threading.RLock()


# ---------------------------------------------------------------------------
# places
# ---------------------------------------------------------------------------
def root() -> pathlib.Path:
    return pathlib.Path(os.environ.get("OSPRIME_VAULT") or paths.home() / "Memory")


def _hist() -> pathlib.Path:
    return root() / ".history"


def _flag(key: str, default: str) -> bool:
    return paths.read_desktop_env().get(key, default).strip('"').lower() not in ("no", "off", "0", "false")


def journal_on() -> bool:
    return _flag(KEY_JOURNAL, "yes")


def auto_on() -> bool:
    """May the assistant write on its own (with the Remembered mark)?"""
    return _flag(KEY_AUTO, "yes")


WELCOME = """# About me

The assistant reads this note before every answer, so the most important
things about you belong here. It adds to it on its own; you can change or
delete any line. Everything in this folder is yours — plain Markdown that
any editor, or Obsidian, can open.

"""


def ensure() -> pathlib.Path:
    r = root()
    with _lock:
        for sub in ("", "People", "Projects", "Places", "Journal", ".history"):
            (r / sub).mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(r, 0o700)
        except OSError:
            pass
        about = r / f"{ABOUT}.md"
        if not about.exists():
            about.write_text(WELCOME, encoding="utf-8")
    return r


# ---------------------------------------------------------------------------
# notes
# ---------------------------------------------------------------------------
_BAD = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def clean_title(title: str) -> str:
    t = _BAD.sub(" ", (title or "").strip()).strip(" .")
    return re.sub(r"\s+", " ", t)[:80]


def notes() -> list:
    """Every note, as paths, the history excluded."""
    r = root()
    if not r.is_dir():
        return []
    out = []
    for p in r.rglob("*.md"):
        rel = p.relative_to(r)
        if any(part.startswith(".") for part in rel.parts):
            continue
        out.append(p)
    return sorted(out)


def find(title: str):
    """A note by its title (file name without .md), any folder, any case.
    Also matches `aliases:` in a note's frontmatter."""
    want = clean_title(title).lower()
    if not want:
        return None
    for p in notes():
        if p.stem.lower() == want:
            return p
    for p in notes():
        m = re.match(r"---\n(.*?)\n---", _read(p), re.S)
        if m and re.search(r"(?im)^aliases:.*\b" + re.escape(want) + r"\b", m.group(1)):
            return p
    return None


def _read(p: pathlib.Path) -> str:
    try:
        return p.read_text(encoding="utf-8")
    except OSError:
        return ""


def rel(p: pathlib.Path) -> str:
    return p.relative_to(root()).as_posix()


# ---------------------------------------------------------------------------
# history: every change the assistant makes can be undone
# ---------------------------------------------------------------------------
def _snapshot(p: pathlib.Path) -> str:
    """Keep the current version of a note; returns the snapshot's name."""
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    dest = _hist() / "versions" / (rel(p) + f".{stamp}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        dest.write_bytes(p.read_bytes())
    else:
        dest.write_text("", encoding="utf-8")
        dest.with_suffix(dest.suffix + ".new").write_text("", encoding="utf-8")
    return dest.relative_to(_hist()).as_posix()


def _log(entry: dict) -> str:
    # milliseconds alone collided: forget() writes several notes in one ms
    entry = dict(entry, id=f"{int(time.time() * 1000):x}{os.urandom(3).hex()}",
                 ts=time.strftime("%Y-%m-%d %H:%M"))
    _hist().mkdir(parents=True, exist_ok=True)
    with open(_hist() / "log.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    return entry["id"]


def changes(limit: int = 30) -> list:
    try:
        lines = (_hist() / "log.jsonl").read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for line in reversed(lines):
        try:
            out.append(json.loads(line))
        except ValueError:
            continue
        if len(out) >= limit:
            break
    return out


def _write(p: pathlib.Path, text: str, action: str, detail: str, by: str = "assistant") -> str:
    """Write a note, keeping the old version. Returns the change id."""
    with _lock:
        snap = _snapshot(p)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, p)
        return _log({"action": action, "note": rel(p), "detail": detail[:300],
                     "snapshot": snap, "by": by})


def undo(change_id: str) -> str:
    """Put a note back as it was before one change."""
    with _lock:
        entry = next((c for c in changes(100000) if c.get("id") == change_id
                      and c.get("action") != "undo"), None)
        if not entry or not entry.get("snapshot"):
            return "ERROR: that change is not in the history."
        if change_id in _undone():
            return "That change was already undone."
        snap = _hist() / entry["snapshot"]
        target = root() / entry["note"]
        if not snap.exists():
            return "ERROR: the earlier version is missing."
        was_new = snap.with_suffix(snap.suffix + ".new").exists()
        current = _read(target)
        _snapshot(target)              # undoing is undoable too
        if was_new:
            target.unlink(missing_ok=True)
        else:
            target.write_bytes(snap.read_bytes())
        _log({"action": "undo", "note": entry["note"], "detail": entry.get("detail", ""),
              "undoes": change_id, "snapshot": "", "by": "person"})
        _mark_undone(change_id)
        if current and _norm(current) != _norm(_read(target)):
            return f"Undone: {entry['note']} is back as it was."
        return f"Undone: {entry['note']}."


def _mark_undone(change_id: str):
    p = _hist() / "undone"
    with open(p, "a") as f:
        f.write(change_id + "\n")


def _undone() -> set:
    try:
        return set((_hist() / "undone").read_text().split())
    except OSError:
        return set()


# ---------------------------------------------------------------------------
# remembering
# ---------------------------------------------------------------------------
def _norm(s: str) -> str:
    return re.sub(r"[\s\-*•\[\]]+", " ", (s or "").lower()).strip()


def _link_names(fact: str, own: str) -> str:
    """Wrap the first mention of a known person, project or place in
    [[...]], so the notes connect the way they do in Obsidian."""
    titles = sorted({p.stem for p in notes()
                     if p.parent.name in KINDS.values() and p.stem.lower() != own.lower()
                     and len(p.stem) >= 3}, key=len, reverse=True)
    for t in titles:
        if f"[[{t}" in fact:
            continue
        m = re.search(r"(?<![\w\[])" + re.escape(t) + r"(?![\w\]])", fact, re.I)
        if m:
            fact = fact[:m.start()] + f"[[{t}]]" + fact[m.end():]
    return fact


# "my brother Erfan …", "برادرم عرفان …": a person, even when the model did
# not say so. 5 October, laptop: the local model put "برادرم عرفان در لوس
# آنجلس زندگی می کند" into About me with no note for Erfan and no link, so
# nothing connected — the Notes app's "Linked from" stayed empty.
_REL_EN = ("brother", "sister", "wife", "husband", "son", "daughter", "mother", "mom",
           "father", "dad", "friend", "boss", "colleague", "cousin", "uncle", "aunt",
           "partner", "girlfriend", "boyfriend", "grandmother", "grandfather", "neighbour",
           "neighbor", "teacher", "doctor")
_REL_FA = ("برادرم", "خواهرم", "همسرم", "زنم", "شوهرم", "پسرم", "دخترم", "مادرم", "پدرم",
           "دوستم", "رئیسم", "همکارم", "پسرعموم", "دخترعموم", "پسرخاله‌ام", "دخترخاله‌ام",
           "عموم", "داییم", "خاله‌ام", "عمه‌ام", "مادربزرگم", "پدربزرگم", "همسایه‌ام", "معلمم",
           "دکترم")
# words that follow "برادرم" and are not a name
_NOT_NAME = set("""در تو توی که هم اسمش خیلی الان فردا دیروز امروز یه یک با از به را رو
و هست است بود میگه می‌گه گفت داره دارد کار زندگی خونه خانه ما من شما اون این همیشه هنوز
دیگه دیگر پیش برای چون مریضه مریض""".split())


def _person_in(fact: str):
    """(name, relation) if the fact is about a named relative or friend."""
    m = re.search(r"\b(?i:my) (?i:(" + "|".join(_REL_EN) + r"))(?:'s name is|,| named| called| is)?\s+"
                  r"([A-Z][\w'-]{1,30})", fact)
    if m and m.group(2).lower() not in ("is", "lives", "works", "has", "and", "who", "the"):
        return m.group(2), m.group(1)
    m = re.search(r"(?:^|\s)(" + "|".join(map(re.escape, _REL_FA)) + r")\s+(?:اسمش\s+)?"
                  r"([\u0600-\u06FF\u200c]{2,30})", fact)
    if m and m.group(2) not in _NOT_NAME and not m.group(2).startswith(("می", "نمی")):
        return m.group(2), m.group(1)
    return None


def remember(fact: str, note: str = "", kind: str = "", by: str = "assistant") -> dict:
    """Add one fact to the right note. Returns {"ok", "note", "id", "message"}."""
    fact = re.sub(r"\s+", " ", (fact or "").strip()).lstrip("-*• ").strip()
    if not fact:
        return {"ok": False, "message": "ERROR: nothing to remember."}
    try:
        import permissions
        if permissions.redact(fact) != fact:
            return {"ok": False, "message": "ERROR: that looks like a password or key — "
                    "it is not written into notes. Nothing was saved."}
    except Exception:
        pass
    ensure()
    title = clean_title(note) or ABOUT
    if title.lower() == ABOUT.lower():
        who = _person_in(fact)
        if who:
            return _remember_person(fact, who[0], who[1], by)
    p = find(title)
    if p is None:
        folder = KINDS.get((kind or "").lower().strip(), "")
        p = root() / folder / f"{title}.md"
    with _lock:
        text = _read(p)
        lines = [_norm(l) for l in text.splitlines()]
        if _norm(fact) in lines:
            return {"ok": True, "note": rel(p), "id": "", "message": "already known",
                    "known": True}
        line = "- " + _link_names(fact, p.stem)
        if not text:
            text = f"# {p.stem}\n\n"
        elif not text.endswith("\n"):
            text += "\n"
        cid = _write(p, text + line + "\n", "remember", fact, by)
    return {"ok": True, "note": rel(p), "id": cid, "message": f"saved in {rel(p)}"}


def _remember_person(fact: str, name: str, relation: str, by: str) -> dict:
    """The fact goes into People/<name>.md, and About me gets one line that
    links to it ("- برادرم: [[عرفان]]"), so the two notes connect."""
    r = remember(fact, note=name, kind="person", by=by)
    about = root() / f"{ABOUT}.md"
    if r.get("ok") and f"[[{name}]]" not in _read(about):
        with _lock:
            text = _read(about) or WELCOME
            if not text.endswith("\n"):
                text += "\n"
            label = relation[0].upper() + relation[1:] if relation.isascii() else relation
            _write(about, text + f"- {label}: [[{name}]]\n", "remember",
                   f"{label}: {name}", by)
    return r


def forget(text: str, by: str = "assistant") -> dict:
    """Remove the lines that say `text` (from every note). Lines, never
    whole notes."""
    want = _norm(text)
    if len(want) < 3:
        return {"ok": False, "message": "ERROR: say what to forget, in a few words."}
    removed = []
    with _lock:
        for p in notes():
            body = _read(p)
            keep, gone = [], []
            for l in body.splitlines():
                if l.strip().startswith(("-", "*")) and want in _norm(l):
                    gone.append(l.strip())
                else:
                    keep.append(l)
            if gone:
                cid = _write(p, "\n".join(keep) + "\n", "forget", "; ".join(gone), by)
                removed.append({"note": rel(p), "lines": gone, "id": cid})
    if not removed:
        return {"ok": False, "message": f"Nothing in the notes says '{text}'."}
    n = sum(len(r["lines"]) for r in removed)
    return {"ok": True, "removed": removed,
            "message": f"Forgot {n} line(s) from " + ", ".join(r["note"] for r in removed)}


# ---------------------------------------------------------------------------
# recalling
# ---------------------------------------------------------------------------
def _terms(q: str) -> list:
    try:
        import fileindex
        return fileindex._terms(q)
    except Exception:
        return [w for w in re.findall(r"\w+", (q or "").lower()) if len(w) > 2]


def recall(query: str, limit: int = 8) -> list:
    """Lines and passages from the notes about `query`, best first:
    [{"note", "text"}]. Words match directly; meaning comes from the file
    index (agent/fileindex.py), which already reads ~/Memory."""
    out, seen = [], set()
    terms = _terms(query)
    try:
        import fileindex
        norm = fileindex.normalize
    except Exception:
        norm = lambda s: s      # noqa: E731
    scored = []
    if terms:
        for p in notes():
            title = p.stem.lower()
            for line in _read(p).splitlines():
                l = norm(line).lower()
                if not line.strip() or line.startswith("#"):
                    continue
                score = sum(1 for t in terms if t in l) + sum(2 for t in terms if t in title)
                if score:
                    scored.append((score, rel(p), line.strip()))
    scored.sort(key=lambda x: -x[0])
    for _s, note, line in scored:
        key = (note, line)
        if key not in seen:
            seen.add(key)
            out.append({"note": note, "text": line})
        if len(out) >= limit:
            return out
    try:
        import fileindex
        if fileindex.enabled():
            r = fileindex.search(query, folder=str(root()), limit=limit)
            for h in r.get("results", []):
                note = pathlib.Path(h["path"]).relative_to(root()).as_posix()
                key = (note, h["snippet"])
                if key not in seen and h["snippet"]:
                    seen.add(key)
                    out.append({"note": note, "text": h["snippet"]})
    except Exception:
        pass
    return out[:limit]


def context(query: str = "") -> str:
    """What the assistant is given every turn: About me.md, then what the
    notes say about this request. Secrets are redacted on the way."""
    about = _read(root() / f"{ABOUT}.md").replace(WELCOME, "")
    about = "\n".join(l for l in about.splitlines() if l.strip() and not l.startswith("#"))
    parts = []
    if about.strip():
        parts.append("About the user (~/Memory/About me.md):\n" + about[-ABOUT_LIMIT:])
    hits = [h for h in recall(query, 6) if h["note"] != f"{ABOUT}.md"] if query else []
    if hits:
        parts.append("From their notes:\n" + "\n".join(f"[{h['note']}] {h['text']}" for h in hits))
    text = "\n\n".join(parts)
    try:
        import permissions
        text = permissions.redact(text)
    except Exception:
        pass
    return text


# ---------------------------------------------------------------------------
# the journal
# ---------------------------------------------------------------------------
def journal(request: str, did: list = None, when: datetime.datetime = None):
    """One line per request in Journal/YYYY-MM-DD.md: what was asked and
    which tools ran. Written as plain fact, not a summary a model made up."""
    if not journal_on():
        return None
    request = re.sub(r"\s+", " ", (request or "")).strip()
    if not request:
        return None
    try:
        import permissions
        request = permissions.redact(request)
    except Exception:
        pass
    when = when or datetime.datetime.now()
    ensure()
    p = root() / "Journal" / f"{when:%Y-%m-%d}.md"
    with _lock:
        text = _read(p) or f"# {when:%A %d %B %Y}\n\n"
        line = f"- {when:%H:%M} — {request[:160]}" + (
            f" ({', '.join(dict.fromkeys(did))})" if did else "")
        p.write_text(text + line + "\n", encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# moving in: the old SQLite memory becomes lines in About me.md
# ---------------------------------------------------------------------------
def migrate(db_path=None) -> int:
    ensure()
    marker = _hist() / "migrated-from-sqlite"
    if marker.exists():
        return 0
    n = 0
    try:
        import memory as memory_mod
        db = pathlib.Path(db_path or paths.memory_db())
        if db.exists():
            facts = [m["fact"] for m in memory_mod.Memory(db).all(5000)]
            p = root() / f"{ABOUT}.md"
            text = _read(p)
            new = [f for f in reversed(facts) if _norm(f) not in
                   {_norm(l) for l in text.splitlines()}]
            if new:
                text = text.rstrip("\n") + "\n\n## Kept before October 2026\n\n" + \
                    "".join(f"- {f}\n" for f in new)
                _write(p, text, "migrate", f"{len(new)} facts from the old memory", "system")
                n = len(new)
    except Exception as e:
        print(f"memory migration skipped: {e}", flush=True)
        return 0
    marker.write_text(time.strftime("%Y-%m-%d %H:%M"))
    return n


# ---------------------------------------------------------------------------
# for Settings and the Notes app
# ---------------------------------------------------------------------------
def summary() -> dict:
    ns = notes()
    undone = _undone()
    recent = [dict(c, undone=c.get("id") in undone) for c in changes(20)
              if c.get("action") in ("remember", "forget")]
    return {"root": str(root()), "exists": root().is_dir(), "notes": len(ns),
            "journal": journal_on(), "auto": auto_on(), "recent": recent}


def forget_everything() -> str:
    """Moves ~/Memory to the trash as a whole (it can be restored from
    there) and starts a fresh one."""
    r = root()
    if not r.exists():
        return "There was nothing to forget."
    trash = paths.home() / ".local/share/Trash/files"
    trash.mkdir(parents=True, exist_ok=True)
    dest = trash / f"Memory {time.strftime('%Y-%m-%d %H%M%S')}"
    os.replace(r, dest)
    info = trash.parent / "info"
    info.mkdir(parents=True, exist_ok=True)
    (info / (dest.name + ".trashinfo")).write_text(
        f"[Trash Info]\nPath={r}\nDeletionDate={time.strftime('%Y-%m-%dT%H:%M:%S')}\n")
    ensure()
    (_hist() / "migrated-from-sqlite").write_text("forgotten")
    return "Everything it knew is in the trash, and the notes start fresh."


# ---------------------------------------------------------------------------
# the Notes app (ui/notes_page.py): reading and editing by the person
# ---------------------------------------------------------------------------
_LINK = re.compile(r"\[\[([^\]|#]+)(?:#[^\]|]*)?(?:\|[^\]]*)?\]\]")


def safe_path(relpath: str):
    """A note inside ~/Memory, or None. Never a hidden folder, never
    outside it, always .md."""
    relpath = (relpath or "").strip().lstrip("/")
    if not relpath.endswith(".md") or "\x00" in relpath:
        return None
    r = root().resolve()
    p = (r / relpath).resolve()
    try:
        parts = p.relative_to(r).parts
    except ValueError:
        return None
    if any(part.startswith(".") for part in parts):
        return None
    return p


def list_notes() -> list:
    out = []
    for p in notes():
        try:
            st = p.stat()
        except OSError:
            continue
        out.append({"path": rel(p), "title": p.stem,
                    "folder": p.parent.relative_to(root()).as_posix() if p.parent != root() else "",
                    "mtime": st.st_mtime, "size": st.st_size})
    return out


def links_in(text: str) -> list:
    return list(dict.fromkeys(m.group(1).strip() for m in _LINK.finditer(text or "")))


def backlinks(title: str) -> list:
    """Notes that link to [[title]], with the line that does."""
    want = title.lower()
    out = []
    for p in notes():
        if p.stem.lower() == want:
            continue
        for line in _read(p).splitlines():
            if any(l.lower() == want for l in links_in(line)):
                out.append({"path": rel(p), "title": p.stem, "line": line.strip()[:200]})
                break
    return out


def read_note(relpath: str) -> dict:
    p = safe_path(relpath)
    if p is None or not p.is_file():
        return {"ok": False, "message": "There is no such note."}
    text = _read(p)
    existing = {n.stem.lower() for n in notes()}
    return {"ok": True, "path": rel(p), "title": p.stem, "text": text,
            "mtime": p.stat().st_mtime,
            "links": [{"title": l, "exists": l.lower() in existing} for l in links_in(text)],
            "backlinks": backlinks(p.stem)}


def save_note(relpath: str, text: str, base_mtime: float = 0) -> dict:
    """The person's edit. Refused if the note changed since they opened it
    (the assistant, or another window), so nobody's words are lost."""
    p = safe_path(relpath)
    if p is None:
        return {"ok": False, "message": "That is not a note in ~/Memory."}
    if len(text or "") > 2_000_000:
        return {"ok": False, "message": "That note is too big."}
    with _lock:
        if p.exists() and base_mtime and abs(p.stat().st_mtime - float(base_mtime)) > 0.001:
            return {"ok": False, "conflict": True, "text": _read(p), "mtime": p.stat().st_mtime,
                    "message": "This note changed since you opened it."}
        if p.exists() and _read(p) == text:
            return {"ok": True, "mtime": p.stat().st_mtime, "unchanged": True}
        _write(p, text, "edit", "", by="person")
    return {"ok": True, "mtime": p.stat().st_mtime}


def new_note(title: str, folder: str = "") -> dict:
    title = clean_title(title)
    if not title:
        return {"ok": False, "message": "Give the note a name."}
    existing = find(title)
    if existing:
        return {"ok": True, "path": rel(existing), "existed": True}
    folder = folder if folder in ("", *KINDS.values(), "Journal") else ""
    p = safe_path(f"{folder + '/' if folder else ''}{title}.md")
    if p is None:
        return {"ok": False, "message": "That name cannot be used."}
    ensure()
    _write(p, f"# {title}\n\n", "new", title, by="person")
    return {"ok": True, "path": rel(p)}


def rename_note(relpath: str, new_title: str) -> dict:
    """Rename, and update every [[link]] to it — as Obsidian does."""
    p = safe_path(relpath)
    new_title = clean_title(new_title)
    if p is None or not p.is_file() or not new_title:
        return {"ok": False, "message": "Cannot rename that."}
    if find(new_title) and find(new_title) != p:
        return {"ok": False, "message": f"There is already a note called {new_title}."}
    old = p.stem
    with _lock:
        dest = p.with_name(new_title + ".md")
        text = _read(p)
        if text.startswith(f"# {old}\n"):
            text = f"# {new_title}\n" + text[len(f"# {old}\n"):]
        _write(p, text, "rename", f"{old} → {new_title}", by="person")
        os.replace(p, dest)
        pat = re.compile(r"\[\[" + re.escape(old) + r"(?=[\]|#])", re.I)
        changed = 0
        for n in notes():
            body = _read(n)
            if pat.search(body):
                _write(n, pat.sub("[[" + new_title, body), "relink", f"{old} → {new_title}", by="person")
                changed += 1
    return {"ok": True, "path": rel(dest), "relinked": changed}


def delete_note(relpath: str) -> dict:
    """To the trash, never gone: it can be restored from there."""
    p = safe_path(relpath)
    if p is None or not p.is_file():
        return {"ok": False, "message": "There is no such note."}
    trash = paths.home() / ".local/share/Trash"
    (trash / "files").mkdir(parents=True, exist_ok=True)
    (trash / "info").mkdir(parents=True, exist_ok=True)
    dest = trash / "files" / f"{p.stem} {time.strftime('%Y%m%d-%H%M%S')}.md"
    with _lock:
        _snapshot(p)
        os.replace(p, dest)
        (trash / "info" / (dest.name + ".trashinfo")).write_text(
            f"[Trash Info]\nPath={p}\nDeletionDate={time.strftime('%Y-%m-%dT%H:%M:%S')}\n")
        _log({"action": "delete", "note": relpath, "detail": "", "snapshot": "", "by": "person"})
    return {"ok": True, "message": f"{p.stem} is in the trash."}


def search_notes(query: str, limit: int = 40) -> list:
    """Titles first, then lines — for the Notes app's search box."""
    q = (query or "").strip().lower()
    if not q:
        return []
    out = []
    for p in notes():
        if q in p.stem.lower():
            out.append({"path": rel(p), "title": p.stem, "line": ""})
    for p in notes():
        for line in _read(p).splitlines():
            if q in line.lower() and not line.startswith("# "):
                out.append({"path": rel(p), "title": p.stem, "line": line.strip()[:200]})
                break
        if len(out) >= limit:
            break
    seen, res = set(), []
    for o in out:
        if (o["path"], o["line"]) not in seen and not (o["line"] and o["path"] in {r["path"] for r in res}):
            seen.add((o["path"], o["line"]))
            res.append(o)
    return res[:limit]
