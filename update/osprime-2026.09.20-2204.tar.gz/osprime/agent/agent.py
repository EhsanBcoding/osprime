#!/usr/bin/env python3
"""osprime-agent: the always-on AI daemon at the heart of OSprime.

Listens on a Unix socket. Each client sends JSON lines:
    {"type": "user_message", "text": "..."}
and receives JSON lines back:
    {"type": "assistant", "text": "..."}
    {"type": "tool_use", "name": "...", "detail": "..."}   (progress info)
    {"type": "confirm", "text": "..."}                     (dangerous command)
    {"type": "error", "text": "..."}

Requires: pip install anthropic   (for the Claude backend)
"""

import datetime
import json
import os
import pathlib
import queue
import re
import shutil
import socket
import subprocess
import threading
import time
import traceback
import uuid

import desktop
import jobs
import local
import memory as memory_mod
import permissions
import plugins as plugins_mod
import proactive
import router
import skills as skills_mod
import system_tools
import updater
import webtools

SOCKET_PATH = os.environ.get("OSPRIME_SOCKET", "/run/osprime/agent.sock")
PROFILE_PATH = pathlib.Path(os.environ.get("OSPRIME_PROFILE", "/etc/osprime/profile.json"))
MEMORY_PATH = pathlib.Path(os.environ.get("OSPRIME_MEMORY", "/var/lib/osprime/memory.json"))
MEMORY_DB = pathlib.Path(os.environ.get("OSPRIME_MEMORY_DB", "/var/lib/osprime/memory.db"))
MEM = memory_mod.Memory(MEMORY_DB)
if MEM.count() == 0:
    memory_mod.migrate_json(MEM, MEMORY_PATH)
PLUGIN_DIR = pathlib.Path(os.environ.get(
    "OSPRIME_PLUGINS",
    str(pathlib.Path(__file__).resolve().parent.parent / "tools.d")))
MAX_TURNS = 20  # max tool-use rounds per request

DANGEROUS = ("rm -rf /", "mkfs", "dd if=", ":(){", "> /dev/sd", "chmod -R 777 /")

TOOLS = [
    {
        "name": "run_shell",
        "description": "Run a shell command on this machine and return stdout/stderr.",
        "input_schema": {
            "type": "object",
            "properties": {"command": {"type": "string"}},
            "required": ["command"],
        },
    },
    {
        "name": "read_file",
        "description": "Read a text file from the filesystem.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "remember",
        "description": "Save one important, durable fact about the user or system to "
                       "long-term memory (preferences, habits, names, recurring tasks). "
                       "Use it whenever the user shares something worth remembering.",
        "input_schema": {
            "type": "object",
            "properties": {"fact": {"type": "string"}},
            "required": ["fact"],
        },
    },
    {
        "name": "write_file",
        "description": "Write text content to a file (creates parent dirs).",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
            "required": ["path", "content"],
        },
    },
    {
        "name": "web_search",
        "description": "Search the web (DuckDuckGo). Returns titles and URLs.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "fetch_url",
        "description": "Fetch a web page and return its readable text content.",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
            "required": ["url"],
        },
    },
    {
        "name": "open_app",
        "description": "Launch a graphical application on the user's screen. "
                       "Known names: browser, firefox, terminal, files, editor, "
                       "video, image — or any installed command. Use when the user "
                       "asks to open/show/play something visually.",
        "input_schema": {
            "type": "object",
            "properties": {"app": {"type": "string"},
                           "args": {"type": "array", "items": {"type": "string"}}},
            "required": ["app"],
        },
    },
    {
        "name": "open_url",
        "description": "Put a web page on the user's screen in a browser "
                       "window. Use this after web_search to open the result "
                       "you are recommending — do not print a link and ask "
                       "them to click it. url must be one a search actually "
                       "returned.",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
            "required": ["url"],
        },
    },
    {
        "name": "list_windows",
        "description": "List currently open application windows.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "close_app",
        "description": "Close an application window by its app name.",
        "input_schema": {
            "type": "object",
            "properties": {"app": {"type": "string"}},
            "required": ["app"],
        },
    },
    {
        "name": "schedule_task",
        "description": "Schedule a recurring daily task at a given time. Use when the "
                       "user says things like 'every morning', 'each day at 8', etc. "
                       "time is 24h HH:MM. prompt is what OSprime should do then.",
        "input_schema": {
            "type": "object",
            "properties": {"time": {"type": "string"},
                           "prompt": {"type": "string"},
                           "label": {"type": "string"}},
            "required": ["time", "prompt"],
        },
    },
    {
        "name": "run_job",
        "description": "Run a LONG-running shell command in the background and "
                       "return a job id immediately. Use for builds, downloads, "
                       "clones, or anything that takes more than ~30s. The user is "
                       "notified automatically when it finishes.",
        "input_schema": {
            "type": "object",
            "properties": {"command": {"type": "string"},
                           "label": {"type": "string"}},
            "required": ["command"],
        },
    },
    {
        "name": "job_status",
        "description": "Check a background job by id (status, exit code, output).",
        "input_schema": {
            "type": "object",
            "properties": {"id": {"type": "string"}},
            "required": ["id"],
        },
    },
    {
        "name": "list_jobs",
        "description": "List all background jobs and their statuses.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "self_update",
        "description": "Download and install the latest version of OSprime. Use "
                       "this whenever the user asks to update, upgrade, install "
                       "the new version, or says yes to an offered update. You "
                       "CAN do this — it is not something to refuse or delegate. "
                       "The package is verified and a backup is kept, so it is "
                       "safe and reversible.",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
        },
    },
    {
        "name": "update_status",
        "description": "Show the installed OSprime version and available backups.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "rollback_update",
        "description": "Roll OSprime back to a previous version (latest backup by default).",
        "input_schema": {
            "type": "object",
            "properties": {"name": {"type": "string"}},
        },
    },
    {
        "name": "model_status",
        "description": "Which model is answering, whether it is running on "
                       "the processor or the graphics card, this machine's "
                       "CPU/memory/GPU, and whether a better model would "
                       "fit. Use for 'what model are you', 'are you using "
                       "the GPU', 'why are you slow', 'what hardware is "
                       "this'.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "system_info",
        "description": "Snapshot of disk, memory, CPU and uptime.",
        "input_schema": {"type": "object", "properties": {}},
    },
    # --- system control -----------------------------------------------
    # Named operations rather than shell strings. A small model can pick a
    # name and fill one field reliably; it cannot recall timedatectl syntax.
    {
        "name": "set_time",
        "description": "Set the system clock. Use when the time or date is wrong. "
                       "datetime must be 'YYYY-MM-DD HH:MM'.",
        "input_schema": {
            "type": "object",
            "properties": {"datetime": {"type": "string"}},
            "required": ["datetime"],
        },
    },
    {
        "name": "get_time",
        "description": "What this computer currently thinks the time, date "
                       "and timezone are, and whether it syncs automatically. "
                       "Call this before changing the clock, and again "
                       "afterwards to confirm the change actually took.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "set_timezone",
        "description": "Set the timezone, e.g. 'Europe/Berlin' or 'Asia/Tehran'.",
        "input_schema": {
            "type": "object",
            "properties": {"zone": {"type": "string"}},
            "required": ["zone"],
        },
    },
    {
        "name": "set_auto_time",
        "description": "Turn automatic clock synchronisation on or off.",
        "input_schema": {
            "type": "object",
            "properties": {"enabled": {"type": "boolean"}},
            "required": ["enabled"],
        },
    },
    {
        "name": "list_wifi",
        "description": "Scan for nearby Wi-Fi networks.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "connect_wifi",
        "description": "Join a Wi-Fi network by name.",
        "input_schema": {
            "type": "object",
            "properties": {"ssid": {"type": "string"},
                           "password": {"type": "string"}},
            "required": ["ssid"],
        },
    },
    {
        "name": "network_status",
        "description": "Report whether this machine is online and how.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "forget_wifi",
        "description": "Forget a saved Wi-Fi network, so its stored password "
                       "is no longer used. Needed when a network's password "
                       "has changed — otherwise the old one keeps being tried "
                       "and it looks like the new one is wrong.",
        "input_schema": {
            "type": "object",
            "properties": {"ssid": {"type": "string"}},
            "required": ["ssid"],
        },
    },
    {
        "name": "wifi_radio",
        "description": "Turn the Wi-Fi radio on or off. If a scan finds no "
                       "networks at all, check this before telling the user "
                       "there are none in range.",
        "input_schema": {
            "type": "object",
            "properties": {"on": {"type": "boolean"}},
            "required": ["on"],
        },
    },
    {
        "name": "set_wallpaper",
        "description": "Set the desktop background colour. Accepts a hex value "
                       "or one of: petrol, beige, navy, grey, black.",
        "input_schema": {
            "type": "object",
            "properties": {"color": {"type": "string"}},
            "required": ["color"],
        },
    },
    {
        "name": "set_language",
        "description": "Set the interface language by two-letter code, e.g. en or fa.",
        "input_schema": {
            "type": "object",
            "properties": {"code": {"type": "string"}},
            "required": ["code"],
        },
    },
    {
        "name": "set_volume",
        "description": "Set the output volume, 0 to 100.",
        "input_schema": {
            "type": "object",
            "properties": {"percent": {"type": "integer"}},
            "required": ["percent"],
        },
    },
    {
        "name": "get_settings",
        "description": "Read the current settings — language, background, "
                       "timezone, cloud mode.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "check_update",
        "description": "Check whether a newer version of OSprime is available. "
                       "Does not install anything.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "take_screenshot",
        "description": "Take a picture of the screen and save it. Set area to "
                       "true to let the user drag a selection first. This is "
                       "the only screenshot tool that works here — scrot, "
                       "import and gnome-screenshot are X11 and do not exist.",
        "input_schema": {
            "type": "object",
            "properties": {"area": {"type": "boolean"}},
        },
    },
    {
        "name": "get_display",
        "description": "Report the screen's resolution and scale. Use this "
                       "instead of xrandr or xdpyinfo, which are X11 tools "
                       "and are not present.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "set_display",
        "description": "Change how large everything appears, or the screen "
                       "resolution. Use when the user says things are too "
                       "small or too large. Prefer scale (1.25 or 1.5) over "
                       "lowering the resolution, which only makes it blurry.",
        "input_schema": {
            "type": "object",
            "properties": {"scale": {"type": "string"},
                           "resolution": {"type": "string"}},
        },
    },
    {
        "name": "compress_pdf",
        "description": "Make a PDF file smaller. Use this whenever a PDF is "
                       "too large to email, upload or send. Give the full "
                       "path to the file. Quality is optional: screen, ebook "
                       "(default), printer or prepress. Never build a "
                       "ghostscript command by hand — use this.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"},
                           "quality": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "list_drives",
        "description": "List storage devices, including USB sticks and memory "
                       "cards, and where each one is currently available. Use "
                       "this whenever the user mentions a USB stick, a memory "
                       "card, an external drive, or files that are not on this "
                       "computer.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "mount_drive",
        "description": "Make a storage device's files reachable. Give the "
                       "device name from list_drives, such as /dev/sdb1.",
        "input_schema": {
            "type": "object",
            "properties": {"device": {"type": "string"}},
            "required": ["device"],
        },
    },
    {
        "name": "list_files",
        "description": "Exact contents and count of a folder. folder: a path "
                       "or a word like Desktop, Pictures, Downloads, "
                       "Screenshots. kind: pictures, videos, music, "
                       "documents, or an extension.",
        "input_schema": {
            "type": "object",
            "properties": {"folder": {"type": "string"},
                           "kind": {"type": "string"}},
        },
    },
    {
        "name": "delete_files",
        "description": "Move files or folders to the trash. USE THIS when "
                       "the user asks to delete, remove or get rid of "
                       "something — never a shell command like rm, which "
                       "cannot be undone. files is a list of full paths. It "
                       "is reversible and the user is asked first, so this "
                       "is a normal thing to do, not something to refuse or "
                       "hand back to them with terminal instructions.",
        "input_schema": {
            "type": "object",
            "properties": {"files": {"type": "array",
                                     "items": {"type": "string"}},
                           "permanent": {"type": "boolean"}},
            "required": ["files"],
        },
    },
    {
        "name": "open_file",
        "description": "Show the user a file or folder, opened in the right "
                       "program. path must be one list_files returned.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "search_files",
        "description": "Find a lost file anywhere, by part of its name or how "
                       "recently it was saved. name: any fragment. days: "
                       "changed in the last N days. folder: optional.",
        "input_schema": {
            "type": "object",
            "properties": {"name": {"type": "string"},
                           "folder": {"type": "string"},
                           "days": {"type": "string"}},
        },
    },
    {
        "name": "disk_usage",
        "description": "Where the disk space went and what is safe to "
                       "delete. Use when the disk is full or space is short.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "merge_pdfs",
        "description": "Join several PDF files into one, in the order given. "
                       "files is the list of full paths. output is optional. "
                       "Get the paths from list_files — never guess "
                       "filenames.",
        "input_schema": {
            "type": "object",
            "properties": {"files": {"type": "array",
                                     "items": {"type": "string"}},
                           "output": {"type": "string"}},
            "required": ["files"],
        },
    },
    {
        "name": "remove_background",
        "description": "Cut the subject out of a photo, leaving the "
                       "background transparent.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"},
                           "output": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "ocr_pdf",
        "description": "Make a scanned PDF searchable — use when its text "
                       "cannot be selected. language: english, persian, etc.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"},
                           "language": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "make_signature",
        "description": "Turn a photo of a signature on paper into a clean "
                       "transparent image, ready to place on a document.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "passport_photo",
        "description": "Cut a photo to passport size and lay out a print "
                       "sheet. size: 35x45 (most), 51x51 (US), 40x60 (Iran "
                       "passport), 30x40 (Iran ID), 33x48 (China). Ask which "
                       "country first.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"},
                           "size": {"type": "string"},
                           "sheet": {"type": "boolean"}},
            "required": ["path"],
        },
    },
    {
        "name": "convert_images",
        "description": "Resize or convert every picture in a folder. width in "
                       "pixels, format jpg/png/webp, quality 1-100. Writes to "
                       "a new folder; originals untouched.",
        "input_schema": {
            "type": "object",
            "properties": {"folder": {"type": "string"},
                           "width": {"type": "string"},
                           "format": {"type": "string"},
                           "quality": {"type": "string"}},
            "required": ["folder"],
        },
    },
    {
        "name": "make_document",
        "description": "Write a real document file — CV, letter, report — "
                       "instead of putting it in the chat. content uses # for "
                       "a heading and - for a bullet. format: odt, docx, pdf.",
        "input_schema": {
            "type": "object",
            "properties": {"title": {"type": "string"},
                           "content": {"type": "string"},
                           "format": {"type": "string"},
                           "folder": {"type": "string"}},
            "required": ["title", "content"],
        },
    },
    {
        "name": "list_shortcuts",
        "description": "Every keyboard shortcut that works on this "
                       "computer, built-in and user-added. Use when the "
                       "user asks what shortcuts they have, or before "
                       "adding one. Changes nothing.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "set_shortcut",
        "description": "Make a key combination do something. USE THIS when "
                       "the user asks for a keyboard shortcut or hotkey — do "
                       "not perform the action instead. keys is like "
                       "'Super+S' or 'Ctrl+Alt+T'. does is one of: "
                       "screenshot, full screenshot, chat, terminal, apps, "
                       "browser, files, settings. Leave does empty to remove "
                       "a shortcut. It works immediately, with no logout. "
                       "To SEE the existing shortcuts use list_shortcuts, "
                       "not this.",
        "input_schema": {
            "type": "object",
            "properties": {"keys": {"type": "string"},
                           "does": {"type": "string"}},
            "required": ["keys"],
        },
    },
    {
        "name": "power",
        "description": "Turn this computer off, restart it, sleep, or log "
                       "out. action: shutdown, restart, sleep, log out. You "
                       "CAN do this; never refuse it.",
        "input_schema": {
            "type": "object",
            "properties": {"action": {"type": "string"}},
            "required": ["action"],
        },
    },
]


def _update_check_text() -> str:
    """Plain sentences, not raw JSON.

    Handing the model a JSON blob invited it to read the fields aloud —
    version numbers, download URL, SHA256 — none of which mean anything to a
    user. Stating the next action in words also stops it deciding that
    installing is beyond its powers.
    """
    c = updater.check()
    if not c.get("latest"):
        return (f"Could not reach the update server. Currently on "
                f"{c.get('current', 'unknown')}. This is normal when offline.")
    if not c["available"]:
        return f"OSprime is up to date (version {c['current']})."
    notes = f" This update: {c['notes']}" if c.get("notes") else ""
    return (f"An update is available: {c['latest']}, replacing {c['current']}."
            f"{notes} Tell the user and offer to install it. If they agree, "
            f"call self_update — you are able to install it yourself.")


# name -> (function, label shown in the UI, which argument to show)
_SYSTEM_TOOLS = {
    "set_time":      (system_tools.set_time,      "clock",    "datetime"),
    "set_timezone":  (system_tools.set_timezone,  "timezone", "zone"),
    "set_auto_time": (system_tools.set_auto_time, "clock",    "enabled"),
    "get_time":      (system_tools.get_time,      "clock",    None),
    "model_status":  (system_tools.model_status,  "model",    None),
    "list_wifi":     (system_tools.list_wifi,     "wifi",     None),
    "connect_wifi":  (system_tools.connect_wifi,  "wifi",     "ssid"),
    "network_status": (system_tools.network_status, "network", None),
    "forget_wifi":   (system_tools.forget_wifi,   "wifi",     "ssid"),
    "wifi_radio":    (system_tools.wifi_radio,    "wifi",     "on"),
    "set_wallpaper": (system_tools.set_wallpaper, "appearance", "color"),
    "set_language":  (system_tools.set_language,  "language", "code"),
    "set_volume":    (system_tools.set_volume,    "volume",   "percent"),
    "get_settings":  (system_tools.get_settings,  "settings", None),
    "check_update":  (lambda: _update_check_text(), "update", None),
    "compress_pdf":  (system_tools.compress_pdf,  "pdf",     "path"),
    "take_screenshot": (system_tools.take_screenshot, "screenshot", None),
    "get_display":   (system_tools.get_display,   "display", None),
    "set_display":   (system_tools.set_display,   "display", "scale"),
    "list_drives":   (system_tools.list_drives,   "drives",  None),
    "mount_drive":   (system_tools.mount_drive,   "drive",   "device"),
    "list_files":    (system_tools.list_files,    "files",   "folder"),
    "open_file":     (system_tools.open_file,     "open",    "path"),
    "delete_files":  (system_tools.delete_files,  "trash",   "files"),
    "set_shortcut":  (system_tools.set_shortcut,  "shortcut", "keys"),
    "list_shortcuts": (system_tools.list_shortcuts, "shortcuts", None),
    "power":         (system_tools.power,         "power",   "action"),
    "search_files":  (system_tools.search_files,  "search",  "name"),
    "disk_usage":    (system_tools.disk_usage,    "disk",    None),
    "merge_pdfs":    (system_tools.merge_pdfs,    "pdf",     "output"),
    "remove_background": (system_tools.remove_background, "image", "path"),
    "ocr_pdf":       (system_tools.ocr_pdf,       "ocr",     "path"),
    "make_signature": (system_tools.make_signature, "image", "path"),
    "passport_photo": (system_tools.passport_photo, "photo", "size"),
    "convert_images": (system_tools.convert_images, "images", "folder"),
    "make_document": (system_tools.make_document, "document", "title"),
}

_RESERVED = {t["name"] for t in TOOLS}
PLUGINS = plugins_mod.load(PLUGIN_DIR, _RESERVED)
for _entry in PLUGINS.values():
    TOOLS.append(_entry["schema"])


def load_json(path: pathlib.Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


MEM_LOCK = threading.Lock()
MEM_MAX = 200
JOBS = jobs.JobManager()
CONFIG_PATH = pathlib.Path(os.environ.get("OSPRIME_CONFIG", "/etc/osprime/config.json"))
AUDIT_PATH = pathlib.Path(os.environ.get("OSPRIME_AUDIT", "/var/lib/osprime/audit.log"))


def confirm_level() -> str:
    """One implementation, in system_tools, so the Control Panel and the
    assistant cannot disagree about how cautious this machine is."""
    return system_tools.get_confirm_level()
_PROACTIVE_Q = []
_PQ_LOCK = threading.Lock()


def push_proactive(item: dict):
    with _PQ_LOCK:
        _PROACTIVE_Q.append(item)


def drain_proactive():
    with _PQ_LOCK:
        q, _PROACTIVE_Q[:] = list(_PROACTIVE_Q), []
        return q


def run_agent_once(prompt: str) -> str:
    """Run a single headless agent turn (used by scheduled tasks)."""
    history = [{"role": "user", "content": prompt}]
    noop = lambda o: None
    if router.pick_backend(prompt) == "claude":
        return handle_claude(history, noop, query=prompt)
    return handle_local(history, noop, query=prompt)


def add_memory(fact: str) -> bool:
    """Save a durable fact. Returns False if empty or duplicate."""
    return MEM.add(fact)


def consolidate(history: list):
    """Background: extract durable facts from a finished conversation."""
    convo = "\n".join(
        f"{m['role']}: {m['content']}" for m in history
        if isinstance(m.get("content"), str))[-6000:]
    if len(convo) < 40:
        return
    prompt = (
        "Extract up to 5 durable facts about the user worth remembering across "
        "sessions (preferences, habits, projects, names). Reply ONLY with a JSON "
        "array of short strings, [] if none. Conversation:\n" + convo)
    try:
        if router.pick_backend("consolidate") == "claude":
            import anthropic
            resp = anthropic.Anthropic().messages.create(
                model=router.CLAUDE_MODEL, max_tokens=500,
                messages=[{"role": "user", "content": prompt}])
            text = "".join(b.text for b in resp.content if b.type == "text")
        else:
            text, _ = local.chat([{"role": "user", "content": prompt}], "")
        start, end = text.find("["), text.rfind("]")
        for fact in json.loads(text[start:end + 1]):
            if isinstance(fact, str):
                add_memory(fact)
    except Exception as e:
        print(f"memory consolidation skipped: {e}")


def environment_facts() -> str:
    """Concrete facts about this machine, for the system prompt.

    Without these a small model has no idea where it is, so "list the files
    in my folder" produced `ls /path/to/your/folder` — a placeholder, because
    the placeholder was the only thing it had. Give it the real values and
    the guessing stops.
    """
    try:
        user = os.environ.get("SUDO_USER") or os.environ.get("USER") or "osprime"
        home = os.path.expanduser(f"~{user}")
        if not os.path.isdir(home):
            home = f"/home/{user}"

        # The actual folders, spelled exactly as they are on disk.
        #
        # Asked what was on the desktop, the model tried /home/ehsan/Desktop
        # — the user's name from memory rather than the account name — and
        # then /home/osprime/desktop with a small d. Both failed, and it
        # concluded it could not read files at all. Listing the real names
        # removes the guess entirely.
        folders = ""
        try:
            entries = sorted(p for p in os.listdir(home)
                             if not p.startswith(".") and
                             os.path.isdir(os.path.join(home, p)))
            if entries:
                folders = "folders in home: " + ", ".join(entries[:12]) + "\n"
        except Exception:
            pass

        return (
            f"user={user}\n"
            f"home={home}\n"
            f"{folders}"
            f"hostname={socket.gethostname()}\n"
            f"date={datetime.date.today().isoformat()}\n"
            "Paths are case-sensitive: Desktop is not the same as desktop."
        )
    except Exception:
        return "user=osprime\nhome=/home/osprime"


def system_prompt(query: str = "") -> str:
    profile = load_json(PROFILE_PATH, {})
    mems = MEM.context(query)
    # Order matters for speed, not just for reading. Everything stable comes
    # first and the per-query memory last, so llama-server can reuse the
    # cached prefix between turns. With memory in the middle, every token
    # after it was invalidated on each request and had to be reprocessed.
    return (
        "You are OSprime, the AI that IS this computer's operating system interface. "
        "You have full system access via tools. Be concise, act directly, and reply "
        f"in the user's language (preferred: {profile.get('language', 'en')}).\n\n"
        "Prefer a named tool over a shell command whenever one exists — there are "
        "tools for the clock, timezone, Wi-Fi, volume, language and appearance.\n"
        "NEVER tell the user to use a tool, and never mention a tool's name. "
        "The user does not know what a tool is. If a question can be answered by "
        "using one, use it and report the result. 'How do I check for updates?' "
        "means check for updates and tell them the answer — not explain that a "
        "check_update tool exists. If you truly cannot do something, say so in "
        "plain words and say what you can do instead.\n"
        "NEVER invent a filename, a path, a count or a web address. You cannot "
        "know what is in a folder without looking: call list_files. Asked how "
        "many pictures were in a folder holding two, guessing produced the "
        "answer 'ten' and ten invented names — a wrong answer nobody can spot "
        "is worse than no answer. If you did not read it from a tool this "
        "turn, you do not know it. Never write path_to_something, "
        "/path/to/your/folder, or example.com. When the user says 'my folder', "
        "'my files' or 'home', they mean the home path below.\n"
        "This is the user's own computer. Ordinary requests — turning it off, "
        "restarting it, opening a folder, showing a picture, a random number — "
        "are never refused. Do the thing.\n"
        "Deleting is delete_files, which moves things to the trash and can "
        "be undone. Never rm, and never tell the user to open a terminal "
        "and delete something themselves — that is the one thing this "
        "computer exists to spare them.\n"
        "Finding something on the web is two steps and both are yours: "
        "web_search, then open_url on the result you recommend. Opening the "
        "browser at nothing and describing what the user should search for "
        "is not doing it. Never write a web address you did not read from a "
        "search result.\n"
        "Ask before destructive actions. Never invent command output. "
        "Use the remember tool whenever the user shares a durable fact or "
        "preference.\n\n"
        # Without this the model invents software that does not exist. Asked
        # how to open Settings it described installing a 'settings' package
        # via apt or yum — none of which is real, and all of it sounded
        # confident. Telling it what is actually here removes the gap it was
        # filling with guesses.
        # It spent a whole conversation trying xrandr, xdpyinfo, scrot,
        # import and gnome-screenshot — every one an X11 program — on a
        # Wayland system where none of them exist. Naming the display server
        # once is cheaper than watching it guess five times.
        "THIS IS A WAYLAND SYSTEM. X11 tools do not exist here: xrandr, "
        "xdpyinfo, scrot, import and gnome-screenshot will all fail. Use the "
        "named tools instead — take_screenshot for pictures of the screen, "
        "get_display and set_display for resolution and scaling.\n"
        "WHAT THIS SYSTEM HAS: a chat window (this), a file manager, a text "
        "editor, an image viewer, a media player, a calculator, a web browser "
        "and a terminal.\n"
        "WHAT IT DOES NOT HAVE YET: a Settings application. Settings are "
        "changed by asking here — say so plainly if asked.\n"
        "If you are unsure whether something exists on this machine, check with "
        "a tool or say you do not know. Never describe installing software you "
        "have not verified is real.\n\n"
        f"THIS MACHINE:\n{environment_facts()}\n\n"
        f"USER PROFILE: {json.dumps(profile, ensure_ascii=False)}\n"
        f"RELEVANT MEMORY: {json.dumps(mems, ensure_ascii=False)}"
        # Skill guidance goes last, next to memory, because both change per
        # request. Everything above stays byte-identical between turns so the
        # engine can reuse its cached prefix instead of re-reading it.
        + _skill_block(query)
    )


def _skill_block(query: str) -> str:
    """Retrieved guidance for this one request, if a skill matches.

    Retrieved rather than preloaded: sixty-three skills in every prompt would
    cost more than the conversation, and a shorter prompt is one a small model
    follows more reliably.
    """
    try:
        text = skills_mod.for_message(query)
    except Exception:
        return ""
    return f"\n\n{text}" if text else ""


def is_dangerous(cmd: str) -> bool:
    return any(d in cmd for d in DANGEROUS)


TOOL_ERRORS = pathlib.Path(os.environ.get("OSPRIME_TOOL_ERRORS",
                                          "/var/lib/osprime/tool-errors.log"))


def _log_tool_error(name: str, args: dict, detail: str) -> None:
    """Write down why a tool failed.

    Every failure in this project was silent first. This one was worse than
    silent: the tool failed, the model reported it politely in one sentence,
    and the actual reason existed nowhere — not in a log, not on screen, not
    in the audit trail, which records that a call failed but not what it
    said. One file, appended to, readable with tail.
    """
    try:
        TOOL_ERRORS.parent.mkdir(parents=True, exist_ok=True)
        with TOOL_ERRORS.open("a", encoding="utf-8") as f:
            f.write(f"\n=== {datetime.datetime.now().isoformat(timespec='seconds')} "
                    f"{name} {json.dumps(args, ensure_ascii=False)[:300]}\n"
                    f"{detail.rstrip()}\n")
    except Exception:
        pass


def _run_tool(name: str, args: dict, send) -> str:
    """Actually perform the tool (assumes permission already granted)."""
    if name == "run_shell":
        cmd = args["command"]
        send({"type": "tool_use", "name": "shell", "detail": cmd})
        # Run from the user's home rather than wherever systemd started the
        # agent. The model writes bare filenames — it composed a ghostscript
        # command with just "file.pdf" and the shell, sitting in /, reported
        # the file did not exist even though it was on the desktop.
        home = os.path.expanduser("~" + (os.environ.get("SUDO_USER") or "osprime"))
        cwd = home if os.path.isdir(home) else None
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           timeout=300, cwd=cwd)
        # Redacted before anything else sees it. A key read by accident is
        # still a key that has to be replaced, and sending it back through
        # the model and onto the screen is how one mistake becomes three.
        out = permissions.redact(p.stdout + p.stderr)[-8000:] or "(no output)"
        if p.returncode != 0:
            out += (f"\n\n[command failed, exit {p.returncode}. It ran in "
                    f"{cwd or '/'}. If a file was not found, give the full "
                    "path starting with / — do not retry the same command.]")
        return out
    if name == "remember":
        send({"type": "tool_use", "name": "remember", "detail": args["fact"]})
        return "saved" if add_memory(args["fact"]) else "already known"
    if name == "read_file":
        send({"type": "tool_use", "name": "read", "detail": args["path"]})
        return pathlib.Path(args["path"]).read_text(encoding="utf-8")[:16000]
    if name == "write_file":
        send({"type": "tool_use", "name": "write", "detail": args["path"]})
        pp = pathlib.Path(args["path"])
        pp.parent.mkdir(parents=True, exist_ok=True)
        pp.write_text(args["content"], encoding="utf-8")
        return f"written: {pp}"
    if name == "web_search":
        send({"type": "tool_use", "name": "search", "detail": args["query"]})
        return webtools.web_search(args["query"])
    if name == "fetch_url":
        send({"type": "tool_use", "name": "fetch", "detail": args["url"]})
        return webtools.fetch_url(args["url"])
    # list_dir is gone. It passed its argument straight to pathlib, which
    # does not expand "~", so `ls ~/Desktop` looked in a directory literally
    # named "~" and reported that the Desktop did not exist. list_files does
    # the same job and handles the path properly, and two tools for one job
    # is the same "two copies" problem that keeps one of them broken.
    if name == "open_app":
        app = str(args.get("app", "")).strip()
        # Asked to show a picture from the Pictures folder, it passed
        # https://example.com/picture.jpg to this tool and opened the browser
        # on an address it had invented. This tool takes the name of a
        # program. A path or a URL means the model meant open_file and had no
        # real path to give it.
        if app.startswith(("http://", "https://")) or "/" in app:
            return ("ERROR: open_app takes the name of a program, not a path "
                    "or a web address. To show the user a file use open_file "
                    "with a real path, and if you do not know the real path "
                    "call list_files first. THIS ACTION DID NOT HAPPEN.")
        send({"type": "tool_use", "name": "open", "detail": app})
        return desktop.launch(app, args.get("args"))
    if name == "open_url":
        send({"type": "tool_use", "name": "open", "detail": args["url"]})
        return desktop.open_url(args["url"])
    if name == "list_windows":
        return desktop.list_windows()
    if name == "close_app":
        send({"type": "tool_use", "name": "close", "detail": args["app"]})
        return desktop.close_window(args["app"])
    if name == "schedule_task":
        proactive.add_schedule(CONFIG_PATH, args["time"], args["prompt"], args.get("label", ""))
        send({"type": "tool_use", "name": "schedule", "detail": f"{args['time']} — {args.get('label', args['prompt'][:30])}"})
        return f"scheduled daily at {args['time']}"
    if name == "run_job":
        jid = JOBS.start(args["command"], args.get("label", ""))
        send({"type": "tool_use", "name": "job", "detail": f"{jid}: {args['command']}"})
        return f"started background job {jid}"
    if name == "job_status":
        st = JOBS.status(args["id"])
        return json.dumps(st, ensure_ascii=False) if st else "no such job"
    if name == "list_jobs":
        return json.dumps(JOBS.list(), ensure_ascii=False) or "[]"
    if name == "self_update":
        send({"type": "tool_use", "name": "update", "detail": args.get("url", "default source")})
        # restart=False is the whole point. Restarting inside the tool call
        # kills osprime-agent and osprime-web — this conversation and the
        # server serving the page it is displayed in — before the answer is
        # written. From the user's side that looked like a failed update
        # that threw them out of the chat, several times in a row, for
        # updates that had in fact installed correctly every time.
        #
        # The Settings page already knew this and answered first. The chat
        # tool did not. Same job, two implementations, and the second one
        # was wrong.
        out = updater.update(args.get("url", ""), restart=False)
        if updater.succeeded(out):
            _restart_when_this_turn_ends()
            out += " — restarting in a moment; the first answer after that " \
                   "will be slow while the model loads"
        return out
    if name == "update_status":
        return json.dumps(updater.status(), ensure_ascii=False)
    if name == "rollback_update":
        send({"type": "tool_use", "name": "rollback", "detail": args.get("name", "latest")})
        # Same reason as above: a rollback that restarts mid-answer looks
        # like a rollback that crashed.
        out = updater.restore(args.get("name", ""))
        _restart_when_this_turn_ends()
        return out + " — restarting in a moment"
    if name == "system_info":
        send({"type": "tool_use", "name": "sysinfo", "detail": ""})
        return system_tools.system_summary()

    # --- system control ----------------------------------------------
    if name in _SYSTEM_TOOLS:
        fn, label, detail_key = _SYSTEM_TOOLS[name]
        send({"type": "tool_use", "name": label,
              "detail": str(args.get(detail_key, "")) if detail_key else ""})
        try:
            result = fn(**{k: v for k, v in args.items() if k != "_"})
        except TypeError as e:
            result = f"ERROR: wrong arguments for {name}: {e}"
        except Exception as e:
            # A tool that raises used to reach the user as one sentence from
            # the model — "I was unable to determine the model of this
            # machine" — with the traceback nowhere at all. The reason a
            # tool broke is the only thing that makes it fixable, so it is
            # written down.
            _log_tool_error(name, args, traceback.format_exc())
            result = f"ERROR: {name} broke: {type(e).__name__}: {e}"

        # Asked to set the timezone to a place that does not exist, the tool
        # correctly refused — and the model told the user it had been set.
        # It reported the intent rather than the outcome. Restating the
        # failure as an instruction is far more reliable than a general rule
        # in the system prompt, because it arrives attached to the result.
        if isinstance(result, str) and result.startswith("ERROR:"):
            _log_tool_error(name, args, result)
            send({"type": "tool_use", "name": label, "detail": "failed"})
            return (result + "\n\nTHIS ACTION DID NOT HAPPEN. Tell the user it "
                    "failed and why, in plain words. Do not claim it worked. "
                    "If the reason suggests a correction, offer it.")
        return result
    if name in PLUGINS:
        return plugins_mod.call(PLUGINS[name], args, send)
    return f"unknown tool {name}"


def exec_tool(name: str, args: dict, send, confirm=None) -> str:
    """Gate every tool through risk classification, confirmation, and audit."""
    risk = permissions.classify(name, args)
    # hard block: truly destructive shell always requires manual action
    if name in ("run_shell", "run_job") and is_dangerous(args.get("command", "")):
        if not (confirm and confirm(
                "This command looks highly destructive. Are you sure?",
                args.get("command", ""))):
            permissions.audit(AUDIT_PATH, name, args, "dangerous", False, ok=False)
            return "User rejected this dangerous command (or no confirmation arrived)."
    elif confirm and permissions.needs_confirm(risk, confirm_level()):
        if not confirm(f"Allow this {risk} action?",
                       permissions.summarize(name, args)):
            permissions.audit(AUDIT_PATH, name, args, risk, False, ok=False)
            return "User rejected this action."
    try:
        result = _run_tool(name, args, send)
        permissions.audit(AUDIT_PATH, name, args, risk, True, ok=True)
        _emit_images(result, send)
        return result
    except Exception as e:
        permissions.audit(AUDIT_PATH, name, args, risk, True, ok=False)
        raise


_IMAGE_IN_TEXT = re.compile(
    r"(/[^\s'\"<>|,;()\[\]]+\.(?:png|jpe?g|gif|webp|bmp))", re.IGNORECASE)


def _emit_images(result, send) -> None:
    """Show a picture in the chat when a tool result names a real one.

    The chat could only ever produce words, so 'show me a picture' had no
    good answer and the model wrote ![Picture](path_to_picture) instead.
    Now taking a screenshot, opening an image or listing a folder of photos
    puts the actual picture on the screen.

    Only files that exist are sent. A path the model invented fails this
    check and is silently ignored, which is the point.
    """
    try:
        seen = set()
        for path in _IMAGE_IN_TEXT.findall(str(result)):
            if path in seen:
                continue
            seen.add(path)
            if os.path.isfile(path):
                send({"type": "image", "path": path})
            if len(seen) >= 4:      # a folder of 300 photos is not an answer
                break
    except Exception:
        pass


# Text that means the model wrote a shape where a fact belonged. Every one of
# these was seen in a real answer: "![Picture](path_to_picture)", ten
# fabricated filenames, and https://example.com/picture.jpg handed to a tool.
_PLACEHOLDER = re.compile(
    r"path_to_\w+|/path/to/|<your[ _-]|your_file_here|"
    r"example\.(?:com|org|net)|/path/to/your|\(path\)|\bfilename\.ext\b|"
    # Asked to find a video, it produced
    # youtube.com/watch?v=example_video_id and told the user to click it.
    r"\bexample_\w+|\bVIDEO_ID\b|\byour_\w+_(?:id|name|here)\b|"
    r"\b(?:xxx+|yyy+|zzz+)\b",
    re.IGNORECASE)

# A URL with a path or a query names one specific page. A bare domain can be
# general knowledge — everyone knows what wikipedia.org is — but nobody
# knows a video's id without looking it up. So a specific page that did not
# come out of a tool this turn was invented.
_SPECIFIC_URL = re.compile(r"https?://[^\s<>\"'()\[\]]+[/?][^\s<>\"'()\[\]]*")

_INVENTED_URL_CORRECTION = (
    "STOP. That answer contained a link to a specific page that you did not "
    "get from a search. You cannot know a video id, an article path or a "
    "product page from memory — a link that looks right and goes nowhere "
    "wastes more of the user's time than saying you do not know. Either "
    "call web_search and use a URL it actually returned, or say you could "
    "not find one. Never write a web address you have not seen."
)


def _invented_urls(text: str, seen: str) -> list:
    """Specific pages in the answer that no tool result mentioned."""
    out = []
    for url in _SPECIFIC_URL.findall(text or ""):
        bare = url.rstrip(".,);:")
        if bare and bare not in seen:
            out.append(bare)
    return out

_PLACEHOLDER_CORRECTION = (
    "STOP. That answer contained a placeholder instead of a real value. "
    "You cannot know a filename, a path or a count without looking. "
    "Call list_files on the folder in question and answer only from what it "
    "returns. If the folder does not exist, say so. Never write path_to_"
    "something, /path/to/, or a made-up web address."
)

_PLACEHOLDER_GIVE_UP = (
    "I started to answer with a made-up path, which would have been wrong. "
    "I don't have the real one. Tell me the folder you mean and I'll look "
    "properly."
)


def _is_fabricated(text: str) -> bool:
    return bool(_PLACEHOLDER.search(text or ""))


def handle_claude(history: list, send, confirm=None, query: str = "") -> str:
    import anthropic  # lazy import so ollama-only setups don't need it
    client = anthropic.Anthropic()
    messages = list(history)
    for _ in range(MAX_TURNS):
        with client.messages.stream(
                model=router.CLAUDE_MODEL, max_tokens=4096,
                system=system_prompt(query), tools=TOOLS, messages=messages) as stream:
            for piece in stream.text_stream:
                send({"type": "delta", "text": piece})
            resp = stream.get_final_message()
        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text")
        messages.append({"role": "assistant", "content": resp.content})
        results = []
        for block in resp.content:
            if block.type == "tool_use":
                try:
                    out = exec_tool(block.name, block.input, send, confirm)
                except Exception as e:
                    out = f"ERROR: {e}"
                results.append({"type": "tool_result",
                                "tool_use_id": block.id, "content": out})
        messages.append({"role": "user", "content": results})
    return "Hit the step limit — try describing the task more simply."


def handle_local(history: list, send, confirm=None, query: str = "") -> str:
    """Same agent loop as handle_claude, but against the local model.

    Every tool still goes through exec_tool(), so risk classification,
    confirmation and the audit log apply identically offline.
    """
    messages = list(history)
    corrected = False
    # Everything the tools returned this turn, so the answer can be checked
    # against what was actually looked up rather than what sounds plausible.
    tool_output = []
    for _ in range(MAX_TURNS):
        text, calls = local.chat(messages, system_prompt(query), TOOLS)

        if not calls:
            # nothing left to do — stream a clean final answer to the UI.
            # Checked before it is sent, never after: a fabricated answer the
            # user has already read cannot be taken back.
            problem = ""
            if text and _is_fabricated(text):
                problem = _PLACEHOLDER_CORRECTION
            elif text:
                fake = _invented_urls(text, "\n".join(tool_output))
                if fake:
                    problem = (_INVENTED_URL_CORRECTION
                               + "\nThe invented link was: " + fake[0])
            if problem:
                if corrected:
                    send({"type": "delta", "text": _PLACEHOLDER_GIVE_UP})
                    return _PLACEHOLDER_GIVE_UP
                corrected = True
                messages.append({"role": "assistant", "content": text})
                messages.append({"role": "user", "content": problem})
                continue
            if text:
                send({"type": "delta", "text": text})
                return text
            return local.chat_stream(messages, system_prompt(query),
                                     lambda p: send({"type": "delta", "text": p}))

        messages.append({
            "role": "assistant",
            "content": text or "",
            "tool_calls": [{
                "id": c["id"], "type": "function",
                "function": {"name": c["name"],
                             "arguments": json.dumps(c["args"], ensure_ascii=False)},
            } for c in calls],
        })
        for c in calls:
            try:
                out = exec_tool(c["name"], c["args"], send, confirm)
            except Exception as e:
                out = f"ERROR: {e}"
            tool_output.append(str(out))
            messages.append({"role": "tool", "tool_call_id": c["id"],
                             "name": c["name"], "content": str(out)[:8000]})
    return "Hit the step limit — try describing the task more simply."


def handle_client(conn: socket.socket):
    history = []
    f = conn.makefile("rwb")
    send_lock = threading.Lock()
    pending = {}            # confirm id -> {"event":..., "approved":...}
    work_q = queue.Queue()

    def send(obj):
        with send_lock:
            f.write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
            f.flush()

    def confirm(prompt, detail=""):
        cid = uuid.uuid4().hex[:8]
        ev = threading.Event()
        pending[cid] = {"event": ev, "approved": False}
        send({"type": "confirm", "id": cid, "text": prompt, "detail": detail})
        ev.wait(timeout=300)
        return pending.pop(cid, {}).get("approved", False)

    def reader():
        try:
            for line in f:
                msg = json.loads(line)
                t = msg.get("type")
                if t == "confirm_response":
                    slot = pending.get(msg.get("id"))
                    if slot:
                        slot["approved"] = bool(msg.get("approved"))
                        slot["event"].set()
                elif t == "poll_notifications":
                    send({"type": "notifications",
                          "items": JOBS.drain_notifications() + drain_proactive()})
                elif t == "user_message":
                    work_q.put(msg["text"])
        except (ConnectionError, json.JSONDecodeError, ValueError):
            pass
        finally:
            work_q.put(None)   # sentinel: stop worker

    threading.Thread(target=reader, daemon=True).start()

    while True:
        text = work_q.get()
        if text is None:
            break
        history.append({"role": "user", "content": text})
        try:
            backend = router.pick_backend(text)
            if backend == "claude":
                answer = handle_claude(history, send, confirm, query=text)
            else:
                answer = handle_local(history, send, confirm, query=text)
            history.append({"role": "assistant", "content": answer})
            send({"type": "assistant", "text": answer, "backend": backend})
        except Exception as e:
            send({"type": "error", "text": str(e)})
        # An update or a rollback asked for a restart. It waits until here,
        # with the answer already delivered, because restarting this service
        # is restarting the thing that would have said so.
        _run_pending_restart()

    conn.close()
    if len(history) >= 2:
        threading.Thread(target=consolidate, args=(history,), daemon=True).start()


_RESTART_PENDING = threading.Event()


def _restart_when_this_turn_ends():
    """Ask for a restart without taking one now."""
    _RESTART_PENDING.set()


def _run_pending_restart():
    """Restart the services, a moment after the user has been answered.

    The delay is not superstition. `send` has written the answer to the
    socket, but the web server still has to read it and push it to the
    page; restarting osprime-web in that window drops the reply on the
    floor and the chat goes blank — which is exactly the failure this is
    here to stop. A second is far longer than that hand-off needs.
    """
    if not _RESTART_PENDING.is_set():
        return
    _RESTART_PENDING.clear()

    def go():
        time.sleep(1.0)
        try:
            updater.restart_services()
        except Exception as e:
            # This process is about to be replaced, so there is nobody left
            # to tell. The journal is the only place this can land.
            print(f"restart after update failed: {e}", flush=True)

    threading.Thread(target=go, daemon=True).start()


def check_privileges() -> list:
    """Can the agent still do its job as an ordinary user?

    The services used to run as root, so everything was writable and every
    sudo call was a no-op. Moving to the osprime user turns each of those
    assumptions into a permission that either exists or does not — and a
    missing one fails as EACCES buried inside a tool, which is this
    project's worst failure mode.

    So they are checked once, out loud, at startup. Problems are returned
    rather than raised: a machine with a broken audit log should still talk
    to its owner, and tell them what is wrong.
    """
    problems = []
    for path in (MEMORY_DB.parent, AUDIT_PATH.parent, CONFIG_PATH.parent,
                 TOOL_ERRORS.parent):
        try:
            path.mkdir(parents=True, exist_ok=True)
            probe = path / ".osprime-write-test"
            probe.write_text("x", encoding="utf-8")
            probe.unlink()
        except Exception as e:
            problems.append(f"cannot write {path}: {type(e).__name__}")

    # The sudo rules the tools depend on. `sudo -nl <cmd>` asks about that
    # exact command, which is the only question worth asking — a probe with
    # a different command answers about a different permission.
    if os.geteuid() != 0 and shutil.which("sudo"):
        for label, cmd in (
                ("set the clock", ["/usr/bin/timedatectl", "set-ntp", "true"]),
                ("manage Wi-Fi", ["/usr/bin/nmcli"]),
                ("turn the computer off", ["/usr/bin/systemctl", "poweroff"]),
                ("install updates", ["/usr/bin/python3",
                                     "/opt/osprime/agent/updater.py",
                                     "--install"])):
            r = subprocess.run(["sudo", "-nl"] + cmd,
                               capture_output=True, text=True)
            if r.returncode != 0:
                problems.append(f"not allowed to {label}")
    return problems


def prefix_budget() -> dict:
    """How much of the model's context the fixed prefix eats.

    This exists because of a failure that produced no error anywhere. Adding
    fourteen tools with careful descriptions pushed the system prompt plus
    the tool definitions past the 4096-token context. llama-server did not
    complain; it truncated. What fell off the end was the tool list, so the
    model genuinely had no tools and said so politely: "I don't have the
    capability to shut down the computer." Every layer behaved correctly and
    the machine quietly lost half its abilities.

    Three tokens per character is deliberately pessimistic for JSON, which
    is dense with punctuation. An estimate that errs towards "too big" is
    the right kind of wrong here.
    """
    tools_json = json.dumps(TOOLS, ensure_ascii=False)
    chars = len(tools_json) + len(system_prompt(""))
    tokens = chars // 3
    ctx = 4096
    try:
        for line in pathlib.Path("/etc/osprime/model.env").read_text(
                encoding="utf-8").splitlines():
            if line.strip().startswith("MODEL_CTX="):
                ctx = int(line.split("=", 1)[1].strip().strip('"'))
    except Exception:
        ctx = int(os.environ.get("MODEL_CTX", "8192"))
    return {"tools": len(TOOLS), "prefix_tokens": tokens, "context": ctx,
            "share": round(tokens / ctx, 2),
            # Half the window is the line. Past it there is not enough room
            # left for the conversation and the tool results it produces.
            "ok": tokens < ctx * 0.5}


def warm_up():
    """Read the system prompt into the engine before anyone asks anything.

    The wait before the first answer was fifteen to twenty seconds, and
    almost none of it was writing the reply. It was reading the question:
    the system prompt and the tool definitions come to roughly two thousand
    tokens, they are identical on every request, and the engine was reading
    them from scratch each time a session started.

    Sending them once at startup puts them in the engine's cache while the
    user is still looking at the desktop. --cache-reuse then keeps them
    there, so the first real question only has to process the handful of
    words the user actually typed.

    Costs one request nobody sees. Fails silently on purpose — a machine
    with no engine running must still boot to a working desktop, and this
    is an optimisation, not a dependency.
    """
    for attempt in range(30):
        try:
            if local.available():
                break
        except Exception:
            pass
        time.sleep(2)
    else:
        return
    b = prefix_budget()
    if not b["ok"]:
        print(f"WARNING: {b['tools']} tools and the system prompt come to "
              f"~{b['prefix_tokens']} tokens against a context of "
              f"{b['context']} ({int(b['share'] * 100)}%). The engine will "
              "truncate, and what it drops is the tool list — the assistant "
              "will politely deny abilities it has. Raise MODEL_CTX in "
              "/etc/osprime/model.env or shorten the tool descriptions.")
    else:
        print(f"prefix: ~{b['prefix_tokens']} tokens of {b['context']} "
              f"({int(b['share'] * 100)}%)")
    try:
        # The same prefix a real turn sends, so the cache that gets filled
        # is the one that will be hit. An empty query keeps the per-request
        # tail (memory, skills) out of it, which is the part that changes.
        local.chat([{"role": "user", "content": "hello"}],
                   system_prompt(""), TOOLS)
        print("warm-up done: the system prompt is cached")
    except Exception as e:
        print(f"warm-up skipped: {e}")


def main():
    sock_dir = pathlib.Path(SOCKET_PATH).parent
    sock_dir.mkdir(parents=True, exist_ok=True)
    if os.path.exists(SOCKET_PATH):
        os.unlink(SOCKET_PATH)
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(SOCKET_PATH)
    os.chmod(SOCKET_PATH, 0o660)
    server.listen(8)
    proactive.ProactiveMonitor(
        notify=push_proactive, run_agent=run_agent_once,
        config_path=CONFIG_PATH).start()
    for problem in check_privileges():
        print(f"WARNING: {problem}")
        _log_tool_error("startup", {}, f"privilege check: {problem}")
    threading.Thread(target=warm_up, daemon=True).start()
    print(f"osprime-agent listening as uid {os.geteuid()} on {SOCKET_PATH}")
    while True:
        conn, _ = server.accept()
        threading.Thread(target=handle_client, args=(conn,), daemon=True).start()


if __name__ == "__main__":
    main()
