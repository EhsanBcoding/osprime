"""OSprime permission model + audit log.

Risk levels:  safe  <  moderate  <  dangerous
confirm_level in config decides what needs user approval:
    "off"        never ask (trust everything, dangerous still blocked)
    "dangerous"  ask only for dangerous ops              (default)
    "moderate"   ask for anything that changes the system (cautious)
"""

import datetime
import json
import pathlib
import threading

_AUDIT_LOCK = threading.Lock()

READ_ONLY = {"read_file", "list_dir", "system_info", "web_search",
             "fetch_url", "job_status", "list_jobs", "list_windows",
             "open_app", "open_url", "update_status",
             # system tools that only look
             "list_wifi", "network_status", "get_settings", "check_update", "get_display",
             "list_drives", "list_files", "open_file",
             "search_files", "disk_usage", "get_time"}

# Tools whose risk is a property of the tool, not of its arguments. Turning
# the computer off is always worth one question, whatever the confirm level
# is set to elsewhere.
_FIXED_RISK = {"power": "dangerous"}

_MODERATE_HINTS = ("apt", "dpkg", "pip", "npm", "install", "mv ", "cp ",
                   "chmod", "chown", "systemctl", "service ", "ln ", "tee ",
                   "git ", "curl", "wget", ">", ">>", "sudo")
_DANGER_HINTS = ("rm -rf", "rm -r", "mkfs", "dd if=", "dd of=", ":(){", "shutdown",
                 "reboot", "userdel", "passwd", "> /dev/sd", "fdisk", "parted",
                 "chmod -R 777 /", "chown -R")

RANK = {"safe": 0, "moderate": 1, "dangerous": 2}
_LEVELS = ("off", "safe", "moderate", "dangerous")


def classify(tool: str, args: dict) -> str:
    if tool in _FIXED_RISK:
        return _FIXED_RISK[tool]
    if tool in READ_ONLY:
        return "safe"
    if tool in ("run_shell", "run_job"):
        cmd = args.get("command", "")
        if any(h in cmd for h in _DANGER_HINTS):
            return "dangerous"
        if any(h in cmd for h in _MODERATE_HINTS):
            return "moderate"
        return "safe"
    return "moderate"


def needs_confirm(risk: str, confirm_level: str) -> bool:
    level = confirm_level if confirm_level in _LEVELS else "dangerous"
    if level == "off":
        return False
    return RANK[risk] >= RANK[level]


_SYSTEM_SUMMARY = {
    "set_time": lambda a: f"set the clock to {a.get('datetime', '')}",
    "set_timezone": lambda a: f"set the timezone to {a.get('zone', '')}",
    "set_auto_time": lambda a: f"automatic clock sync: {a.get('enabled')}",
    "connect_wifi": lambda a: f"join the Wi-Fi network {a.get('ssid', '')}",
    "set_wallpaper": lambda a: f"change the background to {a.get('color', '')}",
    "set_language": lambda a: f"change the language to {a.get('code', '')}",
    "set_volume": lambda a: f"set the volume to {a.get('percent')}%",
    "power": lambda a: {
        "shutdown": "turn this computer off",
        "restart": "restart this computer",
        "sleep": "put this computer to sleep",
    }.get(str(a.get("action", "")).strip().lower(),
          f"{a.get('action', '')} this computer"),
}


def summarize(tool: str, args: dict) -> str:
    if tool in _SYSTEM_SUMMARY:
        return _SYSTEM_SUMMARY[tool](args)
    if tool in ("run_shell", "run_job"):
        return args.get("command", "")
    if tool == "write_file":
        return f"write to {args.get('path', '')}"
    if tool == "schedule_task":
        return f"schedule daily at {args.get('time', '')}"
    if tool == "remember":
        return args.get("fact", "")
    return json.dumps(args, ensure_ascii=False)[:200]


def audit(path, tool: str, args: dict, risk: str, approved: bool, ok: bool = True):
    entry = {
        "t": datetime.datetime.now().isoformat(timespec="seconds"),
        "tool": tool, "risk": risk, "approved": approved, "ok": ok,
        "detail": summarize(tool, args)[:300],
    }
    try:
        p = pathlib.Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with _AUDIT_LOCK:
            with p.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass
    return entry
