#!/usr/bin/env python3
"""osprime-agent: the always-on AI daemon at the heart of OSprime.

Listens on a Unix socket. Each client sends JSON lines:
    {"type": "user_message", "text": "..."}
and receives JSON lines back:
    {"type": "assistant", "text": "..."}
    {"type": "tool_use", "name": "...", "detail": "..."}   (progress info)
    {"type": "confirm", "text": "..."}                     (dangerous command)
    {"type": "error", "text": "..."}

Requires: pip install anthropic   (for the Claude backend)
"""

import datetime
import json
import os
import pathlib
import queue
import socket
import subprocess
import threading
import uuid

import desktop
import jobs
import local
import memory as memory_mod
import permissions
import plugins as plugins_mod
import proactive
import router
import system_tools
import updater
import webtools

SOCKET_PATH = os.environ.get("OSPRIME_SOCKET", "/run/osprime/agent.sock")
PROFILE_PATH = pathlib.Path(os.environ.get("OSPRIME_PROFILE", "/etc/osprime/profile.json"))
MEMORY_PATH = pathlib.Path(os.environ.get("OSPRIME_MEMORY", "/var/lib/osprime/memory.json"))
MEMORY_DB = pathlib.Path(os.environ.get("OSPRIME_MEMORY_DB", "/var/lib/osprime/memory.db"))
MEM = memory_mod.Memory(MEMORY_DB)
if MEM.count() == 0:
    memory_mod.migrate_json(MEM, MEMORY_PATH)
PLUGIN_DIR = pathlib.Path(os.environ.get(
    "OSPRIME_PLUGINS",
    str(pathlib.Path(__file__).resolve().parent.parent / "tools.d")))
MAX_TURNS = 20  # max tool-use rounds per request

DANGEROUS = ("rm -rf /", "mkfs", "dd if=", ":(){", "> /dev/sd", "chmod -R 777 /")

TOOLS = [
    {
        "name": "run_shell",
        "description": "Run a shell command on this machine and return stdout/stderr.",
        "input_schema": {
            "type": "object",
            "properties": {"command": {"type": "string"}},
            "required": ["command"],
        },
    },
    {
        "name": "read_file",
        "description": "Read a text file from the filesystem.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "remember",
        "description": "Save one important, durable fact about the user or system to "
                       "long-term memory (preferences, habits, names, recurring tasks). "
                       "Use it whenever the user shares something worth remembering.",
        "input_schema": {
            "type": "object",
            "properties": {"fact": {"type": "string"}},
            "required": ["fact"],
        },
    },
    {
        "name": "write_file",
        "description": "Write text content to a file (creates parent dirs).",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
            "required": ["path", "content"],
        },
    },
    {
        "name": "web_search",
        "description": "Search the web (DuckDuckGo). Returns titles and URLs.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "fetch_url",
        "description": "Fetch a web page and return its readable text content.",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
            "required": ["url"],
        },
    },
    {
        "name": "list_dir",
        "description": "List a directory: names, sizes, and type (file/dir).",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "open_app",
        "description": "Launch a graphical application on the user's screen. "
                       "Known names: browser, firefox, terminal, files, editor, "
                       "video, image — or any installed command. Use when the user "
                       "asks to open/show/play something visually.",
        "input_schema": {
            "type": "object",
            "properties": {"app": {"type": "string"},
                           "args": {"type": "array", "items": {"type": "string"}}},
            "required": ["app"],
        },
    },
    {
        "name": "open_url",
        "description": "Open a web page in a browser window on the user's screen.",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
            "required": ["url"],
        },
    },
    {
        "name": "list_windows",
        "description": "List currently open application windows.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "close_app",
        "description": "Close an application window by its app name.",
        "input_schema": {
            "type": "object",
            "properties": {"app": {"type": "string"}},
            "required": ["app"],
        },
    },
    {
        "name": "schedule_task",
        "description": "Schedule a recurring daily task at a given time. Use when the "
                       "user says things like 'every morning', 'each day at 8', etc. "
                       "time is 24h HH:MM. prompt is what OSprime should do then.",
        "input_schema": {
            "type": "object",
            "properties": {"time": {"type": "string"},
                           "prompt": {"type": "string"},
                           "label": {"type": "string"}},
            "required": ["time", "prompt"],
        },
    },
    {
        "name": "run_job",
        "description": "Run a LONG-running shell command in the background and "
                       "return a job id immediately. Use for builds, downloads, "
                       "clones, or anything that takes more than ~30s. The user is "
                       "notified automatically when it finishes.",
        "input_schema": {
            "type": "object",
            "properties": {"command": {"type": "string"},
                           "label": {"type": "string"}},
            "required": ["command"],
        },
    },
    {
        "name": "job_status",
        "description": "Check a background job by id (status, exit code, output).",
        "input_schema": {
            "type": "object",
            "properties": {"id": {"type": "string"}},
            "required": ["id"],
        },
    },
    {
        "name": "list_jobs",
        "description": "List all background jobs and their statuses.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "self_update",
        "description": "Update OSprime itself to the latest version. Verifies the "
                       "new code compiles before swapping it in, keeps a backup, "
                       "and restarts services. Ask the user first.",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
        },
    },
    {
        "name": "update_status",
        "description": "Show the installed OSprime version and available backups.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "rollback_update",
        "description": "Roll OSprime back to a previous version (latest backup by default).",
        "input_schema": {
            "type": "object",
            "properties": {"name": {"type": "string"}},
        },
    },
    {
        "name": "system_info",
        "description": "Snapshot of disk, memory, CPU and uptime.",
        "input_schema": {"type": "object", "properties": {}},
    },
    # --- system control -----------------------------------------------
    # Named operations rather than shell strings. A small model can pick a
    # name and fill one field reliably; it cannot recall timedatectl syntax.
    {
        "name": "set_time",
        "description": "Set the system clock. Use when the time or date is wrong. "
                       "datetime must be 'YYYY-MM-DD HH:MM'.",
        "input_schema": {
            "type": "object",
            "properties": {"datetime": {"type": "string"}},
            "required": ["datetime"],
        },
    },
    {
        "name": "set_timezone",
        "description": "Set the timezone, e.g. 'Europe/Berlin' or 'Asia/Tehran'.",
        "input_schema": {
            "type": "object",
            "properties": {"zone": {"type": "string"}},
            "required": ["zone"],
        },
    },
    {
        "name": "set_auto_time",
        "description": "Turn automatic clock synchronisation on or off.",
        "input_schema": {
            "type": "object",
            "properties": {"enabled": {"type": "boolean"}},
            "required": ["enabled"],
        },
    },
    {
        "name": "list_wifi",
        "description": "Scan for nearby Wi-Fi networks.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "connect_wifi",
        "description": "Join a Wi-Fi network by name.",
        "input_schema": {
            "type": "object",
            "properties": {"ssid": {"type": "string"},
                           "password": {"type": "string"}},
            "required": ["ssid"],
        },
    },
    {
        "name": "network_status",
        "description": "Report whether this machine is online and how.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "set_wallpaper",
        "description": "Set the desktop background colour. Accepts a hex value "
                       "or one of: petrol, beige, navy, grey, black.",
        "input_schema": {
            "type": "object",
            "properties": {"color": {"type": "string"}},
            "required": ["color"],
        },
    },
    {
        "name": "set_language",
        "description": "Set the interface language by two-letter code, e.g. en or fa.",
        "input_schema": {
            "type": "object",
            "properties": {"code": {"type": "string"}},
            "required": ["code"],
        },
    },
    {
        "name": "set_volume",
        "description": "Set the output volume, 0 to 100.",
        "input_schema": {
            "type": "object",
            "properties": {"percent": {"type": "integer"}},
            "required": ["percent"],
        },
    },
    {
        "name": "get_settings",
        "description": "Read the current settings — language, background, "
                       "timezone, cloud mode.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "check_update",
        "description": "Check whether a newer version of OSprime is available. "
                       "Does not install anything.",
        "input_schema": {"type": "object", "properties": {}},
    },
]


# name -> (function, label shown in the UI, which argument to show)
_SYSTEM_TOOLS = {
    "set_time":      (system_tools.set_time,      "clock",    "datetime"),
    "set_timezone":  (system_tools.set_timezone,  "timezone", "zone"),
    "set_auto_time": (system_tools.set_auto_time, "clock",    "enabled"),
    "list_wifi":     (system_tools.list_wifi,     "wifi",     None),
    "connect_wifi":  (system_tools.connect_wifi,  "wifi",     "ssid"),
    "network_status": (system_tools.network_status, "network", None),
    "set_wallpaper": (system_tools.set_wallpaper, "appearance", "color"),
    "set_language":  (system_tools.set_language,  "language", "code"),
    "set_volume":    (system_tools.set_volume,    "volume",   "percent"),
    "get_settings":  (system_tools.get_settings,  "settings", None),
    "check_update":  (lambda: json.dumps(updater.check()), "update", None),
}

_RESERVED = {t["name"] for t in TOOLS}
PLUGINS = plugins_mod.load(PLUGIN_DIR, _RESERVED)
for _entry in PLUGINS.values():
    TOOLS.append(_entry["schema"])


def load_json(path: pathlib.Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


MEM_LOCK = threading.Lock()
MEM_MAX = 200
JOBS = jobs.JobManager()
CONFIG_PATH = pathlib.Path(os.environ.get("OSPRIME_CONFIG", "/etc/osprime/config.json"))
AUDIT_PATH = pathlib.Path(os.environ.get("OSPRIME_AUDIT", "/var/lib/osprime/audit.log"))


def confirm_level() -> str:
    cfg = load_json(CONFIG_PATH, {})
    if cfg.get("confirm_level"):
        return cfg["confirm_level"]
    prof = load_json(PROFILE_PATH, {})
    auto = str(prof.get("autonomy", "")).strip()
    # accept either language: onboarding may have been answered in Persian
    return "moderate" if auto in ("yes", "y", "بله", "بلی") else "dangerous"
_PROACTIVE_Q = []
_PQ_LOCK = threading.Lock()


def push_proactive(item: dict):
    with _PQ_LOCK:
        _PROACTIVE_Q.append(item)


def drain_proactive():
    with _PQ_LOCK:
        q, _PROACTIVE_Q[:] = list(_PROACTIVE_Q), []
        return q


def run_agent_once(prompt: str) -> str:
    """Run a single headless agent turn (used by scheduled tasks)."""
    history = [{"role": "user", "content": prompt}]
    noop = lambda o: None
    if router.pick_backend(prompt) == "claude":
        return handle_claude(history, noop, query=prompt)
    return handle_local(history, noop, query=prompt)


def add_memory(fact: str) -> bool:
    """Save a durable fact. Returns False if empty or duplicate."""
    return MEM.add(fact)


def consolidate(history: list):
    """Background: extract durable facts from a finished conversation."""
    convo = "\n".join(
        f"{m['role']}: {m['content']}" for m in history
        if isinstance(m.get("content"), str))[-6000:]
    if len(convo) < 40:
        return
    prompt = (
        "Extract up to 5 durable facts about the user worth remembering across "
        "sessions (preferences, habits, projects, names). Reply ONLY with a JSON "
        "array of short strings, [] if none. Conversation:\n" + convo)
    try:
        if router.pick_backend("consolidate") == "claude":
            import anthropic
            resp = anthropic.Anthropic().messages.create(
                model=router.CLAUDE_MODEL, max_tokens=500,
                messages=[{"role": "user", "content": prompt}])
            text = "".join(b.text for b in resp.content if b.type == "text")
        else:
            text, _ = local.chat([{"role": "user", "content": prompt}], "")
        start, end = text.find("["), text.rfind("]")
        for fact in json.loads(text[start:end + 1]):
            if isinstance(fact, str):
                add_memory(fact)
    except Exception as e:
        print(f"memory consolidation skipped: {e}")


def environment_facts() -> str:
    """Concrete facts about this machine, for the system prompt.

    Without these a small model has no idea where it is, so "list the files
    in my folder" produced `ls /path/to/your/folder` — a placeholder, because
    the placeholder was the only thing it had. Give it the real values and
    the guessing stops.
    """
    try:
        user = os.environ.get("SUDO_USER") or os.environ.get("USER") or "osprime"
        home = os.path.expanduser(f"~{user}")
        if not os.path.isdir(home):
            home = f"/home/{user}"
        return (
            f"user={user}\n"
            f"home={home}\n"
            f"hostname={socket.gethostname()}\n"
            f"date={datetime.date.today().isoformat()}"
        )
    except Exception:
        return "user=osprime\nhome=/home/osprime"


def system_prompt(query: str = "") -> str:
    profile = load_json(PROFILE_PATH, {})
    mems = MEM.context(query)
    # Order matters for speed, not just for reading. Everything stable comes
    # first and the per-query memory last, so llama-server can reuse the
    # cached prefix between turns. With memory in the middle, every token
    # after it was invalidated on each request and had to be reprocessed.
    return (
        "You are OSprime, the AI that IS this computer's operating system interface. "
        "You have full system access via tools. Be concise, act directly, and reply "
        f"in the user's language (preferred: {profile.get('language', 'en')}).\n\n"
        "Prefer a named tool over a shell command whenever one exists — there are "
        "tools for the clock, timezone, Wi-Fi, volume, language and appearance.\n"
        "NEVER tell the user to use a tool, and never mention a tool's name. "
        "The user does not know what a tool is. If a question can be answered by "
        "using one, use it and report the result. 'How do I check for updates?' "
        "means check for updates and tell them the answer — not explain that a "
        "check_update tool exists. If you truly cannot do something, say so in "
        "plain words and say what you can do instead.\n"
        "Never use placeholder paths such as /path/to/your/folder. When the user "
        "says 'my folder', 'my files' or 'home', they mean the home path below. "
        "If a path is genuinely unknown, run a command to find it rather than "
        "inventing one.\n"
        "Ask before destructive actions. Never invent command output. "
        "Use the remember tool whenever the user shares a durable fact or "
        "preference.\n\n"
        f"THIS MACHINE:\n{environment_facts()}\n\n"
        f"USER PROFILE: {json.dumps(profile, ensure_ascii=False)}\n"
        f"RELEVANT MEMORY: {json.dumps(mems, ensure_ascii=False)}"
    )


def is_dangerous(cmd: str) -> bool:
    return any(d in cmd for d in DANGEROUS)


def _run_tool(name: str, args: dict, send) -> str:
    """Actually perform the tool (assumes permission already granted)."""
    if name == "run_shell":
        cmd = args["command"]
        send({"type": "tool_use", "name": "shell", "detail": cmd})
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=300)
        return (p.stdout + p.stderr)[-8000:] or "(no output)"
    if name == "remember":
        send({"type": "tool_use", "name": "remember", "detail": args["fact"]})
        return "saved" if add_memory(args["fact"]) else "already known"
    if name == "read_file":
        send({"type": "tool_use", "name": "read", "detail": args["path"]})
        return pathlib.Path(args["path"]).read_text(encoding="utf-8")[:16000]
    if name == "write_file":
        send({"type": "tool_use", "name": "write", "detail": args["path"]})
        pp = pathlib.Path(args["path"])
        pp.parent.mkdir(parents=True, exist_ok=True)
        pp.write_text(args["content"], encoding="utf-8")
        return f"written: {pp}"
    if name == "web_search":
        send({"type": "tool_use", "name": "search", "detail": args["query"]})
        return webtools.web_search(args["query"])
    if name == "fetch_url":
        send({"type": "tool_use", "name": "fetch", "detail": args["url"]})
        return webtools.fetch_url(args["url"])
    if name == "list_dir":
        send({"type": "tool_use", "name": "ls", "detail": args["path"]})
        entries = []
        for e in sorted(pathlib.Path(args["path"]).iterdir()):
            kind = "dir " if e.is_dir() else "file"
            size = e.stat().st_size if e.is_file() else ""
            entries.append(f"{kind} {e.name} {size}")
        return "\n".join(entries[:300]) or "(empty)"
    if name == "open_app":
        send({"type": "tool_use", "name": "open", "detail": args["app"]})
        return desktop.launch(args["app"], args.get("args"))
    if name == "open_url":
        send({"type": "tool_use", "name": "open", "detail": args["url"]})
        return desktop.open_url(args["url"])
    if name == "list_windows":
        return desktop.list_windows()
    if name == "close_app":
        send({"type": "tool_use", "name": "close", "detail": args["app"]})
        return desktop.close_window(args["app"])
    if name == "schedule_task":
        proactive.add_schedule(CONFIG_PATH, args["time"], args["prompt"], args.get("label", ""))
        send({"type": "tool_use", "name": "schedule", "detail": f"{args['time']} — {args.get('label', args['prompt'][:30])}"})
        return f"scheduled daily at {args['time']}"
    if name == "run_job":
        jid = JOBS.start(args["command"], args.get("label", ""))
        send({"type": "tool_use", "name": "job", "detail": f"{jid}: {args['command']}"})
        return f"started background job {jid}"
    if name == "job_status":
        st = JOBS.status(args["id"])
        return json.dumps(st, ensure_ascii=False) if st else "no such job"
    if name == "list_jobs":
        return json.dumps(JOBS.list(), ensure_ascii=False) or "[]"
    if name == "self_update":
        send({"type": "tool_use", "name": "update", "detail": args.get("url", "default source")})
        return updater.update(args.get("url", ""))
    if name == "update_status":
        return json.dumps(updater.status(), ensure_ascii=False)
    if name == "rollback_update":
        send({"type": "tool_use", "name": "rollback", "detail": args.get("name", "latest")})
        out = updater.restore(args.get("name", ""))
        return out + " — " + updater.restart_services()
    if name == "system_info":
        send({"type": "tool_use", "name": "sysinfo", "detail": ""})
        return system_tools.system_summary()

    # --- system control ----------------------------------------------
    if name in _SYSTEM_TOOLS:
        fn, label, detail_key = _SYSTEM_TOOLS[name]
        send({"type": "tool_use", "name": label,
              "detail": str(args.get(detail_key, "")) if detail_key else ""})
        try:
            return fn(**{k: v for k, v in args.items() if k != "_"})
        except TypeError as e:
            return f"wrong arguments for {name}: {e}"
    if name in PLUGINS:
        return plugins_mod.call(PLUGINS[name], args, send)
    return f"unknown tool {name}"


def exec_tool(name: str, args: dict, send, confirm=None) -> str:
    """Gate every tool through risk classification, confirmation, and audit."""
    risk = permissions.classify(name, args)
    # hard block: truly destructive shell always requires manual action
    if name in ("run_shell", "run_job") and is_dangerous(args.get("command", "")):
        if not (confirm and confirm(
                "This command looks highly destructive. Are you sure?",
                args.get("command", ""))):
            permissions.audit(AUDIT_PATH, name, args, "dangerous", False, ok=False)
            return "User rejected this dangerous command (or no confirmation arrived)."
    elif confirm and permissions.needs_confirm(risk, confirm_level()):
        if not confirm(f"Allow this {risk} action?",
                       permissions.summarize(name, args)):
            permissions.audit(AUDIT_PATH, name, args, risk, False, ok=False)
            return "User rejected this action."
    try:
        result = _run_tool(name, args, send)
        permissions.audit(AUDIT_PATH, name, args, risk, True, ok=True)
        return result
    except Exception as e:
        permissions.audit(AUDIT_PATH, name, args, risk, True, ok=False)
        raise


def handle_claude(history: list, send, confirm=None, query: str = "") -> str:
    import anthropic  # lazy import so ollama-only setups don't need it
    client = anthropic.Anthropic()
    messages = list(history)
    for _ in range(MAX_TURNS):
        with client.messages.stream(
                model=router.CLAUDE_MODEL, max_tokens=4096,
                system=system_prompt(query), tools=TOOLS, messages=messages) as stream:
            for piece in stream.text_stream:
                send({"type": "delta", "text": piece})
            resp = stream.get_final_message()
        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text")
        messages.append({"role": "assistant", "content": resp.content})
        results = []
        for block in resp.content:
            if block.type == "tool_use":
                try:
                    out = exec_tool(block.name, block.input, send, confirm)
                except Exception as e:
                    out = f"ERROR: {e}"
                results.append({"type": "tool_result",
                                "tool_use_id": block.id, "content": out})
        messages.append({"role": "user", "content": results})
    return "Hit the step limit — try describing the task more simply."


def handle_local(history: list, send, confirm=None, query: str = "") -> str:
    """Same agent loop as handle_claude, but against the local model.

    Every tool still goes through exec_tool(), so risk classification,
    confirmation and the audit log apply identically offline.
    """
    messages = list(history)
    for _ in range(MAX_TURNS):
        text, calls = local.chat(messages, system_prompt(query), TOOLS)

        if not calls:
            # nothing left to do — stream a clean final answer to the UI
            if text:
                send({"type": "delta", "text": text})
                return text
            return local.chat_stream(messages, system_prompt(query),
                                     lambda p: send({"type": "delta", "text": p}))

        messages.append({
            "role": "assistant",
            "content": text or "",
            "tool_calls": [{
                "id": c["id"], "type": "function",
                "function": {"name": c["name"],
                             "arguments": json.dumps(c["args"], ensure_ascii=False)},
            } for c in calls],
        })
        for c in calls:
            try:
                out = exec_tool(c["name"], c["args"], send, confirm)
            except Exception as e:
                out = f"ERROR: {e}"
            messages.append({"role": "tool", "tool_call_id": c["id"],
                             "name": c["name"], "content": str(out)[:8000]})
    return "Hit the step limit — try describing the task more simply."


def handle_client(conn: socket.socket):
    history = []
    f = conn.makefile("rwb")
    send_lock = threading.Lock()
    pending = {}            # confirm id -> {"event":..., "approved":...}
    work_q = queue.Queue()

    def send(obj):
        with send_lock:
            f.write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
            f.flush()

    def confirm(prompt, detail=""):
        cid = uuid.uuid4().hex[:8]
        ev = threading.Event()
        pending[cid] = {"event": ev, "approved": False}
        send({"type": "confirm", "id": cid, "text": prompt, "detail": detail})
        ev.wait(timeout=300)
        return pending.pop(cid, {}).get("approved", False)

    def reader():
        try:
            for line in f:
                msg = json.loads(line)
                t = msg.get("type")
                if t == "confirm_response":
                    slot = pending.get(msg.get("id"))
                    if slot:
                        slot["approved"] = bool(msg.get("approved"))
                        slot["event"].set()
                elif t == "poll_notifications":
                    send({"type": "notifications",
                          "items": JOBS.drain_notifications() + drain_proactive()})
                elif t == "user_message":
                    work_q.put(msg["text"])
        except (ConnectionError, json.JSONDecodeError, ValueError):
            pass
        finally:
            work_q.put(None)   # sentinel: stop worker

    threading.Thread(target=reader, daemon=True).start()

    while True:
        text = work_q.get()
        if text is None:
            break
        history.append({"role": "user", "content": text})
        try:
            backend = router.pick_backend(text)
            if backend == "claude":
                answer = handle_claude(history, send, confirm, query=text)
            else:
                answer = handle_local(history, send, confirm, query=text)
            history.append({"role": "assistant", "content": answer})
            send({"type": "assistant", "text": answer, "backend": backend})
        except Exception as e:
            send({"type": "error", "text": str(e)})

    conn.close()
    if len(history) >= 2:
        threading.Thread(target=consolidate, args=(history,), daemon=True).start()


def main():
    sock_dir = pathlib.Path(SOCKET_PATH).parent
    sock_dir.mkdir(parents=True, exist_ok=True)
    if os.path.exists(SOCKET_PATH):
        os.unlink(SOCKET_PATH)
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(SOCKET_PATH)
    os.chmod(SOCKET_PATH, 0o660)
    server.listen(8)
    proactive.ProactiveMonitor(
        notify=push_proactive, run_agent=run_agent_once,
        config_path=CONFIG_PATH).start()
    print(f"osprime-agent listening on {SOCKET_PATH}")
    while True:
        conn, _ = server.accept()
        threading.Thread(target=handle_client, args=(conn,), daemon=True).start()


if __name__ == "__main__":
    main()
