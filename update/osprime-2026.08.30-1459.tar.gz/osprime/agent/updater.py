"""OSprime self-update (OTA) with automatic rollback.

Layout:
    /opt/osprime            <- live code
    /var/lib/osprime/backups/<timestamp>  <- previous versions

An update stages the new code, verifies it compiles, swaps it in, and
restores the backup if anything fails.
"""

import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import urllib.request

INSTALL_DIR = pathlib.Path(os.environ.get("OSPRIME_INSTALL", "/opt/osprime"))
BACKUP_DIR = pathlib.Path(os.environ.get("OSPRIME_BACKUPS", "/var/lib/osprime/backups"))

# Where releases are announced. A static file is enough — no server code.
MANIFEST_URL = os.environ.get(
    "OSPRIME_MANIFEST_URL",
    "https://ehsanbcoding.github.io/osprime/update/manifest.json")

# Direct archive URL, used only when a manifest is deliberately bypassed
# (local testing, or an explicitly supplied package).
SOURCE_URL = os.environ.get("OSPRIME_UPDATE_URL", "")

VERSION_FILE = INSTALL_DIR / "VERSION"
CODE_DIRS = ("agent", "ui", "onboarding", "tools.d", "shell", "installer")
KEEP_BACKUPS = 3
NET_TIMEOUT = 15


def current_version() -> str:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        return "unknown"


def fetch_manifest(url: str = "") -> dict:
    """Read the release manifest. Returns {} when unreachable — being
    offline is a normal state here, not an error worth surfacing."""
    url = url or MANIFEST_URL
    try:
        with urllib.request.urlopen(url, timeout=NET_TIMEOUT) as r:
            data = json.load(r)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _newer(latest: str, current: str) -> bool:
    """Versions are YYYY.MM.DD-HHMM, so string order is chronological."""
    if not latest:
        return False
    if current in ("", "unknown", "dev"):
        return True
    return latest > current


def check(url: str = "") -> dict:
    """Is there a newer version? Never installs anything."""
    m = fetch_manifest(url)
    if not m:
        return {"available": False, "reason": "could not reach the update server",
                "current": current_version()}
    latest = str(m.get("version", ""))
    return {
        "available": _newer(latest, current_version()),
        "current": current_version(),
        "latest": latest,
        "notes": m.get("notes", ""),
        "url": m.get("url", ""),
        "sha256": m.get("sha256", ""),
    }


def _sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _compiles(root: pathlib.Path) -> bool:
    """Every python file in the staged tree must byte-compile."""
    files = [str(p) for d in CODE_DIRS for p in (root / d).rglob("*.py")]
    if not files:
        return False
    env = dict(os.environ, PYTHONPYCACHEPREFIX=tempfile.mkdtemp())
    r = subprocess.run(["python3", "-m", "py_compile", *files],
                       capture_output=True, text=True, env=env)
    return r.returncode == 0


def _find_root(extracted: pathlib.Path) -> pathlib.Path:
    """Archives usually contain a single top-level folder."""
    if (extracted / "agent").is_dir():
        return extracted
    subs = [p for p in extracted.iterdir() if p.is_dir()]
    for s in subs:
        if (s / "agent").is_dir():
            return s
    return extracted


def backup() -> pathlib.Path:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = BACKUP_DIR / stamp
    n = 1
    while dest.exists():                 # two updates in the same second
        dest = BACKUP_DIR / f"{stamp}-{n}"
        n += 1
    dest.mkdir()
    for d in CODE_DIRS:
        src = INSTALL_DIR / d
        if src.is_dir():
            shutil.copytree(src, dest / d, dirs_exist_ok=True)
    if VERSION_FILE.exists():
        shutil.copy(VERSION_FILE, dest / "VERSION")
    _prune_backups()
    return dest


def _prune_backups():
    if not BACKUP_DIR.is_dir():
        return
    olds = sorted([p for p in BACKUP_DIR.iterdir() if p.is_dir()])
    for p in olds[:-KEEP_BACKUPS]:
        shutil.rmtree(p, ignore_errors=True)


def list_backups() -> list:
    if not BACKUP_DIR.is_dir():
        return []
    return sorted(p.name for p in BACKUP_DIR.iterdir() if p.is_dir())


def _swap_in(src_root: pathlib.Path):
    for d in CODE_DIRS:
        s = src_root / d
        if not s.is_dir():
            continue
        target = INSTALL_DIR / d
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(s, target)


def restore(name: str = "") -> str:
    backups = list_backups()
    if not backups:
        return "no backup available"
    name = name or backups[-1]
    src = BACKUP_DIR / name
    if not src.is_dir():
        return f"backup {name} not found"
    _swap_in(src)
    v = src / "VERSION"
    if v.exists():
        shutil.copy(v, VERSION_FILE)
    return f"restored backup {name}"


def restart_services() -> str:
    if not shutil.which("systemctl"):
        return "systemctl not available (restart manually)"
    r = subprocess.run(["systemctl", "restart", "osprime-agent", "osprime-web"],
                       capture_output=True, text=True)
    return "services restarted" if r.returncode == 0 else f"restart failed: {r.stderr.strip()}"


def update(url: str = "", restart: bool = True, expect_sha: str = "",
           version: str = "") -> str:
    """Install an update. With no url, the manifest decides what to fetch.

    The checksum is not optional on the manifest path. This code downloads an
    archive and then runs it as the system's own brain, so an unverified
    package means whoever controls the URL controls the machine.
    """
    if not url:
        info = check()
        if not info.get("latest"):
            return f"no update available ({info.get('reason', 'up to date')})"
        if not info["available"]:
            return f"already on the latest version ({info['current']})"
        url = info["url"]
        expect_sha = expect_sha or info["sha256"]
        version = version or info["latest"]
        if not url:
            return "manifest is missing a download url"
        if not expect_sha:
            return "manifest has no sha256 — refusing to install an unverified package"

    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)
        archive = tmp / "src.tar.gz"
        try:
            if url.startswith(("http://", "https://")):
                urllib.request.urlretrieve(url, archive)
            else:                                  # local file (also used in tests)
                shutil.copy(url, archive)
        except Exception as e:
            return f"download failed: {e}"

        if expect_sha:
            got = _sha256(archive)
            if got.lower() != expect_sha.lower():
                return ("update rejected: checksum mismatch — nothing was changed.\n"
                        f"  expected {expect_sha}\n  got      {got}")

        extract = tmp / "x"
        extract.mkdir()
        try:
            shutil.unpack_archive(str(archive), str(extract))
        except Exception as e:
            return f"extract failed: {e}"

        root = _find_root(extract)
        if not (root / "agent" / "agent.py").is_file():
            return "invalid package: agent/agent.py missing"
        if not _compiles(root):
            return "update rejected: new code does not compile (nothing changed)"

        b = backup()
        try:
            _swap_in(root)
            # Record the version the manifest advertised, not the clock. Using
            # local time here left the installed version below the published
            # one, so check() reported an update available forever.
            new_v = version
            if not new_v and (root / "VERSION").is_file():
                new_v = (root / "VERSION").read_text(encoding="utf-8").strip()
            if not new_v:
                new_v = datetime.datetime.now().strftime("%Y.%m.%d-%H%M")
            VERSION_FILE.write_text(new_v, encoding="utf-8")
        except Exception as e:
            restore(b.name)
            return f"update failed ({e}) — rolled back to {b.name}"

    msg = f"updated to {current_version()} (backup: {b.name})"
    if restart:
        msg += " — " + restart_services()
    return msg


def status() -> dict:
    return {"version": current_version(), "install_dir": str(INSTALL_DIR),
            "backups": list_backups(), "manifest": MANIFEST_URL}
