"""Deep answers (docs/DEEP.md; Ehsan, 12 October).

A question that deserves more than the everyday model goes to a bigger one,
in the background: Qwen3.5-35B-A3B (Apache 2.0), a mixture-of-experts model.
It is 35B in total but only ~3B work for each word, so most of it can sit in
ordinary memory while the graphics card holds the rest — a 35B-class answer
on an 8 GB card and 16 GB of memory, at reading speed, with thinking on.

Why not AirLLM (reviewed 12 October): it streams a whole model from disk
for every word and needs PyTorch + CUDA. llama.cpp — already here — keeps a
compressed model in memory and splits it between the card and RAM.

Which file: the biggest one that fits this computer (`pick()`), from the
same repository, each pinned by sha256. While it thinks, the chat model
steps off the card (engines.card(), the one gate) and comes back after.
"""
import json
import os
import pathlib
import re
import shutil
import socket
import struct
import subprocess
import threading
import time
import urllib.request
import uuid

import images
import paths

REPO = "https://huggingface.co/unsloth/Qwen3.5-35B-A3B-GGUF/resolve/main/"
# Largest first. Sizes and sha256 from the repository, 12 October 2026.
CHOICES = [
    {"name": "Qwen3.5-35B-A3B-UD-Q4_K_XL.gguf", "size": 22241950336,
     "sha256": "1b0ac637dfa092bbba2793977db9485a40c4f8b42df5fe342f0076d61b66ae83"},
    {"name": "Qwen3.5-35B-A3B-UD-Q3_K_XL.gguf", "size": 16601176704,
     "sha256": "fef37f41877128b0c82195c5cd173ca0e02394f48c7667dbf96172fa300fc945"},
    {"name": "Qwen3.5-35B-A3B-UD-IQ3_S.gguf", "size": 13583383168,
     "sha256": "ca6e9542e9f9e34f28d59e1e335b3629825daf30a4c0b5c1ec9d2f898c061fb6"},
    {"name": "Qwen3.5-35B-A3B-UD-Q2_K_XL.gguf", "size": 12156754560,
     "sha256": "855b8d11f4b52e7ea4b9eeea2fbe3555c4d96d5b7b74702b6144810db3e77270"},
]
MIN_RAM_GB = 14.5           # "16 GB" machines report ~15.4
PORT = 8091                  # 8080 web, 8087 chat model, 8088/8089 vision/embed
CTX = 16384
MAX_TOKENS = 8192            # thinking included
SYSTEM = ("You are OSprime's deep-thinking model. Think the question through carefully, "
          "then give a complete, well-organised answer. Answer in the language of the question.")


def home() -> pathlib.Path:
    return paths.data_dir() / "deep"


def _hw():
    try:
        import hardware
        return hardware.profile()
    except Exception:
        return {}


def budget_gb(hw=None) -> float:
    """What a model file may weigh here: most of the card, about two thirds
    of the memory (the desktop, the browser and the page cache keep the rest)."""
    hw = hw or _hw()
    ram = float(hw.get("ram_gb") or 0)
    gpu = hw.get("gpu") or {}
    vram = float(gpu.get("vram_gb") or 0) if gpu.get("useful") else 0.0
    return ram * 0.65 + vram * 0.8


def pick(hw=None):
    """(choice, "") or (None, why)."""
    hw = hw or _hw()
    if float(hw.get("ram_gb") or 0) < MIN_RAM_GB:
        return None, ("deep answers need 16 GB of memory or more; with a cloud key, the cloud "
                      "model gives deep answers anywhere")
    b = budget_gb(hw) * 1e9
    for c in CHOICES:
        if c["size"] <= b:
            return c, ""
    return None, "this computer's memory is too small for the deep-answer model"


def installed():
    """The model file that is here, if any (whichever size was chosen)."""
    for c in CHOICES:
        p = home() / c["name"]
        if p.is_file():
            return c, p
    return None, None


def server_bin():
    for name in ("llama-server", "llama-cpp-server"):
        p = shutil.which(name)
        if p:
            return p
    return None


def ready() -> bool:
    return installed()[0] is not None and server_bin() is not None


# ---------------------------------------------------------------------------
# install / remove (as the person, into their own folder — no root)
# ---------------------------------------------------------------------------
def _state_file() -> pathlib.Path:
    return paths.data_dir() / "deep-install.json"


def install_state() -> dict:
    try:
        st = json.loads(_state_file().read_text())
    except Exception:
        return {}
    if st.get("running") and time.time() - st.get("at", 0) > 600:
        st["running"] = False
        st["message"] = "stopped — press Add again to carry on where it left off"
    return st


def _put_state(**kw):
    try:
        _state_file().parent.mkdir(parents=True, exist_ok=True)
        _state_file().write_text(json.dumps(dict(kw, at=time.time())))
    except Exception:
        pass


def install(progress=None) -> dict:
    c, why = pick()
    if c is None:
        return {"ok": False, "message": why}
    if server_bin() is None:
        return {"ok": False, "message": "the llama-server program is missing — update OSprime first"}
    home().mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(home()).free < c["size"] + 2_000_000_000:
        return {"ok": False, "message": f"not enough free disk space — it needs about {c['size'] // 10**9 + 2} GB"}
    try:
        images._download(REPO + c["name"], home() / c["name"], c["sha256"], c["size"], progress)
    except Exception as e:
        return {"ok": False, "message": f"could not finish: {e}"}
    for other in CHOICES:                      # one size at a time
        if other["name"] != c["name"]:
            try:
                (home() / other["name"]).unlink()
            except FileNotFoundError:
                pass
    return {"ok": True, "message": "Deep answers are ready on this computer."}


def start_install() -> dict:
    if install_state().get("running"):
        return {"ok": True, "message": "Already downloading."}
    c, why = pick()
    if c is None:
        return {"ok": False, "message": why[0].upper() + why[1:] + "."}
    have = home() / (c["name"] + ".part")

    def go():
        done = [have.stat().st_size if have.exists() else 0]
        aid = _activity("begin", "Downloading the deep-answer model")
        last = [0.0]

        def progress(n):
            done[0] += n
            if time.time() - last[0] > 2:
                last[0] = time.time()
                pct = min(99, int(done[0] * 100 / c["size"]))
                _put_state(running=True, percent=pct)
                _activity("update", aid, pct)
        _put_state(running=True, percent=int(done[0] * 100 / c["size"]))
        r = install(progress)
        _put_state(running=False, ok=r["ok"], message=r["message"], percent=100 if r["ok"] else None)
        _activity("end", aid, r["ok"])
    threading.Thread(target=go, daemon=True).start()
    return {"ok": True, "message": f"Downloading about {c['size'] / 1e9:.1f} GB. You can keep working."}


def remove() -> dict:
    if install_state().get("running"):
        return {"ok": False, "message": "Still downloading — wait for it to finish."}
    shutil.rmtree(home(), ignore_errors=True)
    try:
        _state_file().unlink()
    except FileNotFoundError:
        pass
    return {"ok": True, "message": "Deep answers removed from this computer."}


def _activity(what, *a):
    try:
        import activity
        if what == "begin":
            return activity.begin(a[0], "job")
        if a and a[0]:
            if what == "update":
                activity.update(a[0], a[1])
            else:
                activity.end(a[0], ok=a[1])
    except Exception:
        return None


# ---------------------------------------------------------------------------
# running the model: how much of it goes on the card
# ---------------------------------------------------------------------------
def block_count(path) -> int:
    """'<arch>.block_count' from the GGUF header (a few KB read)."""
    types = {0: 1, 1: 1, 2: 2, 3: 2, 4: 4, 5: 4, 6: 4, 7: 1, 10: 8, 11: 8, 12: 8}
    try:
        with open(path, "rb") as f:
            if f.read(4) != b"GGUF":
                return 0
            _ver, _nt, nkv = struct.unpack("<IQQ", f.read(20))

            def s():
                n = struct.unpack("<Q", f.read(8))[0]
                return f.read(n).decode("utf-8", "replace")

            def skip(t):
                if t == 8:
                    s()
                elif t == 9:
                    it, n = struct.unpack("<IQ", f.read(12))
                    for _ in range(n):
                        skip(it)
                else:
                    f.read(types[t])
            for _ in range(min(nkv, 10000)):
                k = s()
                t = struct.unpack("<I", f.read(4))[0]
                if k.endswith(".block_count") and t in (4, 5):
                    return struct.unpack("<I", f.read(4))[0]
                skip(t)
    except Exception:
        return 0
    return 0


def cpu_moe_layers(file_size: int, layers: int, vram_gb: float) -> int:
    """How many layers keep their experts in ordinary memory. About 9 in 10
    bytes of this model are experts; the rest, the context and the working
    space go on the card first, and as many layers' experts as then fit."""
    if layers <= 0:
        return 99
    if vram_gb <= 0:
        return layers
    other = file_size * 0.09 / 1e9
    room = vram_gb * 0.85 - other - 1.5          # 1.5 GB: context + compute buffers
    per_layer = file_size * 0.91 / 1e9 / layers
    on_card = max(0, min(layers, int(room / per_layer))) if room > 0 else 0
    return layers - on_card


def _help(bin_) -> str:
    try:
        return subprocess.run([bin_, "--help"], capture_output=True, text=True, timeout=20).stdout
    except Exception:
        return ""


def ladder(model: str, hw=None) -> list:
    """Ways to start, best first; the last always works (all in memory)."""
    hw = hw or _hw()
    gpu = hw.get("gpu") or {}
    vram = float(gpu.get("vram_gb") or 0) if gpu.get("useful") else 0.0
    bin_ = server_bin()
    h = _help(bin_)
    base = [bin_, "-m", model, "--host", "127.0.0.1", "--port", str(PORT), "-c", str(CTX)]
    if "--jinja" in h:
        base.append("--jinja")
    rungs = []
    if vram > 0 and ("--n-gpu-layers" in h or "-ngl" in h):
        n = cpu_moe_layers(os.path.getsize(model), block_count(model), vram)
        if "--n-cpu-moe" in h:
            rungs.append(base + ["-ngl", "99", "--n-cpu-moe", str(n)])
            rungs.append(base + ["-ngl", "99", "--n-cpu-moe", "99"])
        elif "--override-tensor" in h or "-ot" in h:
            rungs.append(base + ["-ngl", "99", "-ot", r"\.ffn_.*_exps\.=CPU"])
    rungs.append(base + ["-ngl", "0"])
    return rungs


def _healthy(timeout) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/health", timeout=3) as r:
                if r.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(1)
    return False


def _port_free() -> bool:
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", PORT)) != 0


def strip_thinking(text: str) -> str:
    text = re.sub(r"<think>.*?</think>", "", text or "", flags=re.S)
    return text.split("</think>")[-1].strip()


def _ask_server(question: str, context: str) -> str:
    msgs = [{"role": "system", "content": SYSTEM}]
    if context:
        msgs.append({"role": "user", "content": "Earlier in the conversation:\n" + context[:6000]})
        msgs.append({"role": "assistant", "content": "Understood."})
    msgs.append({"role": "user", "content": question})
    body = json.dumps({"messages": msgs, "max_tokens": MAX_TOKENS, "temperature": 0.6,
                       "top_p": 0.95, "stream": False}).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}/v1/chat/completions", data=body,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=3600) as r:
        j = json.loads(r.read().decode("utf-8", "replace"))
    msg = (j.get("choices") or [{}])[0].get("message") or {}
    out = strip_thinking(msg.get("content") or "")
    if not out:
        raise RuntimeError("the model thought for too long without answering — ask a narrower question")
    return out


def run_model(question: str, context: str = "", log=None) -> str:
    """Takes the card, starts the big model, asks, stops it, gives the card back."""
    c, model = installed()
    if c is None:
        raise RuntimeError("deep answers are not installed")
    if not _port_free():
        raise RuntimeError(f"port {PORT} is taken — another deep answer may be running")
    import engines
    with engines.card():
        was = engines._main_running()
        if was:
            engines.stop_main()
        proc = None
        try:
            for cmd in ladder(str(model)):
                logf = open(home() / "server.log", "w")
                proc = subprocess.Popen(cmd, stdout=logf, stderr=subprocess.STDOUT)
                if log:
                    log(" ".join(cmd[1:]))
                ok = False
                end = time.time() + 600                  # reading 13-22 GB from disk
                while time.time() < end:
                    if proc.poll() is not None:
                        break
                    if _healthy(2):
                        ok = True
                        break
                if ok:
                    break
                if proc.poll() is None:
                    proc.terminate()
                    proc.wait(30)
                proc = None
            if proc is None:
                raise RuntimeError("the deep-answer model could not start — see ~/.local/share/osprime/deep/server.log")
            return _ask_server(question, context)
        finally:
            if proc is not None and proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(30)
                except subprocess.TimeoutExpired:
                    proc.kill()
            if was:
                engines._bring_main_back()


# ---------------------------------------------------------------------------
# jobs: in the background, shown when ready (the same shape as videos)
# ---------------------------------------------------------------------------
_LOCK = threading.Lock()


def _jobs_file() -> pathlib.Path:
    return paths.data_dir() / "deep-jobs.json"


def jobs() -> list:
    try:
        return json.loads(_jobs_file().read_text())
    except Exception:
        return []


def _put_job(job: dict):
    with _LOCK:
        all_ = [j for j in jobs() if j["id"] != job["id"]][-19:] + [job]
        _jobs_file().parent.mkdir(parents=True, exist_ok=True)
        tmp = _jobs_file().with_suffix(f".{os.getpid()}.{threading.get_ident()}.tmp")
        tmp.write_text(json.dumps(all_, ensure_ascii=False))
        tmp.replace(_jobs_file())


def _announce(job: dict):
    try:
        import hashlib
        import watchers
        with watchers._locked():
            d = watchers._load()
            text = ("🧠 Deep answer ready: " + job["question"][:80] if job["status"] == "done"
                    else "🧠 The deep answer could not be made: " + job.get("error", ""))
            d["alerts"].append({"id": hashlib.sha1(job["id"].encode()).hexdigest()[:10], "wid": "",
                                "helper": job.get("helper") or "general", "text": text,
                                "answer": job.get("answer", ""), "at": int(time.time()), "seen": False})
            d["alerts"] = d["alerts"][-watchers.MAX_ALERTS:]
            watchers._save(d)
        import companion
        companion.attention(True)
    except Exception:
        pass


def _run(job, context, send):
    aid = _activity("begin", "Thinking deeply")
    try:
        job["answer"] = run_model(job["question"], context)
        job["status"] = "done"
    except Exception as e:
        job.update(status="failed", error=str(e)[:300])
    job["finished"] = int(time.time())
    _activity("end", aid, job["status"] == "done")
    _announce(job)
    if send and job["status"] == "done":
        try:
            send({"type": "deep", "job": job["id"], "text": job["answer"]})
        except Exception:
            pass
    _put_job(job)


# Said this way, it is a deep answer — not left to the everyday model to
# decide (12 October: "think deeply about…" was answered by the small model
# itself, and nothing showed which model had answered).
_TRIGGER = re.compile(
    r"^\s*(?:/deep\b|deep\s*:|deep answer\s*:?|think (?:deeply|hard|carefully|it through)(?: about| on)?\s*:?"
    r"|(?:لطفا\s*)?(?:عمیق|دقیق|خوب|با دقت|مفصل)\s*فکر\s*کن(?:\s*(?:درباره|در مورد)(?:[\s‌]*ی)?)?\s*:?)\s*",
    re.I)


def wanted(text: str) -> str:
    """The question, when the message asks for a deep answer; else ""."""
    m = _TRIGGER.match(text or "")
    if not m:
        return ""
    rest = (text[m.end():] or "").strip()
    return rest if len(rest) >= 3 else ""


def label() -> str:
    c, _p = installed()
    name = (c or {}).get("name", "Qwen3.5-35B-A3B")
    return "Deep answer · " + re.sub(r"-UD-.*|\.gguf$", "", name)


def ask(question: str, context: str = "", helper: str = "", send=None, wait=False) -> dict:
    question = (question or "").strip()[:4000]
    if len(question) < 5:
        return {"ok": False, "message": "Say the question to think about."}
    if not ready():
        c, why = pick()
        if c is None:
            return {"ok": False, "message": why[0].upper() + why[1:] + "."}
        return {"ok": False, "message": "Deep answers are not set up yet — Settings → Assistant → "
                                        "Deep answers → Add deep answers."}
    if any(j["status"] == "running" for j in jobs()):
        return {"ok": False, "message": "A deep answer is already being worked on — one at a time."}
    job = {"id": uuid.uuid4().hex[:10], "status": "running", "question": question, "answer": "",
           "label": label(),
           "error": "", "helper": helper or "general", "started": int(time.time()), "pid": os.getpid()}
    _put_job(job)
    if wait:
        _run(job, context, send)
        return {"ok": job["status"] == "done", "job": job, "message": job.get("error") or "done"}
    threading.Thread(target=_run, args=(job, context, send), daemon=True, name="deep-" + job["id"]).start()
    return {"ok": True, "job": job,
            "message": "Thinking it through with the big model. It takes a few minutes; the answer "
                       "appears in this chat when it is ready, and Brainy gets a dot. The everyday "
                       "model pauses meanwhile."}


def recover():
    """At agent start: a deep answer cut off by a restart is marked, not left 'running'."""
    for job in jobs():
        if job.get("status") == "running" and job.get("pid") != os.getpid():
            job.update(status="failed", finished=int(time.time()),
                       error="interrupted — the assistant or the computer restarted; ask again")
            _put_job(job)


def public_view() -> dict:
    hw = _hw()
    c, why = pick(hw)
    have, _p = installed()
    done = [j for j in jobs() if j["status"] == "done"]
    return {"ready": ready(), "can": c is not None, "why": why, "install": install_state(),
            "model": (have or c or {}).get("name", ""), "size_gb": round((c or have or {"size": 0})["size"] / 1e9, 1),
            "has_server": server_bin() is not None, "last": (done[-1]["question"][:80] if done else "")}
