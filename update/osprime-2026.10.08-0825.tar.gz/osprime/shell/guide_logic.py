"""The guide's contract with the model (docs/COMPANION.md, phase 4).

One model call per step: here is the goal, what has been done, a picture of
the screen and the numbered list of what can be clicked (guide_probe.py).
Name the ONE next thing to do and pick it by number. Everything the model
says is checked here before anything is drawn: a wrong pointer is worse than
none, so whatever fails becomes "I could not find it", never a strand.

Rules that are ours, not the model's (a prompt is not a safety boundary):
never point at a password, PIN or card field; say so when the click cannot
be undone; a box the model draws itself is used only when the list has
nothing, and is then called a best guess.
"""
import json
import re

import guide_probe as gp

MIN_CONF_ELEMENT = 0.3
MIN_CONF_BOX = 0.45
SURE = 0.6
MAX_BOX_AREA = 0.25
MAX_INSTRUCTION = 140
MAX_STEPS = 15

SYSTEM = (
    "You are a quiet on-screen guide built into the user's computer. The user "
    "said what they want to do. You get one picture of their screen and a "
    "numbered list of the things on it that can be clicked or typed into, with "
    "where they are.\n"
    "Your job: say the ONE next thing to do and point at exactly one item.\n"
    "Reply with JSON only, no other text:\n"
    '{"instruction": "<one short imperative sentence, at most 12 words, in the '
    "user's language>\", "
    '"target": {"id": <number from the list>} or {"box": [x, y, w, h], "label": '
    '"<text on it>"} or null, "confidence": 0..1, "done": true|false, '
    '"note": "<only when target is null>"}\n'
    "Rules:\n"
    "- Choose a number from the list whenever the thing is in it. A box (fractions "
    "of the screen, 0..1) only when it is clearly visible but not listed.\n"
    "- The user is walked through it one step at a time; after each step you get "
    "a new picture. Give the next concrete step while the goal needs more.\n"
    "- If the needed app is not open, say which to open, target null.\n"
    "- done is true when the goal is reached; then instruction is a short closing "
    "line and target is null.\n"
    "- Never point at a password, PIN or card number field.\n"
    "- Plain words. Never mention numbers from the list, coordinates, or the picture.")


def _clip(s, n):
    s = re.sub(r"\s+", " ", str(s or "")).strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def build_request(goal, history, window, listing):
    done = "\n".join(f"{i}. {_clip(h, 100)}" for i, h in enumerate(history, 1)) or "(none yet)"
    title = _clip((window or {}).get("title", ""), 100)
    app = _clip((window or {}).get("app", ""), 40)
    return "\n".join([
        "Goal: " + _clip(goal, 300),
        "Front window: " + (f"{title} ({app})" if title or app else "(unknown)"),
        "Steps already done:", done,
        "What can be clicked (id | type | name | x,y,w,h as fractions of the screen):",
        listing or "(nothing listed: use a box with the label you can read, or null)",
        "", "What is the one next step? JSON only."])


def parse_reply(raw):
    if raw is None:
        return None
    s = str(raw).strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s)
    a, b = s.find("{"), s.rfind("}")
    if a < 0 or b <= a:
        return None
    try:
        return json.loads(s[a:b + 1])
    except ValueError:
        return None


def validate(reply, cands, screen_w, screen_h):
    """-> {"ok", "why", "instruction", "rect" (screen px) or None, "guess",
    "done", "note", "irreversible"}"""
    out = {"ok": False, "why": "", "instruction": "", "rect": None, "guess": False,
           "done": False, "note": "", "irreversible": False}
    if not isinstance(reply, dict):
        out["why"] = "the model did not answer in the agreed form"
        return out
    out["instruction"] = _clip(reply.get("instruction"), MAX_INSTRUCTION)
    out["done"] = reply.get("done") is True
    out["note"] = _clip(reply.get("note"), 200)
    try:
        conf = max(0.0, min(1.0, float(reply.get("confidence") or 0)))
    except (TypeError, ValueError):
        conf = 0.0
    if not out["instruction"]:
        out["why"] = "no instruction"
        return out
    t = reply.get("target")
    if t is None or out["done"]:
        out["ok"] = True
        out["why"] = "done" if out["done"] else (out["note"] or "nothing to point at")
        return out
    if not isinstance(t, dict):
        out["why"] = "bad target"
        return out
    name = ""
    if "id" in t:
        try:
            el = next(e for e in cands if e["id"] == int(t["id"]))
        except (StopIteration, TypeError, ValueError):
            out["why"] = f"no item {t.get('id')!r} in the list"
            return out
        if conf < MIN_CONF_ELEMENT:
            out["why"] = "not sure enough"
            return out
        if el.get("sensitive"):
            out["why"] = "that is a password or card field; I do not point at those"
            out["instruction"] = ""
            return out
        out["rect"] = tuple(el["box"])
        out["guess"] = conf < SURE
        name = el.get("name", "")
    elif "box" in t:
        try:
            x, y, w, h = (float(v) for v in t["box"])
        except (TypeError, ValueError):
            out["why"] = "bad box"
            return out
        # a hair past the edge is rounding, not a miss
        if -0.05 <= x < 0:
            w, x = w + x, 0.0
        if -0.05 <= y < 0:
            h, y = h + y, 0.0
        w, h = min(w, 1 - x), min(h, 1 - y)
        if x < 0 or y < 0 or w <= 0 or h <= 0 or x > 1 or y > 1:
            out["why"] = "box off the screen"
            return out
        if w * h > MAX_BOX_AREA:
            out["why"] = "box too big to be one control"
            return out
        if conf < MIN_CONF_BOX:
            out["why"] = "not sure enough"
            return out
        name = _clip(t.get("label"), 80)
        if gp.SENSITIVE_WORDS.search(name):
            out["why"] = "that is a password or card field; I do not point at those"
            out["instruction"] = ""
            return out
        out["rect"] = (x * screen_w, y * screen_h, w * screen_w, h * screen_h)
        out["guess"] = True            # not checked against anything
    else:
        out["why"] = "unknown target"
        return out
    if gp.IRREVERSIBLE.search(name) or gp.IRREVERSIBLE.search(out["instruction"]):
        out["irreversible"] = True
    out["ok"] = True
    out["why"] = "pointing"
    return out
