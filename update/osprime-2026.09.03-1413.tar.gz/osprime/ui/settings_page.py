"""The Settings window.

Kept separate from web.py only so neither file becomes unreadable; it is
served by the same process on the same port.

Every control here goes through agent/system_tools.py — the same functions
the assistant calls. There is deliberately no second path to the same
setting: when a product grows two ways to change one value, they drift, and
the user ends up with an interface that disagrees with itself.
"""

PAGE = r"""<!DOCTYPE html>
<html lang="{{LANG}}" dir="{{DIR}}">
<meta charset="utf-8">
<title>Settings — OSprime</title>
<style>
  :root { --bg:#0d1117; --panel:#161b22; --line:#21262d; --text:#e6edf3;
          --dim:#8b949e; --accent:#2d6cdf; --ok:#2ea043; --warn:#d29922; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--text); height:100vh;
         display:flex; flex-direction:column;
         font-family:system-ui,'Noto Sans','Noto Sans Arabic',sans-serif; }
  header { padding:14px 22px; background:var(--panel);
           border-bottom:1px solid var(--line); display:flex;
           align-items:center; gap:10px; }
  header .logo { font-size:18px; font-weight:700; color:var(--accent); }
  header .sub { color:var(--dim); font-size:13px; }
  main { flex:1; overflow-y:auto; padding:22px; max-width:760px; width:100%;
         margin:0 auto; }
  section { background:var(--panel); border:1px solid var(--line);
            border-radius:12px; padding:16px 20px; margin-bottom:16px; }
  h2 { font-size:15px; font-weight:600; margin:0 0 14px; }
  .row { display:flex; align-items:center; gap:12px; padding:9px 0;
         border-top:1px solid var(--line); }
  .row:first-of-type { border-top:0; }
  .row label { flex:1; font-size:14px; }
  .row .hint { display:block; color:var(--dim); font-size:12px; margin-top:2px; }
  input, select { background:#0d1117; color:var(--text);
                  border:1px solid var(--line); border-radius:7px;
                  padding:7px 10px; font-size:13px; min-width:190px;
                  font-family:inherit; }
  button { background:var(--accent); color:#fff; border:0; border-radius:7px;
           padding:7px 16px; font-size:13px; cursor:pointer;
           font-family:inherit; }
  button.ghost { background:transparent; border:1px solid var(--line);
                 color:var(--text); }
  button:disabled { opacity:.5; cursor:default; }
  #note { position:fixed; left:50%; transform:translateX(-50%); bottom:22px;
          background:var(--panel); border:1px solid var(--line);
          border-radius:9px; padding:10px 18px; font-size:13px;
          display:none; }
  .nets { margin-top:10px; display:flex; flex-direction:column; gap:6px; }
  .net { display:flex; align-items:center; gap:10px; padding:8px 10px;
         border:1px solid var(--line); border-radius:8px; font-size:13px;
         cursor:pointer; }
  .net:hover { border-color:var(--accent); }
  .net .sig { color:var(--dim); font-size:12px; margin-left:auto; }
</style>
<header>
  <span class="logo">Settings</span>
  <span class="sub">OSprime v{{VERSION}}</span>
  <button class="ghost" style="margin-left:auto" onclick="location.href='/'">Back to chat</button>
</header>

<main>
  <section id="display">
    <h2>Display</h2>
    <div class="row">
      <label>Size of everything
        <span class="hint">A 1920×1080 screen on a 14-inch laptop is very
        small at 100%. This keeps text sharp, unlike lowering the resolution.</span></label>
      <select id="scale">
        <option value="1">100%</option>
        <option value="1.25">125%</option>
        <option value="1.5">150%</option>
        <option value="1.75">175%</option>
        <option value="2">200%</option>
      </select>
    </div>
    <div class="row">
      <label>Resolution</label>
      <select id="resolution"><option value="">detecting…</option></select>
    </div>
  </section>

  <section id="appearance">
    <h2>Appearance</h2>
    <div class="row">
      <label>Background
        <span class="hint">Solid colour. Images are not supported yet.</span></label>
      <select id="wallpaper">
        <option value="#12232E">Petrol blue</option>
        <option value="#D9CFBC">Beige</option>
        <option value="#101A2E">Navy</option>
        <option value="#2B2E33">Grey</option>
        <option value="#0B0B0B">Black</option>
      </select>
    </div>
    <div class="row">
      <label>Language
        <span class="hint">Reopen a window to see the change.</span></label>
      <select id="language">
        <option value="en">English</option>
        <option value="fa">فارسی</option>
      </select>
    </div>
  </section>

  <section>
    <h2>Date and time</h2>
    <div class="row">
      <label>Set automatically
        <span class="hint">Needs a network connection.</span></label>
      <input type="checkbox" id="autotime" style="min-width:auto;width:18px;height:18px">
    </div>
    <div class="row">
      <label>Time zone</label>
      <input id="timezone" placeholder="Europe/Berlin">
    </div>
    <div class="row">
      <label>Set manually
        <span class="hint">YYYY-MM-DD HH:MM</span></label>
      <input id="clock" placeholder="2026-08-30 14:30">
    </div>
  </section>

  <section>
    <h2>Network</h2>
    <div class="row">
      <label id="netstate">Checking…</label>
      <button class="ghost" id="scan">Scan for networks</button>
    </div>
    <div class="nets" id="nets"></div>
    <div class="row" style="margin-top:6px">
      <label>Hidden network
        <span class="hint">For a network that does not broadcast its name.</span></label>
      <input id="hidden" placeholder="network name">
      <button class="ghost" id="joinhidden">Join</button>
    </div>
  </section>

  <section>
    <h2>Sound</h2>
    <div class="row">
      <label>Volume</label>
      <input type="range" id="volume" min="0" max="100" step="1" style="min-width:220px">
      <span id="volval" class="sub" style="color:var(--dim);font-size:13px">—</span>
    </div>
  </section>

  <section>
    <h2>Cloud model</h2>
    <div class="row">
      <label>Use a cloud model
        <span class="hint">Optional. OSprime works fully without it.
        Your key stays on this machine.</span></label>
      <select id="cloudmode">
        <option value="off">Never</option>
        <option value="ask">Only when I ask</option>
        <option value="auto">When the local model cannot cope</option>
      </select>
    </div>
    <div class="row">
      <label>API key</label>
      <input id="apikey" type="password" placeholder="not set">
    </div>
  </section>

  <section>
    <h2>About</h2>
    <div class="row">
      <label>Version <span class="hint" id="verline">v{{VERSION}}</span></label>
      <button id="updbtn">Check for updates</button>
    </div>
  </section>
</main>

<div id="note"></div>

<script>
const $ = id => document.getElementById(id);
let saving = false;

function note(msg, ms = 2600) {
  const n = $("note");
  n.textContent = msg; n.style.display = "block";
  clearTimeout(n._t); n._t = setTimeout(() => n.style.display = "none", ms);
}

async function apply(key, value) {
  if (saving) return;
  saving = true;
  try {
    const r = await (await fetch("/api/settings", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({key, value})
    })).json();
    note(r.message || (r.ok ? "Saved" : "Could not save"));
  } catch (e) { note("Could not save: " + e); }
  saving = false;
}

async function load() {
  let s;
  try { s = await (await fetch("/api/settings")).json(); }
  catch (e) { return note("Could not read settings"); }
  if (s.wallpaper) $("wallpaper").value = s.wallpaper;
  if (s.language)  $("language").value  = s.language;
  if (s.timezone)  $("timezone").value  = s.timezone;
  $("autotime").checked = !!s.auto_time;
  if (s.volume !== undefined && s.volume !== null) {
    $("volume").value = s.volume; $("volval").textContent = s.volume + "%";
  }
  $("cloudmode").value = s.cloud_mode || "off";
  if (s.has_api_key) $("apikey").placeholder = "key is set";
  $("netstate").textContent = s.network || "Not connected";
}

async function loadDisplay() {
  let d;
  try { d = await (await fetch("/api/display")).json(); } catch (e) { return; }
  const screen = (d.screens || [])[0];
  if (!screen) { $("resolution").innerHTML = "<option>not available</option>"; return; }
  $("resolution").innerHTML = "";
  (screen.modes || []).forEach(m => {
    const o = document.createElement("option");
    o.value = m; o.textContent = m;
    if (m === screen.current) o.selected = true;
    $("resolution").appendChild(o);
  });
  const sc = parseFloat(screen.scale || "1");
  if (!isNaN(sc)) {
    const opt = [...$("scale").options].find(o => parseFloat(o.value) === sc);
    if (opt) opt.selected = true;
  }
}

$("scale").onchange      = e => apply("scale", e.target.value);
$("resolution").onchange = e => apply("resolution", e.target.value);
$("wallpaper").onchange = e => apply("wallpaper", e.target.value);
$("language").onchange  = e => apply("language", e.target.value);
$("timezone").onchange  = e => apply("timezone", e.target.value.trim());
$("autotime").onchange  = e => apply("auto_time", e.target.checked);
$("clock").onchange     = e => apply("time", e.target.value.trim());
$("cloudmode").onchange = e => apply("cloud_mode", e.target.value);
$("apikey").onchange    = e => { apply("api_key", e.target.value); e.target.value = ""; };
$("volume").oninput     = e => $("volval").textContent = e.target.value + "%";
$("volume").onchange    = e => apply("volume", parseInt(e.target.value, 10));

async function joinNetwork(ssid, password, row) {
  note("Connecting to " + ssid + "…", 20000);
  let r;
  try {
    r = await (await fetch("/api/wifi/connect", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ssid, password: password || ""})
    })).json();
  } catch (e) { r = {ok: false, message: "" + e}; }
  note(r.message || (r.ok ? "Connected" : "Could not connect"), 6000);
  if (r.ok) { if (row) row.remove(); load(); $("scan").click(); }
  return r.ok;
}

// Asking for the password inline rather than through a browser prompt():
// prompt() is blocked or suppressed in an app window, which left clicking a
// secured network doing nothing at all with no way to tell why.
function askPassword(el, ssid) {
  if (el.querySelector("input")) return;
  const box = document.createElement("div");
  box.style.cssText = "display:flex;gap:8px;margin-top:8px;width:100%";
  const inp = document.createElement("input");
  inp.type = "password"; inp.placeholder = "Password for " + ssid;
  inp.style.flex = "1";
  const go = document.createElement("button");
  go.textContent = "Join";
  const submit = async () => {
    if (!inp.value) { inp.focus(); return; }
    go.disabled = true; go.textContent = "…";
    const ok = await joinNetwork(ssid, inp.value, null);
    if (!ok) { go.disabled = false; go.textContent = "Join"; inp.select(); }
  };
  go.onclick = submit;
  inp.onkeydown = e => { if (e.key === "Enter") submit(); };
  box.append(inp, go);
  el.appendChild(box);
  inp.focus();
}

$("scan").onclick = async () => {
  $("scan").disabled = true; $("scan").textContent = "Scanning…";
  const box = $("nets"); box.innerHTML = "";
  try {
    const nets = await (await fetch("/api/wifi/scan")).json();
    (nets.networks || []).forEach(n => {
      const el = document.createElement("div");
      el.className = "net";
      el.style.flexWrap = "wrap";
      const tags = [];
      if (n.active) tags.push("connected");
      else if (n.saved) tags.push("saved");
      if (n.secured) tags.push("locked");
      el.innerHTML = "<span>" + n.ssid + "</span>" +
        "<span class='sig'>" + tags.join(" · ") + "</span>" +
        "<span class='sig'>" + (n.signal || "") + "%</span>";
      el.onclick = () => {
        if (n.active) return;
        // A saved network already has its password stored.
        if (!n.secured || n.saved) joinNetwork(n.ssid, "", null);
        else askPassword(el, n.ssid);
      };
      box.appendChild(el);
    });
    if (!(nets.networks || []).length) note(nets.message || "No networks found", 6000);
  } catch (e) { note("Scan failed: " + e); }
  $("scan").disabled = false; $("scan").textContent = "Scan for networks";
};

$("joinhidden").onclick = () => {
  const ssid = $("hidden").value.trim();
  if (!ssid) return;
  askPassword($("joinhidden").parentElement, ssid);
};

$("updbtn").onclick = async () => {
  const b = $("updbtn");
  b.disabled = true; b.textContent = "Checking…";
  let info;
  try { info = await (await fetch("/api/update/check")).json(); }
  catch (e) { note("Could not reach the update server"); b.disabled = false;
              b.textContent = "Check for updates"; return; }
  if (!info.available) {
    note(info.reason ? "Could not reach the update server" : "Already up to date");
    b.disabled = false; b.textContent = "Check for updates"; return;
  }
  b.textContent = "Install " + info.latest;
  b.disabled = false;
  b.onclick = async () => {
    b.disabled = true; b.textContent = "Installing…";
    const r = await (await fetch("/api/update/install", {method: "POST"})).json();
    note(r.message || "Done", 6000);
    if (r.ok) setTimeout(() => location.reload(), 2000);
    else { b.disabled = false; b.textContent = "Retry"; }
  };
};

load();
loadDisplay();

// Opened from the desktop menu as /settings#display or #appearance: bring
// that section into view rather than making the user hunt for it.
if (location.hash) {
  const el = document.querySelector(location.hash);
  if (el) setTimeout(() => el.scrollIntoView({behavior: "smooth", block: "start"}), 150);
}
</script>
</html>
"""
