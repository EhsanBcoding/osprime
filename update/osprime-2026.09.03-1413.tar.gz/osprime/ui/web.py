#!/usr/bin/env python3
"""OSprime web UI: stdlib-only HTTP server that serves an RTL chat page
and bridges it to the agent daemon's Unix socket.

Run:  python3 ui/web.py   →  open http://localhost:8080
"""

import http.server
import json
import os
import pathlib
import socket
import sys
import threading

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "agent"))
import i18n
import settings_page
import system_tools
import updater
import voice


SECRETS_PATH = pathlib.Path(os.environ.get("OSPRIME_SECRETS",
                                           "/etc/osprime/secrets.env"))


def _plain(msg: str) -> str:
    """Strip the ERROR: marker before showing a message to a person.

    The prefix exists so the assistant cannot mistake a failure for a
    success. It means nothing to the user reading a settings window.
    """
    return msg[6:].strip() if msg.startswith("ERROR:") else msg


def _read_settings() -> dict:
    """One read, from the same place the assistant reads."""
    out = json.loads(system_tools.get_settings())
    t = system_tools.get_time()
    try:
        out["auto_time"] = json.loads(t).get("auto_sync", False)
    except json.JSONDecodeError:
        out["auto_time"] = False
    net = system_tools.network_status()
    try:
        out["network"] = ", ".join(n["name"] for n in json.loads(net))
    except json.JSONDecodeError:
        out["network"] = net
    out["has_api_key"] = "ANTHROPIC_API_KEY" in _read_secrets()
    return out


def _read_secrets() -> dict:
    out = {}
    try:
        for line in SECRETS_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except Exception:
        pass
    return out


def _apply_setting(key: str, value) -> dict:
    """Every branch calls the same function the assistant would call, so the
    two interfaces cannot disagree about what a setting means."""
    try:
        if key == "wallpaper":
            msg = system_tools.set_wallpaper(str(value))
        elif key == "language":
            msg = system_tools.set_language(str(value))
        elif key == "timezone":
            msg = system_tools.set_timezone(str(value))
        elif key == "time":
            msg = system_tools.set_time(str(value))
        elif key == "auto_time":
            msg = system_tools.set_auto_time(bool(value))
        elif key == "volume":
            msg = system_tools.set_volume(value)
        elif key == "scale":
            msg = system_tools.set_display(scale=str(value))
        elif key == "resolution":
            msg = system_tools.set_display(resolution=str(value))
        elif key == "cloud_mode":
            if str(value) not in ("off", "ask", "auto"):
                return {"ok": False, "message": "unknown cloud mode"}
            system_tools._write_env("OSPRIME_CLOUD_MODE", str(value))
            msg = "cloud mode saved — restart the assistant to apply"
        elif key == "api_key":
            v = str(value or "").strip()
            if not v:
                return {"ok": False, "message": "no key given"}
            SECRETS_PATH.parent.mkdir(parents=True, exist_ok=True)
            lines = [l for l in (SECRETS_PATH.read_text(encoding="utf-8").splitlines()
                                 if SECRETS_PATH.exists() else [])
                     if not l.startswith("ANTHROPIC_API_KEY=")]
            lines.append(f"ANTHROPIC_API_KEY={v}")
            SECRETS_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
            SECRETS_PATH.chmod(0o600)
            msg = "key saved on this machine"
        else:
            return {"ok": False, "message": f"unknown setting: {key}"}
    except Exception as e:
        return {"ok": False, "message": str(e)}

    # system_tools marks every failure with an ERROR: prefix, which replaces
    # the previous guesswork of matching phrases inside the message.
    return {"ok": not msg.startswith("ERROR:"), "message": _plain(msg)}


def _version() -> str:
    for p in (pathlib.Path(__file__).resolve().parent.parent / "VERSION",
              pathlib.Path("/opt/osprime/VERSION")):
        try:
            return p.read_text(encoding="utf-8").strip()
        except Exception:
            continue
    return "dev"

SOCKET_PATH = os.environ.get("OSPRIME_SOCKET", "/run/osprime/agent.sock")
PROFILE_PATH = pathlib.Path(os.environ.get("OSPRIME_PROFILE", "/etc/osprime/profile.json"))
PORT = int(os.environ.get("OSPRIME_WEB_PORT", "8080"))

_sessions = {}
_lock = threading.Lock()


def get_session(sid: str):
    """One persistent daemon connection per browser session (keeps history)."""
    with _lock:
        if sid not in _sessions:
            sk = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sk.connect(SOCKET_PATH)
            _sessions[sid] = {"f": sk.makefile("rwb"), "lock": threading.Lock()}
        return _sessions[sid]


def session_send(sess, obj):
    with sess["lock"]:
        sess["f"].write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
        sess["f"].flush()


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/":
            # Locale is resolved per request, so changing it in settings takes
            # effect on reload instead of needing a service restart.
            code = i18n.lang()
            # The version is shown in the header on purpose: a stale service
            # left running from an older install is otherwise indistinguishable
            # from a fresh one, and costs an hour of chasing the wrong build.
            data = (PAGE.replace("{{LANG}}", code)
                        .replace("{{DIR}}", "rtl" if i18n.is_rtl(code) else "ltr")
                        .replace("{{VERSION}}", _version())).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif self.path == "/settings":
            code = i18n.lang()
            data = (settings_page.PAGE.replace("{{LANG}}", code)
                    .replace("{{DIR}}", "rtl" if i18n.is_rtl(code) else "ltr")
                    .replace("{{VERSION}}", _version())).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif self.path == "/api/settings":
            self._json(_read_settings())
        elif self.path == "/api/display":
            raw = system_tools.get_display()
            try:
                self._json({"screens": json.loads(raw)})
            except json.JSONDecodeError:
                self._json({"screens": [], "message": _plain(raw)})
        elif self.path == "/api/wifi/scan":
            raw = system_tools.list_wifi()
            try:
                self._json({"networks": json.loads(raw)})
            except json.JSONDecodeError:
                self._json({"networks": [], "message": _plain(raw)})
        elif self.path == "/api/profile":
            self._json({"exists": PROFILE_PATH.exists()})
        elif self.path == "/api/update/check":
            # Deliberately not routed through the assistant. Asked to install an
            # update the model invented `sudo /path/to/update/install.sh`, and
            # the fix for that behaviour lives inside the update it refuses to
            # install. Keeping a system's own update path behind a 1.5B model's
            # tool choice is a design error; this is the way out of it.
            self._json(updater.check())
        elif self.path == "/api/voice/status":
            self._json(voice.status())
        elif self.path == "/api/notifications":
            try:
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.connect(SOCKET_PATH)
                sf = s.makefile("rwb")
                sf.write(b'{"type": "poll_notifications"}\n'); sf.flush()
                resp = json.loads(sf.readline())
                s.close()
                self._json(resp)
            except Exception as e:
                self._json({"items": [], "error": str(e)})
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length)

        if self.path == "/api/stt":
            suffix = "." + (self.headers.get("X-Audio-Ext") or "webm").lstrip(".")
            lang = self.headers.get("X-Audio-Lang") or "auto"
            try:
                text = voice.transcribe(raw, suffix, lang)
            except Exception as e:
                text = f"ERROR: {e}"
            if text.startswith("ERROR:"):
                self._json({"ok": False, "error": text[6:].strip()})
            else:
                self._json({"ok": True, "text": text})
            return

        if self.path == "/api/tts":
            try:
                payload = json.loads(raw)
                wav = voice.synthesize(payload.get("text", ""))
            except Exception:
                wav = b""
            if not wav:
                self.send_response(503)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(wav)))
            self.end_headers()
            self.wfile.write(wav)
            return

        # Tolerate an empty body. Endpoints that take no arguments were
        # failing here before reaching their handler, because this parsed
        # every remaining POST as JSON unconditionally.
        try:
            body = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            body = {}

        if self.path == "/api/confirm":
            try:
                sess = get_session(body["session"])
                session_send(sess, {"type": "confirm_response",
                                    "id": body["id"], "approved": bool(body["approved"])})
                self._json({"ok": True})
            except Exception as e:
                self._json({"ok": False, "error": str(e)})
            return
        if self.path == "/api/settings":
            self._json(_apply_setting(body.get("key", ""), body.get("value")))
            return

        if self.path == "/api/wifi/connect":
            msg = system_tools.connect_wifi(body.get("ssid", ""),
                                            body.get("password", ""))
            self._json({"ok": not msg.startswith("ERROR:"),
                        "message": _plain(msg)})
            return

        if self.path == "/api/wifi/forget":
            msg = system_tools.forget_wifi(body.get("ssid", ""))
            self._json({"ok": not msg.startswith("ERROR:"),
                        "message": _plain(msg)})
            return

        if self.path == "/api/update/install":
            # restart=False deliberately. Restarting the services is part of an
            # update, but osprime-web is one of them — doing it inline kills
            # this very connection before the reply is written, and the browser
            # reports "Failed to fetch" for an update that actually succeeded.
            try:
                result = updater.update(restart=False)
                ok = result.startswith("updated to")
            except Exception as e:
                result, ok = f"update failed: {e}", False
            self._json({"ok": ok, "message": result,
                        "version": updater.current_version()})
            if ok:
                # Answer first, restart a moment later.
                threading.Timer(1.0, updater.restart_services).start()
            return

        if self.path == "/api/onboard":
            PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
            PROFILE_PATH.write_text(
                json.dumps(body, ensure_ascii=False, indent=2), encoding="utf-8")
            self._json({"ok": True})
        elif self.path == "/api/chat":
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.end_headers()

            def emit(obj):
                self.wfile.write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
                self.wfile.flush()

            try:
                sess = get_session(body["session"])
                f = sess["f"]
                session_send(sess, {"type": "user_message", "text": body["text"]})
                for line in f:
                    msg = json.loads(line)
                    emit(msg)
                    if msg.get("type") in ("assistant", "error"):
                        return
                emit({"type": "error", "text": "Lost connection to the agent"})
            except BrokenPipeError:
                pass
            except Exception as e:
                try:
                    emit({"type": "error", "text": str(e)})
                except Exception:
                    pass
        else:
            self._json({"error": "not found"}, 404)


PAGE = r"""<!DOCTYPE html>
<html lang="{{LANG}}" dir="{{DIR}}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OSprime</title>
<style>
  :root { --bg:#0d1117; --panel:#161b22; --accent:#58a6ff; --text:#e6edf3; --dim:#8b949e; }
  * { box-sizing:border-box; margin:0; }
  body { background:var(--bg); color:var(--text); height:100vh; display:flex; flex-direction:column;
         font-family:"Segoe UI", Vazirmatn, Tahoma, sans-serif; }
  header { padding:14px 22px; background:var(--panel); border-bottom:1px solid #21262d;
           display:flex; align-items:center; gap:10px; }
  header .logo { font-size:20px; font-weight:700; color:var(--accent); }
  header .sub { color:var(--dim); font-size:13px; }
  #chat { flex:1; overflow-y:auto; padding:20px; display:flex; flex-direction:column; gap:10px; }
  .msg { max-width:75%; padding:10px 14px; border-radius:14px; line-height:1.9; white-space:pre-wrap; }
  .user { background:#1f6feb; align-self:flex-start; border-bottom-right-radius:4px; }
  .bot  { background:var(--panel); align-self:flex-end; border-bottom-left-radius:4px; border:1px solid #21262d; }
  .tool { align-self:flex-end; color:var(--dim); font-size:12px; direction:ltr; text-align:left;
          background:#161b2280; border:1px dashed #30363d; border-radius:8px; padding:4px 10px;
          font-family:Consolas, monospace; }
  .badge { font-size:11px; color:var(--dim); margin-top:4px; }
  form { display:flex; gap:10px; padding:14px 20px; background:var(--panel); border-top:1px solid #21262d; }
  input { flex:1; background:var(--bg); color:var(--text); border:1px solid #30363d; border-radius:10px;
          padding:12px 16px; font-size:15px; font-family:inherit; outline:none; }
  input:focus { border-color:var(--accent); }
  button { background:var(--accent); color:#0d1117; border:0; border-radius:10px; padding:0 22px;
           font-size:15px; font-weight:700; cursor:pointer; font-family:inherit; }
  button:disabled { opacity:.5; }
  .typing { color:var(--dim); align-self:flex-end; font-size:13px; }
  .confirm { align-self:flex-end; background:#2d1a1a; border:1px solid #a14; border-radius:12px;
             padding:12px 14px; max-width:75%; }
  .confirm .q { color:#ffb3b3; margin-bottom:6px; }
  .confirm .cmd { direction:ltr; text-align:left; font-family:Consolas,monospace; font-size:13px;
                  background:#0d1117; border-radius:6px; padding:6px 10px; margin-bottom:10px;
                  white-space:pre-wrap; word-break:break-all; }
  .confirm .btns { display:flex; gap:8px; }
  .confirm button { padding:6px 16px; border-radius:8px; border:0; cursor:pointer; font-family:inherit; font-weight:700; }
  .confirm .yes { background:#238636; color:#fff; }
  .confirm .no  { background:#30363d; color:var(--text); }
  .iconbtn { background:var(--bg); color:var(--text); border:1px solid #30363d; border-radius:10px;
             padding:0 14px; font-size:18px; cursor:pointer; }
  .iconbtn.on { background:#a12d2d; border-color:#e05555; animation:pulse 1.2s infinite; }
  .iconbtn.speak-on { background:var(--accent); color:#0d1117; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.55} }
</style>
</head>
<body>
<header><span class="logo">OSprime</span><span class="sub">the operating system that thinks &nbsp;·&nbsp; v{{VERSION}}</span>
<a href="/settings" style="margin-left:auto;color:#8b949e;font-size:13px;text-decoration:none">Settings</a>
<span id="upd" style="display:none;margin-left:14px;font-size:13px;align-items:center;gap:10px">
<span id="updtxt"></span>
<button type="button" id="updbtn" style="border:0;border-radius:6px;padding:5px 14px;background:#2d6cdf;color:#fff;cursor:pointer;font-size:13px">Install</button>
</span></header>
<div id="chat"></div>
<form id="f">
<button type="button" id="mic" class="iconbtn" title="Record voice" style="display:none">🎤</button>
<button type="button" id="spk" class="iconbtn" title="Read answers aloud" style="display:none">🔈</button>
<input id="inp" autocomplete="off" placeholder="Ask your computer anything..." autofocus>
<button id="btn">Send</button></form>
<script>
const chat = document.getElementById("chat"), inp = document.getElementById("inp"),
      btn = document.getElementById("btn"), sid = crypto.randomUUID();
let onboarding = null;
const OB_QUESTIONS = [
  ["name", "What's your name?"],
  ["language", "Preferred language? (en/fa)"],
  ["skill", "Technical level? (beginner/intermediate/expert)"],
  ["usage", "What do you mostly use this computer for?"],
  ["autonomy", "Ask permission before changing the system? (yes/no)"],
];

function add(cls, text) {
  const d = document.createElement("div");
  d.className = "msg " + cls; d.textContent = text;
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight; return d;
}
function addTool(e) {
  const d = document.createElement("div");
  d.className = "tool"; d.textContent = "⚙ " + e.name + ": " + e.detail;
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight;
}

async function init() {
  const r = await fetch("/api/profile").then(r => r.json());
  if (!r.exists) {
    onboarding = { step: 0, answers: {} };
    add("bot", "Hello! I'm OSprime — your operating system.\nA few quick questions so I know you.");
    add("bot", OB_QUESTIONS[0][1]);
  } else {
    add("bot", "Hi — ask your computer anything.");
  }
}

async function send(text) {
  add("user", text);
  if (onboarding) {
    onboarding.answers[OB_QUESTIONS[onboarding.step][0]] = text;
    onboarding.step++;
    if (onboarding.step < OB_QUESTIONS.length) {
      add("bot", OB_QUESTIONS[onboarding.step][1]);
    } else {
      await fetch("/api/onboard", { method: "POST", body: JSON.stringify(onboarding.answers) });
      add("bot", "Thanks " + (onboarding.answers.name || "") + "! I'm at your service now.");
      onboarding = null;
    }
    return;
  }
  btn.disabled = true;
  let t = add("typing", "Thinking..."), bubble = null;
  const clearT = () => { if (t) { t.remove(); t = null; } };
  try {
    const resp = await fetch("/api/chat", { method: "POST",
      body: JSON.stringify({ session: sid, text }) });
    const reader = resp.body.getReader(), dec = new TextDecoder();
    let buf = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line) continue;
        const m = JSON.parse(line);
        if (m.type === "delta") {
          clearT();
          if (!bubble) bubble = add("bot", "");
          bubble.textContent += m.text;
          chat.scrollTop = chat.scrollHeight;
        } else if (m.type === "tool_use") {
          clearT(); addTool(m); bubble = null;
        } else if (m.type === "assistant") {
          clearT();
          if (!bubble) bubble = add("bot", m.text);
          const b = document.createElement("div"); b.className = "badge";
          b.textContent = m.backend === "claude" ? "\u2601 Claude" : "\u2302 Local model";
          bubble.appendChild(b);
          speak(m.text);
        } else if (m.type === "confirm") {
          clearT(); bubble = null; renderConfirm(m);
        } else if (m.type === "error") {
          clearT(); add("bot", "⚠ " + m.text);
        }
      }
    }
  } catch (e) { clearT(); add("bot", "\u26a0 Connection error: " + e); }
  btn.disabled = false; inp.focus();
}

document.getElementById("f").addEventListener("submit", ev => {
  ev.preventDefault();
  const text = inp.value.trim();
  if (text) { inp.value = ""; send(text); }
});
// ---- voice ----------------------------------------------------------
const mic = document.getElementById("mic"), spk = document.getElementById("spk");
let recorder = null, chunks = [], speakOn = false;

async function initVoice() {
  let st = {};
  try { st = await fetch("/api/voice/status").then(r => r.json()); } catch (e) { return; }
  if (st.stt && navigator.mediaDevices) mic.style.display = "";
  if (st.tts) spk.style.display = "";
}

spk.onclick = () => {
  speakOn = !speakOn;
  spk.classList.toggle("speak-on", speakOn);
  spk.textContent = speakOn ? "🔊" : "🔈";
};

async function speak(text) {
  if (!speakOn || !text) return;
  try {
    const r = await fetch("/api/tts", { method: "POST", body: JSON.stringify({ text }) });
    if (!r.ok) return;
    const blob = await r.blob();
    new Audio(URL.createObjectURL(blob)).play();
  } catch (e) {}
}

mic.onclick = async () => {
  if (recorder && recorder.state === "recording") { recorder.stop(); return; }
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
  catch (e) { add("bot", "\u26a0 Microphone access denied."); return; }
  chunks = [];
  recorder = new MediaRecorder(stream);
  recorder.ondataavailable = e => chunks.push(e.data);
  recorder.onstop = async () => {
    stream.getTracks().forEach(t => t.stop());
    mic.classList.remove("on"); mic.textContent = "🎤";
    const blob = new Blob(chunks, { type: recorder.mimeType || "audio/webm" });
    const ext = (recorder.mimeType || "audio/webm").includes("ogg") ? "ogg" : "webm";
    const note = add("typing", "Transcribing...");
    try {
      const r = await fetch("/api/stt", { method: "POST",
        headers: { "X-Audio-Ext": ext }, body: blob }).then(r => r.json());
      note.remove();
      if (r.ok && r.text) { inp.value = r.text; send(r.text); inp.value = ""; }
      else add("bot", "⚠ " + (r.error || "No speech detected"));
    } catch (e) { note.remove(); add("bot", "\u26a0 Transcription error: " + e); }
  };
  recorder.start();
  mic.classList.add("on"); mic.textContent = "⏹";
};

function renderConfirm(m) {
  const d = document.createElement("div");
  d.className = "confirm";
  const q = document.createElement("div"); q.className = "q"; q.textContent = "🔒 " + m.text;
  const cmd = document.createElement("div"); cmd.className = "cmd"; cmd.textContent = m.detail || "";
  const btns = document.createElement("div"); btns.className = "btns";
  const yes = document.createElement("button"); yes.className = "yes"; yes.textContent = "Allow";
  const no = document.createElement("button"); no.className = "no"; no.textContent = "Deny";
  const answer = (approved) => {
    yes.disabled = no.disabled = true;
    yes.style.opacity = no.style.opacity = .5;
    fetch("/api/confirm", { method: "POST",
      body: JSON.stringify({ session: sid, id: m.id, approved }) });
    q.textContent = (approved ? "\u2713 Allowed" : "\u2715 Denied") + " — " + m.text;
  };
  yes.onclick = () => answer(true); no.onclick = () => answer(false);
  btns.append(yes, no); d.append(q); if (m.detail) d.append(cmd); d.append(btns);
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight;
}

async function pollNotifications() {
  try {
    const r = await fetch("/api/notifications").then(r => r.json());
    (r.items || []).forEach(n => {
      if (n.kind === "message" || n.text) {
        add("bot", n.text);
      } else {
        const icon = n.status === "done" ? "✅" : "⚠";
        add("bot", `${icon} Background task "${n.label}" ${n.status === "done" ? "finished" : "failed"} (code ${n.code}).`);
      }
    });
  } catch (e) {}
}
setInterval(pollNotifications, 3000);
initVoice();
init();
// --- updates -------------------------------------------------------------
// Independent of the assistant on purpose. This must keep working on the day
// the model is having a bad day, because the fix for that day arrives here.
(async () => {
  const bar = document.getElementById("upd");
  const txt = document.getElementById("updtxt");
  const btn = document.getElementById("updbtn");
  let info = null;
  try { info = await (await fetch("/api/update/check")).json(); } catch (e) { return; }
  if (!info || !info.available) return;
  txt.textContent = "Version " + info.latest + " is available";
  bar.style.display = "flex";
  btn.onclick = async () => {
    btn.disabled = true;
    txt.textContent = "Installing " + info.latest + "…";
    btn.textContent = "…";
    let r = null;
    try { r = await (await fetch("/api/update/install", {method:"POST"})).json(); }
    catch (e) { r = null; }   // the service may have restarted underneath us
    if (r && !r.ok) {
      txt.textContent = r.message || "Update failed";
      btn.textContent = "Retry"; btn.disabled = false;
      return;
    }
    // Either it reported success, or the connection dropped mid-restart.
    // Both look the same from here, so wait for the service to answer again
    // and reload once it does, rather than guessing.
    txt.textContent = "Installed — restarting";
    for (let i = 0; i < 30; i++) {
      await new Promise(s => setTimeout(s, 1000));
      try { await fetch("/api/update/check", {cache: "no-store"});
            location.reload(); return; } catch (e) {}
    }
    txt.textContent = "Installed — reopen this window";
    btn.style.display = "none";
  };
})();
</script>
</body>
</html>"""


def main():
    server = http.server.ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"🌐 OSprime web UI: http://localhost:{PORT}")
    server.serve_forever()


if __name__ == "__main__":
    main()
