#!/usr/bin/env python3
"""A virtual mouse for Brainy's own desk (docs/ACT.md, step 3).

Speaks the Wayland wire protocol directly — no library — to the compositor
named by WAYLAND_DISPLAY, and uses zwlr_virtual_pointer_manager_v1 (labwc
has it; checked on Ehsan's laptop, 13 October) to move and click.

It is only ever pointed at Brainy's desk (shell/desk.py sets
WAYLAND_DISPLAY to it): the person's own pointer is never touched by this.

    osprime-pointer.py click X Y W H [left|right|double]
    osprime-pointer.py scroll X Y W H STEPS        (STEPS > 0 scrolls down)

X, Y are pixels on an output of W × H.
"""
import os
import socket
import struct
import sys
import time

BTN = {"left": 0x110, "right": 0x111}


def _pad(b: bytes) -> bytes:
    return b + b"\0" * (-len(b) % 4)


def _string(s: str) -> bytes:
    raw = s.encode() + b"\0"
    return struct.pack("<I", len(raw)) + _pad(raw)


class Wire:
    def __init__(self, path):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(5)
        self.sock.connect(path)
        self.next_id = 2              # 1 is wl_display
        self.buf = b""

    def new_id(self):
        n = self.next_id
        self.next_id += 1
        return n

    def send(self, obj, opcode, payload=b""):
        size = 8 + len(payload)
        self.sock.sendall(struct.pack("<II", obj, (size << 16) | opcode) + payload)

    def events(self):
        """Every event that has arrived so far: (object, opcode, payload)."""
        while True:
            while len(self.buf) >= 8:
                obj, word = struct.unpack("<II", self.buf[:8])
                size = word >> 16
                if len(self.buf) < size:
                    break
                payload = self.buf[8:size]
                self.buf = self.buf[size:]
                yield obj, word & 0xFFFF, payload
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ConnectionError("the compositor closed the connection")
            self.buf += chunk

    def roundtrip(self, on_event=None):
        cb = self.new_id()
        self.send(1, 0, struct.pack("<I", cb))           # wl_display.sync
        for obj, op, payload in self.events():
            if obj == cb and op == 0:
                return
            if obj == 1 and op == 0:                       # wl_display.error
                oid, code, n = struct.unpack("<III", payload[:12])
                raise RuntimeError(f"wayland error {code}: {payload[12:12 + n - 1].decode(errors='replace')}")
            if on_event:
                on_event(obj, op, payload)


def connect():
    name = os.environ.get("WAYLAND_DISPLAY", "")
    if not name:
        raise RuntimeError("no WAYLAND_DISPLAY")
    path = name if name.startswith("/") else os.path.join(os.environ.get("XDG_RUNTIME_DIR", "/tmp"), name)
    w = Wire(path)
    reg = w.new_id()
    w.send(1, 1, struct.pack("<I", reg))                   # wl_display.get_registry
    found = {}

    def on_event(obj, op, payload):
        if obj == reg and op == 0:                         # wl_registry.global
            name_id = struct.unpack("<I", payload[:4])[0]
            n = struct.unpack("<I", payload[4:8])[0]
            iface = payload[8:8 + n - 1].decode()
            ver = struct.unpack("<I", payload[8 + ((n + 3) & ~3):12 + ((n + 3) & ~3)])[0]
            found[iface] = (name_id, ver)
    w.roundtrip(on_event)
    if "zwlr_virtual_pointer_manager_v1" not in found:
        raise RuntimeError("this compositor has no virtual pointer")
    gname, ver = found["zwlr_virtual_pointer_manager_v1"]
    mgr = w.new_id()
    w.send(reg, 0, struct.pack("<I", gname) + _string("zwlr_virtual_pointer_manager_v1")
           + struct.pack("<II", min(ver, 1), mgr))          # wl_registry.bind
    ptr = w.new_id()
    w.send(mgr, 0, struct.pack("<II", 0, ptr))              # create_virtual_pointer(seat=null)
    return w, ptr


def _ms():
    return int(time.monotonic() * 1000) & 0xFFFFFFFF


def move(w, ptr, x, y, width, height):
    w.send(ptr, 1, struct.pack("<IIIII", _ms(), max(0, min(x, width)), max(0, min(y, height)), width, height))
    w.send(ptr, 4)                                          # frame


def click(w, ptr, button="left", times=1):
    for _ in range(times):
        w.send(ptr, 2, struct.pack("<III", _ms(), BTN[button], 1))
        w.send(ptr, 4)
        w.send(ptr, 2, struct.pack("<III", _ms(), BTN[button], 0))
        w.send(ptr, 4)


def scroll(w, ptr, steps):
    w.send(ptr, 3, struct.pack("<IIi", _ms(), 0, int(steps * 15 * 256)))   # axis: vertical, fixed
    w.send(ptr, 4)


def main(argv):
    if len(argv) < 6 or argv[1] not in ("click", "scroll"):
        print(__doc__, file=sys.stderr)
        return 2
    x, y, width, height = (int(float(v)) for v in argv[2:6])
    w, ptr = connect()
    move(w, ptr, x, y, width, height)
    if argv[1] == "click":
        how = argv[6] if len(argv) > 6 else "left"
        click(w, ptr, "right" if how == "right" else "left", 2 if how == "double" else 1)
    else:
        scroll(w, ptr, int(argv[6]) if len(argv) > 6 else 3)
    w.send(ptr, 8)                                          # destroy
    w.roundtrip()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
