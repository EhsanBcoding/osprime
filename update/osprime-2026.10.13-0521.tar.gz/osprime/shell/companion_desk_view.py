"""Watch Brainy's own desk, and take it over (docs/ACT.md, step 3).

A small window showing the desk (shell/desk.py) once a second. "Take over"
sends your clicks and keys to the desk instead — for the moments Brainy
must not do itself: typing a password, signing in to a site.
"""
import os
import time

from gi.repository import Gdk, GdkPixbuf, GLib, Gtk

import desk

VIEW_W = 720
_view = None


class DeskView:
    def __init__(self):
        self.win = Gtk.Window(title="Brainy's desk")
        self.win.set_default_size(VIEW_W, int(VIEW_W * desk.HEIGHT / desk.WIDTH) + 48)
        self.win.connect("destroy", self._closed)
        self.win.connect("key-press-event", self._key)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        bar = Gtk.Box(spacing=6)
        self.take = Gtk.ToggleButton(label="Take over")
        self.take.set_tooltip_text("Your clicks and keys go to Brainy's desk (for signing in, "
                                   "or a password Brainy never types)")
        self.take.connect("toggled", self._toggled)
        self.note = Gtk.Label(label="Watching — Brainy works here, not on your screen.", xalign=0)
        bar.pack_start(self.take, False, False, 0)
        bar.pack_start(self.note, True, True, 0)
        box.pack_start(bar, False, False, 0)
        self.ev = Gtk.EventBox()
        self.img = Gtk.Image()
        self.ev.add(self.img)
        self.ev.connect("button-press-event", self._click)
        self.ev.connect("scroll-event", self._scroll)
        box.pack_start(self.ev, True, True, 0)
        self.win.add(box)
        self.path = str(desk._runtime() / f"osprime-desk-view-{os.getpid()}.png")
        self.scale = VIEW_W / desk.WIDTH
        self.tick = GLib.timeout_add(1000, self._refresh)
        self._refresh()
        self.win.show_all()

    def _refresh(self):
        if not desk.running():
            self.note.set_text("Brainy's desk is closed.")
            self.img.clear()
            return True
        if desk.screenshot(self.path):
            try:
                pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(self.path, VIEW_W, -1, True)
                self.img.set_from_pixbuf(pb)
            except Exception:
                pass
        return True

    def _toggled(self, b):
        self.note.set_text("Taken over — your clicks and keys go to Brainy's desk." if b.get_active()
                           else "Watching — Brainy works here, not on your screen.")

    def _click(self, _w, ev):
        if not self.take.get_active():
            return False
        alloc = self.img.get_allocation()
        pb = self.img.get_pixbuf()
        if pb is None:
            return False
        ox = (alloc.width - pb.get_width()) / 2
        oy = (alloc.height - pb.get_height()) / 2
        x = (ev.x - ox) / pb.get_width() * desk.WIDTH
        y = (ev.y - oy) / pb.get_height() * desk.HEIGHT
        if 0 <= x <= desk.WIDTH and 0 <= y <= desk.HEIGHT:
            how = "right" if ev.button == 3 else ("double" if ev.type == Gdk.EventType._2BUTTON_PRESS else "left")
            desk.click(x, y, how)
            GLib.timeout_add(300, self._refresh_once)
        return True

    def _scroll(self, _w, ev):
        if not self.take.get_active():
            return False
        steps = 3 if ev.direction == Gdk.ScrollDirection.DOWN else -3
        desk.scroll(desk.WIDTH / 2, desk.HEIGHT / 2, steps)
        return True

    def _key(self, _w, ev):
        if not self.take.get_active():
            return False
        name = Gdk.keyval_name(ev.keyval) or ""
        if name in desk.KEYS:
            desk.key(name)
        else:
            ch = chr(Gdk.keyval_to_unicode(ev.keyval) or 0)
            if ch and ch.isprintable():
                desk.type_text(ch)
        GLib.timeout_add(200, self._refresh_once)
        return True

    def _refresh_once(self):
        self._refresh()
        return False

    def _closed(self, *_):
        global _view
        GLib.source_remove(self.tick)
        try:
            os.unlink(self.path)
        except OSError:
            pass
        _view = None


def open_view():
    global _view
    if _view is None:
        _view = DeskView()
    else:
        _view.win.present()


def is_open() -> bool:
    return _view is not None
