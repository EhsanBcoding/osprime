#!/usr/bin/env python3
"""OSprime installer — copies the running live system onto a disk.

Guided and deliberately loud about destructive steps. Run from the live ISO:
    sudo python3 /opt/osprime/installer/osprime-install.py
    sudo python3 ... --dry-run          # show the plan, touch nothing
"""

import argparse
import json
import os
import shutil
import subprocess
import sys

RSYNC_EXCLUDES = [
    "/dev/*", "/proc/*", "/sys/*", "/tmp/*", "/run/*", "/mnt/*", "/media/*",
    "/lost+found", "/var/cache/pacman/pkg/*", "/run/archiso/*",
]

MOUNT = "/mnt/osprime-target"


def sh(cmd, dry=False, check=True):
    print(("[dry] " if dry else "  $ ") + (cmd if isinstance(cmd, str) else " ".join(cmd)))
    if dry:
        return ""
    r = subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"command failed: {cmd}\n{r.stderr.strip()}")
    return r.stdout


def list_disks() -> list:
    """Physical disks only — no partitions, loops, or the live ISO media."""
    try:
        out = subprocess.run(
            ["lsblk", "-J", "-b", "-d", "-o", "NAME,SIZE,TYPE,MODEL,RM"],
            capture_output=True, text=True, check=True).stdout
        data = json.loads(out)
    except Exception:
        return []
    disks = []
    for d in data.get("blockdevices", []):
        if d.get("type") != "disk":
            continue
        if d["name"].startswith(("loop", "sr", "ram")):
            continue
        disks.append({
            "name": d["name"], "path": f"/dev/{d['name']}",
            "size_gb": round(int(d.get("size") or 0) / 1024 ** 3, 1),
            "model": (d.get("model") or "").strip(),
            "removable": bool(int(d.get("rm") or 0)),
        })
    return disks


def is_uefi() -> bool:
    return os.path.isdir("/sys/firmware/efi")


def partition_plan(disk: str, uefi: bool) -> list:
    """Return the sequence of commands that will wipe and lay out the disk."""
    if uefi:
        return [
            f"sgdisk --zap-all {disk}",
            f"sgdisk -n1:0:+512M -t1:ef00 -c1:EFI {disk}",
            f"sgdisk -n2:0:0 -t2:8300 -c2:OSPRIME {disk}",
        ]
    return [
        f"sgdisk --zap-all {disk}",
        f"sgdisk -n1:0:+1M -t1:ef02 -c1:BIOSBOOT {disk}",
        f"sgdisk -n2:0:0 -t2:8300 -c2:OSPRIME {disk}",
    ]


def part_name(disk: str, n: int) -> str:
    """nvme0n1 -> nvme0n1p1 ; sda -> sda1"""
    base = os.path.basename(disk)
    return f"{disk}p{n}" if base[-1].isdigit() else f"{disk}{n}"


def place_kernel(mount: str, dry: bool = False) -> bool:
    """Put vmlinuz where a normal Arch system keeps it.

    On a live archiso, /boot is empty — the kernel was moved into the ISO's
    boot structure at build time. Copying the running root therefore produces
    a target with no kernel, no initramfs, and no way to boot. The kernel
    image is still on disk under /usr/lib/modules/<version>/vmlinuz.
    """
    if dry:
        print(f"[dry] copy /usr/lib/modules/<version>/vmlinuz -> {mount}/boot/vmlinuz-linux")
        return True

    import glob
    candidates = sorted(glob.glob(f"{mount}/usr/lib/modules/*/vmlinuz"))
    if not candidates:
        # last resort: the mounted ISO still has it while we are running
        candidates = sorted(glob.glob("/run/archiso/bootmnt/arch/boot/*/vmlinuz-linux"))
    if not candidates:
        print("  !  no kernel image found — the target will not boot")
        return False

    src = candidates[-1]          # newest version if several are installed
    os.makedirs(f"{mount}/boot", exist_ok=True)
    sh(f"cp -f {src} {mount}/boot/vmlinuz-linux")
    print(f"  kernel placed from {src}")
    return True


def verify_target(mount: str, dry: bool = False) -> bool:
    """Check the installed system before we unmount and reboot into it.

    Every item here is something that fails *silently* — the install looks
    fine, then the laptop boots to a black screen or a mute chat window.
    Better to find out while the ISO is still running.
    """
    if dry:
        print("\n[dry] Final checks skipped.")
        return True

    checks = [
        ("linux kernel", os.path.exists(f"{mount}/boot/vmlinuz-linux")),
        ("initramfs", os.path.exists(f"{mount}/boot/initramfs-linux.img")),
        ("archiso hooks removed",
         not os.path.exists(f"{mount}/etc/mkinitcpio.conf.d/archiso.conf")),
        ("model engine (llama-server)",
         os.path.exists(f"{mount}/usr/bin/llama-server")),
        ("bootstrap model",
         os.path.exists(f"{mount}/var/lib/osprime/models/bootstrap.gguf")),
        ("model service enabled", os.path.exists(
            f"{mount}/etc/systemd/system/multi-user.target.wants/osprime-model.service")),
        ("agent service enabled", os.path.exists(
            f"{mount}/etc/systemd/system/multi-user.target.wants/osprime-agent.service")),
        ("fstab written",
         os.path.getsize(f"{mount}/etc/fstab") > 0
         if os.path.exists(f"{mount}/etc/fstab") else False),
    ]

    print("\n> Verifying the installed system:")
    bad = []
    for label, ok in checks:
        print(f"   {'✅' if ok else '❌'}  {label}")
        if not ok:
            bad.append(label)

    if bad:
        print("\n!  These are broken and the system probably will not boot:")
        for b in bad:
            print(f"     - {b}")
        print("   Fix these before rebooting.")
        return False
    print("   Everything is in place.")
    return True


def install(disk: str, dry: bool = False, hostname: str = "osprime",
            no_autologin: bool = False, password: str = ""):
    uefi = is_uefi()
    esp, root = part_name(disk, 1), part_name(disk, 2)

    print(f"\n> Boot mode: {'UEFI' if uefi else 'BIOS'}")
    print(f"> Target disk: {disk}   (ESP={esp}  ROOT={root})\n")

    for cmd in partition_plan(disk, uefi):
        sh(cmd, dry)
    sh(f"partprobe {disk}", dry, check=False)

    sh(f"mkfs.ext4 -F -L OSPRIME {root}", dry)
    if uefi:
        sh(f"mkfs.fat -F32 {esp}", dry)

    sh(f"mkdir -p {MOUNT}", dry)
    sh(f"mount {root} {MOUNT}", dry)
    if uefi:
        sh(f"mkdir -p {MOUNT}/boot", dry)
        sh(f"mount {esp} {MOUNT}/boot", dry)

    excludes = " ".join(f"--exclude={e}" for e in RSYNC_EXCLUDES)
    # check=False on purpose: with the ESP mounted at /boot, rsync cannot set
    # xattrs/ACLs/hardlinks on FAT32 and exits 23 ("partial transfer"). That is
    # expected here and must not abort a working install.
    sh(f"rsync -aAXH {excludes} / {MOUNT}/", dry, check=False)

    # a real root filesystem, not a live image
    sh(f"mkdir -p {MOUNT}/dev {MOUNT}/proc {MOUNT}/sys {MOUNT}/tmp {MOUNT}/run", dry)
    if not dry:
        with open(f"{MOUNT}/etc/hostname", "w") as f:
            f.write(hostname + "\n")
    sh(f"genfstab -U {MOUNT} >> {MOUNT}/etc/fstab", dry, check=False)

    # Autologin is kept by default. OSprime is a personal appliance: the tty1
    # autologin is what starts the graphical shell, so removing it drops the
    # user at a bare console login — not something "anyone can use". Pass
    # --no-autologin on a machine that needs a login prompt.
    if no_autologin:
        sh(f"rm -f {MOUNT}/etc/systemd/system/getty@tty1.service.d/autologin.conf",
           dry, check=False)

    # CRITICAL: the live image builds its initramfs with the archiso hooks,
    # which search for the ISO medium at boot. Regenerating with those hooks
    # still present produces an installed system that cannot find its root and
    # drops to an emergency shell.
    #
    # There are TWO archiso-flavoured files, and removing only one leaves
    # mkinitcpio broken:
    #   1. /etc/mkinitcpio.conf.d/archiso.conf   the hook set
    #   2. /etc/mkinitcpio.d/linux.preset        names an 'archiso' preset
    #                                            that points at file 1
    # Deleting 1 without replacing 2 gives:
    #   ERROR: Invalid option -c -- '.../archiso.conf' must be readable
    if not dry:
        os.makedirs(f"{MOUNT}/etc/mkinitcpio.conf.d", exist_ok=True)
        with open(f"{MOUNT}/etc/mkinitcpio.conf.d/osprime.conf", "w") as f:
            f.write("HOOKS=(base udev autodetect microcode modconf kms keyboard "
                    "keymap consolefont block filesystems fsck)\n")
        os.makedirs(f"{MOUNT}/etc/mkinitcpio.d", exist_ok=True)
        with open(f"{MOUNT}/etc/mkinitcpio.d/linux.preset", "w") as f:
            f.write('ALL_config="/etc/mkinitcpio.conf"\n'
                    'ALL_kver="/boot/vmlinuz-linux"\n\n'
                    "PRESETS=('default')\n\n"
                    'default_image="/boot/initramfs-linux.img"\n')
    sh(f"rm -f {MOUNT}/etc/mkinitcpio.conf.d/archiso.conf", dry, check=False)

    # Leftovers from the live image that mean nothing on a disk.
    #
    # archiso gives root a .zlogin that runs /root/.automated_script.sh, and
    # that script is not copied — so every root login on the installed
    # machine opens with "permission denied: /root/.automated_script.sh".
    # Harmless, and exactly the same shape as the chromium profile lock that
    # still named the host "archiso": something that made sense in the live
    # environment and is only confusing once it is on somebody's disk.
    for leftover in (".zlogin", ".automated_script.sh", ".zprofile"):
        sh(f"rm -f {MOUNT}/root/{leftover}", dry, check=False)

    # CRITICAL #2: /boot is EMPTY on a live archiso system. mkarchiso lifts
    # the kernel out of airootfs into the ISO's own boot structure, so rsync
    # copies nothing into the ESP and mkinitcpio has no kernel to build for.
    # The kernel does survive at /usr/lib/modules/<version>/vmlinuz — put it
    # back where a normal Arch install expects it before generating initramfs.
    place_kernel(MOUNT, dry)

    sh(f"arch-chroot {MOUNT} mkinitcpio -P", dry, check=False)

    if uefi:
        sh(f"arch-chroot {MOUNT} bootctl --path=/boot install", dry, check=False)
        if not dry:
            os.makedirs(f"{MOUNT}/boot/loader/entries", exist_ok=True)
            with open(f"{MOUNT}/boot/loader/entries/osprime.conf", "w") as f:
                f.write("title OSprime\nlinux /vmlinuz-linux\n"
                        "initrd /initramfs-linux.img\n"
                        f"options root=LABEL=OSPRIME rw quiet\n")
            with open(f"{MOUNT}/boot/loader/loader.conf", "w") as f:
                f.write("default osprime\ntimeout 3\n")
    else:
        sh(f"arch-chroot {MOUNT} grub-install --target=i386-pc {disk}", dry, check=False)
        sh(f"arch-chroot {MOUNT} grub-mkconfig -o /boot/grub/grub.cfg", dry, check=False)

    # osprime-model MUST be here: it is the local brain. Without it the
    # installed system boots to a chat window that cannot answer anything.
    # (osprime-shell is intentionally absent — it fights the tty1 autologin
    # for the console and causes a boot restart loop.)
    sh(f"arch-chroot {MOUNT} systemctl enable osprime-model osprime-agent osprime-web",
       dry, check=False)

    # the live image ships a known password; do not carry it to a real disk
    if password:
        sh(f"arch-chroot {MOUNT} sh -c 'echo \"osprime:{password}\" | chpasswd'",
           dry, check=False)

    verify_target(MOUNT, dry)
    sh(f"umount -R {MOUNT}", dry, check=False)
    print("\nInstall complete. Remove the ISO and reboot.")


def main():
    ap = argparse.ArgumentParser(description="OSprime disk installer")
    ap.add_argument("--disk", help="target disk, e.g. /dev/sda")
    ap.add_argument("--hostname", default="osprime")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-autologin", action="store_true",
                    help="require a console login instead of booting straight in")
    ap.add_argument("--password", default="",
                    help="password for the osprime user (default: keep the live one)")
    ap.add_argument("--list", action="store_true", help="list disks and exit")
    a = ap.parse_args()

    disks = list_disks()
    if a.list:
        for d in disks:
            print(f"{d['path']:14} {d['size_gb']:>8} GB  {d['model']}")
        return 0

    if os.geteuid() != 0 and not a.dry_run:
        print("Run this with sudo."); return 1

    disk = a.disk
    if not disk:
        if not disks:
            print("No disks found."); return 1
        print("Available disks:\n")
        for i, d in enumerate(disks, 1):
            tag = " (removable)" if d["removable"] else ""
            print(f"  {i}) {d['path']:14} {d['size_gb']:>8} GB  {d['model']}{tag}")
        try:
            disk = disks[int(input("\nTarget disk number: ").strip()) - 1]["path"]
        except (ValueError, IndexError, EOFError):
            print("Invalid selection."); return 1

    if not a.dry_run:
        print(f"\n!  Everything on {disk} will be erased. This cannot be undone.")
        if input("Type ERASE exactly to continue: ").strip() != "ERASE":
            print("Cancelled."); return 1

    install(disk, a.dry_run, a.hostname, a.no_autologin, a.password)
    return 0


if __name__ == "__main__":
    sys.exit(main())
