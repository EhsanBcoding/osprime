#!/usr/bin/env bash
# Launch the local inference server.
#
# This lives in a script rather than inline in the unit file because the
# one-liner version failed silently: systemd splits Environment= on
# whitespace, so "--ctx-size 4096 --jinja" became three assignments and
# llama-server was started with a valueless --ctx-size. All you saw was a
# restart loop and "local model engine is not running".
#
# Run it by hand to see exactly what is wrong:
#     bash /opt/osprime/shell/osprime-model.sh
set -u

MODEL="${MODEL_PATH:-/var/lib/osprime/models/bootstrap.gguf}"
PORT="${MODEL_PORT:-8087}"
CTX="${MODEL_CTX:-16384}"

BIN="$(command -v llama-server || command -v llama-cpp-server || true)"
if [ -z "$BIN" ]; then
    echo "FATAL: no llama-server binary in PATH." >&2
    echo "Binaries provided by the llama-cpp package:" >&2
    pacman -Ql llama-cpp 2>/dev/null | grep '/usr/bin/' >&2 || echo "  llama-cpp not installed" >&2
    exit 1
fi

if [ ! -s "$MODEL" ]; then
    echo "FATAL: model file missing or empty: $MODEL" >&2
    ls -l "$(dirname "$MODEL")" >&2 2>/dev/null || true
    exit 1
fi

# Probing --help told us a flag exists. It did not tell us the flag would
# work: a build can list an option whose value it then rejects, and an
# option that used to be a plain switch can grow a mandatory argument
# between releases. Either way llama-server exits at once, systemd restarts
# it, and the whole machine loses its assistant because of a speed setting.
#
# So the flags are arranged as a ladder and tried from the top. Each attempt
# is given a few seconds to prove it survives; the first one that does is
# kept. The bottom rung has nothing on it but the model, and it always
# works. A performance flag can slow this down. It can no longer take the
# computer down.
has() { "$BIN" --help 2>&1 | grep -q -- "$1"; }

BASE=(-m "$MODEL" --host 127.0.0.1 --port "$PORT")

# The vision projector, for a model that can see.
#
# Part of BASE rather than a rung on the ladder below, and that is a
# deliberate choice: a vision model started WITHOUT its projector loads
# perfectly and then cannot see, which is the worst of all outcomes — the
# feature is gone and nothing failed. Better to have the engine refuse to
# start, so the ladder falls through to something honest.
#
# Only added when the file is actually there. A --mmproj pointing at
# nothing would stop a text-only model from starting for no reason.
if [ -n "${MODEL_MMPROJ:-}" ] && [ -s "${MODEL_MMPROJ:-}" ] && has '--mmproj'; then
    BASE+=(--mmproj "$MODEL_MMPROJ")
    echo "vision: $MODEL_MMPROJ" >&2
elif [ -n "${MODEL_MMPROJ:-}" ]; then
    # Said out loud. A model that was installed to see and then quietly
    # started blind is exactly the silent half-failure this project keeps
    # meeting.
    echo "WARNING: this model expects a vision file but it is missing or" >&2
    echo "         this llama-server has no --mmproj. It will start, and" >&2
    echo "         it will not be able to see: $MODEL_MMPROJ" >&2
fi

# --jinja turns on the chat template that native tool calling needs.
JINJA=()
if has '--jinja'; then
    JINJA=(--jinja)
else
    echo "note: this llama-server has no --jinja; falling back to the" >&2
    echo "      text tool-call protocol in agent/local.py." >&2
fi

# Speed, in rough order of how much it buys:
#   --cache-reuse   keeps the identical prompt prefix between turns
#   --mlock         holds the weights in RAM instead of paging them off disk
#   --threads-batch reads the prompt on every core
#   --batch-size    reads it in fewer passes
# Layers on the GPU, when setup-gpu.sh has proved that helps. Kept separate
# from the rest so a graphics driver that cannot cope costs only the GPU and
# not --cache-reuse, which is worth more than all the others together.
GPU=()
if [ -n "${OSPRIME_GPU_LAYERS:-}" ] && has '--n-gpu-layers'; then
    GPU=(--n-gpu-layers "$OSPRIME_GPU_LAYERS")
fi

FAST=()
has '--cache-reuse'   && FAST+=(--cache-reuse 256)
has '--mlock'         && FAST+=(--mlock)
CORES="$(nproc 2>/dev/null || echo 0)"
[ "$CORES" -gt 0 ] && has '--threads-batch' && FAST+=(--threads-batch "$CORES")
has '--batch-size'    && FAST+=(--batch-size 512)

# A smaller window is the last thing to give up, not the first: the system
# prompt and the tool definitions need about 5,500 tokens, and below 8192
# llama-server starts silently truncating them — which drops the tool list
# and leaves an assistant that denies abilities it has.
try_start() {
    local label="$1"; shift
    echo "attempt: $label"
    echo "  $BIN $*"
    "$BIN" "$@" &
    local pid=$!
    for _ in 1 2 3 4 5 6 7 8; do
        sleep 1
        kill -0 "$pid" 2>/dev/null || {
            echo "  died within a few seconds — trying the next rung down" >&2
            wait "$pid" 2>/dev/null
            return 1
        }
    done
    echo "  running ($label)"
    wait "$pid"
    exit $?
}

try_start "full"            "${BASE[@]}" --ctx-size "$CTX" "${JINJA[@]}" "${GPU[@]}" "${FAST[@]}"
try_start "cpu only"        "${BASE[@]}" --ctx-size "$CTX" "${JINJA[@]}" "${FAST[@]}"
try_start "no speed flags"  "${BASE[@]}" --ctx-size "$CTX" "${JINJA[@]}"
try_start "8192 context"    "${BASE[@]}" --ctx-size 8192   "${JINJA[@]}"
try_start "no chat template" "${BASE[@]}" --ctx-size 8192
try_start "bare minimum"    "${BASE[@]}"

echo "FATAL: llama-server would not start on any settings." >&2
echo "Its own output is above. Run this script by hand to see more:" >&2
echo "    bash /opt/osprime/shell/osprime-model.sh" >&2
exit 1
