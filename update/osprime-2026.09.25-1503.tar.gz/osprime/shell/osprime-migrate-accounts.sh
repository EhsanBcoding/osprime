#!/usr/bin/env bash
# Give this computer a login: a person account, the login screen, a lock.
# docs/ACCOUNTS.md, phase 1.
#
#   sudo bash /opt/osprime/shell/osprime-migrate-accounts.sh            set it up
#   sudo bash /opt/osprime/shell/osprime-migrate-accounts.sh --revert   undo
#
# Run once, from a terminal, by the person the computer belongs to. It asks
# before every step that changes anything.
#
# What it does:
#   1. installs the login screen and lock if missing (greetd, ReGreet, cage,
#      gtklock, swayidle) — `pacman -S --needed`, never -y;
#   2. creates your account, an administrator, and has you set its password;
#   3. PROVES the password works (su asks for it) before going further;
#   4. COPIES — never moves — your files, memory and settings from the
#      osprime account into yours;
#   5. keeps everything personal it copied from /var/lib/osprime and
#      /etc/osprime in a root-only folder, so it is neither lost nor
#      readable by the next person on this machine;
#   6. switches the login screen on and the automatic login off. The
#      change takes effect at the next restart.
#
# Nothing is switched until 1-5 have succeeded. If anything fails before
# that, the computer starts exactly as it does today.
#
# --revert (from the terminal on Ctrl+Alt+F2 if the login screen will not
# come up): automatic login back, login screen off, the osprime account's
# files back where they were. Your account and its home are kept.
set -u

R="${OSPRIME_MIGRATE_ROOT:-}"        # the tests run against a fake root
KEEP="$R/var/lib/osprime-migrate"    # root-only: what was moved aside, for --revert
FLAG="$R/etc/osprime/accounts"
AUTOLOGIN="$R/etc/systemd/system/getty@tty1.service.d/autologin.conf"
GREETD="$R/etc/greetd"
SVC_HOME="$R/home/osprime"
PKGS="greetd greetd-regreet cage gtklock swayidle"

say()  { echo "$*"; }
ask()  {
    [ -n "${OSPRIME_MIGRATE_YES:-}" ] && return 0
    local a; read -r -p "$1 [y/N] " a; [ "$a" = y ] || [ "$a" = Y ]
}
die()  { echo; echo "Stopped: $*"; echo "Nothing was switched — the computer starts as it did before."; exit 1; }

if [ "$(id -u)" -ne 0 ] && [ -z "${OSPRIME_MIGRATE_TEST:-}" ]; then
    echo "This creates an account and changes how the computer starts — run it with sudo."
    exit 1
fi

# ---------------------------------------------------------------------------
revert() {
    [ -e "$FLAG" ] || { say "This computer has no login set up — nothing to undo."; exit 0; }
    say "Undoing the login: automatic login back, login screen off."
    ask "Go ahead?" || exit 0
    mkdir -p "$(dirname "$AUTOLOGIN")"
    [ -f "$KEEP/autologin.conf" ] && cp -f "$KEEP/autologin.conf" "$AUTOLOGIN"
    if [ -f "$KEEP/greetd-config.toml" ]; then
        cp -f "$KEEP/greetd-config.toml" "$GREETD/config.toml"
    fi
    # The osprime account's own data back where the system-wide assistant
    # reads it. Copies stay in $KEEP until someone deletes them.
    if [ -d "$KEEP/var-lib" ]; then cp -a "$KEEP/var-lib/." "$R/var/lib/osprime/"; fi
    if [ -d "$KEEP/etc" ];     then cp -a "$KEEP/etc/." "$R/etc/osprime/"; fi
    rm -f "$FLAG"
    sysctl_ disable greetd.service
    sysctl_ enable getty@tty1.service
    sysctl_ set-default "$(cat "$KEEP/default.target" 2>/dev/null || echo multi-user.target)"
    usermod_ -U osprime
    usermod_ -s /bin/bash osprime
    say "Done. Restart the computer; it will log in automatically as before."
    say "Your account and its files are still there."
    exit 0
}

# Commands that change the real system go through these, so the tests can
# replace them.
sysctl_()  { [ -n "${OSPRIME_MIGRATE_TEST:-}" ] && { echo "systemctl $*" >> "$R/log"; return 0; }; systemctl "$@"; }
usermod_() { [ -n "${OSPRIME_MIGRATE_TEST:-}" ] && { echo "usermod $*" >> "$R/log"; return 0; }; usermod "$@"; }

[ "${1:-}" = "--revert" ] && revert
[ -e "$FLAG" ] && { say "This computer already has a login (for $(cat "$FLAG" 2>/dev/null | head -1)). To undo it: $0 --revert"; exit 0; }

say "This gives the computer a login screen and gives you your own account."
say "Your files and the assistant's memory are copied into it; nothing is deleted."
say "The change takes effect at the next restart. To undo it later:"
say "    sudo bash $0 --revert"
say
ask "Continue?" || exit 0

# ---- 1. the packages --------------------------------------------------------
MISSING=""
for p in $PKGS; do pacman -Q "$p" >/dev/null 2>&1 || MISSING="$MISSING $p"; done
if [ -n "$MISSING" ]; then
    say "> needed:$MISSING"
    ask "Install them now?" || die "the login screen needs them"
    # shellcheck disable=SC2086
    pacman -S --needed $MISSING || die "pacman could not install them. If it said a file was not found, run 'sudo pacman -Syu' first."
fi

# ---- 2. the account ---------------------------------------------------------
NAME="${OSPRIME_MIGRATE_NAME:-}"
while [ -z "$NAME" ]; do
    read -r -p "Your user name (lowercase, e.g. ehsan): " NAME
    if ! printf '%s' "$NAME" | grep -Eq '^[a-z_][a-z0-9_-]{0,30}$'; then
        say "  lowercase letters, digits, - and _ only, starting with a letter."; NAME=""
    elif [ "$NAME" = osprime ] || [ "$NAME" = root ]; then
        say "  that name is taken by the system."; NAME=""
    fi
done
FULL="${OSPRIME_MIGRATE_FULLNAME:-}"
[ -n "$FULL" ] || read -r -p "Your full name (shown on the login screen): " FULL

if getent passwd "$NAME" >/dev/null; then
    say "> $NAME already exists — using that account."
else
    # The osprime account's groups (video, audio, input …) so the new one can
    # use the same hardware; wheel = administrator; osprime so it can read the
    # machine's settings in /etc/osprime; osprime-users for the sudo rules.
    getent group osprime-users >/dev/null || groupadd -r osprime-users || die "could not create the osprime-users group"
    GROUPS_="$(id -nG osprime 2>/dev/null | tr ' ' '\n' | grep -vx osprime | paste -sd, -)"
    GROUPS_="${GROUPS_:+$GROUPS_,}wheel,osprime,osprime-users"
    useradd -m -c "$FULL" -G "$GROUPS_" -s /bin/bash "$NAME" || die "could not create the account"
fi
say "> choose a password for $NAME (asked twice)"
passwd "$NAME" || die "the password was not set"
HOME_NEW="$R$(getent passwd "$NAME" | cut -d: -f6)"
[ -d "$HOME_NEW" ] || die "$NAME has no home folder"

# ---- 3. prove the password --------------------------------------------------
# su run AS the osprime account asks for the password — root would not be
# asked, and a password that was never checked is how a laptop ends up with
# a login screen nobody can get past.
say "> checking the password: type it once more"
runuser -u osprime -- su "$NAME" -c true || die "that password did not work"

# ---- 4. copy the person's things --------------------------------------------
say "> copying your files and applications into /home/$NAME"
# The whole home, not a list of folders. 25 September: the first version
# copied Documents, Desktop and the rest by name and left GIMP behind —
# applications from the App Store are per-user flatpaks in
# ~/.local/share/flatpak, and settings, browser profile and bookmarks live
# in ~/.config. Left out: the tty1 autologin launcher (.bash_profile), which
# means nothing in a login-screen session, and the osprime account's own
# Python environment, whose paths point into /home/osprime. Existing files
# in the new home are never overwritten.
tar -C "$SVC_HOME" --exclude=./.bash_profile --exclude=./.local/share/osprime \
    -cf - . 2>/dev/null | tar -C "$HOME_NEW" --skip-old-files -xf - \
    || die "could not copy the files from $SVC_HOME"
mkdir -p "$HOME_NEW/.local/share/osprime" "$HOME_NEW/.local/state/osprime" "$HOME_NEW/.config/osprime"
cpif() { [ -f "$1" ] && cp -an "$1" "$2"; return 0; }
cpif "$R/var/lib/osprime/memory.db"        "$HOME_NEW/.local/share/osprime/"
cpif "$R/var/lib/osprime/memory.json"      "$HOME_NEW/.local/share/osprime/"
cpif "$R/var/lib/osprime/audit.log"        "$HOME_NEW/.local/state/osprime/"
cpif "$R/var/lib/osprime/tool-errors.log"  "$HOME_NEW/.local/state/osprime/"
cpif "$R/var/lib/osprime/tool-groups.log"  "$HOME_NEW/.local/state/osprime/"
cpif "$R/var/lib/osprime/proactive.json"   "$HOME_NEW/.local/state/osprime/"
cpif "$R/etc/osprime/config.json"          "$HOME_NEW/.config/osprime/"
cpif "$R/etc/osprime/profile.json"         "$HOME_NEW/.config/osprime/"
cpif "$R/etc/osprime/remote.json"          "$HOME_NEW/.config/osprime/"
cpif "$R/etc/osprime/secrets.env"          "$HOME_NEW/.config/osprime/"
# The personal settings in the machine file become the person's own; the
# machine file stays as the defaults for anyone added later.
cpif "$R/etc/osprime/desktop.env"          "$HOME_NEW/.config/osprime/"
chown -R "$NAME:$NAME" "$HOME_NEW" 2>/dev/null || [ -n "${OSPRIME_MIGRATE_TEST:-}" ] || die "could not hand the copied files to $NAME"
chmod 700 "$HOME_NEW/.local/share/osprime" "$HOME_NEW/.local/state/osprime" "$HOME_NEW/.config/osprime"
[ -f "$HOME_NEW/.config/osprime/secrets.env" ] && chmod 600 "$HOME_NEW/.config/osprime/secrets.env"

# ---- 5. the old personal data: kept, but only root can read it ---------------
# /var/lib/osprime and /etc/osprime are readable by the osprime group, which
# people are in. Left there, the next person added could read this memory.
mkdir -p "$KEEP/var-lib" "$KEEP/etc"; chmod 700 "$KEEP"
for f in memory.db memory.json audit.log tool-errors.log tool-groups.log proactive.json; do
    [ -f "$R/var/lib/osprime/$f" ] && mv -f "$R/var/lib/osprime/$f" "$KEEP/var-lib/"
done
for f in config.json profile.json remote.json secrets.env; do
    [ -f "$R/etc/osprime/$f" ] && mv -f "$R/etc/osprime/$f" "$KEEP/etc/"
done

# ---- 6. switch ----------------------------------------------------------------
say
say "Everything is ready. The last step switches the login screen on."
ask "Switch now? (takes effect at the next restart)" || {
    # Put the moved files back: nothing is switched, nothing is half-done.
    cp -a "$KEEP/var-lib/." "$R/var/lib/osprime/"; cp -a "$KEEP/etc/." "$R/etc/osprime/"
    die "not switched, at your request. Your account and the copies are kept."; }

mkdir -p "$GREETD"
[ -f "$GREETD/config.toml" ] && cp -f "$GREETD/config.toml" "$KEEP/greetd-config.toml"
cat > "$GREETD/config.toml" <<'EOF'
# Written by osprime-migrate-accounts.sh (docs/ACCOUNTS.md).
[terminal]
vt = 1

[default_session]
# ReGreet, the graphical login screen, in the cage kiosk compositor.
command = "cage -s -- regreet"
user = "greeter"
EOF
# ReGreet keeps its state and log here and runs as the greeter user.
if getent passwd greeter >/dev/null; then
    install -d -o greeter -g greeter "$R/var/lib/regreet" "$R/var/log/regreet" 2>/dev/null || true
fi
# labwc also installs its own plain session; if it is picked by mistake,
# the person still gets OSprime's configuration.
mkdir -p "$HOME_NEW/.config"
[ -d "$HOME_NEW/.config/labwc" ] || cp -a "$R/opt/osprime/shell/labwc" "$HOME_NEW/.config/labwc" 2>/dev/null
chown -R "$NAME:$NAME" "$HOME_NEW/.config" 2>/dev/null || true
[ -f "$AUTOLOGIN" ] && mv -f "$AUTOLOGIN" "$KEEP/autologin.conf"
printf '%s\n%s\n' "$NAME" "$(date -Iseconds)" > "$FLAG"
chmod 644 "$FLAG"
sysctl_ disable getty@tty1.service
sysctl_ enable greetd.service
# greetd is a display manager, and display managers start with
# graphical.target. OSprime booted to multi-user.target — the desktop came
# from the tty1 autologin — so on the laptop, 25 September, greetd was
# enabled and never started: a black screen on tty1. The old default is
# kept for --revert.
default_="$(sysctl_ get-default 2>/dev/null)"
[ -n "$default_" ] && echo "$default_" > "$KEEP/default.target"
sysctl_ set-default graphical.target
# Nobody logs in as the service account any more; --revert unlocks it.
usermod_ -L osprime
# …and is not offered on the login screen: ReGreet lists accounts that
# have a login shell. 25 September: it was listed, asked for a password,
# and no password could ever work. --revert gives it bash back.
usermod_ -s /usr/bin/nologin osprime

say
say "Done. Restart the computer: you will see the login screen. Log in as $NAME."
say "If it offers a choice of session, pick OSprime once — it is remembered."
say "If it does not come up, press Ctrl+Alt+F2, log in as $NAME, and run:"
say "    sudo bash $0 --revert"
