#!/usr/bin/env bash
# Runs as root at the end of an update, from inside the new package.
#
# This exists for the half of a change that an update cannot deliver by
# copying files. Ownership and sudo rules are not code, and a release that
# ships new service units without them produces exactly the failure this
# project keeps meeting: an update that reports success while half of it did
# not happen.
#
# The change it completes: the OSprime services now run as the osprime user
# instead of root, so everything the assistant writes has to belong to that
# user, and the few things it still needs root for have to be named in
# sudoers.
#
# Anything essential that fails exits non-zero, and the updater rolls the
# whole release back. That is the point — a machine half-moved to an
# unprivileged agent is worse than one that never moved.
set -u

SRC="$(cd "$(dirname "$0")" && pwd)"
SUDOERS_SRC="$SRC/shell/osprime-sudoers"

# Everything this script touches is under one prefix, empty in real use.
# A script that must not fail is a script that has to be runnable against a
# throwaway directory first — otherwise the only way to test it is to run it
# on the machine it would break.
R="${OSPRIME_POST_ROOT:-}"
SUDOERS_DST="$R/etc/sudoers.d/osprime"
fail=0

echo "> making the assistant's own files belong to it"
# /opt/osprime is deliberately absent: the code stays root-owned, which is
# what stops the unprivileged agent rewriting the script it is allowed to
# ask root to run.
for d in "$R/var/lib/osprime" "$R/etc/osprime"; do
    mkdir -p "$d"
    chown -R osprime:osprime "$d" 2>/dev/null || \
        { [ -z "$R" ] && { echo "  could not chown $d"; fail=1; }; }
    chmod 770 "$d" || fail=1
done
# The key file keeps its own mode; only its owner changes.
[ -f "$R/etc/osprime/secrets.env" ] && chmod 600 "$R/etc/osprime/secrets.env"

echo "> installing the sudo rules"
if [ ! -f "$SUDOERS_SRC" ]; then
    echo "  $SUDOERS_SRC is missing from this package"
    fail=1
else
    tmp="$(mktemp)"
    cp "$SUDOERS_SRC" "$tmp"
    chmod 440 "$tmp"
    # Validated before it replaces anything. An invalid file in
    # /etc/sudoers.d stops sudo running AT ALL, and root is locked on this
    # system — there would be no way back.
    if visudo -c -f "$tmp" >/dev/null 2>&1; then
        # The exit code is checked. The first version printed "updated"
        # whether or not the install worked, which is the same bug this
        # script exists to stop shipping.
        # Ownership is only settable as root; under a test prefix it is not
        # root and does not need to be.
        OWNER=()
        [ -z "$R" ] && OWNER=(-o root -g root)
        if install -m 440 "${OWNER[@]}" "$tmp" "$SUDOERS_DST"; then
            echo "  $SUDOERS_DST updated"
        else
            echo "  could not write $SUDOERS_DST"
            fail=1
        fi
    else
        echo "  the new sudo rules did not validate — the old ones were kept"
        visudo -c -f "$tmp" 2>&1 | sed 's/^/    /'
        fail=1
    fi
    rm -f "$tmp"
fi

# Leftovers from the live image, harmless but confusing on every root login.
rm -f "$R/root/.zlogin" "$R/root/.automated_script.sh" 2>/dev/null

if [ "$fail" -ne 0 ]; then
    echo "post-install did not complete — the update will be rolled back"
    exit 1
fi
echo "post-install complete"
