"""OSprime on the phone (docs/HELPERS.md, step 4; Ehsan, 9 October).

The companion's panel, made for a phone: Home (the helpers and their
cards), Chat (each helper its own conversation) and Alerts (what the
watchers found, and the watchers themselves). Reached through remote access
(ui/remote.py) on the home network, over plain http — Ehsan's choice for now
— and added to the home screen as an app (manifest + icons below; iPhone
and Android both open it full screen).

What the phone may do is remote.py's allowlist, as everywhere: it talks,
reads, and may pause or remove a watcher (Ehsan: those only switch things
off). Making a helper, and anything that needs approval, stays at the
computer.

Plain http means no "secure context": crypto.randomUUID, getUserMedia and
service workers do not exist here (webguard.SECURE_CONTEXT_ONLY). So ids
come from getRandomValues, and the microphone falls back to the phone's own
recorder through a file input.
"""

MANIFEST = {
    "name": "OSprime",
    "short_name": "OSprime",
    "start_url": "/m",
    "scope": "/",
    "display": "standalone",
    "background_color": "#0d1117",
    "theme_color": "#0d1117",
    "icons": [
        {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
        {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
    ],
}

ICON_SIZES = {"/icon-180.png": 180, "/icon-192.png": 192, "/icon-512.png": 512}


def icon_png(size: int) -> bytes:
    """Brainy on the app's dark square, drawn once per size and kept."""
    import pathlib
    import sys
    here = pathlib.Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(here / "shell"))
    sys.path.insert(0, str(here / "agent"))
    import paths
    out = paths.state_dir() / "icons" / f"app-{size}.png"
    if out.is_file():
        return out.read_bytes()
    import cairo
    import companion_art as ca
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, size, size)
    cr = cairo.Context(s)
    cr.set_source_rgb(0.05, 0.07, 0.09)
    cr.paint()
    try:
        ch = ca.Character("pearl")
        h = int(size * 0.84)
        w, _ = ch.size_for(h)
        mini = ca.mini_surface(ch, h)
        cr.set_source_surface(mini, (size - w) / 2, (size - h) / 2)
        cr.paint()
    except Exception:
        cr.arc(size / 2, size / 2, size * 0.36, 0, 6.2832)
        cr.set_source_rgb(0.35, 0.65, 1.0)
        cr.fill()
    out.parent.mkdir(parents=True, exist_ok=True)
    s.write_to_png(str(out))
    return out.read_bytes()


def helper_png(hid: str, color: str) -> bytes:
    """A helper's small Brainy in its colour, as on the computer's panel."""
    import pathlib
    import re
    import sys
    here = pathlib.Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(here / "shell"))
    sys.path.insert(0, str(here / "agent"))
    import paths
    if not re.match(r"^[a-z0-9-]{1,41}$", hid) or not re.match(r"^#[0-9a-fA-F]{6}$", color or ""):
        raise ValueError("not a helper")
    out = paths.state_dir() / "icons" / f"helper-{hid}-{color.lstrip('#').lower()}.png"
    if out.is_file():
        return out.read_bytes()
    import companion_art as ca
    s = ca.mini_surface(ca.Character("pearl"), 72, None if hid == "general" else color)
    out.parent.mkdir(parents=True, exist_ok=True)
    s.write_to_png(str(out))
    return out.read_bytes()


PAGE = r"""<!DOCTYPE html>
<html lang="{{LANG}}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0d1117">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="OSprime">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="apple-touch-icon" href="/icon-180.png">
<title>OSprime</title>
<style>
  :root { --bg:#0d1117; --panel:#161b22; --line:#30363d; --text:#e6edf3; --dim:#8b949e;
          --accent:#58a6ff; --up:#3fb950; --down:#f85149; }
  * { box-sizing: border-box; }
  html, body { margin:0; height:100%; background:var(--bg); color:var(--text);
               font:16px/1.45 system-ui, -apple-system, "Vazirmatn", sans-serif; }
  body { display:flex; flex-direction:column;
         padding: env(safe-area-inset-top) env(safe-area-inset-right) 0 env(safe-area-inset-left); }
  header { display:flex; align-items:center; gap:8px; padding:10px 14px; }
  header h1 { font-size:17px; margin:0; flex:1; }
  header a { color:var(--dim); font-size:13px; text-decoration:none; }
  main { flex:1; overflow-y:auto; padding:0 14px 12px; -webkit-overflow-scrolling:touch; }
  nav { display:flex; border-top:1px solid var(--line); background:var(--panel);
        padding-bottom: env(safe-area-inset-bottom); }
  nav button { flex:1; background:none; border:0; color:var(--dim); padding:10px 0 12px;
               font-size:13px; position:relative; }
  nav button.on { color:var(--text); }
  nav .badge { position:absolute; top:6px; margin-left:4px; background:var(--down); color:#fff;
               border-radius:9px; padding:0 6px; font-size:11px; }
  .pills { display:grid; grid-template-columns:repeat(auto-fill, minmax(96px,1fr)); gap:8px; margin:6px 0 12px; }
  .pill { background:var(--panel); border:1px solid var(--line); border-radius:12px; padding:8px 6px;
          color:var(--text); text-align:center; font-size:13px; position:relative; }
  .pill.on { border-color:var(--accent); background:#1c2a3d; }
  .pill .dot { width:30px; height:36px; object-fit:contain; display:block; margin:0 auto 4px; }
  .pill div.dot { width:30px; height:30px; border-radius:50%; }
  .pill .n { position:absolute; top:4px; right:6px; color:var(--down); font-size:12px; }
  .card { background:var(--panel); border:1px solid var(--line); border-radius:12px; padding:12px; }
  .card h2 { font-size:13px; color:var(--dim); margin:0 0 6px; font-weight:600; }
  .row { display:flex; justify-content:space-between; gap:10px; padding:3px 0; }
  .row .l { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .up { color:var(--up); } .down { color:var(--down); } .dim { color:var(--dim); font-size:13px; }
  .go { display:block; width:100%; margin-top:10px; background:#238636; color:#fff; border:0;
        border-radius:10px; padding:10px; font-size:15px; }
  .msg { margin:8px 0; padding:8px 12px; border-radius:14px; max-width:88%; white-space:pre-wrap;
         word-wrap:break-word; }
  .you { background:#1f6feb; color:#fff; margin-left:auto; border-bottom-right-radius:4px; }
  .it { background:var(--panel); border:1px solid var(--line); border-bottom-left-radius:4px; }
  .tool { color:var(--dim); font-size:13px; margin:4px 0; }
  .alert { border-left:3px solid var(--accent); }
  .ask { display:flex; gap:6px; padding:8px 0 4px; position:sticky; bottom:0; background:var(--bg); }
  .ask input[type=text] { flex:1; background:var(--panel); color:var(--text); border:1px solid var(--line);
                          border-radius:20px; padding:10px 14px; font-size:16px; }
  .ask button, .ask label { background:var(--panel); border:1px solid var(--line); color:var(--text);
                            border-radius:20px; padding:0 14px; font-size:18px; display:flex; align-items:center; }
  .ask input[type=file] { display:none; }
  .btns { display:flex; gap:8px; margin-top:8px; }
  .btns button { flex:1; border:0; border-radius:8px; padding:8px; font-size:14px; color:#fff; background:#30363d; }
  .btns .yes { background:#238636; }
  .w { display:flex; gap:8px; align-items:center; padding:8px 0; border-bottom:1px solid var(--line); }
  .w .t { flex:1; font-size:14px; }
  .w button { background:#21262d; color:var(--text); border:1px solid var(--line); border-radius:8px;
              padding:6px 10px; font-size:13px; }
  .empty { color:var(--dim); text-align:center; padding:30px 10px; }
  [dir=rtl] { text-align:right; }
</style>
</head>
<body>
<header><h1 id="title">OSprime</h1><a href="/">Full chat</a></header>
<main id="main"></main>
<nav>
  <button id="t-home" class="on">Home</button>
  <button id="t-chat">Chat</button>
  <button id="t-alerts">Alerts <span class="badge" id="badge" hidden></span></button>
</nav>
<script>
"use strict";
const $ = id => document.getElementById(id);
const main = $("main");
let helpers = {}, hid = "general", page = "home";
const convs = {};      // hid -> {sid, lines: [[cls, text]], busy}

function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; }
// Ids from getRandomValues: the UUID helper is secure-context only, and this is http.
function newId() {
  const b = crypto.getRandomValues(new Uint8Array(12));
  return "m-" + Array.from(b, x => x.toString(16).padStart(2, "0")).join("");
}
function rtl(t) { const m = /[A-Za-z֐-ࣿ]/.exec(t || ""); return !!m && /[֐-ࣿ]/.test(m[0]); }
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) { e.textContent = text; if (rtl(text)) e.dir = "rtl"; }
  return e;
}
async function getJSON(u) { const r = await fetch(u, {cache: "no-store"}); return r.json(); }
async function post(u, body) {
  const r = await fetch(u, {method: "POST", headers: {"Content-Type": "application/json"},
                            body: JSON.stringify(body || {})});
  return r.json();
}
function conv(h) {
  if (!convs[h]) {
    let sid = store("osprime-sid-" + h);
    if (!sid) { sid = newId(); store("osprime-sid-" + h, sid); }
    convs[h] = {sid, lines: [], busy: false};
  }
  return convs[h];
}

// ---- tabs -------------------------------------------------------------------
function go(p) {
  page = p;
  for (const t of ["home", "chat", "alerts"]) $("t-" + t).classList.toggle("on", t === p);
  $("title").textContent = p === "chat" ? (helpers[hid] ? helpers[hid].name : "Chat") : "OSprime";
  main.textContent = "";
  if (p === "home") drawHome();
  else if (p === "chat") drawChat();
  else drawAlerts();
}
$("t-home").onclick = () => go("home");
$("t-chat").onclick = () => go("chat");
$("t-alerts").onclick = () => go("alerts");

// ---- Home: the helpers and the chosen one's card -------------------------------
async function loadHelpers() {
  try {
    const d = await getJSON("/api/helpers");
    helpers = {}; for (const h of d.helpers) helpers[h.id] = h;
    const last = store("osprime-helper");
    hid = helpers[last] ? last : (helpers[d.last] ? d.last : "general");
    const n = d.unseen || 0;
    $("badge").hidden = !n; $("badge").textContent = n;
  } catch (e) {}
}
function drawHome() {
  const grid = el("div", "pills");
  for (const h of Object.values(helpers)) {
    const b = el("button", "pill" + (h.id === hid ? " on" : ""));
    const dot = el("img", "dot"); dot.alt = ""; dot.src = "/api/helpers/icon?id=" + encodeURIComponent(h.id);
    dot.onerror = () => { const c = el("div", "dot"); c.style.background = h.color; dot.replaceWith(c); };
    b.append(dot);
    b.append(el("div", "", h.name));
    if (h.alerts) b.append(el("span", "n", "🔔" + h.alerts));
    b.onclick = () => {
      if (h.id === hid) { go("chat"); return; }
      hid = h.id; store("osprime-helper", hid); go("home");
    };
    grid.append(b);
  }
  main.append(grid);
  const card = el("div", "card");
  card.append(el("div", "dim", (helpers[hid] ? helpers[hid].name : "") + ": looking…"));
  main.append(card);
  // Once, until it is on the home screen: how to put it there.
  let standalone = false;
  try { standalone = window.matchMedia("(display-mode: standalone)").matches || navigator.standalone === true; } catch (e) {}
  if (!standalone && store("osprime-tip") !== "no") {
    const tip = el("div", "card dim");
    tip.style.marginTop = "12px";
    tip.textContent = /iPhone|iPad/.test(navigator.userAgent)
      ? "Tip: put OSprime on your home screen — Share, then “Add to Home Screen”."
      : "Tip: put OSprime on your home screen — the browser menu (⋮), then “Add to Home screen”.";
    const x = el("button", "", "OK"); x.style.cssText = "float:right;background:none;border:0;color:#58a6ff";
    x.onclick = () => { store("osprime-tip", "no"); tip.remove(); };
    tip.prepend(x); main.append(tip);
  }
  getJSON("/api/helpers/card?id=" + encodeURIComponent(hid)).then(g => {
    if (page !== "home") return;
    card.textContent = "";
    card.append(el("h2", "", g.title || (helpers[hid] || {}).name || ""));
    for (const line of g.lines || []) {
      const r = el("div", "row");
      const a = el("span", "l" + (line[2] === "dim" ? " dim" : ""), line[0]);
      const b = el("span", line[2] || "", line[1]);
      r.append(a, b); card.append(r);
    }
    if (g.alerts) card.append(el("div", "up", "🔔 " + g.alerts + " new — see Alerts"));
    for (const w of g.watching || []) card.append(el("div", "dim", "👁 " + w));
    if (g.foot) card.append(el("div", "dim", g.foot));
    const talk = el("button", "go", hid === "general" ? "Open the conversation"
                                                       : "Talk to the " + (helpers[hid] || {}).name);
    talk.onclick = () => go("chat");
    card.append(talk);
  }).catch(() => { card.textContent = "Could not reach the computer."; });
}

// ---- Chat: each helper its own conversation -------------------------------------
let list = null;
function line(cls, text, keep) {
  const c = conv(hid);
  if (keep !== false) c.lines.push([cls, text]);
  if (page !== "chat" || !list) return null;
  const d = el("div", cls, text);
  list.append(d); main.scrollTop = main.scrollHeight;
  return d;
}
function drawChat() {
  const c = conv(hid);
  list = el("div");
  main.append(list);
  if (!c.lines.length)
    line("tool", hid === "general" ? "Ask anything." : "You are talking to the " + helpers[hid].name + ".", false);
  for (const [cls, text] of c.lines) list.append(el("div", cls, text));
  const form = el("form", "ask");
  const inp = el("input"); inp.type = "text"; inp.placeholder = "Ask…"; inp.enterKeyHint = "send";
  const mic = el("label", "", "🎤");
  const file = el("input"); file.type = "file"; file.accept = "audio/*"; file.setAttribute("capture", "");
  mic.append(file);
  const send = el("button", "", "➤"); send.type = "submit";
  form.append(inp, mic, send);
  main.append(form);
  form.onsubmit = e => { e.preventDefault(); const t = inp.value.trim(); if (t) { inp.value = ""; ask(t); } };
  // The phone's own recorder: live microphone access needs https.
  file.onchange = async () => {
    const f = file.files && file.files[0]; if (!f) return;
    const ext = (f.name.split(".").pop() || "m4a").toLowerCase();
    const note = line("tool", "Writing down what you said…", false);
    try {
      const r = await (await fetch("/api/stt", {method: "POST", headers: {"X-Audio-Ext": ext}, body: f})).json();
      if (note) note.remove();
      if (r.ok && r.text) ask(r.text); else line("tool", "⚠ " + (r.error || "No words heard"));
    } catch (e) { if (note) note.remove(); line("tool", "⚠ Could not send the recording"); }
    file.value = "";
  };
  main.scrollTop = main.scrollHeight;
  markRead(hid);
}

async function ask(text) {
  const h = hid, c = conv(h);
  if (c.busy) return;
  c.busy = true;
  line("msg you", text);
  let bubble = null, acc = "";
  try {
    const resp = await fetch("/api/chat", {method: "POST", headers: {"Content-Type": "application/json"},
                                           body: JSON.stringify({session: c.sid, text, helper: h})});
    const reader = resp.body.getReader(), dec = new TextDecoder();
    let buf = "";
    for (;;) {
      const {done, value} = await reader.read();
      if (done) break;
      buf += dec.decode(value, {stream: true});
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const raw = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!raw) continue;
        const m = JSON.parse(raw);
        if (m.type === "delta") {
          acc += m.text;
          if (hid === h && page === "chat") {
            if (!bubble) bubble = line("msg it", "", false);
            if (bubble) { bubble.textContent = acc; if (rtl(acc)) bubble.dir = "rtl"; }
          }
        } else if (m.type === "assistant") {
          c.lines.push(["msg it", m.text || acc]);
          if (bubble) bubble.textContent = m.text || acc; else if (hid === h) line("msg it", m.text || acc, false);
          bubble = null; acc = "";
        } else if (m.type === "tool_use") {
          bubble = null; acc = "";
          c.lines.push(["tool", "⚙ " + m.name + (m.detail ? ": " + m.detail : "")]);
          if (hid === h) line("tool", "⚙ " + m.name + (m.detail ? ": " + m.detail : ""), false);
        } else if (m.type === "confirm_elsewhere") {
          c.lines.push(["msg it", "🔒 This needs approval on the computer itself: " + m.text +
                        "\nIt waits there five minutes; if nobody approves it, it will not happen."]);
          if (hid === h) go("chat");
        } else if (m.type === "confirm") {
          if (hid === h) confirmBox(c, m);
        } else if (m.type === "status") {
          c.lines.push(["tool", m.text]); if (hid === h) line("tool", m.text, false);
        } else if (m.type === "error") {
          c.lines.push(["msg it", "⚠ " + m.text]); if (hid === h) line("msg it", "⚠ " + m.text, false);
        }
      }
    }
  } catch (e) {
    c.lines.push(["msg it", "⚠ Could not reach the computer. Is it on, and on the same network?"]);
    if (hid === h && page === "chat") go("chat");
  }
  c.busy = false;
}

function confirmBox(c, m) {
  const d = el("div", "msg it", "🔒 " + m.text);
  if (m.detail) d.append(el("div", "dim", m.detail));
  const b = el("div", "btns");
  const yes = el("button", "yes", "Allow"), no = el("button", "", "Don't");
  const answer = ok => { yes.disabled = no.disabled = true;
    post("/api/confirm", {session: c.sid, id: m.id, approved: ok}); };
  yes.onclick = () => answer(true); no.onclick = () => answer(false);
  b.append(yes, no); d.append(b);
  if (list) { list.append(d); main.scrollTop = main.scrollHeight; }
}

// ---- Alerts: what the watchers found, and the watchers ------------------------------
async function markRead(h) {
  try {
    const d = await getJSON("/api/alerts");
    const mine = d.alerts.filter(a => a.helper === h && !a.seen);
    if (!mine.length) return;
    for (const a of mine) line("msg it alert", "🔔 " + a.when + "  " + a.text);
    await post("/api/alerts/seen", {helper: h});
    loadHelpers();
  } catch (e) {}
}
async function drawAlerts() {
  let d, w;
  try { [d, w] = await Promise.all([getJSON("/api/alerts"), getJSON("/api/watchers")]); }
  catch (e) { main.append(el("div", "empty", "Could not reach the computer.")); return; }
  if (page !== "alerts") return;
  main.append(el("h2", "dim", "Alerts"));
  if (!d.alerts.length) main.append(el("div", "empty", "Nothing yet. Ask a helper, e.g. “tell me when bitcoin goes over 70000”."));
  for (const a of d.alerts.slice().reverse()) {
    const c = el("div", "msg it alert", (a.seen ? "" : "🔔 ") + a.when + " · " + a.helper_name + "\n" + a.text);
    c.style.maxWidth = "100%"; main.append(c);
  }
  if (d.alerts.some(a => !a.seen)) { post("/api/alerts/seen", {}).then(loadHelpers); }
  main.append(el("h2", "dim", "Watching"));
  if (!w.items.length) main.append(el("div", "dim", "Nothing."));
  for (const it of w.items) {
    const r = el("div", "w");
    r.append(el("div", "t", (it.paused ? "(paused) " : "") + it.helper_name + ": " + it.what));
    const p = el("button", "", it.paused ? "Resume" : "Pause");
    p.onclick = async () => { p.disabled = true; await post("/api/watchers/pause", {id: it.id, paused: !it.paused}); go("alerts"); };
    const x = el("button", "", "Remove");
    x.onclick = async () => { x.disabled = true; await post("/api/watchers/remove", {id: it.id}); go("alerts"); };
    r.append(p, x); main.append(r);
  }
}

loadHelpers().then(() => go("home"));
// While it is open, new alerts show on the tab. No push: that needs https and
// an outside service (Ehsan, 9 October: http for now).
setInterval(() => { if (document.visibilityState === "visible") loadHelpers(); }, 60000);
</script>
</body>
</html>
"""
