#!/usr/bin/env bash
# Toggle the OSprime chat window.
# Bound to the panel button and to the Super key.
#
# History: this used a PID file. That is unreliable — a dead PID can be
# reused by an unrelated process, so the script would decide the chat was
# open and "close" something else instead of launching. Pressing the key
# then appeared to work only every other time. Detect the real process
# instead, by the private profile directory no other program uses.

. "$(dirname "$0")/osprime-where.sh"
PROFILE="$OSPRIME_PRIV/chat-browser"
LOG="$OSPRIME_PRIV/chat.log"
STAMP="$OSPRIME_PRIV/chat.starting"

# The live USB has no assistant (docs/INSTALL.md): Super and "Open chat"
# explain that, and offer the installer, instead of a window that cannot
# connect to anything.
if [ -d "${OSPRIME_LIVE_DIR:-/run/archiso}" ]; then
    exec python3 "$(dirname "$0")/osprime-live-notice.py"
fi

exec 9>"$OSPRIME_PRIV/chat.lock"
flock -n 9 || exit 0        # a press is already being handled; ignore this one

running() { pgrep -f "user-data-dir=$PROFILE" >/dev/null 2>&1; }

# A profile left locked by a chromium that died — or that belonged to the
# live ISO under a different hostname — makes every later launch abort with
# "The profile appears to be in use by another Chromium process". If nothing
# is actually running, the lock is a lie; clear it.
if ! running; then
    rm -f "$PROFILE/SingletonLock" "$PROFILE/SingletonSocket" \
          "$PROFILE/SingletonCookie" 2>/dev/null
fi

if running; then
    pkill -f "user-data-dir=$PROFILE"
    rm -f "$STAMP"
    exit 0
fi

# Chromium needs a few seconds before its window maps. Without this guard an
# impatient second press kills the instance that is still starting.
if [ -f "$STAMP" ] && [ $(( $(date +%s) - $(cat "$STAMP" 2>/dev/null || echo 0) )) -lt 12 ]; then
    exit 0
fi
# My own web interface only — found and checked, never assumed to be
# whatever answers on a well-known port (docs/SECURITY.md, #11).
URL="$(osprime_web_url)"
if [ -z "$URL" ]; then
    echo "=== $(date) the assistant is not running for $(id -un)" >> "$LOG"
    command -v notify-send >/dev/null && \
        notify-send "OSprime" "The assistant is still starting — try again in a moment."
    exit 0
fi
date +%s > "$STAMP"

{ echo "=== $(date) launching chat ==="; } >> "$LOG"

FLAGS=(
  --ozone-platform=wayland
  --app="$URL"
  --no-first-run
  --no-default-browser-check
  --no-sandbox
  --disable-dev-shm-usage
  --disable-features=TranslateUI
  --password-store=basic
  --user-data-dir="$PROFILE"
  --window-size=900,700
)
# Silence the "unsupported command-line flag" infobar that --no-sandbox
# triggers; it covers the top of the chat window and alarms users for no
# reason on a single-purpose appliance.
FLAGS+=(--test-type)

# software rendering when there is no real GPU (VMs, UHD-only laptops)
[ -e /dev/dri/renderD128 ] || FLAGS+=(--disable-gpu --use-gl=swiftshader --in-process-gpu)

for b in chromium chromium-browser google-chrome-stable google-chrome; do
    if command -v "$b" >/dev/null; then
        "$b" "${FLAGS[@]}" >>"$LOG" 2>&1 &
        exit 0
    fi
done

echo "no chromium found; falling back to the terminal chat" >> "$LOG"
exec foot -F python3 /opt/osprime/ui/chat.py
