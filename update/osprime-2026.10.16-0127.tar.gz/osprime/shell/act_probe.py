"""Brainy's hands, through accessibility (docs/ACT.md; Ehsan, 13 October).

The guide (guide_probe.py) reads the accessibility tree to POINT at a
control. This uses the same tree to USE it: press a button, tick a box,
fill in a field — through AT-SPI's Action and EditableText interfaces.

No mouse and no keyboard are involved: the pointer does not move, the
window the person is working in keeps the focus, and the window Brainy
works in may sit behind it. That is what lets the two work at the same
time (Ehsan: "the user does their work and the assistant does its own").

The live desktop is touched only by list_windows(), controls() and the
do_* functions; everything else is plain data, tested in tests/test_act.py.
"""
import re
import time

import guide_probe as gp

# Windows Brainy never works in, whatever the model says.
TERMINALS = re.compile(r"\b(foot|kitty|alacritty|konsole|xterm|terminal|wezterm|tilix|terminator|"
                       r"urxvt|st-256color)\b", re.I)
AUTH = re.compile(r"authenticat|polkit|\bsudo\b|password|passphrase|keyring|pinentry|unlock|"
                  r"log ?in to|احراز|رمز", re.I)
OURS = re.compile(r"^osprime-(companion|desktop)|^waybar$", re.I)
# Preferred action names, as toolkits spell them.
PRESS = ("click", "press", "activate", "toggle", "select", "jump", "open", "expand or contract")


def _atspi():
    try:
        import gi
        gi.require_version("Atspi", "2.0")
        from gi.repository import Atspi
        try:
            Atspi.set_timeout(800, 3000)
        except Exception:
            pass
        return Atspi
    except Exception:
        return None


def window_ok(app: str, title: str) -> str:
    """'' when Brainy may work in this window, else why not."""
    if OURS.search(app or ""):
        return "that is OSprime's own companion"
    if TERMINALS.search(app or "") or TERMINALS.search(title or ""):
        return "Brainy never types or clicks in a terminal — that would be running commands"
    if AUTH.search(title or "") or AUTH.search(app or ""):
        return "Brainy never works in a window that asks for a password"
    return ""


def list_windows():
    """[{id, app, title, active, ok, _app, _win}] — every top-level window."""
    Atspi = _atspi()
    if Atspi is None:
        return []
    out = []
    desktop = Atspi.get_desktop(0)
    for i in range(desktop.get_child_count()):
        app = desktop.get_child_at_index(i)
        if app is None:
            continue
        aname = app.get_name() or ""
        for j in range(min(app.get_child_count(), 20)):
            win = app.get_child_at_index(j)
            if win is None:
                continue
            try:
                st = win.get_state_set()
                title = win.get_name() or ""
                active = st.contains(Atspi.StateType.ACTIVE)
                shown = st.contains(Atspi.StateType.SHOWING) or st.contains(Atspi.StateType.VISIBLE)
            except Exception:
                continue
            if not shown and not title:
                continue
            try:
                import desk
                on_desk = desk.on_desk(app.get_process_id())
            except Exception:
                on_desk = False
            out.append({"app": aname, "title": title, "active": active and not on_desk, "desk": on_desk,
                        "ok": window_ok(aname, title), "_app": app, "_win": win})
    for n, w in enumerate(out, 1):
        w["id"] = n
    return out


def controls(win_entry, budget: float = 2.0):
    """The usable controls of one window AND of the popups its app has open
    (a combo box's list is a window of its own). Each: {id, role, name,
    sensitive, actions, editable, _node}."""
    Atspi = _atspi()
    if Atspi is None or not win_entry:
        return []
    deadline = time.monotonic() + budget
    out = []
    roots = [win_entry["_win"]]
    try:                                  # the same app's other windows: popups, menus
        app = win_entry["_app"]
        for j in range(min(app.get_child_count(), 20)):
            w = app.get_child_at_index(j)
            if w is not None and w is not win_entry["_win"]:
                try:
                    if w.get_role_name() in ("menu", "popup menu", "window", "list", "combo box") or \
                            w.get_state_set().contains(Atspi.StateType.SHOWING):
                        roots.append(w)
                except Exception:
                    continue
    except Exception:
        pass

    def walk(node, depth):
        if node is None or depth > 60 or len(out) >= 400 or time.monotonic() > deadline:
            return
        try:
            role = node.get_role_name()
            states = node.get_state_set()
            if depth > 1 and not states.contains(Atspi.StateType.SHOWING):
                return
            enabled = states.contains(Atspi.StateType.SENSITIVE) or states.contains(Atspi.StateType.ENABLED)
        except Exception:
            return
        if role in gp.CLICKABLE and enabled:
            try:
                name = (node.get_name() or "").strip() or (node.get_description() or "").strip()
                acts = []
                ai = node.get_action_iface()
                if ai is not None:
                    acts = [(ai.get_action_name(k) or "").lower() for k in range(ai.get_n_actions())]
                editable = node.get_editable_text_iface() is not None
                if name or editable:
                    checked = None
                    if role in ("check box", "toggle button", "switch", "radio button", "check menu item",
                                "radio menu item"):
                        checked = states.contains(Atspi.StateType.CHECKED)
                    out.append({"role": role, "name": name[:80], "actions": acts, "editable": editable,
                                "checked": checked, "focused": states.contains(Atspi.StateType.FOCUSED),
                                "sensitive": role in gp.SENSITIVE_ROLES or bool(gp.SENSITIVE_WORDS.search(name)),
                                "_node": node})
            except Exception:
                pass
        try:
            n = node.get_child_count()
        except Exception:
            return
        for k in range(min(n, 300)):
            try:
                walk(node.get_child_at_index(k), depth + 1)
            except Exception:
                continue

    for r in roots:
        walk(r, 0)
    for n, c in enumerate(out, 1):
        c["id"] = n
    return out


def describe_windows(wins) -> str:
    return "\n".join(f'{w["id"]} | {w["app"]} | "{w["title"][:70]}"' + (" | front" if w["active"] else "")
                     + (" | desk" if w.get("desk") else "")
                     + (" | (not allowed)" if w["ok"] else "") for w in wins)


def describe_controls(ctrls) -> str:
    rows = []
    for c in ctrls:
        extra = ""
        if c.get("checked") is not None:
            extra = " | on" if c["checked"] else " | off"
        if c.get("editable"):
            extra += " | can type"
        rows.append(f'{c["id"]} | {c["role"]} | "{c["name"]}"{extra}')
    return "\n".join(rows)


def pick_action(names) -> int:
    for want in PRESS:
        for k, n in enumerate(names):
            if n == want:
                return k
    return 0 if names else -1


def do_press(ctrl) -> bool:
    node = ctrl.get("_node")
    if node is None:
        return False
    try:
        ai = node.get_action_iface()
        if ai is None:
            return False
        k = pick_action([(ai.get_action_name(i) or "").lower() for i in range(ai.get_n_actions())])
        return k >= 0 and bool(ai.do_action(k))
    except Exception:
        return False


def do_type(ctrl, text: str) -> bool:
    """Replaces what is in the field — never typed key by key, so nothing
    goes to whichever window has the keyboard."""
    node = ctrl.get("_node")
    if node is None:
        return False
    try:
        et = node.get_editable_text_iface()
        if et is None:
            return False
        return bool(et.set_text_contents(text))
    except Exception:
        return False
