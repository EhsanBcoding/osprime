"""Watch Brainy's own desk, and take it over (docs/ACT.md, step 3).

A small window showing the desk (shell/desk.py) once a second. "Take over"
sends your clicks and keys to the desk instead — for the moments Brainy
must not do itself: typing a password, signing in to a site.
"""
import os
import time

from gi.repository import Gdk, GdkPixbuf, GLib, Gtk

import desk

VIEW_W = 720
_view = None
WATCHING = "Watching — you can scroll. Take over to click or type."


class DeskView:
    def __init__(self):
        self.win = Gtk.Window(title="Brainy's desk")
        self.win.set_default_size(VIEW_W, int(VIEW_W * desk.HEIGHT / desk.WIDTH) + 48)
        self.win.connect("destroy", self._closed)
        self.win.connect("key-press-event", self._key)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        bar = Gtk.Box(spacing=6)
        self.take = Gtk.ToggleButton(label="Take over")
        self.take.set_tooltip_text("Your clicks and keys go to Brainy's desk (for signing in, "
                                   "or a password Brainy never types)")
        self.take.connect("toggled", self._toggled)
        self.note = Gtk.Label(label=WATCHING, xalign=0)
        bar.pack_start(self.take, False, False, 0)
        bar.pack_start(self.note, True, True, 0)
        box.pack_start(bar, False, False, 0)
        self.ev = Gtk.EventBox()
        self.img = Gtk.Image()
        self.ev.add(self.img)
        # Without these the box never gets the wheel (Ehsan, 14 October).
        self.ev.add_events(Gdk.EventMask.SCROLL_MASK | Gdk.EventMask.SMOOTH_SCROLL_MASK)
        self.ev.connect("button-press-event", self._click)
        self.ev.connect("scroll-event", self._scroll)
        box.pack_start(self.ev, True, True, 0)
        self.win.add(box)
        self.path = str(desk._runtime() / f"osprime-desk-view-{os.getpid()}.png")
        self.scale = VIEW_W / desk.WIDTH
        self.tick = GLib.timeout_add(1000, self._refresh)
        self._refresh()
        self.win.show_all()

    def _refresh(self):
        if not desk.running():
            self.note.set_text("Brainy's desk is closed.")
            self.img.clear()
            return True
        if desk.screenshot(self.path):
            try:
                pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(self.path, VIEW_W, -1, True)
                self.img.set_from_pixbuf(pb)
            except Exception:
                pass
        return True

    def _toggled(self, b):
        self.note.set_text("Taken over — your clicks and keys go to Brainy's desk." if b.get_active()
                           else WATCHING)

    def _point(self, ev):
        """Where on the desk the pointer is, or None off the picture."""
        alloc = self.img.get_allocation()
        pb = self.img.get_pixbuf()
        if pb is None:
            return None
        ox = (alloc.width - pb.get_width()) / 2
        oy = (alloc.height - pb.get_height()) / 2
        x = (ev.x - ox) / pb.get_width() * desk.WIDTH
        y = (ev.y - oy) / pb.get_height() * desk.HEIGHT
        return (x, y) if 0 <= x <= desk.WIDTH and 0 <= y <= desk.HEIGHT else None

    def _click(self, _w, ev):
        if not self.take.get_active():
            self.note.set_text("Press Take over first to click on Brainy's desk.")
            return True
        pt = self._point(ev)
        if pt:
            how = "right" if ev.button == 3 else ("double" if ev.type == Gdk.EventType._2BUTTON_PRESS else "left")
            desk.note_user_input()
            desk.click(pt[0], pt[1], how)
            GLib.timeout_add(300, self._refresh_once)
        return True

    def _scroll(self, _w, ev):
        """Scrolling is allowed while only watching: it presses nothing, and
        Brainy looks again if the page moved under it (desk.user_input)."""
        steps = wheel_steps(ev)
        if not steps:
            return True
        pt = self._point(ev) or (desk.WIDTH / 2, desk.HEIGHT / 2)
        desk.note_user_input()
        desk.scroll(pt[0], pt[1], steps)
        GLib.timeout_add(250, self._refresh_once)
        return True

    def _key(self, _w, ev):
        if not self.take.get_active():
            return False
        desk.note_user_input()
        name = Gdk.keyval_name(ev.keyval) or ""
        if name in desk.KEYS:
            desk.key(name)
        else:
            ch = chr(Gdk.keyval_to_unicode(ev.keyval) or 0)
            if ch and ch.isprintable():
                desk.type_text(ch)
        GLib.timeout_add(200, self._refresh_once)
        return True

    def _refresh_once(self):
        self._refresh()
        return False

    def _closed(self, *_):
        global _view
        GLib.source_remove(self.tick)
        try:
            os.unlink(self.path)
        except OSError:
            pass
        _view = None


_smooth = [0.0]


def wheel_steps(ev) -> int:
    """Wheel clicks from a GTK scroll event: +down, -up. Touchpads send
    smooth deltas; they are added up until one whole click."""
    d = ev.direction
    if d == Gdk.ScrollDirection.DOWN:
        return 3
    if d == Gdk.ScrollDirection.UP:
        return -3
    if d == Gdk.ScrollDirection.SMOOTH:
        ok, _dx, dy = ev.get_scroll_deltas()
        if not ok:
            return 0
        _smooth[0] += dy
        whole = int(_smooth[0])
        _smooth[0] -= whole
        return max(-10, min(10, whole * 3))
    return 0


def taken_over() -> bool:
    return _view is not None and _view.take.get_active()


def open_view():
    global _view
    if _view is None:
        _view = DeskView()
    else:
        _view.win.present()


def is_open() -> bool:
    return _view is not None
