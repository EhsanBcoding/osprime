#!/usr/bin/env bash
# Outside access through Tailscale (docs/PUSH.md; Ehsan, 15 October).
#
#   osprime-outside.sh on     start tailscaled at every boot, and let the
#                             person who asked run it (operator)
#   osprime-outside.sh off    stop it, sign this computer out, and stop
#                             starting it
#
# Run as root, only through Settings with an administrator's OWN password
# (`sudo -S -k`, ui/outside.py) — there is no password-free rule for it.
# The person it is set up for is the one who ran sudo; nothing on the
# command line chooses it.
set -u
die() { echo "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" -eq 0 ] || die "run as root"
CALLER="${SUDO_USER:-}"
printf '%s' "$CALLER" | grep -Eq '^[a-z_][a-z0-9_-]{0,30}$' || die "no person to set it up for"
case "$CALLER" in root|greeter|nobody) die "not for $CALLER";; esac
command -v tailscale >/dev/null || die "Tailscale is not installed yet (it comes with the next update)."

case "${1:-}" in
on)
    systemctl enable --now tailscaled.service >/dev/null 2>&1 || die "tailscaled did not start"
    for _ in $(seq 1 20); do
        tailscale status --json >/dev/null 2>&1 && break
        [ -S /run/tailscale/tailscaled.sock ] && break
        sleep 0.5
    done
    # Before the first sign-in `set` may refuse; `up` with a short timeout
    # stores the same preference and gives up waiting for the sign-in, which
    # the person then does themselves (Settings shows the link).
    tailscale set --operator="$CALLER" >/dev/null 2>&1 \
        || tailscale up --operator="$CALLER" --timeout=3s >/dev/null 2>&1 || true
    echo "Tailscale is on for $CALLER."
    ;;
off)
    tailscale logout >/dev/null 2>&1 || true
    systemctl disable --now tailscaled.service >/dev/null 2>&1 || true
    echo "Tailscale is off."
    ;;
*)
    die "say on or off"
    ;;
esac
