#!/usr/bin/env bash
# Open the web browser.
#
# Chromium needs the same flags here that the chat window needs: without a
# full user session it will not start sandboxed, and under Wayland with no X
# server the default X11 path exits immediately. Chromium's own menu entry
# has neither, which is why clicking it appeared to do nothing.
#
# One script so the flags live in a single place — the chat, Settings and the
# browser have already drifted apart once when they each kept their own copy.

# Clear a lock left behind by a different machine or a dead process.
#
# Installing copies the home directory out of the live system, whose hostname
# is archiso. Chromium stores its lock as <hostname>-<pid> and refuses to
# start when it sees another computer's name, so the browser was unusable on
# every freshly installed machine. Only genuinely stale locks are removed:
# one held by a live process on this host is left alone.
# One log per user, not one shared file.
#
# /tmp is sticky and Linux stops one user writing to another user's file
# there. The agent ran this as root, the log already belonged to osprime,
# the redirect on the very first line failed, and the script died before it
# could exec the browser — so every page the assistant tried to open failed
# with "Permission denied" on a log file.
BROWSER_LOG="${OSPRIME_BROWSER_LOG:-/tmp/osprime-browser-$(id -u).log}"

PROFILE_DIR="${CHROME_PROFILE:-$HOME/.config/chromium}"
LOCK="$PROFILE_DIR/SingletonLock"
if [ -L "$LOCK" ]; then
    target="$(readlink "$LOCK")"        # looks like: archiso-11864
    lock_host="${target%-*}"
    lock_pid="${target##*-}"
    # uname -n, not hostname: the hostname command (inetutils) is not on
    # OSprime, so the host name came out empty, every lock looked foreign, the
    # running browser's lock was deleted, and each opened page started a
    # second browser on the same profile — a "Profile error occurred"
    # window per page (7 October, laptop).
    this_host="$(uname -n 2>/dev/null || cat /proc/sys/kernel/hostname)"
    if [ "$lock_host" != "$this_host" ] || ! kill -0 "$lock_pid" 2>/dev/null; then
        echo "clearing stale profile lock ($target)" >> "$BROWSER_LOG"
        rm -f "$PROFILE_DIR"/Singleton*
    fi
fi

FLAGS=(
  --ozone-platform=wayland
  # The companion's guide reads the page's buttons through AT-SPI
  # (docs/COMPANION.md, phase 4); Chromium only offers them when asked.
  --force-renderer-accessibility
  --no-first-run
  --no-default-browser-check
  --no-sandbox
  --test-type
  --disable-dev-shm-usage
  --disable-features=TranslateUI
  --password-store=basic
)
# Software rendering where there is no GPU (VMs, integrated-only laptops).
[ -e /dev/dri/renderD128 ] || FLAGS+=(--disable-gpu --use-gl=swiftshader --in-process-gpu)

# Opened with nothing to show (Super+B, the Apps menu): ask for the New Tab
# page explicitly. 28 September: a profile carried over from the old
# single-account setup opened http://localhost:8080 — the chat's address
# before every person got their own port — on every start, and showed
# "This site can't be reached". A page given on the command line replaces
# the remembered start-up pages; it does not touch bookmarks or history.
[ $# -eq 0 ] && set -- "chrome://newtab/"

for b in chromium chromium-browser google-chrome-stable google-chrome; do
    if command -v "$b" >/dev/null; then
        exec "$b" "${FLAGS[@]}" "$@" >>"$BROWSER_LOG" 2>&1
    fi
done

echo "no browser installed" >> "$BROWSER_LOG"
exit 1
