# osprime_read_env FILE — the OSPRIME_* settings in FILE, as DATA (docs/SECURITY.md #17).
#
# Sourced by the session's autostart and by osprime-companion.sh, in plain
# sh. Until 15 October they ran desktop.env with `.`, so whatever the file
# said was run as the person whose session it was — and the machine's copy
# could be written by others. Now each line is only ever a name and a value:
#   * only OSPRIME_NAME=value lines, the name in capitals, digits and _;
#   * the value is taken as it stands, one pair of quotes removed — never
#     expanded, so $(…), `…`, ${…} and ; mean nothing here.
osprime_read_env() {
    [ -r "$1" ] || return 0
    while IFS= read -r _osp_line || [ -n "$_osp_line" ]; do
        case "$_osp_line" in
            OSPRIME_*=*) ;;
            *) continue ;;
        esac
        _osp_key="${_osp_line%%=*}"
        _osp_val="${_osp_line#*=}"
        case "$_osp_key" in
            *[!A-Z0-9_]*) continue ;;
        esac
        case "$_osp_val" in
            \"*\") _osp_val="${_osp_val#\"}"; _osp_val="${_osp_val%\"}" ;;
            \'*\') _osp_val="${_osp_val#\'}"; _osp_val="${_osp_val%\'}" ;;
        esac
        export "$_osp_key=$_osp_val"
    done < "$1"
    unset _osp_line _osp_key _osp_val
}
