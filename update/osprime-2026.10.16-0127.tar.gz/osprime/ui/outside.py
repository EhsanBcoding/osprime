"""Access from outside the home, and https for notifications (docs/PUSH.md;
Ehsan, 15 October: Tailscale, together with ntfy).

Tailscale puts the computer and the phone in one private network of their
own, wherever each of them is. Nothing is opened on the internet: the
computer listens on its Tailscale address only, which only the person's
own devices can reach. Tailscale also hands out a real certificate for
the computer's name (machine.tailnet.ts.net), and that https is what lets
the phone's browser accept notifications (Web Push).

  * Switching it on needs an administrator's own password (it starts the
    tailscaled service and lets this person run it): shell/osprime-outside.sh
    through `sudo -S -k`, like People and Secure Boot.
  * Signing in is the person's own: Tailscale gives a link, they open it and
    sign in to their (free) Tailscale account. The phone signs in to the
    same account in the Tailscale app.
  * The listener here is the remote listener's twin (web.py, OutsideHandler):
    same pairing, same device keys, same allowlists (remote.py), on PORT with
    TLS.
"""
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import threading

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "agent"))
import paths  # noqa: E402

SCRIPT = "/opt/osprime/shell/osprime-outside.sh"
PORT = int(os.environ.get("OSPRIME_OUTSIDE_PORT", "8443"))
TAILSCALE = os.environ.get("OSPRIME_TAILSCALE", "tailscale")
_login = {"url": "", "proc": None, "error": ""}
_lock = threading.Lock()


def _folder() -> pathlib.Path:
    d = paths.state_dir() / "outside"
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o700)
    return d


def cert_files():
    d = _folder()
    return d / "cert.pem", d / "key.pem"


def installed() -> bool:
    return bool(shutil.which(TAILSCALE))


def _ts(*args, timeout=20):
    return subprocess.run([TAILSCALE, *args], capture_output=True, text=True, timeout=timeout)


def state() -> dict:
    """{installed, running, backend, name, ip, ip6, login_url}"""
    out = {"installed": installed(), "running": False, "backend": "", "name": "", "ip": "", "ip6": "",
           "login_url": _login["url"], "login_error": _login["error"]}
    if not out["installed"]:
        return out
    try:
        r = _ts("status", "--json", timeout=10)
        st = json.loads(r.stdout or "{}")
    except Exception:
        return out
    out["backend"] = st.get("BackendState", "")
    me = st.get("Self") or {}
    out["name"] = str(me.get("DNSName") or "").rstrip(".")
    for ip in me.get("TailscaleIPs") or []:
        if ":" in ip:
            out["ip6"] = out["ip6"] or ip
        else:
            out["ip"] = out["ip"] or ip
    out["running"] = out["backend"] == "Running" and bool(out["name"] and out["ip"])
    if st.get("AuthURL") and not out["login_url"]:
        out["login_url"] = st["AuthURL"]
    return out


def tailnet_ip(ip: str) -> bool:
    """A Tailscale address: 100.64.0.0/10 or fd7a:115c:a1e0::/48. Only the
    outside listener accepts these (remote.allowed_client)."""
    import ipaddress
    try:
        a = ipaddress.ip_address(ip.split("%")[0])
    except ValueError:
        return False
    if isinstance(a, ipaddress.IPv6Address) and a.ipv4_mapped:
        a = a.ipv4_mapped
    if isinstance(a, ipaddress.IPv4Address):
        return a in ipaddress.ip_network("100.64.0.0/10")
    return a in ipaddress.ip_network("fd7a:115c:a1e0::/48")


# ---- switching it on and off (an administrator) ------------------------------------------
def admin_run(admin_password: str, action: str) -> dict:
    if action not in ("on", "off"):
        return {"ok": False, "message": "unknown request"}
    import people
    if not people.is_admin():
        return {"ok": False, "message": "Only an administrator can switch this on. Ask one to do it."}
    if not admin_password:
        return {"ok": False, "message": "Type your own password to confirm."}
    try:
        r = subprocess.run(["sudo", "-S", "-k", "-p", "", "/usr/bin/bash", SCRIPT, action],
                           input=admin_password + "\n", text=True, capture_output=True, timeout=120)
    except Exception as e:
        return {"ok": False, "message": f"could not run: {e}"}
    if re.search(r"incorrect password|Sorry, try again|no password was provided", r.stderr or "", re.I):
        return {"ok": False, "message": "Your password was not accepted."}
    if r.returncode != 0:
        msg = " ".join(l.replace("ERROR: ", "") for l in (r.stderr or "").splitlines()
                       if l.strip() and "[sudo]" not in l)
        return {"ok": False, "message": msg or "It did not work."}
    return {"ok": True, "message": "Done."}


# ---- signing in (the person) ----------------------------------------------------------------
def login() -> dict:
    """Start `tailscale up` as this person (the operator) and return the link
    to open. It keeps waiting in the background until they have signed in."""
    with _lock:
        p = _login["proc"]
        if p and p.poll() is None and _login["url"]:
            return {"ok": True, "url": _login["url"]}
        _login.update(url="", error="")
        try:
            p = subprocess.Popen([TAILSCALE, "up", "--timeout=600s"], stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True)
        except Exception as e:
            return {"ok": False, "message": f"could not start Tailscale: {e}"}
        _login["proc"] = p
    found = threading.Event()

    def read():
        for line in p.stdout:
            m = re.search(r"https://login\.tailscale\.com/\S+", line)
            if m:
                _login["url"] = m.group(0)
                found.set()
            elif "access denied" in line.lower() or "checkprefs" in line.lower():
                _login["error"] = line.strip()
                found.set()
        p.wait()
        if p.returncode not in (0, None) and not _login["url"]:
            _login["error"] = _login["error"] or "Tailscale did not start"
        found.set()
    threading.Thread(target=read, daemon=True).start()
    found.wait(30)
    if _login["url"]:
        return {"ok": True, "url": _login["url"]}
    if p.poll() == 0:
        return {"ok": True, "url": "", "message": "Already signed in."}
    return {"ok": False, "message": _login["error"] or "Tailscale gave no sign-in link. Try again."}


def get_cert(name: str = "") -> dict:
    """Tailscale's certificate for this computer's name (renewed when due)."""
    name = name or state().get("name", "")
    if not name:
        return {"ok": False, "message": "not signed in to Tailscale yet"}
    cert, key = cert_files()
    try:
        r = _ts("cert", "--cert-file", str(cert), "--key-file", str(key), name, timeout=120)
    except Exception as e:
        return {"ok": False, "message": str(e)}
    if r.returncode != 0:
        err = (r.stderr or r.stdout or "").strip()
        if re.search(r"HTTPS|certificate|not enabled|support", err, re.I):
            return {"ok": False, "message": "HTTPS is off in your Tailscale account. Open "
                    "https://login.tailscale.com/admin/dns, turn on MagicDNS and HTTPS Certificates, "
                    "then try again.", "detail": err[-300:]}
        return {"ok": False, "message": err[-300:] or "no certificate"}
    for f in (cert, key):
        os.chmod(f, 0o600)
    return {"ok": True}


def have_cert() -> bool:
    cert, key = cert_files()
    return cert.is_file() and key.is_file()


# ---- the setting (kept with remote access, remote.py) ------------------------------------------
def wanted() -> bool:
    import remote
    return bool(remote._load().get("outside"))


def set_wanted(on: bool) -> bool:
    import remote
    with remote._file_lock():
        s = remote._load()
        s["outside"] = bool(on)
        return remote._save(s)


def address() -> str:
    """https://name:PORT when outside access is on and ready, else ''."""
    if not (wanted() and have_cert()):
        return ""
    name = state().get("name", "")
    return f"https://{name}:{PORT}" if name else ""
