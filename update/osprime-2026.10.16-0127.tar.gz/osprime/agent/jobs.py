"""OSprime background jobs: run long shell tasks async, track status,
and queue a notification when each finishes."""

import subprocess
import threading

import permissions
import time
import uuid


class JobManager:
    def __init__(self, on_finish=None):
        self._jobs = {}
        self._lock = threading.Lock()
        self._notifications = []
        self._on_finish = on_finish  # optional callback(job)

    def start(self, command: str, label: str = "") -> str:
        jid = uuid.uuid4().hex[:8]
        job = {
            "id": jid, "command": command, "label": label or command[:40],
            "status": "running", "output": "", "code": None,
            "started": time.time(), "finished": None,
        }
        with self._lock:
            self._jobs[jid] = job
        try:
            import activity       # beside Brainy while it runs (agent/activity.py)
            job["activity"] = activity.begin(job["label"], "job")
        except Exception:
            job["activity"] = None
        threading.Thread(target=self._run, args=(job,), daemon=True).start()
        return jid

    def _run(self, job):
        try:
            p = subprocess.run(job["command"], shell=True, capture_output=True,
                               text=True, timeout=3600)
            # Redacted when stored (docs/SECURITY.md, #14): job_status
            # returned the raw output, keys and all, to the model.
            out = permissions.redact(p.stdout + p.stderr)[-8000:]
            code = p.returncode
        except subprocess.TimeoutExpired:
            out, code = "job timed out after 1h", 124
        except Exception as e:
            out, code = f"job error: {e}", 1
        with self._lock:
            job.update(status="done" if code == 0 else "failed",
                       output=out, code=code, finished=time.time())
            self._notifications.append({
                "id": job["id"], "label": job["label"],
                "status": job["status"], "code": code,
            })
        if job.get("activity"):
            try:
                import activity
                activity.end(job["activity"], ok=code == 0)
            except Exception:
                pass
        if self._on_finish:
            try:
                self._on_finish(job)
            except Exception:
                pass

    def status(self, jid: str) -> dict:
        with self._lock:
            job = self._jobs.get(jid)
            return dict(job) if job else {}

    def list(self) -> list:
        with self._lock:
            return [
                {k: j[k] for k in ("id", "label", "status", "code")}
                for j in self._jobs.values()
            ]

    def drain_notifications(self) -> list:
        """Return and clear pending finish-notifications."""
        with self._lock:
            n, self._notifications = self._notifications, []
            return n
