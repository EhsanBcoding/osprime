"""Notifications on the phone (docs/PUSH.md; Ehsan, 15 October).

Two ways, both chosen per paired phone (ui/remote.py keeps them with the
device):

  * Web Push — the real thing. The phone's browser hands us a subscription
    (an address at Google's, Apple's or Mozilla's push service and two
    keys). We encrypt every message for that phone alone (RFC 8291,
    aes128gcm) and sign the request with our own VAPID key (RFC 8292): the
    push service carries it but cannot read it. Needs the page on https —
    outside access (ui/outside.py, Tailscale) gives that.
  * ntfy — the simple one, for any phone with the ntfy app. No https
    needed. The message says only WHAT happened ("A watcher fired"), never
    the content, because ntfy.sh can read what it carries (Ehsan agreed).

Everything is notified (Ehsan): watchers, finished videos and deep
answers, reminders, and Brainy's own suggestions; each phone can switch
kinds off. Approvals are never sent: they are made at the computer.
"""
import base64
import json
import os
import pathlib
import re
import secrets
import struct
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import paths

KINDS = {
    "watcher": ("A watcher fired", "🔔"),
    "video": ("Your video is ready", "🎬"),
    "deep": ("Your deep answer is ready", "🧠"),
    "reminder": ("A reminder", "⏰"),
    "suggestion": ("Brainy has a suggestion", "💡"),
}
PER_HOUR = 30                 # per phone; more than that is a loop, not news
TTL = 24 * 3600
NTFY_DEFAULT = "https://ntfy.sh"
SUBJECT = "https://ehsanbcoding.github.io/osprime"   # VAPID "sub": who sends (RFC 8292)

# Only real push services. A subscription is data a phone sent us; without
# this list it could make the computer POST to any address (its router's
# admin page, say).
PUSH_HOSTS = re.compile(r"^(fcm\.googleapis\.com|android\.googleapis\.com|"
                        r"updates\.push\.services\.mozilla\.com|"
                        r"([a-z0-9-]+\.)*push\.apple\.com|"
                        r"([a-z0-9-]+\.)*notify\.windows\.com)$", re.I)

_sent = {}                    # device id -> [timestamps]
_lock = threading.Lock()


def _remote():
    ui = str(pathlib.Path(__file__).resolve().parent.parent / "ui")
    if ui not in sys.path:
        sys.path.append(ui)
    import remote
    return remote


def b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def b64u_dec(s: str) -> bytes:
    s = str(s or "")
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


# ---- our VAPID key -------------------------------------------------------------------
def _key_file() -> pathlib.Path:
    return paths.data_dir() / "push-vapid.pem"


def _private_key():
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    f = _key_file()
    try:
        return serialization.load_pem_private_key(f.read_bytes(), None)
    except Exception:
        pass
    key = ec.generate_private_key(ec.SECP256R1())
    pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                            serialization.NoEncryption())
    f.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(f, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as fh:
        fh.write(pem)
    return key


def public_key() -> str:
    """What the phone passes to pushManager.subscribe (applicationServerKey)."""
    from cryptography.hazmat.primitives import serialization
    raw = _private_key().public_key().public_bytes(serialization.Encoding.X962,
                                                   serialization.PublicFormat.UncompressedPoint)
    return b64u(raw)


def available() -> str:
    """'' when Web Push can be used here, else why not."""
    try:
        import cryptography  # noqa: F401
    except ImportError:
        return "python-cryptography is not installed yet (it comes with the next update)"
    return ""


def vapid_header(endpoint: str, now=None) -> str:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec, utils
    u = urllib.parse.urlsplit(endpoint)
    head = b64u(json.dumps({"typ": "JWT", "alg": "ES256"}, separators=(",", ":")).encode())
    claims = b64u(json.dumps({"aud": f"{u.scheme}://{u.netloc}", "exp": int((now or time.time()) + 12 * 3600),
                              "sub": SUBJECT}, separators=(",", ":")).encode())
    signing = f"{head}.{claims}".encode()
    der = _private_key().sign(signing, ec.ECDSA(hashes.SHA256()))
    r, s = utils.decode_dss_signature(der)
    sig = b64u(r.to_bytes(32, "big") + s.to_bytes(32, "big"))
    return f"vapid t={head}.{claims}.{sig}, k={public_key()}"


# ---- RFC 8291: the message, encrypted for one phone ------------------------------------
def encrypt(p256dh: str, auth: str, plaintext: bytes, _salt=None, _key=None) -> bytes:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    ua_public = b64u_dec(p256dh)
    auth_secret = b64u_dec(auth)
    if len(ua_public) != 65 or len(auth_secret) < 16:
        raise ValueError("not a push subscription")
    as_key = _key or ec.generate_private_key(ec.SECP256R1())
    as_public = as_key.public_key().public_bytes(serialization.Encoding.X962,
                                                 serialization.PublicFormat.UncompressedPoint)
    shared = as_key.exchange(ec.ECDH(), ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), ua_public))
    ikm = HKDF(hashes.SHA256(), 32, salt=auth_secret,
               info=b"WebPush: info\x00" + ua_public + as_public).derive(shared)
    salt = _salt or os.urandom(16)
    cek = HKDF(hashes.SHA256(), 16, salt=salt, info=b"Content-Encoding: aes128gcm\x00").derive(ikm)
    nonce = HKDF(hashes.SHA256(), 12, salt=salt, info=b"Content-Encoding: nonce\x00").derive(ikm)
    body = AESGCM(cek).encrypt(nonce, plaintext + b"\x02", None)      # one record, the last
    return salt + struct.pack(">I", 4096) + bytes([len(as_public)]) + as_public + body


def _post(url, data, headers, timeout=15):
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code


def _test_hosts():
    # Only the tests point this at a stand-in service on this machine.
    return [h for h in os.environ.get("OSPRIME_PUSH_TEST_HOSTS", "").split(",") if h]


def endpoint_ok(endpoint: str) -> bool:
    try:
        u = urllib.parse.urlsplit(str(endpoint))
    except ValueError:
        return False
    if u.netloc in _test_hosts():
        return True
    return u.scheme == "https" and bool(PUSH_HOSTS.match(u.hostname or "")) and len(endpoint) < 1000


def send_web(sub: dict, message: dict) -> int:
    """HTTP status from the push service (201 = taken, 404/410 = gone)."""
    endpoint = str(sub.get("endpoint") or "")
    if not endpoint_ok(endpoint):
        return 400
    keys = sub.get("keys") or {}
    body = encrypt(keys.get("p256dh", ""), keys.get("auth", ""),
                   json.dumps(message, ensure_ascii=False).encode()[:3000])
    return _post(endpoint, body, {"Authorization": vapid_header(endpoint), "TTL": str(TTL),
                                  "Content-Encoding": "aes128gcm", "Urgency": "normal",
                                  "Content-Type": "application/octet-stream"})


def send_ntfy(server: str, topic: str, kind: str, click: str = "") -> int:
    """Only what happened, never the content (ntfy.sh can read it)."""
    title, _ = KINDS.get(kind, ("Notifications work", ""))
    headers = {"Title": "Brainy", "Tags": "brain", "Priority": "default"}
    if click.startswith(("https://", "http://")):
        headers["Click"] = click
    url = server.rstrip("/") + "/" + urllib.parse.quote(topic)
    return _post(url, title.encode(), headers)


# ---- what happened -> which phones ----------------------------------------------------------
def kind_of(alert: dict) -> str:
    text = str(alert.get("text") or "")
    if alert.get("video") or text.startswith("🎬"):
        return "video"
    if "answer" in alert or text.startswith("🧠"):
        return "deep"
    if alert.get("kind") in KINDS:
        return alert["kind"]
    if text.startswith("⏰"):
        return "reminder"
    if alert.get("proactive"):
        return "suggestion"
    return "watcher"


def _allowed(dev_id: str) -> bool:
    now = time.time()
    with _lock:
        recent = [t for t in _sent.get(dev_id, []) if now - t < 3600]
        if len(recent) >= PER_HOUR:
            _sent[dev_id] = recent
            return False
        _sent[dev_id] = recent + [now]
        return True


def notify(alert: dict, wait: bool = False) -> list:
    """Send one thing that happened to every phone that wants it. Never raises;
    runs in the background unless wait (tests). -> [(device, way, status)]"""
    out = []

    def go():
        try:
            rm = _remote()
            kind = kind_of(alert)
            title, icon = KINDS[kind]
            text = re.sub(r"^\W+\s*", "", str(alert.get("text") or ""))[:240]
            msg = {"title": f"{icon} {title}", "body": text, "url": "/m#alerts",
                   "tag": str(alert.get("id") or secrets.token_hex(4))}
            for dev in rm.push_targets():
                if kind not in dev["kinds"] or not _allowed(dev["id"]):
                    continue
                if dev.get("web"):
                    try:
                        st = send_web(dev["web"], msg)
                    except Exception as e:
                        st = f"error: {e}"
                    out.append((dev["id"], "web", st))
                    if st in (404, 410):
                        rm.set_push(dev["id"], web=None)       # the phone unsubscribed
                if dev.get("ntfy"):
                    try:
                        st = send_ntfy(rm.ntfy_server(), dev["ntfy"], kind, dev.get("click", ""))
                    except Exception as e:
                        st = f"error: {e}"
                    out.append((dev["id"], "ntfy", st))
        except Exception as e:
            print(f"push: {e}", flush=True)
    if wait:
        go()
    else:
        threading.Thread(target=go, daemon=True, name="push").start()
    return out


def test(dev_id: str) -> list:
    """A test notification to one phone, now. -> [(way, status)]"""
    out = []
    rm = _remote()
    for dev in rm.push_targets():
        if dev["id"] != dev_id or not _allowed(dev_id):
            continue
        msg = {"title": "🔔 Brainy", "body": "Notifications work.", "url": "/m", "tag": "test"}
        if dev.get("web"):
            try:
                st = send_web(dev["web"], msg)
            except Exception as e:
                st = f"error: {e}"
            out.append(("web", st))
            if st in (404, 410):
                rm.set_push(dev_id, web=None)
        if dev.get("ntfy"):
            try:
                st = send_ntfy(rm.ntfy_server(), dev["ntfy"], "test", dev.get("click", ""))
            except Exception as e:
                st = f"error: {e}"
            out.append(("ntfy", st))
    return out
