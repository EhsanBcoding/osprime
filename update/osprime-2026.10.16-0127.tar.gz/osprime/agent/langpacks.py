"""The words OSprime listens for, one file per language (docs/LANGUAGES.md;
Ehsan, 15 October: buyers are not all Persian).

agent/lang/<code>.json holds, for one language:

  routing      {group: [hints]}   which tool groups a request needs
                                  (toolgroups.py). A hint matches at the start
                                  of a word; in a pack with "whole_words", it
                                  must be the whole word unless it ends in *.
  strong       {group: [hints]}   verbs that outweigh the nouns around them
  patterns     [[group, regex, points]]  evidence a word list cannot express
  act_prefix   [regex]            "do it for me: …" (agent.act_wanted)
  web_words    [regex]            a job that is on the web (agent.act_wanted)
  deep_prefix  [regex]            "think deeply about …" (deep.wanted)
  irreversible [regex]            send / pay / delete … (guide_probe, act_logic)
  final        [regex]            install / shut down / sign out … (act_logic)
  skills       {skill: [triggers]}  extra trigger phrases for built-in skills
  stopwords    [words]            words that carry no meaning for skills

Every pack is used at once, whatever language the person chose: Ehsan's
screen is in English and he types Persian, and a safety word must be
recognised in any language. English and Persian are the reference packs;
French and German came on 15 October; the other ten languages carry only
the safety words (irreversible, final) until a buyer asks for them.
"""
import json
import pathlib
import re

DIR = pathlib.Path(__file__).resolve().parent / "lang"
_cache = {"packs": None}


def packs() -> list:
    if _cache["packs"] is None:
        out = []
        # English first: its routing order is the order of the groups, and
        # ties in toolgroups.pick_groups go to that order.
        files = sorted(DIR.glob("*.json"), key=lambda p: (p.stem != "en", p.stem))
        for f in files:
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
            except Exception as e:
                print(f"langpacks: {f.name} is broken: {e}", flush=True)
                continue
            d.setdefault("code", f.stem)
            out.append(d)
        _cache["packs"] = out
    return _cache["packs"]


def codes() -> list:
    return [p["code"] for p in packs()]


def routing():
    """({group: [hints]}, {hints that must be a whole word})"""
    groups, whole = {}, set()
    for p in packs():
        for g, hints in (p.get("routing") or {}).items():
            lst = groups.setdefault(g, [])
            for h in hints:
                # The same word in two packs counts once, and keeps the first
                # pack's way of matching ("app" in German must not turn the
                # English "app" into a whole word: "apps" stopped reaching the
                # app tools; "video*" beside the English "video" counted twice).
                if h in lst or h.rstrip("*") in lst:
                    continue
                lst.append(h)
                if p.get("whole_words") and not h.endswith("*"):
                    whole.add(h)
    return groups, whole


def strong() -> dict:
    out = {}
    for p in packs():
        for g, hints in (p.get("strong") or {}).items():
            out.setdefault(g, [])
            out[g] += [h for h in hints if h not in out[g]]
    return out


def patterns() -> list:
    return [(g, re.compile(rx), int(pts)) for p in packs() for g, rx, pts in (p.get("patterns") or [])]


def fragments(section: str) -> list:
    return [f for p in packs() for f in (p.get(section) or [])]


def prefix_regex(section: str, tail: str = r"\s*[:،,\-–]?\s*"):
    """^ one of the section's openings, and what follows it."""
    return re.compile(r"^\s*(?:" + "|".join(f"(?:{f})" for f in fragments(section)) + ")" + tail, re.I)


def any_regex(section: str):
    return re.compile("|".join(f"(?:{f})" for f in fragments(section)), re.I)


def skill_triggers(name: str) -> list:
    return [t for p in packs() for t in ((p.get("skills") or {}).get(name) or [])]


def stopwords() -> set:
    return {w for p in packs() for w in (p.get("stopwords") or [])}


def check() -> list:
    """Every pack well formed and every regex compiles (release.sh, tests)."""
    bad = []
    known = {"code", "name", "whole_words", "routing", "strong", "patterns", "act_prefix",
             "web_words", "deep_prefix", "irreversible", "final", "skills", "stopwords", "note"}
    for p in packs():
        c = p.get("code", "?")
        for k in p:
            if k not in known:
                bad.append(f"langpacks: {c} has an unknown section {k!r}")
        for sec in ("act_prefix", "web_words", "deep_prefix", "irreversible", "final"):
            for f in p.get(sec) or []:
                try:
                    re.compile(f)
                except re.error as e:
                    bad.append(f"langpacks: {c} {sec} {f!r}: {e}")
        for item in p.get("patterns") or []:
            try:
                re.compile(item[1])
            except (re.error, IndexError, TypeError) as e:
                bad.append(f"langpacks: {c} pattern {item!r}: {e}")
        if not p.get("irreversible") or not p.get("final"):
            bad.append(f"langpacks: {c} has no safety words")
    return bad
