"""Brainy's wardrobe (step 5C, a Coucou idea approved 9 October).

Things to wear, drawn here in code over the character: no pictures to
license, and each one fits any character pack because it is placed from the
pack's own eyes and the outline of its picture. Chosen in Settings →
Companion (OSPRIME_COMPANION_WEAR). Everything stays inside the character's
window, so clicks, the guide's strand and the hands are not affected.
"""
import math

import cairo

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "agent"))
from companion_wear_items import ITEMS  # noqa: E402  one list for Settings and the drawing


def outline(ch):
    """For each row of the picture (0..99), the left and right edge of the
    character as fractions, or None. Read once from the picture's alpha."""
    cached = getattr(ch, "_outline", None)
    if cached is not None:
        return cached
    img = ch.img
    w, h, stride = img.get_width(), img.get_height(), img.get_stride()
    data = img.get_data()
    rows = []
    for i in range(100):
        y = min(h - 1, int(i / 100 * h))
        base = y * stride
        xs = [x for x in range(0, w, 2) if data[base + x * 4 + 3] > 60]
        rows.append((xs[0] / w, xs[-1] / w) if xs else None)
    ch._outline = rows
    return rows


def span(ch, fy):
    r = outline(ch)[max(0, min(99, int(fy * 100)))]
    return r or (0.3, 0.7)


def _rgb(cr, r, g, b, a=1.0):
    cr.set_source_rgba(r / 255, g / 255, b / 255, a)


def draw(cr, ch, w, h, item):
    """Over the picture, under the attention dot."""
    if not item or item == "none" or item not in ITEMS:
        return
    cr.save()
    try:
        globals()["_" + item](cr, ch, w, h)
    finally:
        cr.restore()


def _glasses(cr, ch, w, h):
    eyes = ch.meta.get("eyes", [])
    if len(eyes) < 2:
        return
    cr.set_line_width(max(1.5, w * 0.018))
    _rgb(cr, 40, 40, 48)
    pts = []
    for e in eyes[:2]:
        cx, cy, r = e["cx"] * w, e["cy"] * h, max(e["rx"] * w, e["ry"] * h) * 1.25
        cr.new_sub_path()
        cr.arc(cx, cy, r, 0, 2 * math.pi)
        pts.append((cx, cy, r))
    cr.stroke()
    (x1, y1, r1), (x2, y2, r2) = sorted(pts)
    cr.move_to(x1 + r1, y1 - r1 * 0.2)
    cr.curve_to(x1 + r1 + 4, y1 - r1 * 0.5, x2 - r2 - 4, y2 - r2 * 0.5, x2 - r2, y2 - r2 * 0.2)
    cr.stroke()
    # a glint on each lens
    _rgb(cr, 255, 255, 255, 0.35)
    for cx, cy, r in pts:
        cr.arc(cx - r * 0.35, cy - r * 0.35, r * 0.18, 0, 2 * math.pi)
        cr.fill()


def _headphones(cr, ch, w, h):
    eyes = ch.meta.get("eyes", [])
    ey = (sum(e["cy"] for e in eyes) / len(eyes)) if eyes else 0.3
    l, r = span(ch, ey)
    top = 0.035
    tl, tr = span(ch, top + 0.02)
    cx = (tl + tr) / 2 * w
    _rgb(cr, 50, 54, 64)
    cr.set_line_width(max(3, w * 0.045))
    cr.move_to(l * w + w * 0.04, ey * h)
    cr.curve_to(l * w, top * h, r * w, top * h, r * w - w * 0.04, ey * h)
    cr.stroke()
    for x in (l * w + w * 0.02, r * w - w * 0.02):
        cr.save()
        cr.translate(x, ey * h)
        cr.scale(1, 1.4)
        cr.arc(0, 0, w * 0.06, 0, 2 * math.pi)
        cr.restore()
        _rgb(cr, 88, 166, 255)
        cr.fill_preserve()
        _rgb(cr, 30, 32, 40)
        cr.set_line_width(max(1.5, w * 0.012))
        cr.stroke()
    _ = cx


def _beanie(cr, ch, w, h):
    """Knitted, following the top of the head: drawn only where the
    character is, above a band."""
    band = 0.2
    cr.save()
    cr.rectangle(0, 0, w, band * h)
    cr.clip()
    cr.scale(w / ch.img.get_width(), h / ch.img.get_height())
    _rgb(cr, 214, 64, 82)
    cr.mask_surface(ch.img, 0, 0)
    cr.restore()
    # ribs
    l, r = span(ch, band - 0.03)
    cr.set_line_width(max(1, w * 0.008))
    _rgb(cr, 160, 36, 56, 0.8)
    x = l * w + w * 0.03
    while x < r * w - w * 0.02:
        cr.move_to(x, band * h - h * 0.035)
        cr.line_to(x, band * h)
        x += w * 0.03
    cr.stroke()
    # the folded brim
    cr.rectangle(l * w - w * 0.01, band * h - h * 0.035, (r - l) * w + w * 0.02, h * 0.035)
    _rgb(cr, 236, 236, 240)
    cr.fill()
    # pompom
    tl, tr = span(ch, 0.01)
    _rgb(cr, 245, 245, 250)
    cr.arc((tl + tr) / 2 * w, h * 0.035, w * 0.055, 0, 2 * math.pi)
    cr.fill()


def _bowtie(cr, ch, w, h):
    m = ch.meta.get("mouth") or {"cx": 0.6, "cy": 0.44, "h": 0.05}
    cx, cy = m["cx"] * w, (m["cy"] + m.get("h", 0.05) + 0.07) * h
    s = w * 0.09
    _rgb(cr, 219, 97, 162)
    for d in (-1, 1):
        cr.move_to(cx, cy)
        cr.line_to(cx + d * s * 1.4, cy - s * 0.7)
        cr.line_to(cx + d * s * 1.4, cy + s * 0.7)
        cr.close_path()
        cr.fill()
    cr.arc(cx, cy, s * 0.35, 0, 2 * math.pi)
    _rgb(cr, 160, 50, 110)
    cr.fill()


def _party(cr, ch, w, h):
    l, r = span(ch, 0.02)
    bx, by = (l + (r - l) * 0.3) * w, h * 0.17
    tip = (bx - w * 0.08, 0.0 + h * 0.004)
    base_w = w * 0.24
    cr.move_to(bx - base_w / 2, by)
    cr.line_to(bx + base_w / 2, by)
    cr.line_to(*tip)
    cr.close_path()
    _rgb(cr, 63, 185, 80)
    cr.fill_preserve()
    cr.save()
    cr.clip()
    _rgb(cr, 210, 153, 34)
    cr.set_line_width(w * 0.02)
    for k in (0.3, 0.6):
        cr.move_to(bx - base_w, by - (by - tip[1]) * k)
        cr.line_to(bx + base_w, by - (by - tip[1]) * k - h * 0.02)
    cr.stroke()
    cr.restore()
    _rgb(cr, 248, 81, 73)
    cr.arc(tip[0], tip[1] + h * 0.012, w * 0.025, 0, 2 * math.pi)
    cr.fill()


def _crown(cr, ch, w, h):
    l, r = span(ch, 0.03)
    cx = (l + r) / 2 * w
    cw, top, base = w * 0.34, h * 0.0, h * 0.13
    x0 = cx - cw / 2
    cr.move_to(x0, base)
    for i, (fx, fy) in enumerate([(0, 0.35), (0.17, 1), (0.33, 0.45), (0.5, 1),
                                  (0.67, 0.45), (0.83, 1), (1, 0.35)]):
        cr.line_to(x0 + fx * cw, base - (base - top) * fy)
    cr.line_to(x0 + cw, base)
    cr.close_path()
    g = cairo.LinearGradient(0, top, 0, base)
    g.add_color_stop_rgb(0, 1.0, 0.86, 0.35)
    g.add_color_stop_rgb(1, 0.85, 0.62, 0.12)
    cr.set_source(g)
    cr.fill_preserve()
    _rgb(cr, 150, 100, 20)
    cr.set_line_width(max(1, w * 0.008))
    cr.stroke()
    for fx in (0.25, 0.5, 0.75):
        cr.arc(x0 + fx * cw, base - (base - top) * 0.22, w * 0.012, 0, 2 * math.pi)
        _rgb(cr, 248, 81, 73)
        cr.fill()
