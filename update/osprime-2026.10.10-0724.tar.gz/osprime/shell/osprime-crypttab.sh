#!/usr/bin/env bash
# Move the encrypted disk's entry from /etc/crypttab.initramfs to /etc/crypttab
# with x-initrd.attach (docs/ENCRYPTION.md, "crypttab migration", 9 October).
#
#   bash osprime-crypttab.sh migrate     (root; run by post_install.sh on every update)
#   bash osprime-crypttab.sh status
#
# Why: mkinitcpio 42 (September 2026) deprecates the mkinitcpio-only file
# /etc/crypttab.initramfs in favour of the x-initrd.attach option in the
# standard /etc/crypttab, and machines that kept the old file were reported
# asking for the disk password at every start instead of the TPM opening it.
#
# The rule here is that a mistake must never leave a machine that cannot
# start. So:
#   * nothing happens unless the disk is ours (an osprime-root line) and
#     mkinitcpio is new enough to read the new place (42 or later);
#   * the old files are backed up in /etc/osprime before anything changes;
#   * a TEST startup image is built first and looked inside — the entry and
#     systemd-cryptsetup must be there — before the real one is touched;
#   * any failure puts every file back and rebuilds the image as it was;
#   * the result is written to /etc/osprime/crypttab-migration.json, which
#     Settings → Home → Disk reads.
# Exit status: 0 when migrated, not needed, or safely put back; 1 only when
# putting back failed too — the one case the updater must hear about.
set -u
R="${OSPRIME_CT_ROOT:-}"
MAPPER=osprime-root
OLD="$R/etc/crypttab.initramfs"
NEW="$R/etc/crypttab"
KEEP="$R/etc/osprime"
STATUS="$KEEP/crypttab-migration.json"
IMG="${OSPRIME_CT_IMAGE:-$R/boot/initramfs-linux.img}"
KERNEL="${OSPRIME_CT_KERNEL:-$R/boot/vmlinuz-linux}"
UKIS=("$R/boot/EFI/Linux/osprime.efi" "$R/boot/EFI/Linux/osprime-fallback.efi")

say() { echo "> $*"; }
status_write() {  # status_write STATE WHY
    mkdir -p "$KEEP"
    printf '{"state": "%s", "why": "%s", "at": %s}\n' "$1" "${2//\"/\'}" "$(date +%s)" > "$STATUS"
    chmod 644 "$STATUS" 2>/dev/null || true
}
has_entry() { [ -f "$1" ] && awk -v m="$MAPPER" '$1==m{f=1} END{exit !f}' "$1"; }

mkinitcpio_major() {
    mkinitcpio --version 2>/dev/null | grep -oE '[0-9]+' | head -1
}

# The old line with x-initrd.attach added to its options (the 4th field).
new_line() {
    awk -v m="$MAPPER" '$1==m {
        opts = ($4 == "" ? "none" : $4)
        if (opts !~ /(^|,)x-initrd\.attach(,|$)/) opts = (opts == "none" ? "" : opts ",") "x-initrd.attach"
        sub(/^,/, "", opts)
        print $1, $2, ($3 == "" ? "none" : $3), opts; exit }' "$OLD"
}

# Look inside a startup image: our entry, with x-initrd.attach, and the tool
# that opens it.
image_ok() {
    local img="$1" tmp ok=1
    [ -s "$img" ] || return 1
    tmp="$(mktemp -d)"
    (cd "$tmp" && lsinitcpio -x "$img" >/dev/null 2>&1)
    if awk -v m="$MAPPER" '$1==m{f=1} END{exit !f}' "$tmp/etc/crypttab" 2>/dev/null \
       && lsinitcpio "$img" 2>/dev/null | grep -q "systemd-cryptsetup"; then
        ok=0
    fi
    rm -rf "$tmp"
    return $ok
}

put_back() {  # put_back WHY
    say "putting everything back: $1"
    [ -f "$KEEP/crypttab.initramfs.bak" ] && cp -a "$KEEP/crypttab.initramfs.bak" "$OLD"
    if [ -f "$KEEP/crypttab.bak" ]; then cp -a "$KEEP/crypttab.bak" "$NEW"
    elif [ -f "$KEEP/crypttab.absent" ]; then rm -f "$NEW"; fi
    if mkinitcpio -P >/dev/null 2>&1; then
        status_write "put-back" "$1"
        echo "  The disk still opens the way it did before. Nothing else changed."
        return 0
    fi
    status_write "broken" "$1; rebuilding the old startup image failed too"
    echo "  ERROR: the old startup image could not be rebuilt. Do not restart;"
    echo "  run 'sudo mkinitcpio -P' and check its errors."
    return 1
}

case "${1:-}" in
status)
    cat "$STATUS" 2>/dev/null || echo '{"state": "none"}'
    ;;
migrate)
    if ! has_entry "$OLD"; then
        has_entry "$NEW" && say "crypttab: already in /etc/crypttab"
        exit 0                                   # not encrypted, or done before
    fi
    major="$(mkinitcpio_major)"
    if [ "${major:-0}" -lt 42 ]; then
        say "crypttab: mkinitcpio ${major:-?} still reads crypttab.initramfs; not moving it yet"
        status_write "waiting" "mkinitcpio ${major:-unknown} is older than 42"
        exit 0
    fi
    say "crypttab: moving the disk's entry to /etc/crypttab (x-initrd.attach)"
    mkdir -p "$KEEP"
    cp -a "$OLD" "$KEEP/crypttab.initramfs.bak" || { status_write "put-back" "could not back up"; exit 0; }
    rm -f "$KEEP/crypttab.bak" "$KEEP/crypttab.absent"
    if [ -f "$NEW" ]; then cp -a "$NEW" "$KEEP/crypttab.bak"; else : > "$KEEP/crypttab.absent"; fi

    line="$(new_line)"
    [ -n "$line" ] || { put_back "could not read the old entry"; exit $?; }
    { [ -f "$NEW" ] && awk -v m="$MAPPER" '$1!=m' "$NEW"; echo "$line"; } > "$NEW.osprime-new" \
        && mv "$NEW.osprime-new" "$NEW" && chmod 600 "$NEW" \
        || { put_back "could not write /etc/crypttab"; exit $?; }
    rm -f "$OLD"

    # A test image first, never the real one.
    test_img="$(mktemp -u /tmp/osprime-ct-test.XXXXXX).img"
    if ! mkinitcpio -k "$KERNEL" -g "$test_img" >/dev/null 2>&1; then
        rm -f "$test_img"; put_back "the test startup image could not be built"; exit $?
    fi
    if ! image_ok "$test_img"; then
        rm -f "$test_img"; put_back "the test startup image does not open the disk"; exit $?
    fi
    rm -f "$test_img"

    if ! mkinitcpio -P >/dev/null 2>&1 || ! image_ok "$IMG"; then
        put_back "the new startup image failed its check"; exit $?
    fi
    # Secure Boot: the signed startup files were rebuilt above; sign them again.
    for u in "${UKIS[@]}"; do
        if [ -s "$u" ] && command -v sbctl >/dev/null; then
            sbctl sign -s "${u#"$R"}" >/dev/null 2>&1 || { put_back "could not sign ${u##*/}"; exit $?; }
        fi
    done
    status_write "done" "moved to /etc/crypttab with x-initrd.attach"
    say "crypttab: done; the old file is kept in /etc/osprime/crypttab.initramfs.bak"
    ;;
*)
    echo "usage: $0 migrate|status"; exit 2 ;;
esac
