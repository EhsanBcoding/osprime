"""Brainy's small sounds (step 5B, 9 October; OFF unless the person turns
them on in Settings → Companion — Ehsan's decision).

Our own, made here from a few sine notes with soft edges: nothing borrowed,
nothing to license, no files to ship. Written once as WAV into the person's
state folder and played with whatever the desktop has (pw-play, paplay or
aplay), never waited for.

Kept rare on purpose: one sound at most every 1.5 seconds, and only for
things the person is already waiting on or did themselves.
"""
import math
import os
import shutil
import struct
import subprocess
import time
import wave

RATE = 22050
GAP = 1.5
_last = [0.0]

# name -> notes: (frequency Hz, start s, length s, loudness 0..1), or a slide
# (f0, f1) for the poke.
SOUNDS = {
    "answer": [(659.3, 0.0, 0.16, 0.35), (880.0, 0.09, 0.22, 0.30)],
    "alert": [(587.3, 0.0, 0.14, 0.30), (740.0, 0.11, 0.14, 0.30), (880.0, 0.22, 0.26, 0.30)],
    "done": [(523.3, 0.0, 0.30, 0.25), (659.3, 0.0, 0.30, 0.22), (784.0, 0.06, 0.30, 0.20)],
    "fail": [(392.0, 0.0, 0.16, 0.28), (311.1, 0.13, 0.26, 0.28)],
    "poke": [((420.0, 760.0), 0.0, 0.13, 0.35)],
}


def enabled() -> bool:
    try:
        import paths
        return paths.read_desktop_env().get("OSPRIME_COMPANION_SOUNDS", "no").strip('"') == "yes"
    except Exception:
        return False


def samples(name: str) -> list:
    notes = SOUNDS[name]
    total = max(start + length for _f, start, length, _a in notes) + 0.05
    out = [0.0] * int(total * RATE)
    for f, start, length, amp in notes:
        n = int(length * RATE)
        s0 = int(start * RATE)
        phase = 0.0
        for i in range(n):
            t = i / n
            freq = f[0] + (f[1] - f[0]) * t if isinstance(f, tuple) else f
            phase += 2 * math.pi * freq / RATE
            # soft attack, gentle decay: no clicks
            env = min(1.0, t / 0.08) * (1 - t) ** 1.6
            out[s0 + i] += amp * env * (math.sin(phase) + 0.18 * math.sin(2 * phase))
    peak = max(1e-6, max(abs(x) for x in out))
    k = min(1.0, 0.6 / peak)
    return [x * k for x in out]


def wav_path(name: str):
    import paths
    p = paths.state_dir() / "sounds" / f"{name}.wav"
    if not p.is_file():
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        with wave.open(str(tmp), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(RATE)
            w.writeframes(b"".join(struct.pack("<h", int(x * 32767)) for x in samples(name)))
        os.replace(tmp, p)
    return p


def player():
    for cmd in ("pw-play", "paplay", "aplay"):
        if shutil.which(cmd):
            return [cmd] + (["-q"] if cmd == "aplay" else [])
    return None


def play(name: str, force: bool = False) -> bool:
    """True if a sound was started. Off, too soon, or nothing to play with:
    silence, which is always the safe answer here."""
    if name not in SOUNDS or (not force and not enabled()):
        return False
    now = time.monotonic()
    if now - _last[0] < GAP:
        return False
    cmd = player()
    if not cmd:
        return False
    try:
        subprocess.Popen(cmd + [str(wav_path(name))], stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    except Exception:
        return False
    _last[0] = now
    return True
