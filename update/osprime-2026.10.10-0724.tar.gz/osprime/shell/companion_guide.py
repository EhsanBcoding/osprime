"""The step-by-step guide (docs/COMPANION.md, phase 4).

"Show me how to change the wallpaper." The companion looks at the screen,
names the one next thing to do, and a strand runs from its hand to it. You
click the real thing; the screen changes; it looks again and points at the
next one. Esc or Stop winds the strand back.

One step:
  1. a picture of the screen (grim), into the private point folder;
  2. what can be clicked and where (guide_probe: AT-SPI + OCR);
  3. one question to whatever can see (the agent's "guide_step", which uses
     the local vision model or the cloud one) with the numbered list;
  4. the answer checked (guide_logic.validate) — a failed check is said,
     never drawn;
  5. the strand drawn (companion_overlay), the instruction in the bubble
     and beside the target, the character's eyes on it;
  6. the screen watched once a second, our own drawing left out; when it
     has changed and settled, the next step. Next does the same by hand.

It never clicks or types for you: that is ydotool, a later decision.
"""
import os
import threading
import time

from gi.repository import GLib

import guide_logic as gl
import guide_probe as gp

WATCH_EVERY = 1000          # ms
SETTLE = 2                  # changed, and the same, on this many looks in a row


class GuideSession:
    def __init__(self, companion, bubble):
        self.c = companion
        self.b = bubble
        self.goal = ""
        self.history = []
        self.active = False
        self.step_no = 0
        self.overlay = None
        self.watch_id = None
        self.baseline = None
        self.ignore = frozenset()
        self.pending = None
        self._reply = None
        self._reply_ev = threading.Event()
        self.steps = []             # what was shown, for "Keep this guide"
        self.replay = None          # a kept guide's steps (agent/guides.py)
        self.replay_i = 0
        self.used_model = False

    # ---- control --------------------------------------------------------
    def start(self, goal: str, replay=None, ask_kept=True):
        self.stop(quiet=True)
        if replay is None and ask_kept:
            # Kept before? Offer it; never start it on its own (Ehsan, 10 October).
            try:
                import guides
                kept = guides.find(goal)
            except Exception:
                kept = None
            if kept:
                self.b.guide_card(
                    f"We did this before (\u201c{kept['goal']}\u201d, {len(kept['steps'])} steps). "
                    "Show it the same way?",
                    [("Same way", lambda k=kept: self.start(goal, replay=k["steps"])),
                     ("Ask fresh", lambda: self.start(goal, ask_kept=False))], final=True)
                return
        self.goal, self.history, self.step_no = goal.strip(), [], 0
        self.steps, self.replay, self.replay_i, self.used_model = [], replay, 0, False
        self.active = True
        self.b.guide_card(f"Showing you how: {self.goal}" +
                          (" (the way you kept)" if replay else ""), [])
        try:
            import cloud
            if gl.looks_like_web(self.goal) and not cloud.enabled():
                # 9 October: "create a Google account" lost its way on the
                # local model. Said once, at the start; the choice is theirs.
                self.b._line("Tip: web pages go better with the cloud model "
                             "(Settings → Assistant → Cloud model).", "dim")
        except Exception:
            pass
        self.next_step()

    def stop(self, quiet=False):
        was = self.active
        self.active = False
        self._unwatch()
        if self.overlay:
            self.overlay.wind_back()
        self.c.look_at(None)
        self.c.set_local_state(None)
        if was and not quiet:
            self.b.guide_card("Stopped. Ask me again any time.", [], final=True)

    def next_step(self, *_):
        if not self.active:
            return
        self._unwatch()
        if self.replay is not None and self.replay_i >= len(self.replay) and not self.used_model:
            self.b.guide_card("✓ Done — the same way as last time.", [], final=True)
            self.stop(quiet=True)
            return
        if self.step_no >= gl.MAX_STEPS:
            self.b.guide_card("That is a lot of steps — let's stop here. Ask me again "
                              "from where you are.", [], final=True)
            self.stop(quiet=True)
            return
        self.step_no += 1
        self.c.set_local_state("reading")
        self.b.guide_card(f"Step {self.step_no}: looking…", [("Stop", self.stop)])
        threading.Thread(target=self._think, daemon=True).start()

    # ---- one step, off the GTK thread ------------------------------------
    def _think(self):
        try:
            result = self._one_step()
        except Exception as e:
            result = {"ok": False, "why": f"something went wrong ({e})"}
        GLib.idle_add(self._show, result)

    def _screen(self):
        import companion_point as cp
        cp.sweep()
        path = str(cp.folder() / f"screen-{int(time.time() * 1000)}.png")
        size = gp.capture(path)
        return path, size

    def _replayed(self, cands):
        """The next kept step, found on this screen by name — no model."""
        if self.replay is None or self.replay_i >= len(self.replay):
            return None
        st = self.replay[self.replay_i]
        base = {"ok": True, "why": "kept", "instruction": st["instruction"], "rect": None,
                "guess": False, "done": False, "note": "", "irreversible": False,
                "open": st.get("open"), "name": st.get("name", ""), "type": st.get("type", "")}
        if st.get("open") and not st.get("name"):
            self.replay_i += 1
            return base
        import guides
        el = guides.match_candidate(st, cands)
        if el is None:
            return None
        self.replay_i += 1
        base.update(rect=tuple(el["box"]), open=None,
                    irreversible=bool(gp.IRREVERSIBLE.search(el.get("name", ""))))
        return base

    def _one_step(self):
        path, size = self._screen()
        if not size:
            return {"ok": False, "why": "I could not take a picture of the screen"}
        sw, sh = size
        ow, oh = self.c.screen_size()
        scale = sw / ow if ow else 1.0
        info, controls = gp.atspi_controls()
        lines = gp.ocr_lines(path)
        maxed = None
        ws = info.get("wsize")
        if ws and ws[0] >= ow - 4:
            maxed = (0, 0)
        hints = [h for h in (gp.window_offset(controls, lines, scale),
                             info.get("sbox") and (info["sbox"][0] * scale, info["sbox"][1] * scale),
                             maxed) if h]
        exact = gp.exact_offset(path, info, hints) if controls else None
        cands, how = gp.candidates(info, controls, lines, sw, sh, scale, maxed, exact=exact)
        kept = self._replayed(cands)
        if kept is not None:
            try:
                os.unlink(path)
            except OSError:
                pass
            kept["scale"], kept["how"] = scale, how
            return kept
        if self.replay is not None:
            # A kept step that is not on this screen: the model takes over,
            # and the guide carries on from what it says.
            self.replay_i = len(self.replay)
        self.used_model = True
        prompt = gl.build_request(self.goal, self.history, info,
                                  gp.describe_list(cands, sw, sh))
        raw = self.ask(path, prompt)
        try:
            os.unlink(path)
        except OSError:
            pass
        if raw.startswith("ERROR:"):
            return {"ok": False, "why": raw[6:].strip()}
        res = gl.validate(gl.parse_reply(raw), cands, sw, sh)
        res["scale"] = scale
        res["how"] = how
        return res

    def ask(self, path, prompt) -> str:
        """Through the assistant's own socket, so the model, the cloud switch
        and the engine swapping are the assistant's, not a second copy."""
        self._reply_ev.clear()
        self._reply = None
        self.pending = f"g{time.time():.3f}"
        try:
            self.b.guide_link().send({"type": "guide_step", "id": self.pending, "image": path,
                              "prompt": prompt, "system": gl.SYSTEM})
        except OSError:
            return "ERROR: the assistant is not running"
        if not self._reply_ev.wait(240):
            return "ERROR: no answer in four minutes"
        return self._reply or "ERROR: empty answer"

    def on_reply(self, msg):
        """From the bubble's socket reader (GTK thread)."""
        if msg.get("id") == self.pending:
            self._reply = str(msg.get("raw") or "")
            self._reply_ev.set()

    # ---- showing it -----------------------------------------------------
    def _show(self, r):
        if not self.active:
            return False
        self.c.set_local_state(None)
        rtl = gp_rtl(r.get("instruction", ""))
        if not r.get("ok"):
            self.b.guide_card(f"I could not work out step {self.step_no}: {r.get('why')}.",
                              [("Try again", self._retry), ("Stop", self.stop)])
            self.step_no -= 1
            return False
        text = r["instruction"]
        if r.get("done"):
            self.b.guide_card("✓ " + text, self._keep_button(), final=True)
            self.history.append(text)
            self.stop(quiet=True)
            return False
        self.steps.append({"instruction": text, "name": r.get("name", ""), "type": r.get("type", ""),
                           "open": r.get("open")})
        if not r.get("rect"):
            # Something to do with no one thing to click ("open Settings").
            buttons = [("Next", self._advance), ("Stop", self.stop)]
            o = r.get("open")
            if o:
                label = "Open " + (o.get("app") or o["url"].split("/")[2])
                buttons.insert(0, (label, lambda o=o: self._open(o)))
            self.b.guide_card(f"Step {self.step_no}: {text}" +
                              (f"\n{r['note']}" if r.get("note") else ""), buttons)
            self.history.append(text)
            return False
        extra = []
        if r.get("guess"):
            extra.append("best guess")
        if r.get("irreversible"):
            extra.append("this cannot be undone")
        line = f"Step {self.step_no}: {text}" + (f"  ({', '.join(extra)})" if extra else "")
        self.b.guide_card(line, [("Next", self._advance), ("Done", self._finish),
                                 ("Stop", self.stop)])
        self.history.append(text)
        s = r["scale"] or 1.0
        x, y, w, h = r["rect"]
        rect = (x / s, y / s, w / s, h / s)
        start = self.c.hand_screen(rect[0] + rect[2] / 2)
        if self.overlay is None:
            import companion_overlay
            glow = (self.c.character.meta.get("glow") if self.c.character else None) or [90, 240, 230]
            self.overlay = companion_overlay.Overlay(tuple(v / 255 for v in glow))
        self.overlay.point(start, rect, text, guess=r.get("guess", False), rtl=rtl)
        self.c.look_at((rect[0] + rect[2] / 2, rect[1] + rect[3] / 2))
        # Watch the screen, leaving out what we draw ourselves.
        self.pending_rect = (rect, start, s)
        GLib.timeout_add(int((0.8 + 0.3) * 1000), self._begin_watch)
        return False

    def _open(self, o):
        """The button under an "open …" step: the person's click opens it,
        then the guide looks again once it has had time to appear."""
        def go():
            try:
                import desktop
                desktop.open_url(o["url"]) if o.get("url") else desktop.launch(o["app"])
            except Exception:
                pass
        import threading as _t
        _t.Thread(target=go, daemon=True).start()
        self.history.append("Opened " + (o.get("url") or o.get("app")))
        GLib.timeout_add(3500, lambda: (self.active and self.next_step()) and False)

    def _retry(self, *_):
        self.next_step()

    def _advance(self, *_):
        if self.overlay:
            self.overlay.wind_back()
        self.next_step()

    def _finish(self, *_):
        self.b.guide_card("Done. Nicely done.", self._keep_button(), final=True)
        self.stop(quiet=True)

    def _keep_button(self):
        """Offered when there is something new to keep: a guide the model
        worked out, not one that was replayed as it was."""
        if not self.steps or (self.replay is not None and not self.used_model):
            return []
        goal, steps = self.goal, list(self.steps)

        def keep():
            try:
                import guides
                r = guides.save(goal, steps)
            except Exception as e:
                r = {"message": f"Could not keep it ({e})."}
            self.b._line(r["message"], "dim")
        return [("Keep this guide", keep)]

    # ---- watching for the click's effect ----------------------------------
    def _begin_watch(self):
        if not self.active:
            return False
        rect, start, s = self.pending_rect
        path, size = self._screen()
        g = gp.grid(path) if size else None
        try:
            os.unlink(path)
        except OSError:
            pass
        if not g:
            return False                       # no watching: Next still works
        rows, cols = len(g), len(g[0])
        sw, sh = size
        k = s  # logical -> picture pixels
        shot = lambda r: tuple(v * k for v in r)
        ignore = set(__import__("companion_overlay").cells_under(
            (start[0] * k, start[1] * k), shot(rect), None, cols, rows, cols / sw, rows / sh))
        for r in (self.c.own_rects() or []):
            x, y, w, h = shot(r)
            for yy in range(int(y * rows / sh) - 1, int((y + h) * rows / sh) + 2):
                for xx in range(int(x * cols / sw) - 1, int((x + w) * cols / sw) + 2):
                    ignore.add((yy, xx))
        # the tag under or over the target
        x, y, w, h = shot(rect)
        for yy in range(int((y - 60 * k) * rows / sh), int((y + h + 70 * k) * rows / sh) + 1):
            for xx in range(int((x - 10 * k) * cols / sw), int((x + 400 * k) * cols / sw) + 1):
                ignore.add((yy, xx))
        self.baseline, self.ignore, self.streak, self.last = g, frozenset(ignore), 0, None
        self.watch_id = GLib.timeout_add(WATCH_EVERY, self._watch)
        return False

    def _watch(self):
        if not self.active:
            self.watch_id = None
            return False

        def look():
            path, size = self._screen()
            g = gp.grid(path) if size else None
            try:
                os.unlink(path)
            except OSError:
                pass
            GLib.idle_add(self._compare, g)
        threading.Thread(target=look, daemon=True).start()
        return True

    def _compare(self, g):
        if not self.active or g is None or self.baseline is None:
            return False
        if gp.changed(self.baseline, g, self.ignore):
            same = self.last is not None and not gp.changed(self.last, g, self.ignore, share=0.002)
            self.streak = self.streak + 1 if same or self.streak == 0 else 1
            self.last = g
            if self.streak >= SETTLE:
                self._advance()
        else:
            self.streak, self.last = 0, None
        return False

    def _unwatch(self):
        if self.watch_id:
            GLib.source_remove(self.watch_id)
            self.watch_id = None
        self.baseline = None


def gp_rtl(text):
    import unicodedata
    for ch in text or "":
        d = unicodedata.bidirectional(ch)
        if d in ("R", "AL"):
            return True
        if d == "L":
            return False
    return False
