"""The weekly recap (step 5C, a Coucou idea approved 9 October).

Once a week, on the day the person chooses in Settings → Companion
(OSPRIME_RECAP_DAY; Friday unless changed, "off" for none), a card on the
panel's Home looks back at the last seven days: how many questions they
asked, what the watchers found, the notes and documents they worked on, and
the reminders coming up. Data only — no model writes it, so it costs nothing
and says nothing that did not happen. It shows from the afternoon of that
day until they close it, and never makes a sound or a dot.

The question count is the only thing kept for this: a number per day in the
person's state folder (no words, no topics), the last 60 days.
"""
import datetime
import json
import os
import pathlib
import time

import paths

DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
DAY_NAMES = {"mon": "Monday", "tue": "Tuesday", "wed": "Wednesday", "thu": "Thursday",
             "fri": "Friday", "sat": "Saturday", "sun": "Sunday", "off": "Never"}
FROM_HOUR = 16


def _file() -> pathlib.Path:
    return paths.state_dir() / "recap.json"


def _load() -> dict:
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d: dict):
    f = _file()
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(d), encoding="utf-8")
    tmp.replace(f)


def count_question(now=None):
    """One more question today. Never raises."""
    try:
        day = datetime.date.fromtimestamp(now or time.time()).isoformat()
        d = _load()
        c = d.setdefault("questions", {})
        c[day] = int(c.get(day, 0)) + 1
        for k in sorted(c)[:-60]:
            del c[k]
        _save(d)
    except Exception:
        pass


def day() -> str:
    try:
        v = paths.read_desktop_env().get("OSPRIME_RECAP_DAY", "fri").strip('"').lower()
    except Exception:
        v = "fri"
    return v if v in DAYS or v == "off" else "fri"


def week_key(now=None) -> str:
    y, w, _ = datetime.date.fromtimestamp(now or time.time()).isocalendar()
    return f"{y}-W{w:02d}"


def due(now=None) -> bool:
    """From FROM_HOUR on the chosen day, for the rest of that week, until seen."""
    now = now or time.time()
    d = day()
    if d == "off":
        return False
    dt = datetime.datetime.fromtimestamp(now)
    target = DAYS.index(d)
    if dt.weekday() < target or (dt.weekday() == target and dt.hour < FROM_HOUR):
        return False
    return _load().get("seen") != week_key(now)


def seen(now=None):
    d = _load()
    d["seen"] = week_key(now)
    _save(d)


def _recent_files(root: pathlib.Path, since: float, exts=None, limit=400) -> list:
    out = []
    try:
        for dirpath, dirnames, files in os.walk(root):
            dirnames[:] = [x for x in dirnames if not x.startswith(".")]
            for f in files:
                p = pathlib.Path(dirpath) / f
                if exts and p.suffix.lower() not in exts:
                    continue
                try:
                    if p.stat().st_mtime >= since:
                        out.append(p)
                except OSError:
                    pass
                if len(out) >= limit:
                    return out
    except Exception:
        pass
    return out


def build(now=None) -> dict:
    """{"title", "lines": [[left, right, tone]], "foot"} for the card."""
    now = now or time.time()
    since = now - 7 * 86400
    lines = []
    d = _load()
    first = datetime.date.fromtimestamp(since).isoformat()
    asked = sum(v for k, v in d.get("questions", {}).items() if k > first)
    lines.append(["Questions you asked", str(asked), ""])
    try:
        import watchers
        al = [a for a in watchers._load()["alerts"] if a.get("at", 0) >= since]
        lines.append(["Alerts from your watchers", str(len(al)), "up" if al else "dim"])
        for a in al[-2:]:
            lines.append(["  " + a["text"][:60], "", "dim"])
    except Exception:
        pass
    try:
        import vault
        notes = _recent_files(vault.root(), since, {".md"})
        if notes:
            lines.append(["Notes written or changed", str(len(notes)), ""])
    except Exception:
        pass
    try:
        import helpers
        docs = []
        for sub in ("Documents", "Desktop"):
            docs += _recent_files(paths.home() / sub, since, helpers.DOC_EXT)
        if docs:
            docs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            lines.append(["Documents you worked on", str(len(docs)), ""])
            lines.append(["  " + ", ".join(p.name for p in docs[:3])[:70], "", "dim"])
    except Exception:
        pass
    try:
        import proactive
        sch = proactive.list_schedules(paths.agent_config())
        if sch:
            lines.append(["Reminders next week", str(len(sch)), ""])
    except Exception:
        pass
    start = datetime.date.fromtimestamp(since + 86400).strftime("%d %b")
    end = datetime.date.fromtimestamp(now).strftime("%d %b")
    return {"title": f"Your week · {start} – {end}", "lines": lines,
            "foot": "Only counts and names from this computer; nothing was sent anywhere."}
