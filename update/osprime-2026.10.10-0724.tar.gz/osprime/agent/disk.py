"""Is this computer's disk encrypted, and how does it unlock? docs/ENCRYPTION.md.

Read without root: the root filesystem's source from findmnt, and
/etc/osprime/disk.json, which the installer writes and
osprime-disk-unlock.sh keeps current. The LUKS header itself needs root to
read, and Settings must work without it.
"""
import json
import os
import pathlib
import subprocess

STATE = pathlib.Path(os.environ.get("OSPRIME_DISK_STATE", "/etc/osprime/disk.json"))

WORDS = {
    "tpm": "unlocks with the TPM — only the login password at start",
    "tpm-pin": "unlocks with the TPM and a PIN at start",
    "password": "asks for the disk password at every start",
}


def _root_source() -> str:
    try:
        return subprocess.run(["findmnt", "-no", "SOURCE", "/"], capture_output=True,
                              text=True, timeout=5).stdout.strip()
    except Exception:
        return ""


SB_STATE = pathlib.Path(os.environ.get("OSPRIME_SB_STATE", "/var/lib/osprime/secureboot.json"))
SB_VAR = pathlib.Path(os.environ.get(
    "OSPRIME_SB_VAR",
    "/sys/firmware/efi/efivars/SecureBoot-8be4df61-93ca-11d2-aa0d-00e098032b8c"))


def secure_boot_done() -> bool:
    """Plan C finished and Secure Boot actually on (docs/ENCRYPTION.md)."""
    try:
        stage = json.loads(SB_STATE.read_text(encoding="utf-8")).get("stage")
        return stage == "done" and SB_VAR.read_bytes()[4:5] == b"\x01"
    except Exception:
        return False


def status() -> dict:
    src = _root_source()
    try:
        state = json.loads(STATE.read_text(encoding="utf-8"))
    except Exception:
        state = {}
    encrypted = src.startswith("/dev/mapper/") or bool(state.get("encrypted"))
    mode = state.get("unlock", "") if encrypted else ""
    if not encrypted:
        text = "Not encrypted"
        note = ("A stolen disk can be read. Encryption is chosen when OSprime is "
                "installed.")
    else:
        text = "Encrypted — " + WORDS.get(mode, "unlock method unknown")
        note = ("Keep the recovery key from the installation somewhere safe. "
                "To change how it unlocks: sudo bash "
                "/opt/osprime/shell/osprime-disk-unlock.sh tpm|tpm-pin|password")
        if mode == "tpm" and not secure_boot_done():
            note = ("Protects the disk if it is taken out; against tampering with the "
                    "startup files it also needs Secure Boot (System -> Secure Boot). "
                    + note)
    # The crypttab move of 9 October (shell/osprime-crypttab.sh): say so when
    # it had to be put back — the disk then asks for its password at start.
    try:
        mig = json.loads((STATE.parent / "crypttab-migration.json").read_text(encoding="utf-8"))
    except Exception:
        mig = {}
    if encrypted and mig.get("state") in ("put-back", "broken"):
        note = ("The startup settings for the encrypted disk could not be updated ("
                + str(mig.get("why", "")) + "); it may ask for the disk password at start. "
                "The next update tries again. " + note)
    return {"encrypted": encrypted, "unlock": mode, "text": text, "note": note,
            "crypttab": mig.get("state", "")}
