"""What Brainy can wear (shell/companion_wear.py draws them). Here, without
cairo, so Settings and the assistant can list and check them."""
ITEMS = {
    "none": "Nothing",
    "glasses": "Round glasses",
    "headphones": "Headphones",
    "beanie": "Woolly hat",
    "bowtie": "Bow tie",
    "party": "Party hat",
    "crown": "Crown",
}
