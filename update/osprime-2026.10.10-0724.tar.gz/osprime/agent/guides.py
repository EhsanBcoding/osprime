"""Guides the person kept (docs/COMPANION.md, "Keep and replay"; approved by
Ehsan, 10 October).

When a step-by-step guide reaches the end, the panel offers "Keep this
guide". The steps — what was said, and the name and kind of the thing that
was pointed at — go into ~/Memory/Guides/<goal>.md, readable in Notes and on
the phone like any other note. The next time the person asks for the same
thing, the panel offers to show it the same way. Each saved step is found
again on the screen by its name (accessibility or OCR), with no model; a
step that cannot be found is asked of the model as before.

Nothing typed is ever kept: a guide never types, and the steps hold only the
names of buttons, menus and fields.
"""
import datetime
import json
import pathlib
import re

MAX_STEPS = 20
MATCH = 0.6          # how alike two goals must be to offer a kept guide


def folder() -> pathlib.Path:
    try:
        import vault
        return vault.root() / "Guides"
    except Exception:
        import paths
        return paths.home() / "Memory" / "Guides"


_STOP = {"the", "a", "an", "to", "my", "me", "how", "do", "i", "of", "on", "in", "for", "show",
         "please", "can", "you", "it", "and", "is", "with", "را", "به", "از", "در", "که", "و",
         "چطور", "چطوری", "نشونم", "نشانم", "بده", "بدی", "میشه", "لطفا", "لطفاً", "رو", "یه", "یک", "کنم"}


def words(text: str) -> set:
    t = re.sub(r"[^\w\s]", " ", (text or "").lower())
    return {w for w in t.split() if w not in _STOP and len(w) > 1}


def similarity(a: str, b: str) -> float:
    wa, wb = words(a), words(b)
    if not wa or not wb:
        return 0.0
    return len(wa & wb) / len(wa | wb)


def _slug(goal: str) -> str:
    s = re.sub(r"[^\w\- ]+", "", goal or "").strip()[:60].strip()
    return s or "guide"


def clean_step(st: dict) -> dict:
    """Only what a guide needs again — never anything the person typed."""
    out = {"instruction": str(st.get("instruction", ""))[:140]}
    if st.get("open"):
        o = st["open"]
        out["open"] = {"url": o["url"]} if o.get("url") else {"app": str(o.get("app", ""))[:40]}
    if st.get("name"):
        out["name"] = str(st["name"])[:80]
        out["type"] = str(st.get("type", ""))[:30]
    return out


def save(goal: str, steps: list) -> dict:
    steps = [clean_step(s) for s in (steps or []) if s.get("instruction")][:MAX_STEPS]
    if not goal.strip() or not steps:
        return {"ok": False, "message": "There is nothing to keep yet."}
    d = folder()
    d.mkdir(parents=True, exist_ok=True)
    f = d / f"{_slug(goal)}.md"
    lines = ["---", f"goal: {goal.strip()[:200]}", f"saved: {datetime.date.today().isoformat()}", "---",
             f"# {goal.strip()[:200]}", "",
             "A guide kept from the companion. Each step is found again on the screen by name.", ""]
    for i, s in enumerate(steps, 1):
        what = (f' → {s["type"] or "item"} "{s["name"]}"' if s.get("name")
                else f' → open {s["open"].get("url") or s["open"].get("app")}' if s.get("open") else "")
        lines.append(f"{i}. {s['instruction']}{what}")
    lines += ["", "```json", json.dumps({"steps": steps}, ensure_ascii=False, indent=1), "```", ""]
    f.write_text("\n".join(lines), encoding="utf-8")
    return {"ok": True, "path": str(f), "message": f"Kept as a guide in Memory/Guides/{f.name}."}


def load(path) -> dict:
    try:
        text = pathlib.Path(path).read_text(encoding="utf-8")
        goal = re.search(r"^goal:\s*(.+)$", text, re.M).group(1).strip()
        block = re.search(r"```json\s*(\{.*?\})\s*```", text, re.S).group(1)
        steps = [clean_step(s) for s in json.loads(block).get("steps", [])][:MAX_STEPS]
        return {"goal": goal, "steps": steps, "path": str(path)} if steps else {}
    except Exception:
        return {}


def find(goal: str):
    """The kept guide most like this goal, or None."""
    best, score = None, 0.0
    try:
        files = sorted(folder().glob("*.md"))
    except Exception:
        files = []
    for f in files:
        g = load(f)
        if not g:
            continue
        sc = similarity(goal, g["goal"])
        if sc > score:
            best, score = g, sc
    return best if score >= MATCH else None


def _norm(s: str) -> str:
    return re.sub(r"[\W_]+", " ", (s or "").lower()).strip()


def match_candidate(step: dict, cands: list):
    """The thing on the screen with the step's name: the same kind first,
    then any; an exact name before one that only contains it."""
    name = _norm(step.get("name", ""))
    if not name:
        return None
    exact = [c for c in cands if _norm(c.get("name", "")) == name and not c.get("sensitive")]
    if exact:
        same = [c for c in exact if c.get("type") == step.get("type")]
        return (same or exact)[0]
    if len(name) >= 4:
        part = [c for c in cands if name in _norm(c.get("name", "")) and not c.get("sensitive")
                and len(_norm(c.get("name", ""))) <= len(name) + 12]
        if part:
            return part[0]
    return None
