#!/usr/bin/env python3
"""The Apps menu. docs/HANDOFF.md (asked for 29 September).

A panel over the desktop: a search box, the applications, and along the
bottom Lock, Log out, Restart and Shut down — side by side, the way Windows
and macOS keep them. It closes on Escape, on choosing something, on losing
focus, and on a click anywhere outside it (fuzzel, the menu before this,
closed only on Escape or a choice).

osprime-apps.sh still decides WHAT is in the menu — the curated list plus
everything the person installed — and hands this window the directories to
read. If GTK or gtk-layer-shell is missing, osprime-apps.sh falls back to
fuzzel, so the menu never simply fails to open.

    osprime-appmenu.py DIR [DIR ...]     each DIR holds *.desktop files
"""
import os
import pathlib
import signal
import subprocess
import sys

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("GtkLayerShell", "0.1")
from gi.repository import Gdk, Gio, GLib, Gtk, GtkLayerShell  # noqa: E402

LIVE = os.path.isdir(os.environ.get("OSPRIME_LIVE_DIR", "/run/archiso"))
LIVE_INSTALL = "/usr/share/osprime/live/osprime-install.desktop"
RUNTIME = pathlib.Path(os.environ.get("XDG_RUNTIME_DIR") or f"/tmp/osprime-{os.getuid()}")
PIDFILE = RUNTIME / "osprime-appmenu.pid"
PEOPLE = os.path.exists("/etc/osprime/accounts") and os.environ.get("USER") != "osprime"

CSS = b"""
#backdrop { background-color: rgba(0,0,0,0.25); }
#panel { background-color: #161b22; border: 1px solid #30363d; border-radius: 14px; }
#panel label { color: #e6edf3; }
#search { background-color: #0d1117; color: #e6edf3; border: 1px solid #30363d;
          border-radius: 8px; padding: 8px 12px; font-size: 15px; }
.app { background: transparent; border: none; border-radius: 10px; padding: 8px; }
.app:hover, .app:focus { background-color: #21262d; }
.app label { font-size: 12px; }
#powerbar { border-top: 1px solid #30363d; padding-top: 10px; }
.power { background: transparent; border: none; border-radius: 8px; padding: 6px 10px; }
.power:hover, .power:focus { background-color: #21262d; }
.power label { font-size: 12px; }
#who { color: #8b949e; font-size: 13px; }
"""


def _toggle_existing() -> bool:
    """Pressing the Apps key while the menu is open closes it."""
    try:
        pid = int(PIDFILE.read_text().strip())
        os.kill(pid, 0)
        os.kill(pid, signal.SIGTERM)
        return True
    except Exception:
        return False


def _apps(dirs) -> list:
    seen, apps = set(), []
    paths = [LIVE_INSTALL] if LIVE and os.path.exists(LIVE_INSTALL) else []
    for d in dirs:
        paths += sorted(str(p) for p in pathlib.Path(d).glob("*.desktop"))
    for p in paths:
        try:
            info = Gio.DesktopAppInfo.new_from_filename(p)
        except Exception:
            info = None
        if not info or info.get_nodisplay() or not info.should_show():
            continue
        name = info.get_display_name()
        if name in seen:
            continue
        seen.add(name)
        apps.append(info)
    # Install first on the live USB; everything else by name
    apps.sort(key=lambda a: (a.get_filename() != LIVE_INSTALL, a.get_display_name().lower()))
    return apps


def _run(cmd: list):
    subprocess.Popen(cmd, start_new_session=True, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL)


def _power(action: str):
    if action == "lock":
        _run(["bash", "/opt/osprime/shell/osprime-lock.sh"])
    elif action == "logout":
        _run(["labwc", "--exit"])
    else:
        verb = {"restart": "reboot", "shutdown": "poweroff"}[action]
        # logind lets the person at the computer do this; the sudo rule
        # (OSPRIME_POWER) is the fallback where it does not.
        _run(["sh", "-c", f"systemctl {verb} || sudo -n systemctl {verb}"])


class Menu(Gtk.Window):
    def __init__(self, dirs):
        super().__init__()
        self.set_name("backdrop")
        GtkLayerShell.init_for_window(self)
        GtkLayerShell.set_layer(self, GtkLayerShell.Layer.OVERLAY)
        GtkLayerShell.set_namespace(self, "osprime-appmenu")
        for edge in (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.BOTTOM,
                     GtkLayerShell.Edge.LEFT, GtkLayerShell.Edge.RIGHT):
            GtkLayerShell.set_anchor(self, edge, True)
        GtkLayerShell.set_keyboard_mode(self, GtkLayerShell.KeyboardMode.EXCLUSIVE)
        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual:
            self.set_visual(visual)
        self.set_app_paintable(True)
        prov = Gtk.CssProvider()
        prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(screen, prov,
                                                 Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        # a click on the backdrop — anywhere outside the panel — closes it
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("button-press-event", self._outside)
        self.connect("key-press-event", self._key)
        # Losing focus closes it too — but not in the first moment, when some
        # compositors hand focus over twice while the surface maps.
        self._ready = False
        GLib.timeout_add(500, self._set_ready)
        self.connect("focus-out-event", lambda *_: self._ready and self.close())

        self.panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12,
                             halign=Gtk.Align.CENTER, valign=Gtk.Align.END,
                             margin_bottom=56)
        self.panel.set_name("panel")
        self.panel.set_size_request(600, 560)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin=18)
        self.panel.pack_start(inner, True, True, 0)
        self.add(self.panel)

        self.search = Gtk.SearchEntry(placeholder_text="Search apps")
        self.search.set_name("search")
        self.search.connect("search-changed", lambda *_: self.grid.invalidate_filter())
        self.search.connect("activate", self._first)
        inner.pack_start(self.search, False, False, 0)

        scroll = Gtk.ScrolledWindow(vexpand=True)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.grid = Gtk.FlowBox(max_children_per_line=5, min_children_per_line=5,
                                selection_mode=Gtk.SelectionMode.NONE,
                                homogeneous=True, valign=Gtk.Align.START)
        self.grid.set_filter_func(self._filter)
        scroll.add(self.grid)
        inner.pack_start(scroll, True, True, 0)
        for info in _apps(dirs):
            self.grid.add(self._app_button(info))

        bar = Gtk.Box(spacing=4)
        bar.set_name("powerbar")
        who = Gtk.Label(label=os.environ.get("USER", ""), xalign=0)
        who.set_name("who")
        bar.pack_start(who, True, True, 4)
        buttons = [("system-lock-screen", "Lock", "lock")] if PEOPLE else []
        buttons += [("system-log-out", "Log out", "logout"),
                    ("system-reboot", "Restart", "restart"),
                    ("system-shutdown", "Shut down", "shutdown")]
        for icon, label, action in buttons:
            b = Gtk.Button()
            b.get_style_context().add_class("power")
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            box.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.LARGE_TOOLBAR),
                           False, False, 0)
            box.pack_start(Gtk.Label(label=label), False, False, 0)
            b.add(box)
            b.set_tooltip_text(label)
            b.connect("clicked", self._power, action)
            bar.pack_start(b, False, False, 0)
        inner.pack_start(bar, False, False, 0)

    def _set_ready(self):
        self._ready = True
        return False

    # ---- pieces --------------------------------------------------------------
    def _app_button(self, info):
        b = Gtk.Button()
        b.get_style_context().add_class("app")
        b.info = info
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        gicon = info.get_icon()
        img = (Gtk.Image.new_from_gicon(gicon, Gtk.IconSize.DIALOG) if gicon
               else Gtk.Image.new_from_icon_name("application-x-executable", Gtk.IconSize.DIALOG))
        img.set_pixel_size(48)
        box.pack_start(img, False, False, 0)
        lab = Gtk.Label(label=info.get_display_name(), justify=Gtk.Justification.CENTER,
                        max_width_chars=12, ellipsize=3, lines=2, wrap=True)
        box.pack_start(lab, False, False, 0)
        b.add(box)
        b.set_tooltip_text(info.get_description() or info.get_display_name())
        b.connect("clicked", lambda *_: self._launch(info))
        return b

    def _filter(self, child):
        q = self.search.get_text().strip().lower()
        if not q:
            return True
        info = child.get_child().info
        hay = " ".join(filter(None, [info.get_display_name(), info.get_description() or "",
                                     " ".join(info.get_keywords() or [])])).lower()
        return q in hay

    def _first(self, *_):
        for child in self.grid.get_children():
            if child.get_child_visible() and self._filter(child):
                self._launch(child.get_child().info)
                return

    def _launch(self, info):
        try:
            info.launch([], None)
        except Exception:
            pass
        self.close()

    def _power(self, _btn, action):
        self.close()
        _power(action)

    def _outside(self, _w, event):
        alloc = self.panel.get_allocation()
        inside = (alloc.x <= event.x <= alloc.x + alloc.width
                  and alloc.y <= event.y <= alloc.y + alloc.height)
        if not inside:
            self.close()
        return False

    def _key(self, _w, event):
        if event.keyval == Gdk.KEY_Escape:
            self.close()
            return True
        # typing anywhere goes into the search box
        if not self.search.has_focus() and event.string and event.string.isprintable():
            self.search.grab_focus_without_selecting()
        return False


def main():
    if _toggle_existing():
        return 0
    RUNTIME.mkdir(parents=True, exist_ok=True)
    PIDFILE.write_text(str(os.getpid()))
    signal.signal(signal.SIGTERM, lambda *_: Gtk.main_quit())
    w = Menu(sys.argv[1:])
    w.connect("destroy", Gtk.main_quit)
    w.show_all()
    w.search.grab_focus()
    try:
        Gtk.main()
    finally:
        try:
            PIDFILE.unlink()
        except OSError:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
