"""OSprime system control.

Narrow, named operations instead of asking the model to compose shell
commands. A 1.5B model cannot reliably remember that setting the clock means
`timedatectl set-time "2026-08-15 14:30:00"` — it can reliably pick
`set_time` from a list and fill one field. That difference is why asking
OSprime to fix the clock failed.

Every function here also has a second consumer: Settings. Both read and write
through this module so the two can never disagree about what the system
currently is.

Each returns a short human sentence, because the result is shown to the user.
"""

import json
import os
import pathlib
import re
import shutil
import subprocess

CONFIG_PATH = pathlib.Path(os.environ.get("OSPRIME_DESKTOP_ENV",
                                          "/etc/osprime/desktop.env"))
TIMEOUT = 30


def _run(args, timeout: int = TIMEOUT):
    """Run a command directly — no shell, so nothing can be injected."""
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", f"{args[0]} is not installed"
    except subprocess.TimeoutExpired:
        return 124, "", f"{args[0]} timed out"


def _sudo(args):
    """These actions need root. The agent runs unprivileged by design."""
    if os.geteuid() == 0:
        return _run(args)
    if shutil.which("sudo"):
        return _run(["sudo", "-n"] + args)
    return 1, "", "root privileges are required and sudo is unavailable"


# --------------------------------------------------------------------------
# time
# --------------------------------------------------------------------------

_DT = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$")


def get_time() -> str:
    code, out, _ = _run(["timedatectl", "show", "--property=Timezone",
                         "--property=NTP", "--property=TimeUSec", "--value"])
    if code != 0:
        return "ERROR: could not read the clock"
    parts = out.splitlines()
    return json.dumps({"timezone": parts[0] if parts else "",
                       "auto_sync": (parts[1] if len(parts) > 1 else "") == "yes",
                       "time": parts[2] if len(parts) > 2 else ""})


def set_time(datetime: str) -> str:
    """Set the clock. Expects `YYYY-MM-DD HH:MM` or with seconds.

    The parameter is named to match the tool schema exactly — the dispatcher
    passes arguments through by keyword, so a mismatch here is a runtime
    failure the model cannot recover from.
    """
    s = (datetime or "").strip().replace("T", " ")
    if not _DT.match(s):
        return ("ERROR: I need the time as YYYY-MM-DD HH:MM, "
                f"and I was given '{datetime}'.")
    if len(s) == 16:
        s += ":00"
    # Automatic sync overrides any manual setting, so it has to go first.
    _sudo(["timedatectl", "set-ntp", "false"])
    code, _, err = _sudo(["timedatectl", "set-time", s])
    if code != 0:
        return f"ERROR: could not set the clock: {err}"
    return f"clock set to {s}"


def resolve_timezone(text: str):
    """Turn what a person types into an IANA zone name.

    Nobody living in Irvine knows their timezone is called
    America/Los_Angeles. Requiring the exact name made a correct request look
    like a user error, so the city is resolved here instead — the tz database
    already lists every city it knows.

    Returns (zone, candidates). Exactly one of them is meaningful.
    """
    want = (text or "").strip()
    if not want:
        return None, []
    code, out, _ = _run(["timedatectl", "list-timezones", "--no-pager"])
    if code != 0:
        return want, []          # cannot check; let timedatectl decide
    zones = out.split()

    if want in zones:
        return want, []

    norm = want.replace(" ", "_").lower()
    exact = [z for z in zones if z.lower() == norm]
    if exact:
        return exact[0], []

    # A bare city: match the last component of the zone name.
    city = [z for z in zones if z.rsplit("/", 1)[-1].lower() == norm.rsplit("/", 1)[-1]]
    if len(city) == 1:
        return city[0], []
    if city:
        return None, city[:6]

    loose = [z for z in zones if norm.rsplit("/", 1)[-1] in z.lower()]
    if len(loose) == 1:
        return loose[0], []
    return None, loose[:6]


def set_timezone(zone: str) -> str:
    resolved, options = resolve_timezone(zone)
    if not resolved:
        if options:
            return (f"ERROR: '{zone}' matches several timezones. "
                    f"Which one: {', '.join(options)}?")
        return (f"ERROR: '{zone}' does not match any timezone. Give me the "
                "nearest large city, or a name like Europe/Berlin.")
    code, _, err = _sudo(["timedatectl", "set-timezone", resolved])
    if code != 0:
        return f"ERROR: could not set timezone: {err}"
    if resolved != (zone or "").strip():
        return f"timezone set to {resolved} (matched from '{zone}')"
    return f"timezone set to {resolved}"


def set_auto_time(enabled: bool = True) -> str:
    code, _, err = _sudo(["timedatectl", "set-ntp", "true" if enabled else "false"])
    if code != 0:
        return f"ERROR: could not change automatic time: {err}"
    return "clock now syncs automatically" if enabled else "automatic clock sync off"


# --------------------------------------------------------------------------
# network
# --------------------------------------------------------------------------

def list_wifi() -> str:
    code, out, err = _run(["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY",
                           "device", "wifi", "list"], timeout=45)
    if code != 0:
        return f"ERROR: could not scan for networks: {err}"
    seen, rows = set(), []
    for line in out.splitlines():
        parts = line.split(":")
        ssid = parts[0].strip()
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        rows.append({"ssid": ssid,
                     "signal": parts[1] if len(parts) > 1 else "",
                     "secured": bool(parts[2].strip()) if len(parts) > 2 else True})
    if not rows:
        return "no networks found"
    rows.sort(key=lambda r: int(r["signal"] or 0), reverse=True)
    return json.dumps(rows[:15])


def connect_wifi(ssid: str, password: str = "") -> str:
    if not ssid:
        return "ERROR: I need the network name."
    args = ["nmcli", "device", "wifi", "connect", ssid]
    if password:
        args += ["password", password]
    code, _, err = _sudo(args + ["--wait", "25"])
    if code != 0:
        low = err.lower()
        if "secrets" in low or "password" in low:
            return f"ERROR: '{ssid}' needs a password."
        return f"ERROR: could not connect to {ssid}: {err}"
    return f"connected to {ssid}"


def network_status() -> str:
    code, out, _ = _run(["nmcli", "-t", "-f", "TYPE,STATE,CONNECTION",
                         "device", "status"])
    if code != 0:
        return "ERROR: could not read network status"
    active = [l for l in out.splitlines() if ":connected:" in l]
    if not active:
        return "not connected to any network"
    return json.dumps([{"type": l.split(":")[0], "name": l.split(":")[2]}
                       for l in active])


# --------------------------------------------------------------------------
# appearance and locale — shared with Settings through desktop.env
# --------------------------------------------------------------------------

def _read_env() -> dict:
    out = {}
    try:
        for line in CONFIG_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except Exception:
        pass
    return out


def _write_env(key: str, value: str) -> bool:
    """Update one key, preserving comments and the rest of the file."""
    try:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        lines = (CONFIG_PATH.read_text(encoding="utf-8").splitlines()
                 if CONFIG_PATH.exists() else [])
        done = False
        for i, line in enumerate(lines):
            if line.strip().startswith(f"{key}="):
                lines[i] = f"{key}={value}"
                done = True
                break
        if not done:
            lines.append(f"{key}={value}")
        CONFIG_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return True
    except Exception:
        return False


_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")


def set_wallpaper(color: str) -> str:
    """Solid colour only for now — no image support yet."""
    c = (color or "").strip()
    named = {"petrol": "#12232E", "beige": "#D9CFBC", "black": "#0B0B0B",
             "navy": "#101A2E", "grey": "#2B2E33", "gray": "#2B2E33"}
    c = named.get(c.lower(), c)
    if not _HEX.match(c):
        return (f"ERROR: '{color}' is not a colour I understand. "
                "Give me a hex value like #12232E, or: petrol, beige, navy, grey.")
    if not _write_env("OSPRIME_WALLPAPER", c):
        return "ERROR: could not save the setting"
    if shutil.which("swaybg"):
        subprocess.run(["pkill", "swaybg"], capture_output=True)
        subprocess.Popen(["swaybg", "-c", c],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return f"background set to {c}"


def set_language(code: str) -> str:
    code = (code or "").strip().lower()
    if not re.match(r"^[a-z]{2}$", code):
        return f"ERROR: '{code}' is not a language code. Use two letters, such as en or fa."
    if not _write_env("OSPRIME_LANG", code):
        return "ERROR: could not save the setting"
    return f"language set to {code}. Reopen the chat window to see it."


def get_settings() -> str:
    """Everything Settings displays, from the one place that holds it."""
    env = _read_env()
    code, tz, _ = _run(["timedatectl", "show", "--property=Timezone", "--value"])
    return json.dumps({
        "language": env.get("OSPRIME_LANG", "en"),
        "wallpaper": env.get("OSPRIME_WALLPAPER", "#12232E"),
        "timezone": tz if code == 0 else "",
        "cloud_mode": os.environ.get("OSPRIME_CLOUD_MODE", "off"),
    })


# --------------------------------------------------------------------------
# display and sound
# --------------------------------------------------------------------------

def set_volume(percent: int) -> str:
    try:
        p = max(0, min(100, int(percent)))
    except (TypeError, ValueError):
        return f"ERROR: '{percent}' is not a number between 0 and 100."
    if shutil.which("wpctl"):
        code, _, err = _run(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{p}%"])
    elif shutil.which("amixer"):
        code, _, err = _run(["amixer", "-q", "sset", "Master", f"{p}%"])
    else:
        return "ERROR: no audio control available"
    return f"volume set to {p}%" if code == 0 else f"ERROR: could not set volume: {err}"


def system_summary() -> str:
    """Facts about this machine, for answering 'what am I running on'."""
    out = {}
    code, o, _ = _run(["uname", "-r"])
    out["kernel"] = o if code == 0 else ""
    try:
        mem = pathlib.Path("/proc/meminfo").read_text()
        kb = int(re.search(r"MemTotal:\s+(\d+)", mem).group(1))
        out["memory_gb"] = round(kb / 1024 / 1024, 1)
    except Exception:
        pass
    out["cpu_cores"] = os.cpu_count()
    code, o, _ = _run(["df", "-h", "--output=avail,pcent", "/"])
    if code == 0 and len(o.splitlines()) > 1:
        avail, pcent = o.splitlines()[1].split()
        out["disk_free"] = avail
        out["disk_used"] = pcent
    return json.dumps(out)
