"""OSprime desktop control: let the agent launch and manage real GUI windows
on the Wayland session (labwc + wlr protocols).

Uses wlrctl when available for window listing/closing; falls back to plain
process management so the tools still work in a bare session.
"""

import os
import shutil
import signal
import subprocess
import time

# friendly name -> list of candidate commands (first installed one wins)
APPS = {
    "browser":  [["chromium", "--ozone-platform=wayland", "--new-window"],
                 ["chromium-browser", "--ozone-platform=wayland", "--new-window"],
                 ["google-chrome", "--ozone-platform=wayland", "--new-window"],
                 ["firefox"]],
    "chromium": [["chromium"], ["chromium-browser"]],
    "firefox":  [["firefox"]],
    "terminal": [["foot"], ["xterm"], ["gnome-terminal"]],
    "files":    [["thunar"], ["nautilus"], ["pcmanfm"]],
    "editor":   [["mousepad"], ["gnome-text-editor"], ["gedit"], ["nano"]],
    "video":    [["mpv"], ["vlc"]],
    "image":    [["imv"], ["eog"], ["feh"]],
    "calculator": [["gnome-calculator"], ["galculator"]],
}

_launched = {}   # name -> Popen


def _env():
    """The environment a graphical program needs to reach the screen.

    This used to guess: WAYLAND_DISPLAY=wayland-0 and
    XDG_RUNTIME_DIR=/run/user/<our own uid>. The agent runs as root, so that
    was /run/user/0 — a directory that does not exist. Every window this
    module opened therefore died the instant it started, while launch()
    cheerfully reported a pid. Asked to open a video, the assistant said
    "opened in the browser" and nothing appeared.

    system_tools already solved this by finding the compositor's socket.
    One implementation, imported rather than repeated, because two copies of
    this logic is how the first one stayed wrong.
    """
    try:
        import system_tools
        return system_tools._wayland_env()
    except Exception:
        e = os.environ.copy()
        e.setdefault("WAYLAND_DISPLAY", "wayland-0")
        e.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
        return e


def resolve(app: str):
    """Return the argv for an app name, or None if nothing is installed."""
    candidates = APPS.get(app) or [[app]]
    path = _env().get("PATH")
    for argv in candidates:
        exe = shutil.which(argv[0], path=path)
        if exe:
            return [exe] + argv[1:]
    return None


def launch(app: str, args=None) -> str:
    argv = resolve(app)
    if not argv:
        avail = ", ".join(sorted(APPS))
        return f"'{app}' is not installed. Known apps: {avail}"
    argv = argv + list(args or [])
    try:
        # stderr is kept, not discarded. A window that fails to open says
        # why on stderr, and throwing that away is what made this look like
        # a working launch for weeks.
        p = subprocess.Popen(argv, env=_env(), stdout=subprocess.DEVNULL,
                             stderr=subprocess.PIPE, start_new_session=True)
    except Exception as e:
        return f"ERROR: could not start {app}: {e}"

    # A pid is not a window. Give it a moment and check it is still there —
    # anything that cannot reach the display exits immediately.
    time.sleep(1.5)
    if p.poll() is not None:
        try:
            err = (p.stderr.read() or b"").decode("utf-8", "replace")
        except Exception:
            err = ""
        tail = " ".join(err.split())[-300:]
        return (f"ERROR: {app} started and closed again straight away. "
                f"{tail or 'It gave no reason.'} THIS DID NOT OPEN — do not "
                "tell the user it did.")
    _launched[app] = p
    return f"{app} is open on screen (pid {p.pid})"


def _wlrctl(*args):
    if not shutil.which("wlrctl"):
        return None
    try:
        r = subprocess.run(["wlrctl", *args], env=_env(), capture_output=True,
                           text=True, timeout=10)
        return (r.stdout + r.stderr).strip()
    except Exception:
        return None


def list_windows() -> str:
    out = _wlrctl("window", "list")
    if out:
        return out or "(no windows)"
    alive = [f"{n} (pid {p.pid})" for n, p in _launched.items() if p.poll() is None]
    return "\n".join(alive) or "(no windows launched by OSprime)"


def close_window(app: str) -> str:
    out = _wlrctl("window", "close", f"app_id:{app}")
    if out is not None:
        return f"closed {app}"
    p = _launched.get(app)
    if p and p.poll() is None:
        os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        return f"closed {app}"
    return f"no running window for {app}"


def open_url(url: str) -> str:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    for browser in ("chromium", "firefox"):
        if resolve(browser):
            return launch(browser, [url])
    return "no browser installed"
