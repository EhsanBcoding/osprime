"""Making pictures (docs/IMAGES.md; Ehsan, 12 October).

Two ways, chosen the same way as everything else — by the one cloud switch:

  * on this computer: Z-Image-Turbo (Apache 2.0, Alibaba Tongyi) run by
    stable-diffusion.cpp (MIT), only offered on a graphics card with 8 GB or
    more ("Add image making" in Settings downloads ~6.7 GB, each file checked
    against its sha256). While it draws, the chat model steps off the card
    and comes back, the way the vision model does.
  * in the cloud, on the person's own keys: the chat keys that can draw
    (OpenAI, Google, xAI, OpenRouter) and image services added for it
    (Black Forest Labs / FLUX, Ideogram, Recraft, fal.ai). Their cost is on
    the person's own account; nothing paid is built in.

Which one: a service named in the request; else, with the cloud switch on,
the default image service, else the active chat key if it can draw; else
the local model; else say what is missing.

Pictures go to ~/Pictures/OSprime. A prompt asking for sexual content with
a child is refused everywhere; the local model has no filter of its own, so
explicit sexual content is refused there too.
"""
import base64
import datetime
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import time
import urllib.parse
import urllib.request
import uuid
import zipfile

import paths

# ---------------------------------------------------------------------------
# the local engine and model: pinned, checked
# ---------------------------------------------------------------------------
ENGINE = {
    "url": "https://github.com/leejet/stable-diffusion.cpp/releases/download/master-872-cc515a0/"
           "sd-master-cc515a0-bin-Linux-Ubuntu-24.04-x86_64-vulkan.zip",
    "sha256": "05af485a8405cdded7318cec19ef5e28c75621ea56be3c4035f1c8f46329e706",
    "size": 38408438,
}
FILES = [
    {"role": "diffusion", "name": "z_image_turbo-Q4_K.gguf",
     "url": "https://huggingface.co/leejet/Z-Image-Turbo-GGUF/resolve/main/z_image_turbo-Q4_K.gguf",
     "sha256": "14b375ab4f226bc5378f68f37e899ef3c2242b8541e61e2bc1aff40976086fbd", "size": 3864250304},
    {"role": "llm", "name": "Qwen3-4B-Instruct-2507-Q4_K_M.gguf",
     "url": "https://huggingface.co/unsloth/Qwen3-4B-Instruct-2507-GGUF/resolve/main/"
            "Qwen3-4B-Instruct-2507-Q4_K_M.gguf",
     "sha256": "3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597", "size": 2497281120},
    {"role": "vae", "name": "ae.safetensors",
     "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/vae/ae.safetensors",
     "sha256": "afc8e28272cd15db3919bacdb6918ce9c1ed22e96cb12c4d5ed0fba823529e38", "size": 335304388},
]
MIN_VRAM_GB = 7.5          # "8 GB or more" (Ehsan, 12 October); cards report a little less
UA = {"User-Agent": "OSprime/1.0 (images)"}


def home() -> pathlib.Path:
    return paths.data_dir() / "imagegen"


def _bin():
    d = home() / "bin"
    for name in ("sd-cli", "sd"):
        for p in d.rglob(name):
            if p.is_file() and os.access(p, os.X_OK):
                return p
    return None


def local_ready() -> bool:
    return _bin() is not None and all((home() / "models" / f["name"]).is_file() for f in FILES)


def gpu_ok():
    """(True, "") when this computer may make pictures itself, else (False, why)."""
    try:
        import hardware
        gpu = hardware.profile().get("gpu") or {}
    except Exception as e:
        return False, f"could not read this computer ({e})"
    if gpu.get("useful") and float(gpu.get("vram_gb") or 0) >= MIN_VRAM_GB:
        return True, ""
    have = f"{gpu.get('vram_gb')} GB" if gpu.get("useful") else "no usable graphics card"
    return False, (f"making pictures here needs a graphics card with 8 GB or more ({have}); "
                   "a cloud image service works on any computer")


def _sha256(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _download(url, dest: pathlib.Path, sha, size, progress=None):
    """Resumable (.part + Range), and checked against its sha256 at the end."""
    part = dest.with_name(dest.name + ".part")
    have = part.stat().st_size if part.exists() else 0
    if have > size:
        part.unlink()
        have = 0
    if have < size:
        req = urllib.request.Request(url, headers=dict(UA, **({"Range": f"bytes={have}-"} if have else {})))
        with urllib.request.urlopen(req, timeout=60) as r, open(part, "ab" if have else "wb") as f:
            if have and r.status != 206:          # the server ignored Range: start again
                f.truncate(0)
                have = 0
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
                have += len(chunk)
                if progress:
                    progress(len(chunk))
    if _sha256(part) != sha:
        part.unlink()
        raise RuntimeError(f"{dest.name} did not match its checksum — it was deleted; try again")
    part.replace(dest)


def install(progress=None) -> dict:
    """Download the engine and the model. Runs as the person, into their
    own data folder: no root, no sudo."""
    ok, why = gpu_ok()
    if not ok:
        return {"ok": False, "message": why}
    need = ENGINE["size"] + sum(f["size"] for f in FILES)
    free = shutil.disk_usage(paths.data_dir() if paths.data_dir().exists() else paths.home()).free
    if free < need + 1_000_000_000:
        return {"ok": False, "message": f"not enough free disk space — it needs about "
                                        f"{(need + 1_000_000_000) // 1_000_000_000 + 1} GB"}
    (home() / "models").mkdir(parents=True, exist_ok=True)
    (home() / "bin").mkdir(parents=True, exist_ok=True)
    try:
        for f in FILES:
            dest = home() / "models" / f["name"]
            if not dest.is_file():
                _download(f["url"], dest, f["sha256"], f["size"], progress)
        if _bin() is None:
            z = home() / "engine.zip"
            _download(ENGINE["url"], z, ENGINE["sha256"], ENGINE["size"], progress)
            with zipfile.ZipFile(z) as zf:
                for m in zf.infolist():
                    target = (home() / "bin" / m.filename).resolve()
                    if home().resolve() not in target.parents:
                        raise RuntimeError("the engine archive has a file outside its folder")
                zf.extractall(home() / "bin")
            z.unlink()
            for p in (home() / "bin").rglob("*"):
                if p.is_file() and (p.name in ("sd", "sd-cli") or ".so" in p.name):
                    p.chmod(0o755)
    except Exception as e:
        return {"ok": False, "message": f"could not finish: {e}"}
    if not local_ready():
        return {"ok": False, "message": "the engine was downloaded but its program was not found in it"}
    return {"ok": True, "message": "This computer can make pictures now."}


def _state_file() -> pathlib.Path:
    return paths.data_dir() / "imagegen-install.json"


def install_state() -> dict:
    try:
        st = json.loads(_state_file().read_text())
    except Exception:
        return {}
    if st.get("running") and time.time() - st.get("at", 0) > 600:
        st["running"] = False            # no progress for ten minutes: the window was closed
        st["message"] = "stopped — press Add again to carry on where it left off"
    return st


def _put_state(**kw):
    try:
        _state_file().parent.mkdir(parents=True, exist_ok=True)
        _state_file().write_text(json.dumps(dict(kw, at=time.time())))
    except Exception:
        pass


def start_install() -> dict:
    """From Settings: download in the background, progress on the activity card."""
    if install_state().get("running"):
        return {"ok": True, "message": "Already downloading."}
    ok, why = gpu_ok()
    if not ok:
        return {"ok": False, "message": why[0].upper() + why[1:] + "."}
    import threading
    total = ENGINE["size"] + sum(f["size"] for f in FILES)

    def go():
        done = [sum((home() / "models" / f["name"]).stat().st_size
                    for f in FILES if (home() / "models" / f["name"]).is_file())]
        aid = None
        try:
            import activity
            aid = activity.begin("Downloading image making", "download")
        except Exception:
            pass
        last = [0.0]

        def progress(n):
            done[0] += n
            if time.time() - last[0] > 2:
                last[0] = time.time()
                pct = min(99, int(done[0] * 100 / total))
                _put_state(running=True, percent=pct)
                if aid:
                    try:
                        import activity
                        activity.update(aid, pct)
                    except Exception:
                        pass
        _put_state(running=True, percent=int(done[0] * 100 / total))
        r = install(progress)
        _put_state(running=False, ok=r["ok"], message=r["message"], percent=100 if r["ok"] else None)
        if aid:
            try:
                import activity
                activity.end(aid, ok=r["ok"])
            except Exception:
                pass
    threading.Thread(target=go, daemon=True).start()
    return {"ok": True, "message": f"Downloading about {total / 1e9:.1f} GB. You can keep working."}


def remove() -> dict:
    if install_state().get("running"):
        return {"ok": False, "message": "Still downloading — wait for it to finish."}
    shutil.rmtree(home(), ignore_errors=True)
    try:
        _state_file().unlink()
    except FileNotFoundError:
        pass
    return {"ok": True, "message": "Image making removed from this computer (about 7 GB freed)."}


def generate_local(prompt: str, out: pathlib.Path, w: int = 1024, h: int = 1024) -> str:
    sd = _bin()
    if sd is None or not local_ready():
        raise RuntimeError("image making is not installed on this computer")
    m = {f["role"]: str(home() / "models" / f["name"]) for f in FILES}
    cmd = [str(sd), "--diffusion-model", m["diffusion"], "--vae", m["vae"], "--llm", m["llm"],
           "-p", prompt, "--cfg-scale", "1.0", "--steps", "8", "-W", str(w), "-H", str(h),
           "--offload-to-cpu", "--diffusion-fa", "-o", str(out)]
    env = dict(os.environ, LD_LIBRARY_PATH=f"{sd.parent}:{os.environ.get('LD_LIBRARY_PATH', '')}")
    import engines
    with engines.card_for_pictures():
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=900, env=env)
    if r.returncode != 0 or not out.is_file():
        tail = (r.stderr or r.stdout or "").strip().splitlines()[-3:]
        raise RuntimeError("the picture could not be made: " + " ".join(tail)[:300])
    return str(out)


# ---------------------------------------------------------------------------
# the cloud: the chat keys that can draw, and keys added for pictures only
# ---------------------------------------------------------------------------
# Every service that draws, with the models offered in Settings (Ehsan, 12
# October: "the models they support ready to choose, not typed in"). The
# first is the default. For the services with a model list of their own
# (OpenAI, Google, xAI, OpenRouter) Settings also asks the service, so a
# model released after this list is written still shows up.
SERVICES = {
    "openai": {"name": "OpenAI", "good_at": "following long, exact instructions; text in pictures",
               "models": [("gpt-image-2", "GPT Image 2"), ("gpt-image-1.5", "GPT Image 1.5"),
                          ("gpt-image-1", "GPT Image 1"), ("gpt-image-1-mini", "GPT Image 1 mini (cheaper)")]},
    "google": {"name": "Google Gemini", "good_at": "fast everyday pictures and editing (Nano Banana)",
               "models": [("gemini-3.1-flash-image", "Gemini 3.1 Flash Image (Nano Banana 2)"),
                          ("gemini-3-pro-image-preview", "Gemini 3 Pro Image (Nano Banana Pro)"),
                          ("gemini-2.5-flash-image", "Gemini 2.5 Flash Image")]},
    "xai": {"name": "xAI (Grok)", "good_at": "bold styles and quick drafts",
            "models": [("grok-imagine-image-2.0", "Grok Imagine Image 2.0"),
                       ("grok-imagine-image", "Grok Imagine Image"), ("grok-2-image", "Grok 2 Image")]},
    "openrouter": {"name": "OpenRouter", "good_at": "one key for the image models of several companies",
                   "models": [("google/gemini-3.1-flash-image", "Google · Gemini 3.1 Flash Image"),
                              ("google/gemini-2.5-flash-image", "Google · Gemini 2.5 Flash Image"),
                              ("openai/gpt-image-2", "OpenAI · GPT Image 2")]},
    "bfl": {"name": "Black Forest Labs (FLUX)", "good_at": "photorealism",
            "models": [("flux-2-pro", "FLUX.2 [pro]"), ("flux-2-max", "FLUX.2 [max] (best, slower)"),
                       ("flux-2-flex", "FLUX.2 [flex]"), ("flux-pro-1.1-ultra", "FLUX1.1 [pro] Ultra"),
                       ("flux-pro-1.1", "FLUX1.1 [pro]")]},
    "ideogram": {"name": "Ideogram", "good_at": "text inside pictures — logos, posters, banners",
                 "models": [("DEFAULT", "Ideogram 3.0"), ("QUALITY", "Ideogram 3.0 · Quality (slower)"),
                            ("TURBO", "Ideogram 3.0 · Turbo (faster)"), ("FLASH", "Ideogram 3.0 · Flash (fastest)")]},
    "recraft": {"name": "Recraft", "good_at": "vector pictures (SVG) and a consistent brand style",
                "models": [("recraftv4_1", "Recraft V4.1"), ("recraftv3", "Recraft V3")]},
    "fal": {"name": "fal.ai", "good_at": "one key for many models (FLUX, Ideogram, Recraft and more)",
            "models": [("fal-ai/flux-2-pro", "FLUX.2 [pro]"), ("fal-ai/flux-pro/v1.1-ultra", "FLUX1.1 [pro] Ultra"),
                       ("fal-ai/flux-pro/v1.1", "FLUX1.1 [pro]"), ("fal-ai/ideogram/v3", "Ideogram 3.0"),
                       ("fal-ai/recraft/v3/text-to-image", "Recraft V3"), ("fal-ai/imagen4/preview", "Google Imagen 4")]},
}
CHAT_DRAWS = ("openai", "google", "xai", "openrouter")    # chat keys that can draw too
_BASE = {"openai": "https://api.openai.com/v1", "xai": "https://api.x.ai/v1",
         "openrouter": "https://openrouter.ai/api/v1"}
_MODEL_RE = re.compile(r"^[\w.:/@-]{1,120}$")


def _cloud():
    import cloud
    return cloud


def default_model(service: str) -> str:
    return SERVICES[service]["models"][0][0]


def _drawers(st=None) -> list:
    """Everything that can draw, as one list: keys added here, then the chat
    keys whose service draws. Each: {id, service, key, model, kind}."""
    st = st or _cloud().load()
    out = [dict(k, kind="image") for k in st.get("image_keys") or [] if k.get("service") in SERVICES]
    chosen = st.get("image_models") or {}
    for e in st.get("keys") or []:
        if e.get("provider") in CHAT_DRAWS:
            out.append({"id": e["id"], "service": e["provider"], "key": e["key"], "kind": "chat",
                        "base_url": e.get("base_url", ""),
                        # a picture model typed as the chat model before
                        # Making pictures had its own menu is used for pictures
                        "model": chosen.get(e["id"]) or (e.get("model") if _cloud()._picture_model(
                            e.get("model") or "") else default_model(e["provider"]))})
    return out


def public_view() -> dict:
    """For Settings: everything but the keys themselves."""
    st = _cloud().load()
    ok, why = gpu_ok()
    return {"local": {"ready": local_ready(), "can": ok, "why": why, "install": install_state(),
                      "size_gb": round((ENGINE["size"] + sum(f["size"] for f in FILES)) / 1e9, 1)},
            "services": [{"id": k, "name": v["name"], "good_at": v["good_at"],
                          "models": [{"id": m, "name": n} for m, n in v["models"]]}
                         for k, v in SERVICES.items()],
            "keys": [{"id": d["id"], "service": d["service"], "name": SERVICES[d["service"]]["name"],
                      "kind": d["kind"], "model": d["model"], "tail": d["key"][-4:]}
                     for d in _drawers(st)],
            "default": st.get("image_default", ""), "last": last(),
            "uses": _uses(st)}


def _uses(st) -> str:
    """In words: what draws the next picture when no service is named."""
    try:
        how, why = choose()
    except Exception:
        return ""
    if how == "local":
        return "this computer (Z-Image-Turbo)"
    if how is None:
        return ""
    return SERVICES[how["service"]]["name"] + " · " + how["model"]


def add_key(service: str, key: str, model: str = "") -> dict:
    if service not in SERVICES:
        return {"ok": False, "message": "Unknown image service."}
    key = (key or "").strip()
    if len(key) < 8 or any(c.isspace() for c in key):
        return {"ok": False, "message": "Paste the key first."}
    model = (model or "").strip() or default_model(service)
    if not _MODEL_RE.match(model):
        return {"ok": False, "message": "That is not a model name."}
    st = _cloud().load()
    entry = {"id": uuid.uuid4().hex[:8], "service": service, "key": key, "model": model}
    st.setdefault("image_keys", []).append(entry)
    if not st.get("image_default"):
        st["image_default"] = entry["id"]
    _cloud().save(st)
    return {"ok": True, "id": entry["id"],
            "message": f"{SERVICES[service]['name']} saved. It is checked the first time it draws."}


def set_model(kid: str, model: str) -> dict:
    """The picture model for a key — one added here or a chat key that draws."""
    model = (model or "").strip()
    if not _MODEL_RE.match(model):
        return {"ok": False, "message": "That is not a model name."}
    st = _cloud().load()
    for k in st.get("image_keys") or []:
        if k["id"] == kid:
            k["model"] = model
            _cloud().save(st)
            return {"ok": True, "message": f"Pictures now use {model}."}
    if any(e["id"] == kid and e.get("provider") in CHAT_DRAWS for e in st.get("keys") or []):
        st.setdefault("image_models", {})[kid] = model
        _cloud().save(st)
        return {"ok": True, "message": f"Pictures now use {model}; the chat model is unchanged."}
    return {"ok": False, "message": "That key is not saved any more."}


def remove_key(kid: str) -> dict:
    """Only keys added here; a chat key is removed in the Cloud model section."""
    st = _cloud().load()
    st["image_keys"] = [k for k in st.get("image_keys") or [] if k["id"] != kid]
    if st.get("image_default") == kid:
        st["image_default"] = st["image_keys"][0]["id"] if st["image_keys"] else ""
    _cloud().save(st)
    return {"ok": True, "message": "Removed."}


def set_default(kid: str) -> dict:
    st = _cloud().load()
    if kid and not any(d["id"] == kid for d in _drawers(st)):
        return {"ok": False, "message": "That key is not saved any more."}
    st["image_default"] = kid
    _cloud().save(st)
    return {"ok": True, "message": "Default image service set." if kid else "No default image service."}


def _get_json(url, headers):
    try:
        r = _http(url, headers=headers, timeout=20)
        return r if isinstance(r, (dict, list)) else {}
    except Exception:
        return {}


def live_models(kid: str) -> dict:
    """The picture models the service itself lists for this key, after the
    ones written above. Services with no list of their own get the list above."""
    d = next((d for d in _drawers() if d["id"] == kid), None)
    if d is None:
        return {"models": [], "message": "That key is not saved any more."}
    s, key = d["service"], d["key"]
    known = [{"id": m, "name": n} for m, n in SERVICES[s]["models"]]
    found = []
    if s in ("openai", "xai"):
        base = (d.get("base_url") or _BASE[s]).rstrip("/")
        j = _get_json(base + ("/image-generation-models" if s == "xai" else "/models"),
                      {"Authorization": "Bearer " + key})
        rows = j.get("models") or j.get("data") or []
        found = [r.get("id") for r in rows if isinstance(r, dict) and r.get("id")
                 and (s == "xai" or re.search(r"image|dall-e", r["id"]))]
    elif s == "google":
        j = _get_json("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",
                      {"x-goog-api-key": key})
        found = [r["name"].split("/", 1)[-1] for r in j.get("models") or []
                 if "image" in r.get("name", "") and "generateContent" in (r.get("supportedGenerationMethods") or [])]
    elif s == "openrouter":
        j = _get_json("https://openrouter.ai/api/v1/models?output_modalities=image",
                      {"Authorization": "Bearer " + key})
        found = [r["id"] for r in j.get("data") or []
                 if "image" in ((r.get("architecture") or {}).get("output_modalities") or [])]
    have = {m["id"] for m in known}
    extra = [{"id": m, "name": m} for m in sorted(set(found)) if m not in have and _MODEL_RE.match(m)]
    return {"models": known + extra, "current": d["model"]}


def choose(service: str = ""):
    """(drawer, "") | ("local", "") | (None, why)."""
    st = _cloud().load()
    drawers = _drawers(st)
    want = (service or "").strip().lower()
    if want in ("local", "here", "this computer"):
        return ("local", "") if local_ready() else (None, "image making is not installed here")
    if want:
        for d in drawers:                       # a key added for pictures first
            nm = SERVICES[d["service"]]["name"].lower()
            if want == d["service"] or want in nm or nm.split(" (")[0] in want:
                return d, ""
        return None, f"there is no saved key for {service}; add one in Settings → Making pictures"
    if _cloud().enabled():
        d = next((d for d in drawers if d["id"] == st.get("image_default")), None)
        if d:
            return d, ""
        cur = _cloud().current()
        d = next((d for d in drawers if cur and d["id"] == cur.get("id")), None)
        if d:
            return d, ""
    if local_ready():
        return "local", ""
    pictures_only = [d for d in drawers if d["kind"] == "image"]
    if pictures_only:
        return next((d for d in pictures_only if d["id"] == st.get("image_default")), pictures_only[0]), ""
    ok, why = gpu_ok()
    if ok:
        return None, "image making is not set up yet — Settings → Making pictures → Add image making"
    return None, why + "; add a key in Settings → Making pictures"


def _http(url, body=None, headers=None, method=None, timeout=120):
    data = None
    h = dict(UA, **(headers or {}))
    if isinstance(body, (dict, list)):
        data = json.dumps(body).encode()
        h.setdefault("Content-Type", "application/json")
    elif isinstance(body, bytes):
        data = body
    req = urllib.request.Request(url, data=data, headers=h, method=method or ("POST" if data else "GET"))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read(40_000_000)
            ctype = r.headers.get("Content-Type", "")
    except urllib.error.HTTPError as e:
        msg = e.read().decode("utf-8", "replace")[:300]
        if e.code in (401, 403):
            raise RuntimeError("the service refused the key")
        if e.code == 402:
            raise RuntimeError("the account has no credit left")
        if e.code == 429:
            raise RuntimeError("too many requests — try again in a minute")
        if e.code == 404 and re.search(r"model", msg, re.I):
            raise RuntimeError("the service does not know that model — choose another in Settings → Making pictures")
        if e.code == 400 and re.search(r"safety|moderation|policy|content", msg, re.I):
            raise RuntimeError("the service would not draw that (its content rules)")
        raise RuntimeError(f"the service said {e.code}: {msg[:160]}")
    except urllib.error.URLError:
        raise RuntimeError("could not reach the service — is the internet on?")
    return (json.loads(raw.decode("utf-8", "replace")) if "json" in ctype or raw[:1] in (b"{", b"[")
            else raw)


def _fetch_picture(url_or_data: str) -> bytes:
    if url_or_data.startswith("data:"):
        return base64.b64decode(url_or_data.split(",", 1)[1])
    if not url_or_data.startswith("https://"):
        raise RuntimeError("the service sent no picture")
    raw = _http(url_or_data, timeout=120)
    if not isinstance(raw, bytes):
        raise RuntimeError("the service sent no picture")
    return raw


def _multipart(fields: dict):
    b = "----osprime" + uuid.uuid4().hex
    out = b""
    for k, v in fields.items():
        out += (f"--{b}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n").encode()
    return out + f"--{b}--\r\n".encode(), f"multipart/form-data; boundary={b}"


def _draw(d, prompt, vector=False, size="square", poll_every=1.0) -> tuple:
    """(bytes, extension) from one drawer."""
    s, key, model = d["service"], d["key"], d.get("model") or default_model(d["service"])
    wide, tall = size == "wide", size == "tall"
    if s in ("openai", "xai"):
        base = (d.get("base_url") or _BASE[s]).rstrip("/")
        body = {"model": model, "prompt": prompt, "n": 1}
        if s == "openai":
            body["size"] = "1536x1024" if wide else "1024x1536" if tall else "1024x1024"
        else:
            body["response_format"] = "b64_json"
        r = _http(base + "/images/generations", body, {"Authorization": "Bearer " + key})
        x = (r.get("data") or [{}])[0]
        return (base64.b64decode(x["b64_json"]) if x.get("b64_json") else _fetch_picture(x.get("url", ""))), "png"
    if s == "google":
        cfg = {"responseModalities": ["IMAGE", "TEXT"]}
        if wide or tall:
            cfg["imageConfig"] = {"aspectRatio": "16:9" if wide else "9:16"}
        r = _http(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                  {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": cfg},
                  {"x-goog-api-key": key})
        for part in ((r.get("candidates") or [{}])[0].get("content") or {}).get("parts") or []:
            inline = part.get("inlineData") or part.get("inline_data")
            if inline and inline.get("data"):
                return base64.b64decode(inline["data"]), "png"
        raise RuntimeError("Google sent no picture (its content rules may have stopped it)")
    if s == "openrouter":
        r = _http("https://openrouter.ai/api/v1/chat/completions",
                  {"model": model, "messages": [{"role": "user", "content": prompt}],
                   "modalities": ["image", "text"]},
                  {"Authorization": "Bearer " + key, "HTTP-Referer": "https://osprime.app", "X-Title": "OSprime"})
        msg = (r.get("choices") or [{}])[0].get("message") or {}
        for im in msg.get("images") or []:
            u = (im.get("image_url") or {}).get("url") or ""
            if u:
                return _fetch_picture(u), "png"
        raise RuntimeError("OpenRouter sent no picture — that model may not draw")
    if s == "bfl":
        body = {"prompt": prompt}
        if "ultra" in model:
            body["aspect_ratio"] = "16:9" if wide else "9:16" if tall else "1:1"
        else:
            body.update(width=1344 if wide else 768 if tall else 1024, height=768 if wide else 1344 if tall else 1024)
        r = _http(f"https://api.bfl.ai/v1/{model}", body, {"x-key": key})
        poll = r.get("polling_url") or f"https://api.bfl.ai/v1/get_result?id={r.get('id', '')}"
        for _ in range(240):
            time.sleep(poll_every)
            j = _http(poll, headers={"x-key": key})
            st = j.get("status")
            if st == "Ready":
                return _fetch_picture((j.get("result") or {}).get("sample", "")), "png"
            if st in ("Error", "Failed", "Request Moderated", "Content Moderated"):
                raise RuntimeError("Black Forest Labs would not draw that" if "Moderated" in st
                                   else "Black Forest Labs could not draw it")
        raise RuntimeError("Black Forest Labs took too long")
    if s == "ideogram":
        fields = {"prompt": prompt, "rendering_speed": model if model in ("DEFAULT", "QUALITY", "TURBO", "FLASH")
                  else "DEFAULT"}
        if wide or tall:
            fields["aspect_ratio"] = "16x9" if wide else "9x16"
        body, ctype = _multipart(fields)
        r = _http("https://api.ideogram.ai/v1/ideogram-v3/generate", body,
                  {"Api-Key": key, "Content-Type": ctype})
        return _fetch_picture(((r.get("data") or [{}])[0]).get("url", "")), "png"
    if s == "recraft":
        body = {"prompt": prompt, "model": model}
        if vector:
            if model.startswith("recraftv4"):
                body["model"] = model.replace("_vector", "") + "_vector"
            else:
                body["style"] = "vector_illustration"
        r = _http("https://external.api.recraft.ai/v1/images/generations", body,
                  {"Authorization": f"Bearer {key}"})
        url = ((r.get("data") or [{}])[0]).get("url", "")
        return _fetch_picture(url), ("svg" if url.split("?")[0].endswith(".svg") else "png")
    if s == "fal":
        r = _http(f"https://fal.run/{model}",
                  {"prompt": prompt, "image_size": "landscape_16_9" if wide else "portrait_16_9" if tall
                   else "square_hd"}, {"Authorization": f"Key {key}"})
        return _fetch_picture(((r.get("images") or [{}])[0]).get("url", "")), "png"
    raise RuntimeError("unknown image service")


# ---------------------------------------------------------------------------
# the one entry point
# ---------------------------------------------------------------------------
_SEX = re.compile(r"\b(nude|naked|nsfw|sex|sexual|porn|erotic|explicit|topless|lingerie)\b|"
                  r"برهنه|لخت|سکسی|جنسی|پورن|عریان", re.I)
_MINOR = re.compile(r"\b(child|children|kid|kids|minor|teen|teens|teenager|underage|young girl|"
                    r"young boy|schoolgirl|schoolboy|loli|toddler|baby)\b|\b1[0-7]\s*(yo|year)|"
                    r"کودک|بچه|نوجوان|دختربچه|پسربچه|خردسال|نابالغ", re.I)


def refused(prompt: str, local: bool) -> str:
    if _SEX.search(prompt or "") and _MINOR.search(prompt or ""):
        return "I will not make that picture."
    if local and _SEX.search(prompt or ""):
        return "I don't make sexual pictures on this computer."
    return ""


def folder() -> pathlib.Path:
    return paths.home() / "Pictures" / "OSprime"


def _name(prompt: str, ext: str) -> pathlib.Path:
    slug = re.sub(r"[^\w]+", "-", prompt.lower(), flags=re.U).strip("-")[:40] or "picture"
    stamp = datetime.datetime.now().strftime("%Y-%m-%d-%H%M%S")
    folder().mkdir(parents=True, exist_ok=True)
    out, n = folder() / f"{stamp}-{slug}.{ext}", 2
    while out.exists():
        out, n = folder() / f"{stamp}-{slug}-{n}.{ext}", n + 1
    return out


def _last_file() -> pathlib.Path:
    return paths.data_dir() / "images-last.json"


def _remember_last(by: str, path: str):
    """Shown in Settings: which service made the last picture — the chat badge
    names the chat model, not the one that drew (12 October)."""
    try:
        _last_file().parent.mkdir(parents=True, exist_ok=True)
        _last_file().write_text(json.dumps({"by": by, "path": path,
                                            "at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}))
    except Exception:
        pass


def last() -> dict:
    try:
        return json.loads(_last_file().read_text())
    except Exception:
        return {}


def make(prompt: str, service: str = "", size: str = "square", vector: bool = False) -> dict:
    """{"ok", "path", "by", "message"}."""
    prompt = " ".join((prompt or "").split())[:1500]
    if len(prompt) < 3:
        return {"ok": False, "message": "Say what the picture should show."}
    vector = vector or bool(re.search(r"\b(svg|vector)\b|وکتور", prompt, re.I))
    how, why = choose(service)
    if how is None:
        return {"ok": False, "message": why[0].upper() + why[1:] + "."}
    no = refused(prompt, how == "local")
    if no:
        return {"ok": False, "message": no}
    w, h = {"wide": (1216, 832), "tall": (832, 1216)}.get(size, (1024, 1024))
    aid = None
    try:
        import activity
        aid = activity.begin("Making a picture", "job")
    except Exception:
        pass
    ok = False
    try:
        if how == "local":
            out = _name(prompt, "png")
            generate_local(prompt, out, w, h)
            by = "this computer (Z-Image-Turbo)"
        else:
            data, ext = _draw(how, prompt, vector, size)
            by = SERVICES[how["service"]]["name"] + " · " + how["model"]
            if data[:4] == b"<svg" or data[:5] == b"<?xml":
                ext = "svg"
            out = _name(prompt, ext)
            out.write_bytes(data)
        ok = True
        _remember_last(by, str(out))
        return {"ok": True, "path": str(out), "by": by, "message": f"Made by {by}; saved in Pictures/OSprime."}
    except Exception as e:
        return {"ok": False, "message": f"Could not make the picture: {e}."}
    finally:
        if aid:
            try:
                import activity
                activity.end(aid, ok=ok)
            except Exception:
                pass
