"""Settings -> System -> Secure Boot. docs/ENCRYPTION.md, plan C.

Reading where it stands needs no privilege: the firmware's own variables
are readable by everyone, and the stage is in a world-readable file. Every
change goes through shell/osprime-secureboot.sh with `sudo -S -k` and the
administrator's OWN password, exactly like People: there is no
password-free rule for putting keys into the firmware.
"""
import os
import re
import subprocess

import people

SCRIPT = os.environ.get("OSPRIME_SB_SCRIPT", "/opt/osprime/shell/osprime-secureboot.sh")
ACTIONS = ("prepare", "enroll", "finish", "firmware")

# What the page says, by stage. `next` names the one button to show.
STEPS = {
    "none": ("Off", "Protects against tampering with the startup files. Step 1 of 3 "
             "makes this computer's own keys and one signed startup file.", "prepare"),
    "prepared": ("Ready — keys made, startup file signed",
                 "Step 2 of 3: restart into the firmware setup, clear the Secure Boot "
                 "keys (often called 'Reset to Setup Mode' or 'Delete all keys'), "
                 "save and come back here.", "firmware"),
    "setup": ("Ready — the firmware is waiting for keys",
              "Step 2 of 3: put this computer's keys into the firmware.", "enroll"),
    "enrolled": ("Keys are in the firmware",
                 "Step 3 of 3: restart. If the firmware does not switch Secure Boot on "
                 "by itself, switch it on there. OSprime finishes by itself at the "
                 "next start.", ""),
    "enrolled-pin": ("Secure Boot is on — one step left",
                     "Your disk has a PIN, so the last step needs it: type it and "
                     "finish.", "finish"),
    "done": ("On, with this computer's own keys",
             "The startup files are signed and the disk opens only after a checked "
             "start.", ""),
}


def _status_lines() -> dict:
    try:
        out = subprocess.run(["bash", SCRIPT, "status"], capture_output=True,
                             text=True, timeout=10).stdout
    except Exception:
        return {}
    return dict(l.split("=", 1) for l in out.splitlines() if "=" in l)


def status() -> dict:
    s = _status_lines()
    if not s:
        return {"available": False, "text": "Could not read the Secure Boot state", "note": ""}
    if s.get("uefi") != "yes":
        return {"available": False, "text": "Not possible here",
                "note": "This computer starts in BIOS mode; Secure Boot needs UEFI."}
    stage = s.get("stage", "none")
    key = stage
    if stage == "prepared" and s.get("setup_mode") == "yes":
        key = "setup"
    if stage == "enrolled" and s.get("secure_boot") == "on" and s.get("unlock") == "tpm-pin":
        key = "enrolled-pin"
    if stage == "done" and s.get("secure_boot") != "on":
        text, note, nxt = ("Switched off in the firmware",
                           "The keys are still there — switch Secure Boot on again in "
                           "the firmware setup. Until then the disk asks for its "
                           "password or recovery key.", "firmware")
    else:
        text, note, nxt = STEPS.get(key, STEPS["none"])
    return {"available": True, "stage": stage, "secure_boot": s.get("secure_boot"),
            "setup_mode": s.get("setup_mode"), "text": text, "note": note, "next": nxt,
            "needs_pin": s.get("unlock") == "tpm-pin" and nxt in ("enroll", "finish"),
            "admin": people.is_admin()}


def run(admin_password: str, action: str, pin: str = "") -> dict:
    if action not in ACTIONS:
        return {"ok": False, "message": "unknown request"}
    if not people.is_admin():
        return {"ok": False, "message": "only an administrator can do that"}
    if not admin_password:
        return {"ok": False, "message": "type your own password to confirm"}
    stdin = admin_password + "\n" + (pin + "\n" if pin else "")
    try:
        r = subprocess.run(["sudo", "-S", "-k", "-p", "", "/usr/bin/bash", SCRIPT, action],
                           input=stdin, text=True, capture_output=True, timeout=900)
    except Exception as e:
        return {"ok": False, "message": f"could not run: {e}"}
    err = r.stderr or ""
    if re.search(r"incorrect password|Sorry, try again|no password was provided", err, re.I):
        return {"ok": False, "message": "your password was not accepted"}
    text = "\n".join(l.replace("ERROR: ", "").lstrip("> ")
                     for l in (err if r.returncode else r.stdout).strip().splitlines()
                     if l.strip() and "[sudo]" not in l)
    return {"ok": r.returncode == 0, "message": text.splitlines()[-1] if text else
            ("Done." if r.returncode == 0 else "It did not work.")}
