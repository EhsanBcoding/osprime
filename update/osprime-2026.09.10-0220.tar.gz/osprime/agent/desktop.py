"""OSprime desktop control: let the agent launch and manage real GUI windows
on the Wayland session (labwc + wlr protocols).

Uses wlrctl when available for window listing/closing; falls back to plain
process management so the tools still work in a bare session.
"""

import os
import pathlib
import shutil
import signal
import subprocess
import time

def _browser_script():
    """The one place the browser's flags live.

    Chromium needs --no-sandbox, --test-type and a Wayland platform to start
    without a full session, and it needs a stale SingletonLock cleared —
    installing copies a home directory whose hostname was archiso, and
    chromium refuses to start when the lock names another machine.
    osprime-browser.sh has all of that. This module was launching bare
    `chromium` instead, so every page the assistant opened failed exactly
    the way the script's own comment says the menu entry used to fail.
    """
    p = pathlib.Path(__file__).resolve().parent.parent / "shell" / "osprime-browser.sh"
    return ["bash", str(p)] if p.is_file() else None


# friendly name -> list of candidate commands (first installed one wins)
APPS = {
    # osprime-browser.sh is put at the front of the browser entries below,
    # because the script's path depends on where OSprime is installed. The
    # bare-chromium commands stay as a last resort.
    "browser":  [["chromium", "--ozone-platform=wayland", "--new-window"],
                 ["chromium-browser", "--ozone-platform=wayland", "--new-window"],
                 ["google-chrome", "--ozone-platform=wayland", "--new-window"],
                 ["firefox"]],
    "chromium": [["chromium"], ["chromium-browser"]],
    "firefox":  [["firefox"]],
    "terminal": [["foot"], ["xterm"], ["gnome-terminal"]],
    "files":    [["thunar"], ["nautilus"], ["pcmanfm"]],
    "editor":   [["mousepad"], ["gnome-text-editor"], ["gedit"], ["nano"]],
    "video":    [["mpv"], ["vlc"]],
    "image":    [["imv"], ["eog"], ["feh"]],
    "calculator": [["gnome-calculator"], ["galculator"]],
}

if _browser_script():
    APPS["browser"].insert(0, _browser_script())
    APPS["chromium"].insert(0, _browser_script())

_launched = {}   # name -> Popen


def _env():
    """The environment a graphical program needs to reach the screen.

    This used to guess: WAYLAND_DISPLAY=wayland-0 and
    XDG_RUNTIME_DIR=/run/user/<our own uid>. The agent runs as root, so that
    was /run/user/0 — a directory that does not exist. Every window this
    module opened therefore died the instant it started, while launch()
    cheerfully reported a pid. Asked to open a video, the assistant said
    "opened in the browser" and nothing appeared.

    system_tools already solved this by finding the compositor's socket.
    One implementation, imported rather than repeated, because two copies of
    this logic is how the first one stayed wrong.
    """
    try:
        import system_tools
        e = system_tools._wayland_env()
        home = str(system_tools._user_home())
    except Exception:
        e = os.environ.copy()
        e.setdefault("WAYLAND_DISPLAY", "wayland-0")
        e.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
        home = os.path.expanduser("~" + (os.environ.get("SUDO_USER") or "osprime"))
    # The agent runs as root, so HOME is /root. A browser started with that
    # keeps its profile, bookmarks and logins somewhere the user can never
    # see, in a second profile that is not the one their own browser uses.
    if os.path.isdir(home):
        e["HOME"] = home
    return e


def resolve(app: str):
    """Return the argv for an app name, or None if nothing is installed."""
    candidates = APPS.get(app) or [[app]]
    path = _env().get("PATH")
    for argv in candidates:
        exe = shutil.which(argv[0], path=path)
        if exe:
            return [exe] + argv[1:]
    return None


def launch(app: str, args=None) -> str:
    argv = resolve(app)
    if not argv:
        avail = ", ".join(sorted(APPS))
        return f"'{app}' is not installed. Known apps: {avail}"
    argv = argv + list(args or [])
    try:
        # stderr is kept, not discarded. A window that fails to open says
        # why on stderr, and throwing that away is what made this look like
        # a working launch for weeks.
        p = subprocess.Popen(argv, env=_env(), stdout=subprocess.DEVNULL,
                             stderr=subprocess.PIPE, start_new_session=True)
    except Exception as e:
        return f"ERROR: could not start {app}: {e}"

    # A pid is not a window, so wait a moment and look. But an exit is not a
    # failure either: chromium, handed a URL while another window already
    # owns the profile, passes the address to that window and exits 0. The
    # first version of this check called that a failure, so the assistant
    # reported "there is still an issue opening the browser" five times in a
    # row while the page was opening perfectly well each time.
    #
    # The exit CODE is the thing that distinguishes them.
    time.sleep(1.5)
    code = p.poll()
    if code is None:
        _launched[app] = p
        return f"{app} is open on screen (pid {p.pid})"
    if code == 0:
        return (f"{app} is open on screen — the page was handed to a window "
                "that was already running.")
    try:
        err = (p.stderr.read() or b"").decode("utf-8", "replace")
    except Exception:
        err = ""
    tail = " ".join(err.split())[-300:]
    return (f"ERROR: {app} exited straight away with code {code}. "
            f"{tail or 'It gave no reason.'} THIS DID NOT OPEN — do not tell "
            "the user it did.")


def _wlrctl(*args):
    if not shutil.which("wlrctl"):
        return None
    try:
        r = subprocess.run(["wlrctl", *args], env=_env(), capture_output=True,
                           text=True, timeout=10)
        return (r.stdout + r.stderr).strip()
    except Exception:
        return None


def list_windows() -> str:
    out = _wlrctl("window", "list")
    if out:
        return out or "(no windows)"
    alive = [f"{n} (pid {p.pid})" for n, p in _launched.items() if p.poll() is None]
    return "\n".join(alive) or "(no windows launched by OSprime)"


def close_window(app: str) -> str:
    out = _wlrctl("window", "close", f"app_id:{app}")
    if out is not None:
        return f"closed {app}"
    p = _launched.get(app)
    if p and p.poll() is None:
        os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        return f"closed {app}"
    return f"no running window for {app}"


def open_url(url: str) -> str:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    # "browser" first: that entry is the script with the flags chromium
    # needs. Going straight to "chromium" got the bare command.
    for browser in ("browser", "chromium", "firefox"):
        if resolve(browser):
            return launch(browser, [url])
    return "ERROR: no browser is installed."
