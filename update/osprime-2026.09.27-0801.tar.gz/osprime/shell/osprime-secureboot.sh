#!/usr/bin/env bash
# Secure Boot with this computer's own keys. docs/ENCRYPTION.md, plan C.
#
#   osprime-secureboot.sh status            where it stands (no root needed)
#   osprime-secureboot.sh prepare           keys, one signed startup file (UKI)
#   osprime-secureboot.sh enroll            put our keys in the firmware
#   osprime-secureboot.sh finish [--auto]   bind the disk to them, tidy up
#   osprime-secureboot.sh firmware          restart into the firmware setup
#   osprime-secureboot.sh verify            everything that boots is signed
#
# Why: the kernel and initramfs sit on the unencrypted boot partition. With
# only the TPM, someone with the laptop for an afternoon can swap the
# initramfs for one that copies the disk key out, and the TPM cannot tell.
# After this, the kernel, initramfs and kernel command line are one file
# signed with keys made on this computer; the firmware refuses anything
# else, and the TPM (PCR 7) releases the disk only after a boot checked
# against those keys.
#
# The order, and who drives it:
#   prepare   the installer, or Settings on a machine installed before this
#   enroll    needs the firmware in Setup Mode — clearing its keys is done
#             by a person in the firmware screen; it differs on every laptop
#   (restart; Secure Boot on — some firmware does that itself)
#   finish    runs by itself at the next start (osprime-secureboot-finish
#             .service), or from Settings when the disk also needs a PIN
#
# The one restart where Secure Boot turns on changes PCR 7, so the TPM
# would refuse the disk that once. `enroll` therefore adds a temporary TPM
# way in that is not tied to PCR 7, for that restart only; `finish` binds a
# new one to PCR 7 and wipes both the old one and the temporary one
# (decided, Ehsan, 26 September: 2 = A). Microsoft's keys are kept next to
# ours (1 = yes): some graphics and network cards will not start without
# them, and PCR 7 records which key approved the boot, so a Microsoft-signed
# USB stick still does not get the disk.
#
# A PIN, when the disk has one, arrives on stdin — never on a command line.
set -u
R="${OSPRIME_SB_ROOT:-}"
GUID=8be4df61-93ca-11d2-aa0d-00e098032b8c
EFIVARS="$R/sys/firmware/efi/efivars"
STATE="$R/var/lib/osprime/secureboot.json"
CRYPTTAB="$R/etc/crypttab.initramfs"
DISK_STATE="$R/etc/osprime/disk.json"
CMDLINE="$R/etc/kernel/cmdline"
PRESET="$R/etc/mkinitcpio.d/linux.preset"
LOADER="$R/boot/loader/loader.conf"
OLD_ENTRY="$R/boot/loader/entries/osprime.conf"
UKI=/boot/EFI/Linux/osprime.efi
BOOT_EFI=/usr/lib/systemd/boot/efi/systemd-bootx64.efi
FINISH_UNIT=osprime-secureboot-finish.service

die()  { echo "ERROR: $*" >&2; exit 1; }
say()  { echo "> $*"; }
root() { [ "$(id -u)" -eq 0 ] || [ -n "${OSPRIME_SB_TEST:-}" ] || die "run as root"; }

efivar() {  # the value byte after the 4 attribute bytes, or empty
    local f="$EFIVARS/$1-$GUID"
    [ -r "$f" ] || { echo ""; return; }
    od -An -tu1 -j4 -N1 "$f" 2>/dev/null | tr -d ' \n'
}
uefi()       { [ -d "$R/sys/firmware/efi" ]; }
sb_on()      { [ "$(efivar SecureBoot)" = 1 ]; }
setup_mode() { [ "$(efivar SetupMode)" = 1 ]; }

jget() {  # jget FILE KEY
    python3 - "$1" "$2" <<'PY' 2>/dev/null
import json, sys
try:
    v = json.load(open(sys.argv[1])).get(sys.argv[2], "")
except Exception:
    v = ""
print(v if v is not None else "")
PY
}
stage()  { local s; s="$(jget "$STATE" stage)"; echo "${s:-none}"; }
unlock() { jget "$DISK_STATE" unlock; }
write_state() {  # write_state STAGE [TEMP_SLOT]
    mkdir -p "$(dirname "$STATE")"
    printf '{"stage": "%s", "temp_slot": "%s"}\n' "$1" "${2:-}" > "$STATE"
    chmod 644 "$STATE"        # Settings reads it without root
}

luks_dev() {
    [ -n "${OSPRIME_SB_DEV:-}" ] && { echo "$OSPRIME_SB_DEV"; return; }
    [ -f "$CRYPTTAB" ] || return 0
    local uuid
    uuid="$(awk '$1=="osprime-root"{sub(/^UUID=/,"",$2); print $2}' "$CRYPTTAB")"
    [ -n "$uuid" ] && echo "/dev/disk/by-uuid/$uuid"
}
tpm_slots() { systemd-cryptenroll "$1" 2>/dev/null | awk '$2=="tpm2"{print $1}' | sort -n; }
uses_tpm()  { case "$(unlock)" in tpm|tpm-pin) return 0;; esac; return 1; }

read_pin() {  # for a disk that asks for a PIN: stdin, first line
    if [ "$(unlock)" = tpm-pin ]; then
        IFS= read -r PIN || true
        [ -n "${PIN:-}" ] || die "this disk needs its PIN to do this"
        export PIN NEWPIN="$PIN"
    fi
}
pin_flag() { [ "$(unlock)" = tpm-pin ] && echo "--tpm2-with-pin=yes"; }

# What must be signed: the files the firmware actually starts. NOT the
# plain kernel, /boot/vmlinuz-linux: `sbctl verify` lists it as unsigned
# (it is an EFI program too), and signing it would reopen the very hole
# this closes — a signed kernel starts with ANY initramfs, so a boot entry
# written next to it on the unencrypted partition would pass Secure Boot
# with the same PCR 7. Unsigned, it cannot start at all. (27 September, VM:
# prepare stopped at "still unsigned" because of exactly that file.)
REQUIRED="$UKI /boot/EFI/BOOT/BOOTX64.EFI /boot/EFI/systemd/systemd-bootx64.efi"
unsigned_required() {  # prints the required files sbctl calls unsigned
    local out f
    out="$(sbctl verify 2>/dev/null)"
    for f in $REQUIRED; do
        echo "$out" | grep -F " $f " | grep -q "not signed" && echo "$f"
    done
}

sbctl_keys() { [ -d "$R/var/lib/sbctl/keys" ] || [ -d "$R/usr/share/secureboot/keys" ]; }

# ---------------------------------------------------------------------------
cmd="${1:-}"; shift || true
case "$cmd" in
status)
    echo "uefi=$(uefi && echo yes || echo no)"
    echo "secure_boot=$(sb_on && echo on || echo off)"
    echo "setup_mode=$(setup_mode && echo yes || echo no)"
    echo "stage=$(stage)"
    echo "unlock=$(unlock)"
    ;;

prepare)
    root
    uefi || die "this computer starts in BIOS mode — Secure Boot needs UEFI"
    command -v sbctl >/dev/null || die "sbctl is missing: sudo pacman -Syu --needed sbctl"
    case "$(stage)" in enrolled|done) say "already prepared ($(stage))"; exit 0;; esac

    # The kernel command line goes INSIDE the signed file: nobody can add
    # init=/bin/sh at the boot menu any more. Taken from the entry the
    # installer wrote, the first time.
    if [ ! -s "$CMDLINE" ]; then
        opts="$(sed -n 's/^options[[:space:]]\+//p' "$OLD_ENTRY" 2>/dev/null | head -1)"
        [ -n "$opts" ] || die "no kernel command line: neither $CMDLINE nor $OLD_ENTRY"
        mkdir -p "$(dirname "$CMDLINE")"
        echo "$opts" > "$CMDLINE"
    fi
    say "kernel command line: $(cat "$CMDLINE")"

    if ! sbctl_keys; then
        say "making this computer's own Secure Boot keys"
        sbctl create-keys || die "sbctl could not create keys"
    fi

    # The initramfs image stays as well, for the old boot entry — it is the
    # way back if the signed file ever fails, until `finish` removes it.
    say "building one signed startup file ($UKI)"
    mkdir -p "$R/boot/EFI/Linux"
    cat > "$PRESET" <<EOF
# written by osprime-secureboot.sh (docs/ENCRYPTION.md, plan C)
ALL_kver="/boot/vmlinuz-linux"
PRESETS=('default')
default_image="/boot/initramfs-linux.img"
default_uki="$UKI"
EOF
    mkinitcpio -P || die "mkinitcpio failed — nothing else was changed; the old entry still starts"
    [ -s "$R$UKI" ] || die "mkinitcpio did not write $UKI"

    say "signing it, and the boot menu"
    sbctl sign -s "$UKI" || die "could not sign $UKI"
    sbctl sign -s -o "$BOOT_EFI.signed" "$BOOT_EFI" || die "could not sign systemd-boot"
    bootctl --path=/boot install >/dev/null 2>&1 || bootctl --path=/boot update || true
    for f in /boot/EFI/BOOT/BOOTX64.EFI /boot/EFI/systemd/systemd-bootx64.efi; do
        [ -e "$R$f" ] && { sbctl sign -s "$f" || die "could not sign $f"; }
    done

    # The signed file first; no editing of the command line at the menu.
    printf 'default osprime.efi\ntimeout 3\neditor no\n' > "$LOADER"
    [ -f "$OLD_ENTRY" ] && sed -i 's/^title .*/title OSprime (old way, without Secure Boot)/' "$OLD_ENTRY"

    bad="$(unsigned_required)"
    [ -z "$bad" ] || die "still unsigned: $bad"
    write_state prepared
    say "prepared. Next: put the keys in the firmware (enroll)."
    ;;

enroll)
    root
    case "$(stage)" in
        prepared) ;;
        none) die "run prepare first" ;;
        *) say "keys are already in the firmware ($(stage))"; exit 0 ;;
    esac
    setup_mode || die "the firmware is not in Setup Mode. Restart into the firmware \
setup, clear the Secure Boot keys (often called 'Reset to Setup Mode' or \
'Delete all keys'), save, and come back."
    read_pin

    say "putting this computer's keys in the firmware (with Microsoft's, for the hardware)"
    sbctl enroll-keys -m || die "the firmware did not accept the keys"

    temp=""
    DEV="$(luks_dev)"
    if [ -n "$DEV" ] && uses_tpm; then
        # The temporary way in for the one restart that changes PCR 7.
        say "adding a temporary TPM key for the next start only"
        before="$(tpm_slots "$DEV")"
        systemd-cryptenroll --tpm2-device=auto --tpm2-pcrs= $(pin_flag) \
            --unlock-tpm2-device=auto "$DEV" \
            || die "could not add the temporary TPM key — the keys are in the firmware; \
the disk will ask for its password or recovery key once, then run finish"
        temp="$(comm -13 <(echo "$before") <(tpm_slots "$DEV") | head -1)"
        [ -n "$temp" ] || die "the temporary TPM key did not appear"
    fi
    write_state enrolled "$temp"
    systemctl enable "$FINISH_UNIT" >/dev/null 2>&1 || true
    say "done. Restart; if the firmware does not turn Secure Boot on by itself, turn it on there."
    ;;

finish)
    root
    auto=no; [ "${1:-}" = --auto ] && auto=yes
    if [ "$(stage)" != enrolled ]; then
        [ $auto = yes ] && exit 0
        die "nothing to finish (stage: $(stage))"
    fi
    if ! sb_on; then
        [ $auto = yes ] && { echo "Secure Boot is still off in the firmware — waiting."; exit 0; }
        die "Secure Boot is still off. Restart into the firmware and turn it on."
    fi
    # A PIN is only known to the person: at start-up there is nobody to
    # type it, so a PIN disk is finished from Settings.
    if [ $auto = yes ] && [ "$(unlock)" = tpm-pin ]; then
        echo "The disk has a PIN — finish from Settings."; exit 0
    fi
    read_pin

    temp="$(jget "$STATE" temp_slot)"
    DEV="$(luks_dev)"
    if [ -n "$DEV" ] && uses_tpm; then
        old="$(tpm_slots "$DEV")"
        say "binding the disk to this computer's own keys (PCR 7)"
        systemd-cryptenroll --tpm2-device=auto --tpm2-pcrs=7 $(pin_flag) \
            --unlock-tpm2-device=auto "$DEV" || die "could not bind the TPM — nothing was removed"
        new="$(comm -13 <(echo "$old") <(tpm_slots "$DEV") | head -1)"
        [ -n "$new" ] || die "the new TPM key did not appear — nothing was removed"
        wipe="$(echo "$old" | grep -vx "$new" | paste -sd, -)"
        if [ -n "$wipe" ]; then
            say "removing the old and the temporary TPM keys (slots $wipe)"
            systemd-cryptenroll --wipe-slot="$wipe" "$DEV" \
                || die "the new key works, but slots $wipe could not be removed — run finish again"
        fi
    fi
    # The old entry would not start with Secure Boot on anyway; gone, so the
    # menu offers nothing that fails.
    rm -f "$OLD_ENTRY"
    write_state done
    systemctl disable "$FINISH_UNIT" >/dev/null 2>&1 || true
    say "Secure Boot is on with this computer's own keys."
    ;;

firmware)
    root
    uefi || die "this computer starts in BIOS mode"
    systemctl reboot --firmware-setup
    ;;

verify)
    root
    [ "$(stage)" = none ] && { echo "Secure Boot is not in use here."; exit 0; }
    if [ -n "$(unsigned_required)" ]; then
        say "re-signing"
        sbctl sign-all >/dev/null 2>&1
        bad="$(unsigned_required)"
        [ -z "$bad" ] || die "unsigned startup files ($bad) — do NOT restart until this is fixed"
    fi
    echo "Everything that starts the computer is signed."
    ;;

*)
    sed -n '2,9p' "$0"; exit 2 ;;
esac
