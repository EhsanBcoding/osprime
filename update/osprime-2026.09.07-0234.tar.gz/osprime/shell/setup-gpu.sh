#!/usr/bin/env bash
# Move the model onto the graphics card.
#
#   sudo bash /opt/osprime/shell/setup-gpu.sh          install, then reboot
#   sudo bash /opt/osprime/shell/setup-gpu.sh          again after the reboot
#   sudo bash /opt/osprime/shell/setup-gpu.sh --undo   put everything back
#
# The shipped llama-cpp is a plain CPU build, on purpose: it runs on any
# machine that boots the ISO. But reading a long prompt is what keeps people
# waiting — about twenty seconds of the first answer — and that is precisely
# what a graphics card is good at.
#
# Two things this learned the hard way. NVIDIA cards do not want the Vulkan
# route; they want their own driver, which is a kernel module and therefore
# needs a reboot before it can be judged. And a machine whose driver is not
# installed cannot be asked what graphics it has by any tool that ships with
# a driver — so the card is found on the PCI bus instead.
#
# Nothing is kept that cannot be shown to be faster. The speed of reading a
# long prompt is measured before, and again after, and if the card did not
# win the whole thing is put back.
set -u

MODEL_ENV=/etc/osprime/model.env
STATE=/var/lib/osprime/gpu-setup.state
PORT="${MODEL_PORT:-8087}"
LOG=/tmp/osprime-gpu-setup.log
AGENT=/opt/osprime/agent

[ "$EUID" -eq 0 ] || { echo "Run this with sudo."; exit 1; }
mkdir -p "$(dirname "$STATE")"

# --------------------------------------------------------------------------

undo() {
    echo "> putting the CPU build back"
    sed -i '/^OSPRIME_GPU_LAYERS=/d' "$MODEL_ENV" 2>/dev/null
    rm -f "$STATE"
    pacman -S --noconfirm llama-cpp >>"$LOG" 2>&1 || {
        echo "Could not reinstall llama-cpp. Do it by hand:"
        echo "    sudo pacman -S llama-cpp"; exit 1; }
    systemctl restart osprime-model
    echo "Back on the CPU build. The graphics driver was left installed;"
    echo "remove it with 'sudo pacman -Rns nvidia-open' if you want it gone."
    exit 0
}
[ "${1:-}" = "--undo" ] && undo

wait_up() {
    for _ in $(seq 1 180); do
        sleep 1
        curl -fsS --max-time 5 "http://127.0.0.1:$PORT/v1/models" >/dev/null 2>&1 \
            && return 0
    done
    return 1
}

# Reading a long prompt is the thing being fixed, so it is the thing timed.
measure() {
    local filler start end
    filler="$(head -c 6000 /dev/urandom | base64 | tr -d '\n' | head -c 6000)"
    start="$(date +%s%N)"
    curl -fsS --max-time 300 -X POST \
        "http://127.0.0.1:$PORT/v1/chat/completions" \
        -H 'Content-Type: application/json' \
        -d "{\"messages\":[{\"role\":\"user\",\"content\":\"Reply with OK only. Ignore this: $filler\"}],\"max_tokens\":4}" \
        >/dev/null 2>&1 || { echo 0; return; }
    end="$(date +%s%N)"
    echo $(( (end - start) / 1000000 ))
}

# --------------------------------------------------------------------------
# second run: the reboot has happened, so judge it
# --------------------------------------------------------------------------

if [ -f "$STATE" ]; then
    # shellcheck disable=SC1090
    . "$STATE"
    echo "> the driver is installed; timing the card"
    wait_up || {
        echo "The engine is not answering at all. Putting everything back."
        undo; }
    AFTER="$(measure)"
    echo "  before, on the CPU : ${BEFORE} ms"
    echo "  now, on the card   : ${AFTER} ms"
    if [ "$AFTER" -gt 0 ] && [ "$AFTER" -lt "$BEFORE" ]; then
        echo
        echo "Keeping it: $(( (BEFORE - AFTER) * 100 / BEFORE ))% faster at reading a prompt."
        echo "To undo at any time:  sudo bash $0 --undo"
        rm -f "$STATE"
        exit 0
    fi
    echo
    echo "The card was not faster. Putting the CPU build back."
    undo
fi

# --------------------------------------------------------------------------
# first run
# --------------------------------------------------------------------------

VENDOR="$(PYTHONPATH="$AGENT" python3 -c "
import hardware
g = hardware._gpu()
print(g.get('vendor') or ('NVIDIA' if 'nvidia' in g.get('kind','').lower() else ''))
" 2>/dev/null)"
KIND="$(PYTHONPATH="$AGENT" python3 -c "
import hardware; print(hardware._gpu().get('kind',''))" 2>/dev/null)"

if [ -z "$VENDOR" ]; then
    echo "No graphics card found on the PCI bus. Nothing to do."
    exit 1
fi
echo "Graphics found: ${KIND:-$VENDOR}"

echo "> timing the current setup"
wait_up || { echo "The engine is not answering. Fix that first:"; \
             echo "    systemctl status osprime-model"; exit 1; }
BEFORE="$(measure)"
[ "$BEFORE" -gt 0 ] || { echo "Could not time it — nothing changed."; exit 1; }
echo "  reading a long prompt takes ${BEFORE} ms on the CPU"
echo

case "$VENDOR" in
NVIDIA)
    cat <<'WARN'
This installs NVIDIA's own driver. Two honest warnings before it does:

  * It is a kernel module, so the machine has to restart before the card
    can be used at all. Nothing is measured or kept until after that.
  * On a laptop the screen is normally driven by the built-in graphics and
    stays that way, so the desktop should come back exactly as it is. If it
    ever does not, choose an older entry in the boot menu and run
    'sudo bash /opt/osprime/shell/setup-gpu.sh --undo'.

WARN
    printf 'Type yes to continue: '
    read -r answer
    [ "$answer" = "yes" ] || { echo "Nothing was changed."; exit 0; }

    echo "> installing the NVIDIA driver"
    # nvidia-open covers every RTX card and is what Arch now recommends for
    # them; the older proprietary package is the fallback for anything else.
    pacman -Sy --noconfirm --needed nvidia-open nvidia-utils >>"$LOG" 2>&1 ||
    pacman -Sy --noconfirm --needed nvidia nvidia-utils >>"$LOG" 2>&1 || {
        echo "Could not install the driver. Nothing else was changed."
        tail -8 "$LOG"; exit 1; }

    echo "> installing a build that can use it"
    # CUDA is the right route for NVIDIA. The package name is not something
    # this script is willing to bet on, so Vulkan is the fallback — with the
    # driver installed, that works on NVIDIA too.
    ENGINE=""
    for candidate in llama-cpp-cuda llama-cpp-vulkan; do
        if pacman -S --noconfirm "$candidate" >>"$LOG" 2>&1; then
            ENGINE="$candidate"; break
        fi
    done
    [ -n "$ENGINE" ] || {
        echo "Could not install a GPU build of the engine."
        echo "The driver is installed but the engine is unchanged."
        tail -8 "$LOG"; exit 1; }
    echo "  using $ENGINE"
    ;;

AMD|Intel)
    echo "> installing the graphics driver and the Vulkan build"
    pacman -Sy --noconfirm --needed vulkan-tools mesa \
        $([ "$VENDOR" = "AMD" ] && echo vulkan-radeon || echo vulkan-intel) \
        >>"$LOG" 2>&1 || {
        echo "Could not install the graphics driver. Nothing was changed."
        tail -8 "$LOG"; exit 1; }
    if ! vulkaninfo --summary >>"$LOG" 2>&1; then
        echo "Vulkan cannot use this hardware (it crashed or found nothing)."
        echo "Nothing was changed; the CPU build is untouched."
        exit 1
    fi
    pacman -S --noconfirm llama-cpp-vulkan >>"$LOG" 2>&1 || {
        echo "Could not install llama-cpp-vulkan. Putting the CPU build back."
        pacman -S --noconfirm llama-cpp >>"$LOG" 2>&1
        tail -8 "$LOG"; exit 1; }
    ENGINE=llama-cpp-vulkan
    ;;
*)
    echo "Unknown graphics vendor '$VENDOR'. Nothing was changed."
    exit 1
    ;;
esac

# 99 means "all the layers". The launch script's ladder means a driver that
# cannot cope drops back to the CPU rather than leaving no assistant at all.
touch "$MODEL_ENV"
sed -i '/^OSPRIME_GPU_LAYERS=/d' "$MODEL_ENV"
echo 'OSPRIME_GPU_LAYERS="99"' >> "$MODEL_ENV"

printf 'BEFORE=%s\nENGINE=%s\n' "$BEFORE" "$ENGINE" > "$STATE"

if [ "$VENDOR" = "NVIDIA" ]; then
    echo
    echo "Installed. Restart the computer, then run this again:"
    echo "    sudo bash $0"
    echo "It will time the card and keep the change only if it was faster."
else
    systemctl restart osprime-model
    exec "$0"
fi
