"""Brainy does it for you, in the background (docs/ACT.md; Ehsan, 13 October).

Asked "do it for me: …", the assistant first uses its own tools (the
direct way, no screen at all). When the job lives in an app's window, it
hands the goal here, and this works in that window through accessibility
(act_probe.py): pressing and filling in, with no mouse and no keyboard —
the person goes on working in their own window at the same time.

  * One approval for the whole task; anything irreversible (send, delete,
    pay, install, shut down…) is asked about on its own (Ehsan).
  * Never a password field, a terminal, or a window that asks for a
    password (act_logic.validate / act_probe.window_ok).
  * Super+Escape, or Stop in the panel, stops it at once.
  * At most 15 steps; each step is one model call with words only.
"""
import os
import threading
import time

from gi.repository import GLib

import act_logic as al
import act_probe as ap


def _log_path():
    import sys
    agent = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "agent")
    if agent not in sys.path:
        sys.path.append(agent)
    import paths
    return paths.data_dir() / "act-turns.log"


def _unlink(path):
    if path:
        try:
            os.unlink(path)
        except OSError:
            pass


def _track(r, at_cell, typed, claims):
    """Which cell Brainy is in and what it typed there, after one step that
    worked. -> (at_cell, typed); claims[cell] = the text it should hold."""
    do = r["do"]
    if do == "cell":
        return r["cell"], ""
    if do == "keys":
        if at_cell:
            typed += r["text"]
            claims[at_cell] = typed
        return at_cell, typed
    if do == "key":
        k = r["key"]
        if k == "BackSpace" and at_cell and typed:
            typed = typed[:-1]
            claims[at_cell] = typed
            return at_cell, typed
        if k == "Escape" and at_cell and typed:
            claims.pop(at_cell, None)       # Escape throws the typing away
        return None, ""                     # Return, Tab, arrows: the cell is left
    return None, ""                         # a click: somewhere else now



class ActSession:
    def __init__(self, companion, bubble):
        self.c = companion
        self.b = bubble
        self.active = False
        self.goal = ""
        self.history = []
        self.win = None              # the window being worked in (title, app)
        self.on_desk = False         # Brainy opened something on its own desk (desk.py)
        self.screen = None           # screen_turns.Screen while taking turns (step 4)
        self.target = None           # (handle, app, title) of the window worked in, in turns
        self.pending = None
        self._reply = None
        self._reply_ev = threading.Event()
        self._answer = None
        self._answer_ev = threading.Event()
        self._stop = threading.Event()

    # ---- control (GTK thread) ----------------------------------------------
    def start(self, goal: str):
        self.stop(quiet=True)
        self.goal = " ".join((goal or "").split())[:300]
        if not self.goal:
            return
        self.history, self.win, self.on_desk = [], None, False
        self._stop.clear()
        self.b.guide_card(
            f"Brainy will do this for you, in the background: “{self.goal}”.\n"
            "It presses and fills in through the app itself — your mouse and keyboard stay "
            "yours. Up to 15 steps; anything that cannot be undone is asked first. "
            "Super+Esc stops it.",
            [("Do it", self._go), ("Cancel", lambda: self.stop(quiet=True))])

    def _go(self):
        self.active = True
        self.c.set_local_state("reading")
        threading.Thread(target=self._run, daemon=True, name="act").start()

    def stop(self, quiet=False):
        was = self.active
        self.active = False
        scr, self.screen = self.screen, None
        if scr:
            scr.close()
        self._stop.set()
        self._answer_ev.set()
        self._reply_ev.set()
        try:
            self.c.set_local_state(None)
        except Exception:
            pass
        if was and not quiet:
            GLib.idle_add(lambda: self.b.guide_card("Stopped. Nothing more will be pressed.", [], final=True)
                          and False)

    # ---- the work (its own thread) ---------------------------------------------
    def _ui(self, text, buttons=(), final=False):
        GLib.idle_add(lambda: self.b.guide_card(text, list(buttons), final=final) and False)

    def _ask_person(self, text) -> bool:
        """An irreversible step: asked on its own, the task waits."""
        self._answer, self._answer_ev = None, threading.Event()

        def yes():
            self._answer = True
            self._answer_ev.set()

        def no():
            self._answer = False
            self._answer_ev.set()
        self._ui(text, [("Yes, do it", yes), ("Skip", no), ("Stop", self.stop)])
        self._answer_ev.wait(600)
        return bool(self._answer) and not self._stop.is_set()

    def ask(self, prompt, image=None, system=None) -> str:
        """Words only on the person's screen; with a picture of Brainy's own
        desk when it works there (that picture shows exactly its window)."""
        self._reply_ev.clear()
        self._reply = None
        self.pending = f"a{time.time():.3f}"
        msg = {"type": "guide_step", "id": self.pending, "prompt": prompt, "system": system or al.SYSTEM}
        if image:
            msg["image"] = image
        else:
            msg["text_only"] = True
        try:
            self.b.guide_link().send(msg)
        except OSError:
            return "ERROR: the assistant is not running"
        if not self._reply_ev.wait(240):
            return "ERROR: no answer in four minutes"
        return self._reply or "ERROR: empty answer"

    def on_reply(self, msg):
        if msg.get("id") == self.pending:
            self._reply = str(msg.get("raw") or "")
            self._reply_ev.set()

    def _current(self, wins):
        """The window worked in, found again (windows come and go). After
        Brainy opened something on its desk: the desk's newest window."""
        if self.win:
            for w in wins:
                if w["app"] == self.win[1] and w["title"] == self.win[0]:
                    return w
            for w in wins:
                if w["app"] == self.win[1] or (self.win[1] and self.win[1].lower() in w["app"].lower()):
                    return w
        if self.on_desk:
            desk_wins = [w for w in wins if w.get("desk") and not w["ok"]]
            if desk_wins:
                self.win = (desk_wins[-1]["title"], desk_wins[-1]["app"])
                return desk_wins[-1]
        return None

    def watch(self):
        try:
            import companion_desk_view
            companion_desk_view.open_view()
        except Exception as e:
            self._ui(f"The desk cannot be shown: {e}", [("Stop", self.stop)])

    def _buttons(self):
        try:
            import desk
            if desk.running():
                return [("Watch", self.watch), ("Stop", self.stop)]
        except Exception:
            pass
        return [("Stop", self.stop)]

    def _desk_picture(self):
        try:
            import companion_point as cp
            import desk
            cp.sweep()
            path = str(cp.folder() / f"desk-{int(time.time() * 1000)}.png")
            return path if desk.screenshot(path) else None
        except Exception:
            return None

    # ---- step 4: turns on the person's own screen ------------------------------
    def _offer_turns(self, why) -> bool:
        """The card Brainy shows itself when steps 1-3 could not (Ehsan)."""
        self._answer, self._answer_ev = None, threading.Event()

        def yes():
            self._answer = True
            self._answer_ev.set()

        def no():
            self._answer = False
            self._answer_ev.set()
        reason = f" ({why})" if why and why != "stuck" else ""
        self._ui("I could not do this in the background" + reason + ".\n"
                 "May I use your own screen, in turns? I act only while your hands rest, "
                 "pause the moment you move, and never touch terminals or password windows. "
                 "Each step, a picture of your whole screen goes to the assistant's model "
                 "(the cloud one when the cloud switch is on). Super+Esc stops.",
                 [("Use my screen", yes), ("No", no)])
        self._answer_ev.wait(600)
        return bool(self._answer) and not self._stop.is_set()

    def _turn_windows(self):
        """The person's windows, numbered, with the same checks as step 2."""
        out = []
        for n, w in enumerate(self.screen.windows(), 1):
            out.append(dict(w, id=n, ok=ap.window_ok(w["app"], w["title"]), desk=False))
        return out

    def _turn_target(self, wins):
        if not self.target:
            return None
        h, app, title = self.target
        return (next((w for w in wins if w["handle"] == h), None) or
                next((w for w in wins if w["app"] == app and w["title"] == title), None) or
                next((w for w in wins if w["app"] == app), None))

    def _release_keyboard(self):
        """Clicking the panel (Use my screen, Yes) gives it the keyboard
        EXCLUSIVELY, and then labwc will not bring any window to the front —
        the first laptop test looked 15 times and did nothing (15 October).
        Hand the keyboard back before working on the person's screen."""
        kb = getattr(self.b, "keyboard", None)
        if not kb:
            return
        done = threading.Event()

        def go():
            try:
                kb(False)
            finally:
                done.set()
            return False
        GLib.idle_add(go)
        done.wait(1.0)
        time.sleep(0.2)

    def _front_is(self, cur) -> bool:
        """The window worked in is in front — bringing it there if needed."""
        f = self.screen.front()
        if f and f["handle"] == cur["handle"]:
            return True
        if self.screen.activate(cur["handle"]):
            return True
        self._release_keyboard()          # the panel may be holding the keyboard
        return self.screen.activate(cur["handle"])

    def _log(self, line):
        """What each step in turns saw and decided (data/act-turns.log, last task only)."""
        try:
            with open(_log_path(), "a") as f:
                f.write(time.strftime("%H:%M:%S ") + line.replace("\n", " ")[:600] + "\n")
        except Exception:
            pass

    def _skip(self, why_model, why_person):
        """A look thrown away: told to the model, shown to the person, logged."""
        self.history.append(f"({why_model})")
        self._ui("Looking again: " + why_person, [("Stop", self.stop)])
        self._log("skip: " + why_model)

    def _aim(self, pic, x, y, say):
        """A close-up with numbered squares around the model's point; it picks
        a square (laptop test, 16 October: "B3" landed in D7). -> ((x, y) in
        picture pixels, note), or (None, note) when the thing is not there."""
        import screen_turns as st
        import companion_point as cp
        z = str(cp.folder() / f"zoom-{int(time.time() * 1000)}.png")
        grid = st.zoom(pic, x, y, z)
        if not grid:
            return (x, y), "no close-up"
        try:
            raw = self.ask(al.zoom_request(self.goal, say), z, system=al.ZOOM_SYSTEM)
        finally:
            _unlink(z)
        if raw.startswith("ERROR:"):
            return (x, y), "the close-up was not answered"
        rep = al.parse_reply(raw)
        n = rep.get("square") if isinstance(rep, dict) else None
        if str(n).strip() == "0":
            return None, "not in the close-up"
        c = st.square_centre(grid, n)
        if c is None:
            return (x, y), "no square named"
        return c, f"square {n}"

    def _verify_done(self, cur, claims):
        """Before "done" is believed (laptop test, 16 October: it said 120 was
        in B3 while B3 was empty). -> (True, what proves it) | (False, what
        is wrong) | (None, why it could not be checked)."""
        if claims and cur:
            good, bad, unread = [], [], 0
            for ref, text in claims.items():
                cr = al.parse_cell(ref)
                v = ap.read_cell(cur["title"], *cr) if cr else None
                if v is None:
                    unread += 1
                elif v.strip() == text.strip():
                    good.append(f"{ref} = {v.strip()[:30]}")
                else:
                    bad.append(f"{ref} holds {v.strip()[:30]!r}, not {text.strip()[:30]!r}")
            if bad:
                return False, "; ".join(bad)
            if good and not unread:
                return True, ", ".join(good)
        import screen_turns as st
        import companion_point as cp
        pic = str(cp.folder() / f"check-{int(time.time() * 1000)}.png")
        if not st.screenshot(pic):
            _unlink(pic)
            return None, "no picture of the screen"
        try:
            raw = self.ask(al.verify_request(self.goal), pic, system=al.VERIFY_SYSTEM)
        finally:
            _unlink(pic)
        if raw.startswith("ERROR:"):
            return None, raw[6:].strip()
        reached, seen = al.parse_verify(raw)
        if reached is None:
            return None, "the check gave no clear answer"
        return reached, seen or ("it looks reached" if reached else "it does not look reached")

    def _run_turns(self, first, did):
        import screen_turns as st
        try:
            self.screen = st.Screen()
        except Exception as e:
            self._ui(f"Your screen cannot be used in turns: {e}. Nothing else was pressed.", final=True)
            return
        scr = self.screen
        try:
            _log_path().parent.mkdir(parents=True, exist_ok=True)
            _log_path().write_text(f"goal: {self.goal}\n")
        except Exception:
            pass
        self._release_keyboard()
        self.history.append("(the user allowed turns: you now see their screen and click_at, keys, key "
                            "and scroll work there; pick the window with window first)")
        step = first
        looks = 0
        last_click = None             # (x, y) in picture pixels, drawn on the next picture
        done_acts = []                # what was really done, to catch the same step again
        at_cell, typed = None, ""     # the cell Brainy went to, and what it typed there
        claims = {}                   # cell -> text Brainy put there, checked before "done"
        checks_failed = 0
        pic = None
        try:
            while step <= al.MAX_STEPS:
                _unlink(pic)
                pic = None
                looks += 1
                if looks > 3 * al.MAX_STEPS:
                    self._ui("I kept having to look again, so I stopped. Nothing else was pressed.",
                             final=True)
                    return
                if self._stop.is_set() or scr.closed:
                    return
                if not scr.idle:
                    self._ui("Paused — I go on when your hands rest.", [("Stop", self.stop)])
                    if not scr.wait_idle(self._stop):
                        if not self._stop.is_set():
                            self._ui("You stayed busy, so I stopped. Nothing else was pressed.", final=True)
                        return
                wins = self._turn_windows()
                cur = self._turn_target(wins)
                if cur is None:
                    f = next((w for w in wins if w["active"] and not w["ok"]), None)
                    if f:
                        cur = f
                        self.target = (f["handle"], f["app"], f["title"])
                if cur and not cur["ok"] and not cur["active"]:
                    # Bring it forward before the picture (no input event: still idle).
                    if self._front_is(cur):
                        wins = self._turn_windows()
                        cur = self._turn_target(wins) or cur
                    else:
                        self._log(f"could not bring {cur['app']} to the front")
                seen = scr.changes
                self._ui(f"Step {step}: looking at your screen…", [("Stop", self.stop)])
                import companion_point as cp
                cp.sweep()
                pic = str(cp.folder() / f"screen-{int(time.time() * 1000)}.png")
                size = st.screenshot(pic)
                if not size:
                    self._ui("I cannot take a picture of your screen. Nothing else was pressed.", final=True)
                    return
                marked = bool(last_click) and st.mark(pic, *last_click)
                prompt = al.build_request(
                    self.goal, self.history, ap.describe_windows(wins),
                    (f'{cur["app"]} — "{cur["title"]}" (on the user\'s screen, in turns)' if cur else ""),
                    "(not readable here — use the picture)")
                prompt += ("\nA picture of the user's whole screen is attached. click_at, keys, key and "
                           "scroll act on it, in the window you work in. There are no numbered controls "
                           "here: to write text, click where it goes, then use keys (not type). In a "
                           "spreadsheet go to a cell with cell (like {\"do\": \"cell\", \"cell\": \"B3\"}), "
                           "never by clicking it.\n"
                           "Before each step, LOOK at the picture: did your last step work? Never repeat a "
                           "step that already worked. After keys into a cell or a field, press key Return "
                           "to confirm it. When the picture shows the goal reached, say done.")
                if marked:
                    prompt += "\nThe red ring on the picture marks where your last click landed."
                if len(done_acts) >= 2 and st.same_action(done_acts[-1], done_acts[-2]):
                    prompt += ("\nYou did the same step twice in a row. It probably worked already, or "
                               "it does not work: check the picture and do something different.")
                raw = self.ask(prompt, pic)       # the picture is kept to aim a click
                if self._stop.is_set():
                    return
                if raw.startswith("ERROR:"):
                    self._ui("Turns need a model that can see pictures: " + raw[6:].strip() +
                             ". Nothing else was pressed.", final=True)
                    return
                self._log(f"step {step} window={cur['app'] if cur else None!r} front="
                          f"{(scr.front() or {}).get('app')!r} reply={raw}")
                reply = al.parse_reply(raw)
                if isinstance(reply, dict) and reply.get("do") == "type" and reply.get("text"):
                    # No numbered controls in turns: "type" can only mean typing where the
                    # keyboard is — keys (laptop test, 15 October: refused three times).
                    reply = dict(reply, do="keys")
                r = al.validate(reply, [], wins, on_desk=True, window=cur)
                if r["ok"] and r["do"] in ("open", "web", "press", "type", "turns"):
                    r = dict(r, ok=False, why="in turns, work in the user's window with click_at, keys, "
                                              "key or scroll")
                step += 1
                if not r["ok"]:
                    self.history.append(f"(refused: {r['why']})")
                    self._ui(f"Step {step - 1}: not allowed — {r['why']}", [("Stop", self.stop)])
                    self._log("refused: " + r["why"])
                    if all(h.startswith("(refused") for h in self.history[-3:]):
                        self._ui(f"I keep getting stuck ({r['why']}). Stopped; nothing else was pressed.",
                                 final=True)
                        return
                    continue
                say = r["say"] or r["do"]
                if r["do"] == "done":
                    self._ui(f"Step {step - 1}: checking that it really worked…", [("Stop", self.stop)])
                    verdict, note = self._verify_done(cur, claims)
                    self._log(f"check: {verdict} {note}")
                    if self._stop.is_set():
                        return
                    steps_done = ("\n" + "\n".join("• " + d for d in did)) if did else ""
                    if verdict is True:
                        self._ui("✓ " + (say or "Done.") + f"\nChecked: {note}" + steps_done, final=True)
                        return
                    if verdict is None:
                        self._ui(f"I think it is done, but I could not check it ({note}) — please look "
                                 "at your screen." + steps_done, final=True)
                        return
                    checks_failed += 1
                    if checks_failed >= 2:
                        self._ui(f"I am not sure it worked — a check of your screen found: {note}. "
                                 "Please look." + steps_done, final=True)
                        return
                    self.history.append(f"(you said done, but a check found: {note}. The goal is NOT "
                                        "reached yet — look at the picture and fix it)")
                    self._ui(f"Not done yet — {note}. Going on.", [("Stop", self.stop)])
                    continue
                if r["do"] == "stuck":
                    self._ui("I could not do it: " + say + ". Nothing else was pressed.", final=True)
                    return
                if r["do"] == "window":
                    w = r["window"]
                    self.target = (w["handle"], w["app"], w["title"])
                    self.history.append(f"Working in {w['app']}")
                    continue
                if cur is None or cur["ok"]:
                    self._skip("choose the window to work in with window first", "choosing the window")
                    continue
                act = {"do": r["do"], "x": r.get("x"), "y": r.get("y"), "text": r.get("text"),
                       "key": r.get("key"), "cell": r.get("cell")}
                if len(done_acts) >= 2 and st.same_action(act, done_acts[-1]) and \
                        st.same_action(act, done_acts[-2]):
                    # A third time the same: refused (it typed "120" eight times, 15 October).
                    self.history.append("(refused: you already did exactly this twice; it is done or it "
                                        "does not work — look at the picture and do something else, "
                                        "or say done)")
                    self._ui(f"Step {step - 1}: not repeating the same thing a third time",
                             [("Stop", self.stop)])
                    self._log("refused: same step a third time")
                    if sum(1 for h in self.history[-3:] if h.startswith("(refused")) >= 3:
                        self._ui("I keep repeating myself, so I stopped. Look at your screen to see "
                                 "what was done.", final=True)
                        return
                    continue
                if r["do"] == "click_at":
                    w, h = size
                    pt, note = self._aim(pic, r["x"] * w, r["y"] * h, say)
                    self._log(f"aim: {note}" + (f" -> x={pt[0] / w:.3f} y={pt[1] / h:.3f}" if pt else ""))
                    if self._stop.is_set():
                        return
                    if pt is None:
                        self.history.append("(a close-up around your point did not show what you meant "
                                            "to click; nothing was clicked — look again)")
                        continue
                    r = dict(r, x=pt[0] / w, y=pt[1] / h)
                if r["irreversible"]:
                    if not self._ask_person(f"Step {step - 1}: {say}\nThis cannot be undone. Do it?"):
                        if self._stop.is_set():
                            return
                        self.history.append("(the user said no to that; do not do it)")
                        continue
                    # Answering moved their hands and took the keyboard to the panel.
                    self._release_keyboard()
                    if not scr.wait_idle(self._stop):
                        return
                    seen = scr.changes
                # The last checks, right before acting on their screen.
                # A look thrown away does not count as a step.
                if not scr.idle or scr.changes != seen:
                    step -= 1
                    self._skip("the user moved meanwhile; look again", "you moved while I was thinking")
                    continue
                if not self._front_is(cur):
                    step -= 1
                    self._skip("your window could not be brought to the front; look again",
                               f"{cur['app']} would not come to the front")
                    continue
                f = scr.front()
                if not f or f["handle"] != cur["handle"] or ap.window_ok(f["app"], f["title"]):
                    step -= 1
                    self._skip("another window is in front; look again", "another window is in front")
                    continue
                w, h = size
                if r["do"] == "click_at":
                    ok = st.click(r["x"] * w, r["y"] * h, w, h)
                elif r["do"] == "scroll":
                    ok = st.scroll(r["x"] * w, r["y"] * h, w, h, r["steps"])
                elif r["do"] == "keys":
                    ok = st.type_text(r["text"])
                elif r["do"] == "cell":
                    seq = r["keys"]
                    if typed:
                        seq = ["Return"] + seq[1:]   # keep what Brainy typed: confirm, not Escape
                    ok = st.press_keys(seq)
                else:
                    ok = st.key(r["key"])
                if ok:
                    at_cell, typed = _track(r, at_cell, typed, claims)
                if r["do"] == "click_at":
                    what = f"clicked at x={r['x']:.2f} y={r['y']:.2f}"
                    last_click = (r["x"] * w, r["y"] * h) if ok else None
                elif r["do"] == "scroll":
                    what = f"scrolled {r['steps']:+d} at x={r['x']:.2f} y={r['y']:.2f}"
                elif r["do"] == "keys":
                    what = f"typed {r['text'][:40]!r}"
                elif r["do"] == "cell":
                    what = f"went to cell {r['cell']}"
                else:
                    what = f"pressed {r['key']}"
                if r["do"] != "click_at":
                    last_click = None
                # What was really done, not what the model said it would do.
                self.history.append(f"{what} ({say})" if ok else f"(that did not work: {what})")
                if ok:
                    done_acts.append(act)
                self._log(f"{r['do']} -> {'ok' if ok else 'FAILED'}")
                if ok:
                    did.append(say + " (on your screen)")
                    self._ui(f"Step {step - 1}: {say}", [("Stop", self.stop)])
                else:
                    self._ui(f"Step {step - 1}: that did not work ({r['do']})", [("Stop", self.stop)])
                time.sleep(0.3)
            self._ui("That is a lot of steps — I stopped here.\n" + "\n".join("• " + d for d in did),
                     final=True)
        finally:
            _unlink(pic)
            self.screen = None
            scr.close()

    @staticmethod
    def _desk_input():
        try:
            import desk
            return desk.user_input
        except Exception:
            return 0

    def _wait_while_taken_over(self):
        """While the person has taken over the desk, Brainy does nothing there."""
        try:
            import companion_desk_view as dv
        except Exception:
            return
        told = False
        while dv.taken_over() and not self._stop.is_set():
            if not told:
                self._ui("You have the desk — I wait until you hand it back (Take over off).",
                         self._buttons())
                told = True
            time.sleep(0.5)

    def _run(self):
        did = []
        try:
            for step in range(1, al.MAX_STEPS + 1):
                if self._stop.is_set():
                    return
                self._ui(f"Step {step}: looking…", self._buttons())
                wins = ap.list_windows()
                cur = self._current(wins)
                ctrls = ap.controls(cur) if cur and not cur["ok"] else []
                here = bool(cur and cur.get("desk"))
                if here:
                    self._wait_while_taken_over()
                    if self._stop.is_set():
                        return
                seen_input = self._desk_input()
                picture = self._desk_picture() if here else None
                prompt = al.build_request(self.goal, self.history, ap.describe_windows(wins),
                                          (f'{cur["app"]} — "{cur["title"]}"' + (" (on your own desk)" if here else ""))
                                          if cur else "",
                                          ap.describe_controls(ctrls))
                if picture:
                    prompt += "\nA picture of your own desk is attached (its whole screen)."
                raw = self.ask(prompt, picture)
                if picture and raw.startswith("ERROR:"):
                    # Nothing that can see right now: carry on with the words.
                    raw = self.ask(prompt.replace("\nA picture of your own desk is attached (its whole screen).", ""))
                if picture:
                    try:
                        os.unlink(picture)
                    except OSError:
                        pass
                if self._stop.is_set():
                    return
                if raw.startswith("ERROR:"):
                    self._ui(f"I could not go on: {raw[6:].strip()}.", final=True)
                    return
                focused = next((c for c in ctrls if c.get("focused")), None)
                r = al.validate(al.parse_reply(raw), ctrls, wins, on_desk=here, focused=focused)
                if not r["ok"] and not here and r["do"] in al.DESK_ONLY:
                    # Wanting to click or type on the person's own screen IS asking for
                    # turns (laptop test, 15 October: the model never said "turns", was
                    # refused three times and stopped). Brainy offers the card instead.
                    r = dict(r, ok=True, do="turns")
                if not r["ok"]:
                    # Told to the model as a step, so it can choose differently.
                    self.history.append(f"(refused: {r['why']})")
                    if len(self.history) >= 3 and all(h.startswith("(refused") for h in self.history[-3:]):
                        self._ui(f"I keep getting stuck ({r['why']}). Stopped; nothing else was pressed.",
                                 final=True)
                        return
                    continue
                say = r["say"] or r["do"]
                if r["do"] == "done":
                    self._ui("✓ " + (say or "Done.") + ("\n" + "\n".join("• " + d for d in did) if did else ""),
                             final=True)
                    return
                if r["do"] in ("stuck", "turns") and not here:
                    # Steps 1-3 could not: Brainy itself offers turns (Ehsan, 14 October).
                    if self._offer_turns(say if r["do"] == "stuck" else ""):
                        self._run_turns(step + 1, did)
                        return
                    if self._stop.is_set():
                        return
                    self._ui("Then I cannot do it. Nothing else was pressed.", final=True)
                    return
                if r["do"] in ("stuck", "turns"):
                    self._ui("I could not do it here: " + (say or "no way forward") +
                             ". Nothing else was pressed.", final=True)
                    return
                if r["do"] == "window":
                    self.win = (r["window"]["title"], r["window"]["app"])
                    self.history.append(f"Working in {r['window']['app']}")
                    continue
                if r["do"] in ("open", "web"):
                    # On Brainy's own desk: nothing appears on the person's screen.
                    try:
                        import desk
                        if r["do"] == "open":
                            desk.open_app(r["app"])
                        else:
                            desk.open_url(r["url"])
                    except Exception as e:
                        self.history.append(f"(could not open it: {e})")
                        continue
                    what = r["app"] or r["url"]
                    self.history.append(f"Opened {what} on your own desk")
                    did.append(f"opened {what} on Brainy's desk")
                    self.on_desk, self.win = True, ("", r["app"])
                    time.sleep(4)
                    continue
                if r["do"] in al.DESK_ONLY:
                    import desk
                    if self._desk_input() != seen_input:
                        # The person scrolled or clicked on the desk since the
                        # picture: the point may be wrong now. Look again.
                        self.history.append("(the user moved the page on your desk; look again)")
                        continue
                    if r["irreversible"] and not self._ask_person(
                            f"Step {step}: {say}\nThis cannot be undone. Do it?"):
                        if self._stop.is_set():
                            return
                        self.history.append("(the user said no to that; do not do it)")
                        continue
                    if r["do"] == "click_at":
                        ok = desk.click(r["x"] * desk.WIDTH, r["y"] * desk.HEIGHT)
                    elif r["do"] == "scroll":
                        ok = desk.scroll(r["x"] * desk.WIDTH, r["y"] * desk.HEIGHT, r["steps"])
                    elif r["do"] == "keys":
                        ok = desk.type_text(r["text"])
                    elif r["do"] == "cell":
                        ok = desk.press_keys(r["keys"])
                    else:
                        ok = desk.key(r["key"])
                    self.history.append((say or r["do"]) if ok else f"(that did not work: {r['do']})")
                    if ok:
                        did.append(say or r["do"])
                        self._ui(f"Step {step}: {say}", self._buttons())
                    time.sleep(0.8)
                    continue
                c = r["ctrl"]
                if r["irreversible"] and not self._ask_person(
                        f"Step {step}: {say}\n“{c['name']}” cannot be undone. Do it?"):
                    if self._stop.is_set():
                        return
                    self.history.append(f"(the user said no to pressing {c['name']!r}; do not press it)")
                    continue
                ok = ap.do_type(c, r["text"]) if r["do"] == "type" else ap.do_press(c)
                what = (f"typed into “{c['name']}”" if r["do"] == "type"
                        else f"pressed “{c['name']}”")
                if ok:
                    self.history.append(say or what)
                    did.append(what)
                    self._ui(f"Step {step}: {say}", self._buttons())
                else:
                    self.history.append(f"(that did not work: {what})")
                time.sleep(0.6)
            self._ui("That is a lot of steps — I stopped here.\n" + "\n".join("• " + d for d in did),
                     final=True)
        finally:
            self.active = False
            GLib.idle_add(lambda: self.c.set_local_state(None) and False)
