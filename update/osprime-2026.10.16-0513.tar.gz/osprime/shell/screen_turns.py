"""Taking turns on the person's own screen (docs/ACT.md, step 4; Ehsan, 14 October).

Only when steps 1-3 cannot do the job, and only after the person says yes
on a card Brainy shows itself. Brainy then acts on the person's own screen,
one step at a time, and ONLY while their hands rest:

  * ext_idle_notifier_v1 (version 2: get_input_idle_notification, so a
    playing video does not hide the person's activity) says when nobody
    has touched the mouse or keyboard for IDLE_MS (1.5 s, Ehsan).
  * The moment they move, Brainy pauses (it does not stop). A step whose
    picture was taken before they moved is thrown away and looked at again.
  * zwlr_foreign_toplevel_management_v1 lists the windows, says which one is
    in front, and lets Brainy bring its window to the front before acting.
    Nothing is typed when another window is in front.
  * The mouse stays where Brainy clicked (Wayland does not tell anyone where
    the pointer is, so it cannot be put back; Ehsan agreed).

The Wayland wire protocol is spoken directly, as in osprime-pointer.py.
"""
import os
import pathlib
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time

HERE = pathlib.Path(__file__).resolve().parent
IDLE_MS = 1500
WAIT_MAX = 10 * 60            # waiting this long for a pause ends the task

# Globals we need, and the highest version we speak.
WANT = {"wl_seat": 1, "ext_idle_notifier_v1": 2, "zwlr_foreign_toplevel_manager_v1": 3}
ACTIVATED = 2                 # zwlr_foreign_toplevel_handle_v1 state


def _pad(b: bytes) -> bytes:
    return b + b"\0" * (-len(b) % 4)


def _string(s: str) -> bytes:
    raw = s.encode() + b"\0"
    return struct.pack("<I", len(raw)) + _pad(raw)


def _read_string(payload: bytes, off: int = 0):
    n = struct.unpack("<I", payload[off:off + 4])[0]
    s = payload[off + 4:off + 4 + max(n - 1, 0)].decode(errors="replace")
    return s, off + 4 + ((n + 3) & ~3)


class Screen:
    """One connection to the person's compositor, read by its own thread."""

    def __init__(self, display=None, idle_ms=IDLE_MS):
        name = display or os.environ.get("WAYLAND_DISPLAY", "")
        if not name:
            raise RuntimeError("no WAYLAND_DISPLAY")
        path = name if name.startswith("/") else os.path.join(
            os.environ.get("XDG_RUNTIME_DIR", "/tmp"), name)
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(5)
        self.sock.connect(path)
        self.sock.settimeout(None)
        self.lock = threading.Lock()
        self.cond = threading.Condition()
        self.next_id = 2
        self.error = ""
        self.closed = False
        self.globals = {}
        self.callbacks = set()
        self.idle = False
        self.changes = 0              # every switch between idle and active
        self.tops = {}                # handle id -> {app, title, active, done}
        self.order = []               # handle ids, oldest first
        self.reg = self._new()
        self.seat = self.mgr = self.notif = None
        self._send(1, 1, struct.pack("<I", self.reg))          # wl_display.get_registry
        threading.Thread(target=self._read, daemon=True, name="screen-turns").start()
        self.roundtrip()
        missing = [g for g in ("wl_seat", "ext_idle_notifier_v1") if g not in self.globals]
        if missing:
            self.close()
            raise RuntimeError("the desktop does not say when you pause (" + ", ".join(missing) + ")")
        self.seat = self._bind("wl_seat")
        notifier = self._bind("ext_idle_notifier_v1")
        self.notif = self._new()
        # Version 2: input idleness, which a playing video cannot hold back.
        op = 2 if self.globals["ext_idle_notifier_v1"][1] >= 2 else 1
        self._send(notifier, op, struct.pack("<III", self.notif, int(idle_ms), self.seat))
        if "zwlr_foreign_toplevel_manager_v1" in self.globals:
            self.mgr = self._bind("zwlr_foreign_toplevel_manager_v1")
        self.roundtrip()
        self.roundtrip()

    # ---- the wire --------------------------------------------------------------
    def _new(self):
        with self.lock:
            n = self.next_id
            self.next_id += 1
            return n

    def _send(self, obj, op, payload=b""):
        if self.closed:
            raise RuntimeError(self.error or "the connection to the desktop is closed")
        with self.lock:
            self.sock.sendall(struct.pack("<II", obj, ((8 + len(payload)) << 16) | op) + payload)

    def _bind(self, iface):
        gname, ver = self.globals[iface]
        oid = self._new()
        self._send(self.reg, 0, struct.pack("<I", gname) + _string(iface)
                   + struct.pack("<II", min(ver, WANT[iface]), oid))
        return oid

    def roundtrip(self, timeout=5.0):
        cb = self._new()
        with self.cond:
            self.callbacks.add(cb)
        self._send(1, 0, struct.pack("<I", cb))                 # wl_display.sync
        end = time.time() + timeout
        with self.cond:
            while cb in self.callbacks and not self.closed:
                left = end - time.time()
                if left <= 0:
                    raise RuntimeError("the desktop did not answer")
                self.cond.wait(left)
        if self.closed and self.error:
            raise RuntimeError(self.error)

    def _read(self):
        buf = b""
        while True:
            try:
                chunk = self.sock.recv(65536)
            except OSError:
                chunk = b""
            if not chunk:
                with self.cond:
                    self.closed = True
                    self.error = self.error or "the desktop closed the connection"
                    self.cond.notify_all()
                return
            buf += chunk
            while len(buf) >= 8:
                obj, word = struct.unpack("<II", buf[:8])
                size = word >> 16
                if size < 8 or len(buf) < size:
                    break
                op, payload, buf = word & 0xFFFF, buf[8:size], buf[size:]
                with self.cond:
                    try:
                        self._event(obj, op, payload)
                    except Exception:
                        pass
                    self.cond.notify_all()

    def _event(self, obj, op, p):
        if obj == 1 and op == 0:                                # wl_display.error
            code = struct.unpack("<I", p[4:8])[0]
            msg, _ = _read_string(p, 8)
            self.error = f"wayland error {code}: {msg}"
        elif obj in self.callbacks and op == 0:                 # wl_callback.done
            self.callbacks.discard(obj)
        elif obj == self.reg and op == 0:                       # wl_registry.global
            gname = struct.unpack("<I", p[:4])[0]
            iface, off = _read_string(p, 4)
            ver = struct.unpack("<I", p[off:off + 4])[0]
            if iface in WANT and iface not in self.globals:
                self.globals[iface] = (gname, ver)
        elif obj == self.notif and self.notif:
            if op in (0, 1):                                    # idled / resumed
                self.idle = op == 0
                self.changes += 1
        elif obj == self.mgr and self.mgr and op == 0:          # toplevel(new handle)
            h = struct.unpack("<I", p[:4])[0]
            self.tops[h] = {"app": "", "title": "", "active": False, "done": False}
            self.order.append(h)
        elif obj in self.tops:
            t = self.tops[obj]
            if op == 0:
                t["title"] = _read_string(p)[0]
            elif op == 1:
                t["app"] = _read_string(p)[0]
            elif op == 4:                                       # state (array of uint)
                n = struct.unpack("<I", p[:4])[0]
                states = struct.unpack(f"<{n // 4}I", p[4:4 + n]) if n else ()
                t["active"] = ACTIVATED in states
            elif op == 5:
                t["done"] = True
            elif op == 6:                                       # closed
                self.tops.pop(obj, None)
                if obj in self.order:
                    self.order.remove(obj)
                try:
                    with self.lock:
                        self.sock.sendall(struct.pack("<II", obj, (8 << 16) | 7))   # destroy
                except OSError:
                    pass

    # ---- what the session uses ---------------------------------------------------
    def wait_idle(self, stop: threading.Event, max_wait=WAIT_MAX) -> bool:
        """True once the person's hands rest; False on stop, timeout or a lost link."""
        end = time.time() + max_wait
        with self.cond:
            while not self.idle:
                if stop.is_set() or self.closed or time.time() >= end:
                    return False
                self.cond.wait(0.25)
        return not stop.is_set()

    def windows(self):
        """[{handle, app, title, active}] — every window on the person's screen."""
        with self.cond:
            return [dict(handle=h, **{k: self.tops[h][k] for k in ("app", "title", "active")})
                    for h in self.order if h in self.tops and self.tops[h]["done"]]

    def front(self):
        return next((w for w in self.windows() if w["active"]), None)

    def activate(self, handle, wait=1.0) -> bool:
        """Bring a window to the front (no input event: the person stays idle)."""
        if handle not in self.tops:
            return False
        self._send(handle, 4, struct.pack("<I", self.seat))     # activate(seat)
        end = time.time() + wait
        with self.cond:
            while time.time() < end:
                t = self.tops.get(handle)
                if t is None:
                    return False
                if t["active"]:
                    return True
                self.cond.wait(0.05)
        return bool(self.tops.get(handle, {}).get("active"))

    def close(self):
        with self.cond:
            self.closed = True
            self.cond.notify_all()
        try:
            self.sock.close()
        except OSError:
            pass


# ---- acting on the person's screen (their own WAYLAND_DISPLAY) --------------------
def _env():
    env = dict(os.environ)
    env.pop("OSPRIME_DESK", None)
    return env


def png_size(path):
    with open(path, "rb") as f:
        head = f.read(24)
    if head[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    return struct.unpack(">II", head[16:24])


def screenshot(path: str):
    """(width, height) of a picture of the person's whole screen, or None."""
    if not shutil.which("grim"):
        return None
    r = subprocess.run(["grim", "-t", "png", path], env=_env(), capture_output=True, timeout=20)
    if r.returncode != 0 or not os.path.exists(path):
        return None
    try:
        return png_size(path)
    except OSError:
        return None


def mark(path, x, y) -> bool:
    """Draw a red ring where the last click landed, so the model can see
    whether it hit what it meant to (laptop test, 15 October: it clicked
    "B3" four times at different places and could not tell)."""
    try:
        import cairo
        surf = cairo.ImageSurface.create_from_png(path)
        cr = cairo.Context(surf)
        r = max(10, surf.get_width() // 120)
        cr.set_source_rgba(1, 0, 0, 0.9)
        cr.set_line_width(max(2, r // 4))
        cr.arc(x, y, r, 0, 6.2832)
        cr.stroke()
        cr.move_to(x - 2 * r, y)
        cr.line_to(x + 2 * r, y)
        cr.move_to(x, y - 2 * r)
        cr.line_to(x, y + 2 * r)
        cr.stroke()
        surf.write_to_png(path)
        return True
    except Exception:
        return False


ZOOM_COLS, ZOOM_ROWS, ZOOM_SCALE = 16, 9, 2


def zoom(path, x, y, out_path):
    """A close-up around (x, y) — a third of the screen each way, twice as
    big — with numbered squares on it, so the model picks a square instead
    of guessing a point on a picture shrunk to 1280 wide (laptop test, 16
    October: "B3" landed three columns off). -> the grid, or None."""
    try:
        import cairo
        src = cairo.ImageSurface.create_from_png(path)
        w, h = src.get_width(), src.get_height()
        cw, ch = max(ZOOM_COLS * 12, w // 3), max(ZOOM_ROWS * 12, h // 3)
        cw, ch = min(cw, w), min(ch, h)
        x0 = int(min(max(0, x - cw / 2), w - cw))
        y0 = int(min(max(0, y - ch / 2), h - ch))
        s = ZOOM_SCALE
        surf = cairo.ImageSurface(cairo.FORMAT_RGB24, cw * s, ch * s)
        cr = cairo.Context(surf)
        cr.scale(s, s)
        cr.set_source_surface(src, -x0, -y0)
        cr.get_source().set_filter(cairo.FILTER_BEST)
        cr.paint()
        cr.identity_matrix()
        sw, sh = cw * s / ZOOM_COLS, ch * s / ZOOM_ROWS
        cr.set_line_width(1)
        for i in range(1, ZOOM_COLS):
            cr.move_to(i * sw, 0)
            cr.line_to(i * sw, ch * s)
        for j in range(1, ZOOM_ROWS):
            cr.move_to(0, j * sh)
            cr.line_to(cw * s, j * sh)
        cr.set_source_rgba(1, 0.1, 0.6, 0.55)
        cr.stroke()
        cr.select_font_face("sans-serif", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        fs = max(9, int(min(sw, sh) / 4))
        cr.set_font_size(fs)
        for n in range(ZOOM_COLS * ZOOM_ROWS):
            c, r = n % ZOOM_COLS, n // ZOOM_COLS
            label = str(n + 1)
            ext = cr.text_extents(label)
            cr.set_source_rgba(0, 0, 0, 0.6)
            cr.rectangle(c * sw + 1, r * sh + 1, ext.x_advance + 4, fs + 3)
            cr.fill()
            cr.set_source_rgb(1, 1, 0.3)
            cr.move_to(c * sw + 3, r * sh + fs + 1)
            cr.show_text(label)
        surf.write_to_png(out_path)
        return {"x0": x0, "y0": y0, "sq_w": cw / ZOOM_COLS, "sq_h": ch / ZOOM_ROWS,
                "cols": ZOOM_COLS, "rows": ZOOM_ROWS}
    except Exception:
        return None


def square_centre(grid, n):
    """Screen pixels of the middle of square n (1-based), or None."""
    try:
        n = int(n)
    except (TypeError, ValueError):
        return None
    if not grid or not 1 <= n <= grid["cols"] * grid["rows"]:
        return None
    c, r = (n - 1) % grid["cols"], (n - 1) // grid["cols"]
    return grid["x0"] + (c + 0.5) * grid["sq_w"], grid["y0"] + (r + 0.5) * grid["sq_h"]


def same_action(a: dict, b: dict) -> bool:
    """The same step again: same action, same text, key or cell, a click within ~2%."""
    if not a or not b or a.get("do") != b.get("do"):
        return False
    if a["do"] in ("click_at", "scroll"):
        return abs(a.get("x", 0) - b.get("x", 0)) < 0.02 and abs(a.get("y", 0) - b.get("y", 0)) < 0.02
    return (a.get("text"), a.get("key"), a.get("cell")) == (b.get("text"), b.get("key"), b.get("cell"))


def wtype_args(seq):
    """wtype's arguments for keys like ["Escape", "ctrl+Home", "Right"]."""
    import desk
    args = []
    for k in seq:
        mod, _, name = k.rpartition("+")
        if name not in desk.KEYS or mod not in ("", "ctrl"):
            return None
        args += (["-M", "ctrl", "-k", name, "-m", "ctrl"] if mod else ["-k", name])
    return args


def press_keys(seq) -> bool:
    args = wtype_args(seq)
    if not args or not shutil.which("wtype"):
        return False
    return subprocess.run(["wtype"] + args, env=_env(), capture_output=True, timeout=30).returncode == 0


def click(x, y, w, h, how="left") -> bool:
    r = subprocess.run([sys.executable, str(HERE / "osprime-pointer.py"), "click", str(int(x)), str(int(y)),
                        str(int(w)), str(int(h)), how], env=_env(), capture_output=True, timeout=15)
    return r.returncode == 0


def scroll(x, y, w, h, steps) -> bool:
    r = subprocess.run([sys.executable, str(HERE / "osprime-pointer.py"), "scroll", str(int(x)), str(int(y)),
                        str(int(w)), str(int(h)), str(int(steps))], env=_env(), capture_output=True, timeout=15)
    return r.returncode == 0


def type_text(text: str) -> bool:
    if not shutil.which("wtype"):
        return False
    return subprocess.run(["wtype", "--", text], env=_env(), capture_output=True, timeout=30).returncode == 0


def key(name: str) -> bool:
    import desk
    if name not in desk.KEYS or not shutil.which("wtype"):
        return False
    return subprocess.run(["wtype", "-k", name], env=_env(), capture_output=True, timeout=10).returncode == 0
