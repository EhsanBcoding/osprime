# Hardening for the scripts that run as root (docs/SECURITY.md #16; found in
# a review on 15 October). Sourced, never run.
#
# A script reached through a sudo rule inherits more than its arguments:
#   * the caller's working directory — `python3 -c` and `python3 -` put it
#     FIRST on sys.path, so a hardware.py there ran as root instead of ours;
#   * the caller's PATH, which sudo keeps unless secure_path is set — so a
#     `python3` of the caller's own came first;
#   * PYTHON* and LD_* variables, when anything lets them through.
# osprime_root_env takes all of that away, and osprime_py runs Python with
# -I (no working directory, no user site, no PYTHON* variables) and our
# agent folder as the only extra import path — after checking that folder
# belongs to root and nobody else can write to it.

osprime_root_env() {
    # As an ordinary user (the tests, with stand-in tools first on PATH) the
    # caller's PATH is kept: running as yourself there is nothing to gain.
    [ "$(id -u)" -eq 0 ] && export PATH=/usr/local/sbin:/usr/local/bin:/usr/bin:/usr/sbin
    unset PYTHONPATH PYTHONHOME PYTHONSTARTUP PYTHONUSERBASE PYTHONINSPECT \
          LD_PRELOAD LD_LIBRARY_PATH LD_AUDIT BASH_ENV ENV CDPATH GLOBIGNORE
    umask 022
    cd / || exit 1
    # A private folder for this run's logs and scratch files (self-review,
    # 16 October): fixed names in /tmp are names someone else can make first.
    OSPRIME_TMP="$(mktemp -d /tmp/osprime-run.XXXXXXXX)" || exit 1
    chmod 700 "$OSPRIME_TMP"
}

# True when nobody but root can change the code in this folder.
osprime_trusted_code() {
    local d="$1"
    [ "$(id -u)" -ne 0 ] && return 0          # the tests, as an ordinary user
    [ -d "$d" ] || return 1
    [ "$(stat -c %u "$d")" = 0 ] || return 1
    [ -n "$(find "$d" -maxdepth 1 \( ! -user root -o -perm /022 \) -print -quit 2>/dev/null)" ] && return 1
    return 0
}

# osprime_py -c CODE [ARG…]  — CODE with $AGENT (and nothing from the caller)
# importable; ARGs are sys.argv[1:] as usual.
osprime_py() {
    if [ "${1:-}" != -c ] || [ $# -lt 2 ]; then
        echo "osprime_py: only -c CODE [ARG…]" >&2
        return 2
    fi
    if ! osprime_trusted_code "$AGENT"; then
        echo "ERROR: $AGENT is not root's alone — refusing to run its code as root" >&2
        return 3
    fi
    # The folder arrives as an argument, not pasted into the code.
    /usr/bin/python3 -I -c "import sys; sys.path.insert(0, sys.argv.pop(1))
$2" "$AGENT" "${@:3}"
}

# Run a program as the osprime service account when we are root: the model
# files it reads live in a folder that account can write, so parsing them
# as root would hand that account root (a crafted file for the loader).
#
# Only ever in the background (`osprime_as_service "$BIN" … &`): it EXECs, so
# the $! the caller kills is the loader itself (runuser passes the signal on),
# not a subshell that would leave it running on the port.
osprime_as_service() {
    if [ "$(id -u)" -eq 0 ] && id osprime >/dev/null 2>&1; then
        exec runuser -u osprime -- "$@"
    fi
    exec "$@"
}
