"""Brainy's own desk (docs/ACT.md, step 3; Ehsan, 13 October).

A second, invisible desktop: labwc on the headless backend, one virtual
screen of 1280 × 800, run as the person (no root). Apps Brainy opens for a
job are opened HERE, so nothing appears on the person's screen and its own
mouse and keyboard (osprime-pointer.py, wtype) never touch theirs. Their
files are the same files — a download lands in ~/Downloads.

  * The browser here has its own profile (Ehsan: sign-ins stay separate);
    the person can sign in themselves from the Watch window, with
    Take over.
  * Started when a job needs it; stopped after 10 minutes with nothing to do
    (the companion's timer), with every app in it.
  * Which windows are on the desk: a process belongs to it when its
    environment names the desk's display — no list to keep in step.
"""
import json
import os
import pathlib
import shutil
import signal
import subprocess
import sys
import time

WIDTH, HEIGHT = 1280, 800
IDLE_STOP = 10 * 60
HERE = pathlib.Path(__file__).resolve().parent


def _runtime() -> pathlib.Path:
    return pathlib.Path(os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}")


def _state_file() -> pathlib.Path:
    return _runtime() / "osprime-desk.json"


def _data() -> pathlib.Path:
    sys.path.insert(0, str(HERE.parent / "agent"))
    import paths
    return paths.data_dir() / "desk"


def state() -> dict:
    try:
        return json.loads(_state_file().read_text())
    except Exception:
        return {}


def _alive(pid) -> bool:
    try:
        os.kill(int(pid), 0)
        return True
    except Exception:
        return False


def running() -> bool:
    st = state()
    return bool(st.get("display")) and _alive(st.get("pid", 0)) and \
        (_runtime() / st["display"]).exists()


def touch():
    st = state()
    if st:
        st["used"] = time.time()
        _state_file().write_text(json.dumps(st))


def idle_for() -> float:
    return time.time() - state().get("used", time.time())


def _clean_env():
    env = {k: v for k, v in os.environ.items()
           if k not in ("WAYLAND_DISPLAY", "DISPLAY", "WAYLAND_SOCKET")}
    return env


def start(timeout=15) -> str:
    """The desk's WAYLAND_DISPLAY, starting it if needed."""
    if running():
        touch()
        return state()["display"]
    if not shutil.which("labwc"):
        raise RuntimeError("labwc is missing")
    conf = _data() / "labwc"
    conf.mkdir(parents=True, exist_ok=True)
    (conf / "rc.xml").write_text(
        '<?xml version="1.0"?>\n<labwc_config>\n  <core><decoration>server</decoration></core>\n'
        '  <windowRules><windowRule identifier="*"><action name="Maximize"/></windowRule></windowRules>\n'
        '</labwc_config>\n')
    (conf / "autostart").write_text("")
    marker = _runtime() / f"osprime-desk-{os.getpid()}.name"
    try:
        marker.unlink()
    except FileNotFoundError:
        pass
    env = _clean_env()
    env.update(WLR_BACKENDS="headless", WLR_HEADLESS_OUTPUTS="1", WLR_LIBINPUT_NO_DEVICES="1",
               WLR_RENDERER="pixman", XDG_CURRENT_DESKTOP="osprime-desk")
    # labwc tells the -s command its WAYLAND_DISPLAY: that is how we learn it.
    proc = subprocess.Popen(["labwc", "-C", str(conf), "-s",
                             f'sh -c \'printf %s "$WAYLAND_DISPLAY" > "{marker}"\''],
                            env=env, stdout=subprocess.DEVNULL, stderr=open(_data() / "labwc.log", "w"),
                            start_new_session=True)
    end = time.time() + timeout
    name = ""
    while time.time() < end:
        if marker.exists() and marker.read_text().strip():
            name = marker.read_text().strip()
            break
        if proc.poll() is not None:
            raise RuntimeError("Brainy's desk could not start (see ~/.local/share/osprime/desk/labwc.log)")
        time.sleep(0.2)
    try:
        marker.unlink()
    except FileNotFoundError:
        pass
    if not name:
        proc.terminate()
        raise RuntimeError("Brainy's desk did not come up in time")
    _state_file().write_text(json.dumps({"pid": proc.pid, "display": name, "used": time.time()}))
    if shutil.which("wlr-randr"):
        subprocess.run(["wlr-randr", "--output", "HEADLESS-1", "--custom-mode", f"{WIDTH}x{HEIGHT}"],
                       env=env_for(name), capture_output=True, timeout=10)
    return name


def env_for(name=None) -> dict:
    name = name or state().get("display", "")
    env = _clean_env()
    env.update(WAYLAND_DISPLAY=name, GDK_BACKEND="wayland", QT_QPA_PLATFORM="wayland",
               MOZ_ENABLE_WAYLAND="1", OSPRIME_DESK="1")
    return env


def on_desk(pid) -> bool:
    """A process (an AT-SPI app's pid) that runs on the desk."""
    name = state().get("display", "")
    if not name or not pid:
        return False
    try:
        raw = pathlib.Path(f"/proc/{int(pid)}/environ").read_bytes()
    except Exception:
        return False
    return f"WAYLAND_DISPLAY={name}".encode() in raw.split(b"\0")


def open_app(app: str) -> str:
    start()
    sys.path.insert(0, str(HERE.parent / "agent"))
    import desktop
    argv, label = desktop.find_app(app)
    if not argv:
        raise RuntimeError(f"'{app}' is {label}")
    subprocess.Popen(argv, env=env_for(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True)
    touch()
    return app


def open_url(url: str) -> str:
    """The desk's browser: its own profile, never the person's."""
    if not url.startswith(("https://", "http://")):
        raise RuntimeError("only web addresses")
    # The public internet only: not this computer, not the home network
    # (self-review, 16 October) — OSprime's own Settings is on 127.0.0.1.
    sys.path.insert(0, str(HERE.parent / "agent"))
    import webtools
    why = webtools.public_url_problem(url)
    if why:
        raise RuntimeError(why)
    start()
    prof = _data() / "browser"
    prof.mkdir(parents=True, exist_ok=True)
    env = env_for()
    env["CHROME_PROFILE"] = str(prof)
    subprocess.Popen(["bash", str(HERE / "osprime-browser.sh"), f"--user-data-dir={prof}", url],
                     env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    touch()
    return url


def screenshot(path: str):
    """(width, height) or None."""
    if not running():
        return None
    r = subprocess.run(["grim", "-t", "png", path], env=env_for(), capture_output=True, timeout=20)
    touch()
    return (WIDTH, HEIGHT) if r.returncode == 0 and os.path.exists(path) else None


def click(x: int, y: int, how: str = "left") -> bool:
    if not running():
        return False
    r = subprocess.run([sys.executable, str(HERE / "osprime-pointer.py"), "click", str(int(x)), str(int(y)),
                        str(WIDTH), str(HEIGHT), how], env=env_for(), capture_output=True, timeout=15)
    touch()
    return r.returncode == 0


def scroll(x: int, y: int, steps: int) -> bool:
    if not running():
        return False
    r = subprocess.run([sys.executable, str(HERE / "osprime-pointer.py"), "scroll", str(int(x)), str(int(y)),
                        str(WIDTH), str(HEIGHT), str(int(steps))], env=env_for(), capture_output=True, timeout=15)
    touch()
    return r.returncode == 0


# Counted each time the person clicks, scrolls or types on the desk from the
# Watch window. Brainy's step is thrown away when this changed after its
# picture was taken (the page moved under it), and it looks again.
user_input = 0


def note_user_input():
    global user_input
    user_input += 1


KEYS = {"Return", "Tab", "Escape", "BackSpace", "Delete", "Up", "Down", "Left", "Right", "Home", "End",
        "Page_Up", "Page_Down", "space"}


def type_text(text: str) -> bool:
    if not running() or not shutil.which("wtype"):
        return False
    r = subprocess.run(["wtype", "--", text], env=env_for(), capture_output=True, timeout=30)
    touch()
    return r.returncode == 0


def key(name: str) -> bool:
    if name not in KEYS or not running() or not shutil.which("wtype"):
        return False
    r = subprocess.run(["wtype", "-k", name], env=env_for(), capture_output=True, timeout=10)
    touch()
    return r.returncode == 0


def press_keys(seq) -> bool:
    """Several keys in one go, like ["Escape", "ctrl+Home", "Right"] (cell)."""
    import screen_turns
    args = screen_turns.wtype_args(seq)
    if not args or not running() or not shutil.which("wtype"):
        return False
    r = subprocess.run(["wtype"] + args, env=env_for(), capture_output=True, timeout=30)
    touch()
    return r.returncode == 0


def stop():
    """The desk and every app on it."""
    st = state()
    name = st.get("display", "")
    if name:
        for p in pathlib.Path("/proc").iterdir():
            if p.name.isdigit() and int(p.name) != os.getpid() and on_desk(int(p.name)):
                try:
                    os.kill(int(p.name), signal.SIGTERM)
                except Exception:
                    pass
    if st.get("pid") and _alive(st["pid"]):
        try:
            os.killpg(int(st["pid"]), signal.SIGTERM)
        except Exception:
            try:
                os.kill(int(st["pid"]), signal.SIGTERM)
            except Exception:
                pass
    try:
        _state_file().unlink()
    except FileNotFoundError:
        pass
