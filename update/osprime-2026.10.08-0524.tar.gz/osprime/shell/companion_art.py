"""How a companion character is drawn (docs/COMPANION.md, "Characters").

Pure cairo, no GTK: the window in osprime-companion.py owns position,
dragging and clicks, and asks this module to paint one frame. The tests and
the screenshot tool paint frames into a PNG the same way.

A character is a pack folder (shell/characters/<id>/, see make_pack.py):
the picture, a glow mask, and character.json saying where the eyes, mouth and
hands are. On top of the picture this draws what makes it alive:

  * EYES, drawn over the painted ones in the same sockets: they blink, and
    the pupils look somewhere — at the user, up while thinking, at the thing
    it is pointing to (phase 4).
  * A MOUTH that opens over the painted smile while it talks. Closed, the
    painted smile is all there is, so at rest it is exactly the picture.
  * GLOW added to its seams by state: none at rest (the picture already
    glows a little), a slow pulse while listening, a band of light running
    through the seams while thinking, amber while it reads the screen.

Pose is a plain dict, so the window's animation clock and the tests can
build one without each other:

    {"blink": 0..1 (1 = shut), "look": (x, y) each -1..1,
     "mouth": 0..1, "glow": 0..1, "band": 0..1 or None (position of the
     travelling light), "tint": "amber" or None, "attention": bool}
"""
import json
import math
import pathlib

import cairo

HERE = pathlib.Path(__file__).resolve().parent
PACKS = HERE / "characters"
AMBER = (1.0, 0.70, 0.25)


def available() -> list:
    """[(id, name)] of every pack that has what it needs, sorted by name."""
    out = []
    for d in sorted(PACKS.glob("*/character.json")):
        try:
            meta = json.loads(d.read_text(encoding="utf-8"))
            if (d.parent / "character.png").is_file():
                out.append((d.parent.name, meta.get("name", d.parent.name)))
        except Exception:
            continue
    return out


def rest_pose() -> dict:
    return {"blink": 0.0, "look": (0.0, 0.0), "mouth": 0.0, "glow": 0.0,
            "band": None, "tint": None, "attention": False}


class Character:
    def __init__(self, pack_id: str, packs: pathlib.Path = PACKS):
        d = packs / pack_id
        self.id = pack_id
        self.meta = json.loads((d / "character.json").read_text(encoding="utf-8"))
        self.name = self.meta.get("name", pack_id)
        self.aspect = float(self.meta.get("aspect", 0.83))
        self.img = cairo.ImageSurface.create_from_png(str(d / "character.png"))
        glow = d / "glow.png"
        self.glow = cairo.ImageSurface.create_from_png(str(glow)) if glow.is_file() else None
        self._cache = {}         # height -> (picture, glow) scaled once

    # ---- geometry -----------------------------------------------------------
    def size_for(self, height: int):
        return max(1, round(height * self.aspect)), int(height)

    def hand(self, height: int, side: str = "right"):
        """Where a pointing strand leaves from, in window px."""
        w, h = self.size_for(height)
        hands = self.meta.get("hands") or [{"x": 0.9, "y": 0.73}]
        hd = hands[-1] if side == "right" else hands[0]
        return hd["x"] * w, hd["y"] * h

    def _scaled(self, w: int, h: int):
        key = (w, h)
        if key not in self._cache:
            out = []
            for src in (self.img, self.glow):
                if src is None:
                    out.append(None)
                    continue
                s = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
                c = cairo.Context(s)
                c.scale(w / src.get_width(), h / src.get_height())
                c.set_source_surface(src, 0, 0)
                c.get_source().set_filter(cairo.FILTER_BEST)
                c.paint()
                out.append(s)
            self._cache = {key: tuple(out)}      # one size at a time
        return self._cache[key]

    def alpha_surface(self, height: int):
        """The picture at this height: the window's click area is its alpha."""
        return self._scaled(*self.size_for(height))[0]

    # ---- one frame ----------------------------------------------------------
    def draw(self, cr, height: int, pose: dict):
        w, h = self.size_for(height)
        pic, glow = self._scaled(w, h)
        cr.save()
        cr.set_source_surface(pic, 0, 0)
        cr.paint()
        if glow is not None:
            self._draw_glow(cr, glow, w, h, pose)
        for eye in self.meta.get("eyes", []):
            self._draw_eye(cr, eye, w, h, pose)
        self._draw_mouth(cr, w, h, float(pose.get("mouth") or 0))
        if pose.get("attention"):
            r = max(5, w * 0.06)
            cr.arc(w - r - 2, r + 2, r, 0, 2 * math.pi)
            cr.set_source_rgba(0.95, 0.62, 0.12, 1)
            cr.fill_preserve()
            cr.set_source_rgba(1, 1, 1, 0.9)
            cr.set_line_width(max(1.5, r * 0.25))
            cr.stroke()
        cr.restore()

    def _draw_glow(self, cr, glow, w, h, pose):
        level = max(0.0, min(1.0, float(pose.get("glow") or 0)))
        band = pose.get("band")
        tint = AMBER if pose.get("tint") == "amber" else tuple(c / 255 for c in self.meta.get("glow", [90, 240, 230]))
        if pose.get("tint") == "amber":
            level = max(level, 0.8)
        if level <= 0.01 and band is None:
            return
        cr.save()
        # The colour, poured through the glow mask. ADD so the seams get
        # brighter rather than painted over: they still look like the picture.
        cr.set_operator(cairo.OPERATOR_ADD)
        if band is not None:
            # A band of light running down through the seams and back up.
            y = (band % 1.0) * h * 1.3 - h * 0.15
            g = cairo.LinearGradient(0, y - h * 0.22, 0, y + h * 0.22)
            g.add_color_stop_rgba(0, *tint, 0)
            g.add_color_stop_rgba(0.5, *tint, 0.95)
            g.add_color_stop_rgba(1, *tint, 0)
            cr.set_source(g)
            cr.mask_surface(glow, 0, 0)
        if level > 0.01:
            if pose.get("tint") == "amber":
                # Over, not add: added to a white seam amber is just white,
                # and "it is reading your screen" has to be seen.
                cr.set_operator(cairo.OPERATOR_OVER)
            cr.set_source_rgba(*tint, 0.9 * level)
            cr.mask_surface(glow, 0, 0)
        cr.restore()

    def _draw_eye(self, cr, eye, w, h, pose):
        cx, cy = eye["cx"] * w, eye["cy"] * h
        rx, ry = eye["rx"] * w, eye["ry"] * h
        pr = eye["pupil"] * w
        lx, ly = pose.get("look") or (0.0, 0.0)
        lx, ly = max(-1, min(1, lx)), max(-1, min(1, ly))
        cr.save()
        # The eyeball: an ellipse in the painted socket, clipped to it.
        cr.translate(cx, cy)
        cr.scale(rx, ry)
        cr.arc(0, 0, 0.97, 0, 2 * math.pi)
        cr.restore()
        cr.save()
        cr.clip_preserve()
        ball = cairo.RadialGradient(cx - rx * 0.3, cy - ry * 0.35, 0, cx, cy, max(rx, ry))
        ball.add_color_stop_rgb(0, 1, 1, 1)
        ball.add_color_stop_rgb(0.7, 0.96, 0.96, 0.97)
        ball.add_color_stop_rgb(1, 0.80, 0.81, 0.84)
        cr.set_source(ball)
        cr.fill()
        # The pupil, travelling inside the eye.
        px = cx + lx * (rx - pr) * 0.78
        py = cy + ly * (ry - pr) * 0.70
        pupil = cairo.RadialGradient(px - pr * 0.3, py - pr * 0.3, pr * 0.1, px, py, pr)
        pupil.add_color_stop_rgb(0, 0.16, 0.16, 0.18)
        pupil.add_color_stop_rgb(1, 0.02, 0.02, 0.03)
        cr.arc(px, py, pr, 0, 2 * math.pi)
        cr.set_source(pupil)
        cr.fill()
        # Two catch-lights, fixed to the light, not to the pupil.
        cr.set_source_rgba(1, 1, 1, 0.95)
        cr.arc(px - pr * 0.32, py - pr * 0.38, pr * 0.24, 0, 2 * math.pi)
        cr.fill()
        cr.set_source_rgba(1, 1, 1, 0.6)
        cr.arc(px + pr * 0.35, py + pr * 0.30, pr * 0.10, 0, 2 * math.pi)
        cr.fill()
        # The lid, coming down from the top.
        blink = max(0.0, min(1.0, float(pose.get("blink") or 0)))
        if blink > 0.02:
            top, bot = self.meta.get("lid_top", [240] * 3), self.meta.get("lid_bottom", [200] * 3)
            edge = cy - ry + 2 * ry * blink
            lid = cairo.LinearGradient(0, cy - ry, 0, edge)
            lid.add_color_stop_rgb(0, *(c / 255 for c in top))
            lid.add_color_stop_rgb(1, *(c / 255 for c in bot))
            cr.rectangle(cx - rx - 1, cy - ry - 1, 2 * rx + 2, edge - (cy - ry) + 1)
            cr.set_source(lid)
            cr.fill()
            cr.move_to(cx - rx, edge)
            cr.line_to(cx + rx, edge)
            cr.set_source_rgba(0.1, 0.1, 0.12, 0.55)
            cr.set_line_width(max(1, rx * 0.06))
            cr.stroke()
        cr.restore()

    def _draw_mouth(self, cr, w, h, opening):
        if opening < 0.08:
            return               # closed: the painted smile is the mouth
        m = self.meta.get("mouth")
        if not m:
            return
        cx, cy = m["cx"] * w, m["cy"] * h
        mw = m["w"] * w * (0.55 + 0.25 * opening)
        mh = m["h"] * h * (0.35 + 0.95 * opening)
        cr.save()
        cr.translate(cx, cy)
        cr.scale(mw / 2, mh / 2)
        cr.arc(0, 0, 1, 0, 2 * math.pi)
        cr.restore()
        cr.set_source_rgb(0.07, 0.06, 0.07)
        cr.fill_preserve()
        cr.save()
        cr.clip()                # the tongue stays inside the mouth
        cr.save()
        cr.translate(cx, cy + mh * 0.38)
        cr.scale(mw * 0.32, mh * 0.30)
        cr.arc(0, 0, 1, 0, 2 * math.pi)
        cr.restore()
        cr.set_source_rgb(0.80, 0.33, 0.36)
        cr.fill()
        cr.restore()


def render_png(pack_id: str, height: int, pose: dict, path: str, background=None):
    """One frame to a file — the tests and the screenshots use this."""
    ch = Character(pack_id)
    w, h = ch.size_for(height)
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    cr = cairo.Context(s)
    if background:
        cr.set_source_rgb(*background)
        cr.paint()
    ch.draw(cr, height, pose)
    s.write_to_png(path)
    return path
