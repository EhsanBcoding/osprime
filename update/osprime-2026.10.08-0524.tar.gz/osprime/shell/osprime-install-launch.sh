#!/usr/bin/env bash
# The "Install OSprime" icon on the live USB desktop. docs/INSTALL.md.
#
# On a desktop it opens the graphical installer (installer/
# osprime-installer-gui.py). If that cannot start, or with --checked/--here,
# it opens a terminal and runs the text installer in it — that one stays as
# the fallback. When the text installer finishes, the window stays open: on
# success it offers to restart, on failure the error stays on screen until
# Enter.
#
# Only ever from the live USB. On an installed machine this does nothing
# but say so — the installer's own guard (it never erases a disk in use)
# is the second line of defence, not the first.
set -u
LIVE="${OSPRIME_LIVE_DIR:-/run/archiso}"
INSTALLER="${OSPRIME_INSTALLER:-/opt/osprime/installer/osprime-install.py}"

COMPAT="${OSPRIME_COMPAT:-$(dirname "$0")/osprime-compat.py}"
CHECK_TEXT="${OSPRIME_COMPAT_TEXT:-$(dirname "$0")/../agent/compat.py}"

GUI="${OSPRIME_INSTALLER_GUI:-$(dirname "$INSTALLER")/osprime-installer-gui.py}"

# From the icon on the live desktop: the graphical installer, full screen.
# Its second page is the system check. It exits with 3 when it cannot start
# a window at all; then the older way takes over: the "Is this computer
# ready?" window, whose Install button comes back here with --checked and
# runs the text installer in a terminal. Without a desktop (a terminal), the
# same check is printed before the text installer.
if [ "${1:-}" = "" ] && [ -d "$LIVE" ] && [ -n "${WAYLAND_DISPLAY:-}" ]; then
    if [ -f "$GUI" ]; then
        python3 "$GUI"
        rc=$?
        [ $rc -ne 3 ] && exit $rc
    fi
    [ -f "$COMPAT" ] && exec python3 "$COMPAT"
fi
[ "${1:-}" = --checked ] && { CHECKED=1; shift; }

# Started from the desktop there is no terminal yet: open one, run again in it.
if [ "${1:-}" != --here ]; then
    if [ -t 0 ] && [ -t 1 ]; then
        exec bash "$0" --here
    fi
    exec foot -T "Install OSprime" env OSPRIME_CHECKED="${CHECKED:-}" bash "$0" --here
fi

pause() { printf "\nPress Enter to close this window. "; read -r _ || true; }

if [ ! -d "$LIVE" ]; then
    echo "OSprime is already installed on this computer."
    echo "The installer only runs from the OSprime USB."
    pause; exit 1
fi

echo "Install OSprime"
echo "==============="
echo
if [ -z "${OSPRIME_CHECKED:-}${CHECKED:-}" ] && [ -f "$CHECK_TEXT" ]; then
    report="$(python3 "$CHECK_TEXT" --text 2>/dev/null)"
    if [ -n "$report" ]; then
        echo "$report"; echo
        if printf '%s' "$report" | head -1 | grep -q "Not recommended"; then
            printf "OSprime is not recommended on this computer. Install anyway? [y/N] "
            read -r a || a=""
            case "$a" in y|Y|yes) ;; *) echo "Nothing was changed."; pause; exit 1 ;; esac
        fi
    fi
fi
# -n: the live USB's own sudo rule needs no password. If it asks for one,
# something is wrong with this USB — say so rather than prompting a buyer
# for a password nobody gave them.
if ! sudo -n true 2>/dev/null; then
    echo "The installer could not get administrator rights on this USB."
    echo "Try:  sudo python3 $INSTALLER"
    pause; exit 1
fi

sudo -n python3 "$INSTALLER"
rc=$?
echo
if [ $rc -ne 0 ]; then
    echo "The installation did not finish. Nothing above was hidden —"
    echo "the messages show where it stopped."
    pause; exit $rc
fi

echo "OSprime is installed."
echo "Remove the USB stick, then restart to start OSprime from the disk."
printf "Restart now? [y/N] "; read -r a || a=""
echo
case "$a" in
    y|Y|yes) sudo -n systemctl reboot ;;
    *) echo "Restart whenever you are ready."; pause ;;
esac
