#!/usr/bin/env python3
"""The OSprime companion: a character that lives on the desktop.

Click it to ask something right there (the bubble beside it); drag it
wherever you like; right-click for the chat, Settings, and hiding it.

Read docs/COMPANION.md before changing this. The short version:

  * This file owns the WINDOW: where it is, dragging, clicks, timers. What
    it looks like is shell/companion_art.py, and which character is a pack
    folder in shell/characters/ (Pearl and Coral, 8 October). "simple" is the
    round button of 23 September, kept as a choice.
  * States come from the agent through a file (agent/companion.py): idle,
    working, attention, and for the next phases listening, speaking,
    reading. The bubble adds "talking" while an answer streams in.
  * AT REST IT IS STILL. It blinks now and then and may glance around; it
    does not bob, glow or follow the pointer. Anything that moves all the
    time is a thing people switch off. Calmer movement (Settings) drops
    the glances and the travelling light as well.
  * ATTENTION IS A DOT. Not a bubble, not a window, not a sound. The bubble
    opens only when the person clicks.
  * Nothing here may take the session down. If this program dies the user
    loses a button, not their computer.

Dragging is ours to implement. A layer-shell surface is placed by the
compositor from an anchor and a margin — there is no window manager to drag
it with — so we track the pointer and move the margin ourselves.
"""

import json
import math
import os
import pathlib
import random
import signal
import subprocess
import sys
import time

import cairo
import gi

gi.require_version("Gtk", "3.0")
gi.require_version("GtkLayerShell", "0.1")
from gi.repository import Gtk, Gdk, GLib, GtkLayerShell  # noqa: E402

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / "agent"))
import paths  # noqa: E402  — machine defaults + the person's own file
import companion_art  # noqa: E402
ENV_FILE = paths.desktop_env_target()
STATE_FILE = paths.companion_state()
LOG = pathlib.Path(os.environ.get("OSPRIME_COMPANION_LOG",
                                  f"/tmp/osprime-companion-{os.getuid()}.log"))

STATES = ("idle", "working", "attention", "listening", "speaking", "reading")
SIZES = {"small": 110, "medium": 150, "large": 200}
DEFAULT_CHARACTER = "pearl"
FPS = 30


def log(msg):
    try:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%H:%M:%S')} {msg}\n")
    except Exception:
        pass


def env() -> dict:
    return {k: v.strip('"') for k, v in paths.read_desktop_env().items()}


def save_env(key: str, value: str):
    """Write one key back, keeping the rest of the file.

    The same file Settings and the assistant use, so the companion's
    position is not a fourth place configuration lives.
    """
    if not paths.write_desktop_env(key, value):
        log(f"could not save {key} to {ENV_FILE}")


def look_config(cfg: dict):
    """(character id or "simple", height px, calm) from desktop.env."""
    ch = cfg.get("OSPRIME_COMPANION_CHARACTER", DEFAULT_CHARACTER)
    if ch != "simple" and ch not in dict(companion_art.available()):
        ch = DEFAULT_CHARACTER if DEFAULT_CHARACTER in dict(companion_art.available()) else "simple"
    size = cfg.get("OSPRIME_COMPANION_LOOK_SIZE", "medium")
    height = SIZES.get(size, SIZES["medium"])
    calm = cfg.get("OSPRIME_COMPANION_MOTION", "normal") == "calm"
    return ch, height, calm


class Animator:
    """The pose of the character over time. Pure: the clock is passed in, so
    the tests can step it without a screen (tests/test_companion.py)."""

    def __init__(self, calm=False, rng=None):
        self.calm = calm
        self.rng = rng or random.Random()
        self.state = "idle"
        self.talking = False
        self.attention = False
        self.look = [0.0, 0.0]          # where the pupils are
        self.look_to = [0.0, 0.0]       # where they are going
        self.blink_at = None            # start time of the current blink
        self.next_blink = 0.0
        self.next_glance = 0.0
        self.mouth = 0.0
        self.level = 0.0                # microphone loudness while listening
        self.t0 = time.monotonic()

    def schedule(self, now):
        self.next_blink = now + self.rng.uniform(2.5, 6.5)
        self.next_glance = now + self.rng.uniform(7, 15)

    def busy(self, now) -> bool:
        """Does it need frames right now? At rest, only for a blink or a
        glance; that is what keeps an idle laptop idle."""
        if self.state in ("working", "listening", "speaking", "reading") or self.talking:
            return True
        if self.blink_at is not None:
            return True
        return any(abs(a - b) > 0.01 for a, b in zip(self.look, self.look_to)) or self.mouth > 0.01

    def target_look(self):
        return {"working": (-0.45, -0.85), "reading": (0.6, -0.2),
                "listening": (0.0, 0.1), "speaking": (0.0, 0.1)}.get(self.state)

    def step(self, now) -> dict:
        # Blinks: one every few seconds, sometimes two in a row.
        if self.blink_at is None and now >= self.next_blink:
            self.blink_at = now
        blink = 0.0
        if self.blink_at is not None:
            k = (now - self.blink_at) / 0.18
            blink = max(0.0, 1 - abs(2 * k - 1)) if k < 1 else 0.0
            if k >= 1:
                self.blink_at = None
                double = self.rng.random() < 0.18
                self.next_blink = now + (0.15 if double else self.rng.uniform(2.5, 6.5))
        # Where to look: the state says, else an occasional glance.
        tgt = self.target_look()
        if tgt is not None:
            self.look_to = list(tgt)
        elif now >= self.next_glance:
            if self.calm:
                self.look_to = [0.0, 0.0]
            else:
                self.look_to = ([0.0, 0.0] if self.rng.random() < 0.45 else
                                [self.rng.uniform(-0.8, 0.8), self.rng.uniform(-0.5, 0.4)])
            self.next_glance = now + self.rng.uniform(7, 15)
        elif self.state == "idle" and tgt is None and self.look_to != [0.0, 0.0] \
                and self.calm:
            self.look_to = [0.0, 0.0]
        for i in (0, 1):
            self.look[i] += (self.look_to[i] - self.look[i]) * 0.25
        # The mouth: flaps while words arrive, closes when they stop.
        if self.talking or self.state == "speaking":
            ph = (now - self.t0) * 9.0
            self.mouth = 0.25 + 0.55 * abs(math.sin(ph) * math.sin(ph * 0.37 + 1))
        else:
            self.mouth *= 0.6
        t = now - self.t0
        pose = companion_art.rest_pose()
        pose.update(blink=blink, look=tuple(self.look), mouth=self.mouth,
                    attention=self.attention)
        if self.state == "working":
            if self.calm:
                pose["glow"] = 0.45
            else:
                pose["band"] = (t / 2.2) % 1.0
                pose["glow"] = 0.15
        elif self.state == "listening":
            # It glows with your voice; a slow breath when you are quiet.
            breath = 0.12 * (0.5 + 0.5 * math.sin(t * 3.0))
            pose["glow"] = min(1.0, 0.2 + breath + self.level * 6)
        elif self.state == "speaking" or self.talking:
            pose["glow"] = 0.25 + 0.25 * self.mouth
        elif self.state == "reading":
            pose["tint"] = "amber"
            pose["glow"] = 0.85
        return pose


class Companion:
    # Corners, and the edges each one anchors to. Position is stored as a
    # corner plus an offset rather than as x,y from the top left: a screen
    # that changes resolution then keeps the companion in the corner it was
    # near, instead of leaving it off the edge of a smaller display.
    CORNERS = {
        "bottom-right": (GtkLayerShell.Edge.BOTTOM, GtkLayerShell.Edge.RIGHT),
        "bottom-left": (GtkLayerShell.Edge.BOTTOM, GtkLayerShell.Edge.LEFT),
        "top-right": (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.RIGHT),
        "top-left": (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.LEFT),
    }

    def __init__(self):
        cfg = env()
        self.corner = cfg.get("OSPRIME_COMPANION_CORNER", "bottom-right")
        if self.corner not in self.CORNERS:
            self.corner = "bottom-right"
        try:
            self.mx = int(cfg.get("OSPRIME_COMPANION_X", 28))
            self.my = int(cfg.get("OSPRIME_COMPANION_Y", 76))
        except ValueError:
            self.mx, self.my = 28, 76

        self.state = "idle"
        self.attention = False
        self._phase = 0.0
        self._drag = None
        self._moved = False
        self._anim_id = None
        self.bubble = None
        self.character = None
        self._look = None
        self.local_state = None     # listening/working/speaking, set here, wins over the file

        self.win = Gtk.Window()
        self.win.set_name("companion")
        GtkLayerShell.init_for_window(self.win)
        # TOP, not OVERLAY: above ordinary windows, but still below a
        # full-screen video or a lock screen, which should not have a
        # button floating over them.
        GtkLayerShell.set_layer(self.win, GtkLayerShell.Layer.TOP)
        GtkLayerShell.set_namespace(self.win, "osprime-companion")
        # 0, not -1: it must not reserve space or push other windows around.
        GtkLayerShell.set_exclusive_zone(self.win, 0)
        try:
            GtkLayerShell.set_keyboard_mode(
                self.win, GtkLayerShell.KeyboardMode.NONE)
        except Exception:
            pass

        screen = self.win.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.win.set_visual(visual)
        self.win.set_app_paintable(True)

        self.area = Gtk.DrawingArea()
        self.area.connect("draw", self.on_draw)
        self.win.add(self.area)

        self.win.add_events(Gdk.EventMask.BUTTON_PRESS_MASK
                            | Gdk.EventMask.BUTTON_RELEASE_MASK
                            | Gdk.EventMask.POINTER_MOTION_MASK
                            | Gdk.EventMask.ENTER_NOTIFY_MASK
                            | Gdk.EventMask.LEAVE_NOTIFY_MASK)
        self.win.connect("button-press-event", self.on_press)
        self.win.connect("button-release-event", self.on_release)
        self.win.connect("motion-notify-event", self.on_motion)
        self.win.connect("realize", lambda *_: self.apply_input_shape())

        self.load_look(cfg)
        self.apply_position()
        self.win.show_all()

        GLib.timeout_add(700, self.poll_state)
        # The keyboard shortcuts reach a running companion as signals
        # (shell/osprime-companion-ctl.sh): Super+Space = SIGUSR1, talk.
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGUSR1, self.on_listen_key)
        # Settings changes the character, the size or the calm switch in
        # desktop.env; picked up here, without restarting anything.
        GLib.timeout_add(3000, self.poll_look)
        self.anim.schedule(time.monotonic())
        self.wake()

    # ---- the look --------------------------------------------------------
    def load_look(self, cfg=None):
        ch, height, calm = look_config(cfg or env())
        self._look = (ch, height, calm)
        self.character = None
        if ch != "simple":
            try:
                self.character = companion_art.Character(ch)
            except Exception as e:
                log(f"character {ch} could not load ({e}); the round one instead")
        if self.character:
            self.w, self.h = self.character.size_for(height)
        else:
            self.w = self.h = max(32, min(160, int((cfg or env()).get("OSPRIME_COMPANION_SIZE", 56))))
        self.anim = Animator(calm=calm)
        self.area.set_size_request(self.w, self.h)
        self.win.set_size_request(self.w, self.h)
        self.win.resize(self.w, self.h)
        self.apply_input_shape()

    def poll_look(self):
        now = look_config(env())
        if now != self._look:
            log(f"look changed: {now}")
            self.load_look()
            self.anim.schedule(time.monotonic())
            self.area.queue_draw()
            if self.bubble:
                self.bubble.reposition()
        return True

    def apply_input_shape(self):
        """Clicks land on the character, not on the empty corners of its box:
        a click beside its arm reaches the window underneath."""
        gw = self.win.get_window()
        if gw is None:
            return
        try:
            if self.character:
                region = Gdk.cairo_region_create_from_surface(
                    self.character.alpha_surface(self.h))
            else:
                region = cairo.Region(cairo.RectangleInt(0, 0, self.w, self.h))
            gw.input_shape_combine_region(region, 0, 0)
        except Exception as e:
            log(f"input shape: {e}")

    # ---- position ------------------------------------------------------
    def apply_position(self):
        for edge in (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.BOTTOM,
                     GtkLayerShell.Edge.LEFT, GtkLayerShell.Edge.RIGHT):
            GtkLayerShell.set_anchor(self.win, edge, False)
        v, h = self.CORNERS[self.corner]
        GtkLayerShell.set_anchor(self.win, v, True)
        GtkLayerShell.set_anchor(self.win, h, True)
        GtkLayerShell.set_margin(self.win, h, max(0, self.mx))
        GtkLayerShell.set_margin(self.win, v, max(0, self.my))
        if self.bubble:
            self.bubble.reposition()

    def save_position(self):
        save_env("OSPRIME_COMPANION_CORNER", self.corner)
        save_env("OSPRIME_COMPANION_X", str(int(self.mx)))
        save_env("OSPRIME_COMPANION_Y", str(int(self.my)))

    # ---- drawing -------------------------------------------------------
    def on_draw(self, _area, cr):
        # SOURCE rather than OVER, so this REPLACES the alpha instead of
        # compositing onto it. Painting transparent with OVER changes
        # nothing, and the window keeps whatever GTK last left there —
        # which is how a "transparent" window ends up a grey square.
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)
        if self.character:
            self.character.draw(cr, self.h, self.anim.step(time.monotonic()))
        else:
            self.draw_simple(cr)
        return False

    def draw_simple(self, cr):
        """The round button of 23 September, for whoever prefers it."""
        s = self.w
        cx = cy = s / 2
        r = s / 2 - 4
        cr.arc(cx, cy, r, 0, 2 * math.pi)
        cr.set_source_rgba(0.09, 0.12, 0.18, 0.96)
        cr.fill_preserve()
        cr.set_source_rgba(0.18, 0.42, 0.87, 0.9)
        cr.set_line_width(2)
        cr.stroke()
        if self.state in ("working", "listening", "reading") or self.anim.talking:
            start = self._phase
            cr.arc(cx, cy, r, start, start + math.pi * 0.6)
            cr.set_source_rgba(0.35, 0.62, 1.0, 0.95)
            cr.set_line_width(3)
            cr.stroke()
        cr.select_font_face("Noto Sans")
        cr.set_font_size(s * 0.42)
        cr.set_source_rgba(0.85, 0.90, 0.98, 0.95)
        ext = cr.text_extents("O")
        cr.move_to(cx - ext.width / 2 - ext.x_bearing,
                   cy - ext.height / 2 - ext.y_bearing)
        cr.show_text("O")
        if self.attention:
            cr.arc(cx + r * 0.72, cy - r * 0.72, max(4, s * 0.11), 0, 2 * math.pi)
            cr.set_source_rgba(0.82, 0.60, 0.13, 1.0)
            cr.fill()

    def wake(self):
        """Start the frame clock if it is not running. It stops itself as
        soon as nothing moves (Animator.busy), so an idle companion costs
        a timer every few seconds, not 30 frames a second."""
        if self._anim_id is None:
            self._anim_id = GLib.timeout_add(1000 // FPS, self.tick)
        return False

    def tick(self):
        now = time.monotonic()
        self._phase = (self._phase + 0.18) % (2 * math.pi)
        self.area.queue_draw()
        if self.anim.busy(now) or (not self.character and self.state == "working"):
            return True
        self._anim_id = None
        # Sleep until the next blink or glance, then wake for it.
        wait = max(0.05, min(self.anim.next_blink, self.anim.next_glance) - now)
        GLib.timeout_add(int(wait * 1000), self.wake)
        return False

    def set_talking(self, on: bool):
        self.anim.talking = bool(on)
        self.wake()

    def set_local_state(self, state):
        """The bubble's own states (listening, writing it down, speaking).
        They win over the agent's file until cleared with None."""
        self.local_state = state
        self.anim.state = state or self.state
        self.wake()
        self.area.queue_draw()
        return False

    def set_level(self, lv: float):
        self.anim.level = lv

    def on_listen_key(self, *_):
        """Super+Space: open the bubble if needed and listen; again to stop."""
        try:
            if self.bubble is None:
                import companion_bubble
                self.bubble = companion_bubble.Bubble(self)
            self.bubble.listen_toggle()
        except Exception as e:
            log(f"listening failed: {e}")
        return True             # keep the signal handler

    # ---- state ---------------------------------------------------------
    def poll_state(self):
        """Read the state another process wrote. Never asks the agent.

        A file rather than a socket: the companion must keep working when
        the agent is not running, and a missing file means idle, which is
        the correct answer for a machine whose assistant is not there.
        """
        state, attention = "idle", False
        try:
            raw = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            state = raw.get("state", "idle")
            attention = bool(raw.get("attention"))
            # A stale file is not a state. If nothing has updated it for a
            # while, the writer died mid-turn and the companion would spin
            # for ever.
            if time.time() - float(raw.get("at", 0)) > 120:
                state = "idle"
        except Exception:
            pass
        if state not in STATES:
            state = "idle"
        if state == "attention":
            state, attention = "idle", True

        changed = (state != self.state) or (attention != self.attention)
        self.state, self.attention = state, attention
        self.anim.state, self.anim.attention = self.local_state or state, attention
        if changed:
            self.wake()
            self.area.queue_draw()
        return True

    # ---- pointer -------------------------------------------------------
    def on_press(self, _w, ev):
        if ev.button == 3:
            self.menu(ev)
            return True
        if ev.button == 1:
            self._drag = (ev.x_root, ev.y_root, self.mx, self.my)
            self._moved = False
        return True

    def on_motion(self, _w, ev):
        if not self._drag:
            return False
        sx, sy, ox, oy = self._drag
        dx, dy = ev.x_root - sx, ev.y_root - sy
        if abs(dx) > 3 or abs(dy) > 3:
            self._moved = True
        # The margin grows towards the anchored edge, so the sign depends
        # on which corner it is anchored to. Getting this wrong makes the
        # companion run away from the pointer, which is very funny once.
        v, h = self.corner.split("-")
        self.mx = max(0, ox + (-dx if h == "right" else dx))
        self.my = max(0, oy + (-dy if v == "bottom" else dy))
        self.apply_position()
        return True

    def on_release(self, _w, ev):
        if not self._drag:
            return False
        self._drag = None
        if not self._moved:
            if self.bubble and self.bubble.recording:
                self.bubble.stop_listening("done")     # a click ends the turn
            else:
                self.toggle_bubble()
            return True

        # Re-anchor to whichever corner it was left nearest, so a drag
        # across the screen does not leave it anchored to the far edge with
        # a margin the width of the display — which breaks the moment the
        # resolution changes.
        mon = self.win.get_screen().get_monitor_geometry(0)
        v, h = self.corner.split("-")
        x = (mon.width - self.mx - self.w) if h == "right" else self.mx
        y = (mon.height - self.my - self.h) if v == "bottom" else self.my
        new_h = "right" if x + self.w / 2 > mon.width / 2 else "left"
        new_v = "bottom" if y + self.h / 2 > mon.height / 2 else "top"
        self.corner = f"{new_v}-{new_h}"
        self.mx = (mon.width - x - self.w) if new_h == "right" else x
        self.my = (mon.height - y - self.h) if new_v == "bottom" else y
        self.mx, self.my = max(0, int(self.mx)), max(0, int(self.my))
        self.apply_position()
        self.save_position()
        return True

    # ---- actions -------------------------------------------------------
    def toggle_bubble(self):
        """Ask right here (shell/companion_bubble.py). The chat window is one
        click away in the bubble and on the right-click menu."""
        try:
            if self.bubble is None:
                import companion_bubble
                self.bubble = companion_bubble.Bubble(self)
            self.bubble.toggle()
        except Exception as e:
            log(f"bubble failed ({e}); opening the chat instead")
            self.toggle_chat()

    def toggle_chat(self):
        try:
            subprocess.Popen(["bash", str(HERE / "osprime-toggle.sh")],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        except Exception as e:
            log(f"could not open the chat: {e}")

    def menu(self, ev):
        m = Gtk.Menu()
        for label, fn in (
                ("Ask here", lambda *_: self.toggle_bubble()),
                ("Talk (Super+Space)", lambda *_: self.on_listen_key()),
                ("Open the chat", lambda *_: self.toggle_chat()),
                ("Settings", lambda *_: self.open_settings()),
                ("Hide until next login", lambda *_: Gtk.main_quit()),
                ("Hide for good", lambda *_: self.hide_for_good())):
            item = Gtk.MenuItem(label=label)
            item.connect("activate", fn)
            m.append(item)
        m.show_all()
        m.popup_at_pointer(ev)

    def open_settings(self):
        try:
            subprocess.Popen(["bash", str(HERE / "osprime-settings.sh"),
                              "personal"],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        except Exception as e:
            log(f"could not open settings: {e}")

    def hide_for_good(self):
        # Writes the same switch Settings shows, so the two cannot disagree
        # about whether the companion is meant to be here.
        save_env("OSPRIME_COMPANION", "no")
        Gtk.main_quit()


def main():
    if env().get("OSPRIME_COMPANION", "yes") == "no":
        log("companion is switched off")
        return
    try:
        Companion()
        Gtk.main()
    except Exception as e:
        # A button is not worth a session. Log it and leave; labwc, the
        # panel and the Super key all keep working without us.
        log(f"companion failed: {e}")
        sys.exit(0)


if __name__ == "__main__":
    main()
