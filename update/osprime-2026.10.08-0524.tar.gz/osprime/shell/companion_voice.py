"""Talking to the companion (docs/COMPANION.md, phase 2).

Super+Space (or the microphone button in the bubble) starts listening; it
stops by itself when you stop talking, or on Super+Space again, a click on
the character, or Stop. Esc cancels and nothing is sent.

Why not "hold to talk": on Wayland a program is never told about a key it
does not own being let go. labwc can run a command on press and another on
release, but the two arrive as unrelated events with nothing to tie them
together, so a lost release would leave the microphone open. Stopping on a
pause is what a phone assistant does anyway, and it cannot get stuck.

Everything stays on this computer: arecord for the sound (PipeWire answers
it through its ALSA layer, and the panel's microphone badge lights up —
which is the point of having one), whisper.cpp for the words
(agent/voice.py, the same engine the chat's microphone uses).

Pure Python apart from arecord: the listening logic (Listener.feed) takes
raw samples, so the tests drive it without a microphone.
"""
import array
import io
import math
import os
import shutil
import subprocess
import threading
import wave

RATE = 16000
CHUNK = 1600                  # 0.1 s of 16-bit mono
MAX_SECONDS = 60
SILENCE_AFTER_SPEECH = 1.3    # this long quiet after talking ends the turn
NOTHING_HEARD = 8.0           # this long without any speech: give up
MIN_SPEECH = 0.3


def rms(pcm: bytes) -> float:
    """Loudness of a chunk, 0..1."""
    a = array.array("h")
    a.frombytes(pcm[: len(pcm) // 2 * 2])
    if not a:
        return 0.0
    return min(1.0, math.sqrt(sum(x * x for x in a) / len(a)) / 32768.0)


class Listener:
    """Decides when a spoken turn is over. Feed it chunks; it says "go on",
    "done" (speech then a pause, or the time limit) or "nothing"."""

    def __init__(self):
        self.t = 0.0
        self.noise = None
        self.speech = 0.0
        self.quiet = 0.0
        self.levels = []

    def threshold(self) -> float:
        # Three times the room, but never so high that someone who starts
        # talking the instant they press the key (and so is "the room") is
        # not heard at all.
        return max(0.012, min(0.05, (self.noise or 0.004) * 3.0))

    def feed(self, pcm: bytes) -> str:
        dt = len(pcm) / 2 / RATE
        self.t += dt
        lv = rms(pcm)
        self.levels.append(lv)
        if self.t <= 0.3:          # the room, before anyone speaks
            self.noise = lv if self.noise is None else (self.noise + lv) / 2
            return "go on"
        if lv > self.threshold():
            self.speech += dt
            self.quiet = 0.0
        else:
            self.quiet += dt
        if self.t >= MAX_SECONDS:
            return "done" if self.speech >= MIN_SPEECH else "nothing"
        if self.speech >= MIN_SPEECH and self.quiet >= SILENCE_AFTER_SPEECH:
            return "done"
        if self.speech < MIN_SPEECH and self.t >= NOTHING_HEARD:
            return "nothing"
        return "go on"


def to_wav(pcm: bytes) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm)
    return buf.getvalue()


def can_listen():
    """(ok, why not) — checked before the microphone is opened."""
    try:
        import json
        import system_tools
        if not json.loads(system_tools.capture_state())["allowed"]["microphone"]:
            return False, ("The microphone is switched off for OSprime "
                           "(Settings → Privacy).")
    except Exception:
        pass
    try:
        import voice
        st = voice.status()
        if not st.get("stt"):
            return False, st.get("stt_why") or "Speech to text is not set up."
    except Exception as e:
        return False, f"Speech to text is not available ({e})."
    if not shutil.which("arecord"):
        return False, "arecord is missing (package alsa-utils)."
    return True, ""


class Recording:
    """One spoken turn. Callbacks run on the recording thread; the caller
    hands them to its own loop (GLib.idle_add)."""

    def __init__(self, on_level, on_end):
        self.on_level = on_level          # (level 0..1)
        self.on_end = on_end              # ("done"|"nothing"|"cancelled"|"error", pcm, detail)
        self.proc = None
        self.pcm = bytearray()
        self.listener = Listener()
        self._stop = None

    def start(self):
        self.proc = subprocess.Popen(
            ["arecord", "-q", "-f", "S16_LE", "-r", str(RATE), "-c", "1", "-t", "raw"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        threading.Thread(target=self._run, daemon=True).start()

    def stop(self, why="done"):
        """Stop now: "done" keeps what was said, "cancelled" throws it away."""
        self._stop = why

    def _run(self):
        result, detail = "error", ""
        try:
            while True:
                chunk = self.proc.stdout.read(CHUNK * 2)
                if not chunk:
                    result, detail = "error", "the microphone stopped"
                    break
                self.pcm += chunk
                verdict = self.listener.feed(chunk)
                self.on_level(self.listener.levels[-1])
                if self._stop:
                    result = self._stop
                    if result == "done" and self.listener.speech < MIN_SPEECH:
                        result = "nothing"
                    break
                if verdict != "go on":
                    result = verdict
                    break
        except Exception as e:
            result, detail = "error", str(e)
        finally:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=2)
            except Exception:
                pass
        self.on_end(result, bytes(self.pcm) if result == "done" else b"", detail)


def transcribe(pcm: bytes) -> str:
    """Words, or 'ERROR: …'."""
    import voice
    return voice.transcribe(to_wav(pcm), ".wav", "auto")


# ---- spoken answers -------------------------------------------------------
def can_speak() -> bool:
    try:
        import voice
        return voice.tts_available() and bool(shutil.which("pw-play") or shutil.which("aplay"))
    except Exception:
        return False


def speak(text: str, on_start, on_end):
    """Read an answer aloud (piper), in the background. The mouth moves
    while it plays: on_start / on_end tell the companion."""
    def run():
        try:
            import voice
            wav = voice.synthesize(text[:1500])
            if not wav:
                return
            path = f"/tmp/osprime-say-{os.getuid()}.wav"
            with open(path, "wb") as f:
                f.write(wav)
            player = shutil.which("pw-play") or shutil.which("aplay")
            on_start()
            subprocess.run([player, path], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=300)
        except Exception:
            pass
        finally:
            on_end()
    threading.Thread(target=run, daemon=True).start()


def clean(text: str) -> str:
    """whisper marks silence and noise as [BLANK_AUDIO], (music) and so on."""
    import re
    text = re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", text or "")
    return " ".join(text.split())
