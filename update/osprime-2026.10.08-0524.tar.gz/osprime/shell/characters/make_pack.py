#!/usr/bin/env python3
"""Turn a character picture into a companion pack (docs/COMPANION.md).

    python3 shell/characters/make_pack.py   # rebuilds pearl/ and coral/

A pack is a folder in shell/characters/ that the companion reads and never
writes:

    character.png   the picture, cropped to the figure, transparent around it
    glow.png        where it glows: white, with the strength in the alpha
    character.json  what the code needs to bring it to life — where the eyes,
                    the mouth and the hand are (as fractions of the picture),
                    the eyelid and glow colours, and a display name

Adding a character later is a new folder, not new code: draw it, take the
background off, measure its eyes and mouth, and write the JSON (by hand, or
by adding an entry to SOURCES below). The two Brainy pictures were made by
Ehsan, 7 October 2026, background removed by hand (docs/Brainy/).

Development only: needs OpenCV and numpy, which the installed machine does
not. The packs it writes are what ships.
"""
import json
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent.parent
OUT_HEIGHT = 420      # px; sharp up to the "large" size on a 2x screen

# Both Brainy pictures are the same render in two colours, so they share the
# geometry (measured on the picture, in pixels of the cropped figure — the
# crop below is taken first, so (0, 0) is its top left corner)
# and the glow mask, which is taken from the turquoise one: its seams are
# the only cyan in it, so they separate cleanly.
BRAINY = {
    "crop": (215, 155, 827, 995),                  # x, y, w, h of the figure
    # eyes measured from the white of each eyeball (inside the metal ring);
    # the right one is narrower, it is turned slightly away
    "eyes": [{"cx": 407.5, "cy": 282.0, "rx": 86.0, "ry": 87.0, "pupil": 36.0},
             {"cx": 659.0, "cy": 293.0, "rx": 76.0, "ry": 85.0, "pupil": 34.0}],
    "mouth": {"cx": 536.0, "cy": 438.0, "w": 109.0, "h": 53.0},
    # the gloves: where a pointing strand leaves from (phase 4)
    "hands": [{"x": 80.0, "y": 730.0}, {"x": 760.0, "y": 730.0}],
}
SOURCES = {
    "pearl": dict(BRAINY, name="Pearl", picture="docs/Brainy/Pearl Robotic Brain Companion-No BG.png",
                  glow=[90, 240, 230], lid_top=[246, 246, 248], lid_bottom=[196, 198, 204]),
    "coral": dict(BRAINY, name="Coral", picture="docs/Brainy/Coral Robotic Brain Companion-No BG.png",
                  glow=[255, 196, 140], lid_top=[252, 156, 132], lid_bottom=[200, 92, 76]),
}
GLOW_FROM = "pearl"


def main():
    import cv2
    import numpy as np

    def load(spec):
        im = cv2.imread(str(ROOT / spec["picture"]), cv2.IMREAD_UNCHANGED)
        x, y, w, h = spec["crop"]
        im = im[y:y + h, x:x + w].copy()
        a = im[..., 3]
        a[a < 24] = 0            # specks left by the old label (not visible, but counted)
        return im

    gsrc = load(SOURCES[GLOW_FROM])
    b, g, r = (gsrc[..., i].astype(int) for i in range(3))
    glow = np.clip((np.minimum(g, b) - r - 12) * 6, 0, 255).astype(np.uint8)
    glow[gsrc[..., 3] < 200] = 0
    glow = cv2.GaussianBlur(glow, (5, 5), 0)

    for pid, spec in SOURCES.items():
        im = load(spec)
        h0, w0 = im.shape[:2]
        scale = OUT_HEIGHT / h0
        size = (round(w0 * scale), OUT_HEIGHT)
        out = HERE / pid
        out.mkdir(exist_ok=True)
        cv2.imwrite(str(out / "character.png"), cv2.resize(im, size, interpolation=cv2.INTER_AREA))
        gm = cv2.resize(glow, size, interpolation=cv2.INTER_AREA)
        rgba = np.zeros((size[1], size[0], 4), np.uint8)
        rgba[..., :3] = 255
        rgba[..., 3] = gm
        cv2.imwrite(str(out / "glow.png"), rgba)

        def fx(v): return round(v / w0, 4)
        def fy(v): return round(v / h0, 4)
        meta = {
            "name": spec["name"],
            "aspect": round(w0 / h0, 4),
            "glow": spec["glow"],
            "lid_top": spec["lid_top"], "lid_bottom": spec["lid_bottom"],
            "eyes": [{"cx": fx(e["cx"]), "cy": fy(e["cy"]), "rx": fx(e["rx"]),
                      "ry": fy(e["ry"]), "pupil": fx(e["pupil"])} for e in spec["eyes"]],
            "mouth": {"cx": fx(spec["mouth"]["cx"]), "cy": fy(spec["mouth"]["cy"]),
                      "w": fx(spec["mouth"]["w"]), "h": fy(spec["mouth"]["h"])},
            "hands": [{"x": fx(hd["x"]), "y": fy(hd["y"])} for hd in spec["hands"]],
            "source": spec["picture"],
        }
        (out / "character.json").write_text(json.dumps(meta, indent=1) + "\n", encoding="utf-8")
        print(pid, size, out)


if __name__ == "__main__":
    main()
