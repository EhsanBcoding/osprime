"""Skill loading and matching.

A skill is one Markdown file with a JSON header. The header holds what the
system must search — trigger phrases, required tools, required packages,
source licences. The body holds four sections written for a reader:

    ## Do it            how the assistant performs it
    ## Teach it         how the user is taught to perform it
    ## Check            how to know it actually worked
    ## Common mistakes  what goes wrong, accumulated over time

Skills are retrieved per request rather than all loaded into the prompt.
Sixty-three skills in every system prompt would cost more tokens than the
conversation, and a 1.5B model reads a shorter prompt more reliably anyway.

Matching is keyword scoring over the trigger phrases, deliberately not a
model call: asking a small model to choose from sixty options is exactly the
kind of decision it gets wrong, and a wrong choice here is invisible.
"""

import json
import os
import pathlib
import re
import shutil

SKILL_DIR = pathlib.Path(os.environ.get(
    "OSPRIME_SKILLS",
    str(pathlib.Path(__file__).resolve().parent.parent / "skills")))

_SECTION = re.compile(r"^##\s+(.+?)\s*$", re.M)
_HEADER = re.compile(r"^---json\s*\n(.*?)\n---\s*\n", re.S)

# Phrasing that asks to be taught rather than served. The user's own words
# choose the mode; presenting a menu before doing anything is itself an
# interruption.
_TEACH = ("how do i", "how can i", "how to", "teach me", "show me how",
          "walk me through", "i want to learn", "learn how", "explain how",
          "step by step")
_WATCH = ("show me", "demonstrate", "watch")

_CACHE = {"mtime": None, "skills": []}


def _parse(path: pathlib.Path):
    try:
        raw = path.read_text(encoding="utf-8")
    except Exception:
        return None
    m = _HEADER.match(raw)
    if not m:
        return None
    try:
        meta = json.loads(m.group(1))
    except json.JSONDecodeError:
        return None

    body = raw[m.end():]
    sections, bounds = {}, [(mm.group(1).lower(), mm.start(), mm.end())
                            for mm in _SECTION.finditer(body)]
    for i, (title, _s, e) in enumerate(bounds):
        end = bounds[i + 1][1] if i + 1 < len(bounds) else len(body)
        sections[title] = body[e:end].strip()

    meta["sections"] = sections
    meta.setdefault("triggers", [])
    meta.setdefault("packages", [])
    meta.setdefault("tools", [])
    meta.setdefault("type", "shared")
    return meta


# ---- the person's own skills: ~/Memory/Skills (6 October) -------------------
# Written for a person, not for this parser:
#
#     ---
#     when: weekly report, گزارش هفتگی
#     ---
#     # Weekly report
#     1. Find this week's files in Documents/Reports …
#
# They are instructions the model will follow, every time the words come
# up — so only the person makes them: by hand in Notes, or through
# save_skill, which always asks first and shows the whole text. The
# assistant's own writing (remember, forget) never touches this folder
# (agent/vault.py). Built-in skills stay read-only in /opt, where updates
# can still fix them.
PERSONAL_LIMIT = 1500       # characters of one personal skill sent to the model


def personal_dir() -> pathlib.Path:
    if os.environ.get("OSPRIME_PERSONAL_SKILLS"):
        return pathlib.Path(os.environ["OSPRIME_PERSONAL_SKILLS"])
    try:
        import vault
        return vault.root() / "Skills"
    except Exception:
        return pathlib.Path.home() / "Memory" / "Skills"


def _parse_personal(path: pathlib.Path):
    try:
        raw = path.read_text(encoding="utf-8")
    except Exception:
        return None
    when, body = [], raw
    m = re.match(r"---\s*\n(.*?)\n---\s*\n", raw, re.S)
    if m:
        body = raw[m.end():]
        for line in m.group(1).splitlines():
            k, _, v = line.partition(":")
            if k.strip().lower() in ("when", "triggers", "trigger"):
                when += [w.strip().strip("'\"[]") for w in re.split(r"[,،;]", v) if w.strip()]
    if not when:
        return None          # a skill with no words that call it never runs
    title = re.search(r"^#\s+(.+)$", body, re.M)
    steps = re.sub(r"^#\s+.+\n?", "", body, count=1, flags=re.M).strip()
    return {"name": "personal:" + path.stem, "title": title.group(1).strip() if title else path.stem,
            "type": "personal", "path": str(path), "triggers": when, "tools": [],
            "packages": [], "sections": {"do it": steps[:PERSONAL_LIMIT]}}


def _stamp(paths) -> float:
    try:
        return max((p.stat().st_mtime for p in paths), default=0)
    except Exception:
        return 0


def load(refresh: bool = False) -> list:
    """Built-in skills and the person's own, caching until a file changes."""
    builtin = sorted(SKILL_DIR.glob("*.md")) if SKILL_DIR.is_dir() else []
    pdir = personal_dir()
    personal = sorted(pdir.glob("*.md")) if pdir.is_dir() else []
    stamp = (_stamp(builtin), _stamp(personal), len(personal))
    if not refresh and _CACHE["mtime"] == stamp:
        return _CACHE["skills"]
    skills = [s for s in (_parse(p) for p in builtin) if s]
    skills += [s for s in (_parse_personal(p) for p in personal) if s]
    _CACHE.update(mtime=stamp, skills=skills)
    return skills


# Common words carry no signal and inflate every score. Without this,
# "what is the capital of France" matched the clock skill: it shares "the"
# and "is" with the trigger "the time is off", which was half the phrase.
_STOP = {
    "a", "an", "and", "are", "as", "at", "be", "by", "can", "do", "does",
    "for", "from", "has", "have", "how", "i", "in", "is", "it", "its", "me",
    "my", "of", "on", "or", "please", "so", "that", "the", "then", "there",
    "this", "to", "up", "want", "was", "what", "when", "where", "with",
    "would", "you", "your",
    # Persian
    "و", "به", "از", "که", "این", "اون", "را", "رو", "یه", "یک", "من", "برام",
    "کن", "بکن", "با", "در", "تو", "توی",
}


_FA = str.maketrans({"ي": "ی", "ك": "ک", "\u200c": " "})


def _words(text: str) -> set:
    # Letters of any script: a-z only meant no Persian trigger could ever
    # match (the backlog's "Persian skill triggers").
    return set(re.findall(r"[^\W_]+", (text or "").lower().translate(_FA)))


def _content(text: str) -> set:
    return _words(text) - _STOP


def match(message: str, minimum: float = 0.5):
    """Best matching skill for this message, or None.

    Scores each trigger phrase by how much of it appears in the message. A
    two-word trigger that fully matches beats a six-word trigger that half
    matches, which keeps short specific phrases like "compress a pdf" from
    being drowned out.
    """
    msg = _content(message)
    if not msg:
        return None
    best, best_key = None, None
    for skill in load():
        for trigger in skill.get("triggers", []):
            tw = _content(trigger)
            if not tw:
                continue
            overlap = tw & msg
            # Two real words in common for any trigger that has two — one is
            # enough only for a one-word trigger.
            #
            # This used to accept a single shared word, which against a
            # two-word trigger is already the 50% threshold. Measured on 59
            # plain requests on 24 September, 17 were handed the wrong
            # skill's instructions in the system prompt: "turn the volume
            # up" got the Wi-Fi skill because "turn on wifi" says turn,
            # "update yourself" got the CV skill because "update my resume"
            # says update, "take a photo" got the lost-file skill. Nothing
            # failed; the model was just quietly told how to do the wrong
            # job. With this rule it is 2 of 59, and every trigger still
            # matches its own skill.
            if len(overlap) < min(2, len(tw)):
                continue
            # Ranked on three things, in order. The ratio is the real signal.
            # The other two only break ties — and ties are common, because a
            # trigger like "where is my document" reduces to the single word
            # "document" and then scores a perfect 1.0 against any sentence
            # containing it. Without a tie-break the winner was decided by
            # filename order, which is not a decision anyone made.
            # …and the person's own skill wins a tie: they wrote it for
            # exactly this.
            key = (len(overlap) / len(tw), len(overlap), len(tw),
                   skill.get("type") == "personal")
            if best_key is None or key > best_key:
                best, best_key = skill, key
    return best if best_key and best_key[0] >= minimum else None


def detect_mode(message: str) -> str:
    """'teach', 'watch' or 'do' — taken from how the user phrased it."""
    low = (message or "").lower()
    if any(p in low for p in _TEACH):
        return "teach"
    if any(p in low for p in _WATCH):
        return "watch"
    return "do"


def missing_packages(skill: dict) -> list:
    """Packages the skill needs that are not present."""
    missing = []
    for pkg in skill.get("packages", []):
        # A package name is usually its command; where it is not, the skill
        # can name the command explicitly as "package:command".
        cmd = pkg.split(":")[-1]
        if not shutil.which(cmd):
            missing.append(pkg.split(":")[0])
    return missing


def render(skill: dict, mode: str = "do") -> str:
    """The guidance to put in front of the model for this request."""
    if not skill:
        return ""
    s = skill.get("sections", {})
    if skill.get("type") == "personal":
        return (f"SKILL the user taught you ({skill.get('title')}) — do it this way:\n"
                + s.get("do it", ""))
    parts = [f"SKILL: {skill.get('title', skill.get('name', ''))}"]

    if mode == "teach" and s.get("teach it"):
        parts.append("The user asked to be taught, not served. Follow this, "
                     "one step at a time, and wait for them between steps.")
        parts.append(s["teach it"])
    else:
        if s.get("do it"):
            parts.append(s["do it"])
        if mode == "watch" and s.get("teach it"):
            parts.append("Explain each step as you perform it.")

    if s.get("check"):
        parts.append("VERIFY BEFORE REPORTING SUCCESS:\n" + s["check"])
    if s.get("common mistakes"):
        parts.append("AVOID:\n" + s["common mistakes"])

    gone = missing_packages(skill)
    if gone:
        # Some skills need something an update cannot deliver — a model too
        # large to ship, for instance. Telling the user to "install an
        # update" when the real remedy is one specific command sends them
        # somewhere that will not help.
        setup = skill.get("setup")
        remedy = (f"Tell the user to run this once in a terminal, exactly as "
                  f"written, and then ask again:\n    {setup}"
                  if setup else
                  "Tell the user this needs an update before it can run.")
        parts.append("NOT INSTALLED: " + ", ".join(gone) + ". " + remedy +
                     "\nDo not attempt the steps, and do not substitute a "
                     "different method that gives a worse result.")
    return "\n\n".join(parts)


def for_message(message: str) -> str:
    """One call for the agent: matched skill guidance, or empty."""
    skill = match(message)
    if not skill:
        return ""
    return render(skill, detect_mode(message))


def selftest() -> list:
    """Requests that must NOT pull in a skill, and triggers that must.

    The first list is the evidence for the two-word rule in match(): each of
    these was once handed another skill's instructions.
    """
    bad = []
    for phrase in ("take a photo", "turn the volume up", "update yourself",
                   "change my wallpaper", "check for updates",
                   "make everything bigger", "what windows are open"):
        s = match(phrase)
        if s:
            bad.append(f"skills: {phrase!r} pulls in the {s['name']} skill")
    for skill in load():
        for trig in skill.get("triggers", []):
            got = match(trig)
            if not got or got["name"] != skill["name"]:
                bad.append(f"skills: trigger {trig!r} of {skill['name']} "
                           f"matches {got['name'] if got else 'nothing'}")
    return bad


def save_personal(name: str, when: str, steps: str) -> dict:
    """Write ~/Memory/Skills/<name>.md. Only ever called after the person
    said yes to the whole text (agent.py: save_skill is always confirmed)."""
    import vault
    title = vault.clean_title(name)
    words = [w.strip() for w in re.split(r"[,،;\n]", when or "") if w.strip()]
    steps = (steps or "").strip()
    if not title or not words or not steps:
        return {"ok": False, "message": "ERROR: a skill needs a name, the words "
                "that call it, and its steps. Nothing was saved."}
    if len(steps) > PERSONAL_LIMIT:
        return {"ok": False, "message": f"ERROR: keep the steps under {PERSONAL_LIMIT} "
                "characters. Nothing was saved."}
    try:
        import permissions
        if permissions.redact(steps) != steps:
            return {"ok": False, "message": "ERROR: the steps contain what looks like a "
                    "password or key. Nothing was saved."}
    except Exception:
        pass
    p = personal_dir() / f"{title}.md"
    text = f"---\nwhen: {', '.join(words)}\n---\n# {title}\n\n{steps}\n"
    p.parent.mkdir(parents=True, exist_ok=True)
    cid = vault._write(p, text, "skill", f"{title} — when: {', '.join(words)}", by="person")
    load(refresh=True)
    return {"ok": True, "id": cid, "note": vault.rel(p),
            "message": f"Saved. From now on '{words[0]}' uses {vault.rel(p)}."}
