"""OSprime backend router — local-first, one switch (docs/CLOUD.md).

The local model answers unless the person has switched the cloud model on
in Settings → Assistant. Then the cloud model answers everything. Nothing
switches by itself in either direction (Ehsan, 7 October): a cloud that
cannot be reached is reported with an offer to go back to the local model,
and a local model that is down is started again, not replaced by the
cloud.

The three modes this replaces ("never", "only when I ask", "when the local
model cannot cope") and the phrases that summoned the cloud mid-sentence
are gone: they made it hard to know which model had answered, and "only
when I ask" once quietly became "always" when the local engine stopped.
"""

import cloud
import local


def local_available() -> bool:
    return local.available()


def cloud_on() -> bool:
    return cloud.enabled()


def pick_backend(message: str = "") -> str:
    """'cloud' when the switch is on, else 'local'. Never raises: what to do
    when the chosen one cannot answer is the caller's to say."""
    return "cloud" if cloud.enabled() else "local"
