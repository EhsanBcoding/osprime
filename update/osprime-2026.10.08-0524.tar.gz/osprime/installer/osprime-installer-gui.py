#!/usr/bin/env python3
"""The graphical installer — full screen, in the buyer's language.

Asked for by Ehsan, 7 October: full screen (decided), English first with a
choice of every language (installer/installer_strings.py), and the text
installer kept as the fallback.

This window only asks and shows. The work is done by the same engine as
before, installer/osprime-install.py, started with --answers-stdin: the
answers go to it as one JSON line on stdin (passwords included — never on a
command line), and it reports back as JSON lines (steps, progress, the
recovery key, done). The live USB's own sudo rule runs it; nothing here
runs as root.

    python3 osprime-installer-gui.py               the real thing
    OSPRIME_INSTALL_DRY=1 python3 …                a practice run: every page,
                                                   the engine in --dry-run,
                                                   nothing written to any disk

Pages: language → this computer → disk → you → keyboard → protection →
summary (type ERASE) → installing → recovery key → done.
"""
import json
import os
import pathlib
import re
import subprocess
import sys
import threading

HERE = pathlib.Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent / "agent")]
import installer_strings as S  # noqa: E402

ENGINE = os.environ.get("OSPRIME_INSTALLER", str(HERE / "osprime-install.py"))
DRY = bool(os.environ.get("OSPRIME_INSTALL_DRY"))
NAME_RE = r"^[a-z_][a-z0-9_-]{0,30}$"
RESERVED = ("osprime", "root", "greeter")


# ---------------------------------------------------------------------------
# the parts that are not GTK (tests/test_gui_installer.py checks these)
# ---------------------------------------------------------------------------
def suggest_username(full: str) -> str:
    """'Ehsan Bahrami' → 'ehsan'. Empty for a name in another script — the
    person types one; a guessed transliteration of their name is worse."""
    first = (full or "").strip().split(" ")[0].lower() if full else ""
    name = re.sub(r"[^a-z0-9_-]", "", first)
    return name if re.match(NAME_RE, name) and name not in RESERVED else ""


def check_account(name: str, password: str, again: str):
    """(ok, problem key)."""
    if not re.match(NAME_RE, name or "") or name in RESERVED:
        return False, "user_bad"
    if not password:
        return False, "pw_empty"
    if password != again:
        return False, "pw_mismatch"
    return True, ""


def check_protection(mode: str, pw: str, again: str, pin: str = "", pin2: str = ""):
    if mode == "none":
        return True, ""
    if not pw:
        return False, "pw_empty"
    if pw != again:
        return False, "pw_mismatch"
    if mode == "tpm-pin" and (not pin.isdigit() or len(pin) < 4):
        return False, "pin_bad"
    if mode == "tpm-pin" and pin != pin2:
        return False, "pw_mismatch"
    return True, ""


def keyboard_ids(chosen: set, persian_style: str = "fa") -> str:
    """English first, then the others in a fixed order."""
    order = [l[3] for l in S.LANGUAGES if l[3] != "en"]
    out = ["en"]
    for k in order:
        if k in chosen:
            out.append(persian_style if k == "fa" else k)
    return ",".join(out)


def build_answers(st: dict) -> dict:
    enc = {"mode": st.get("enc_mode", "none")}
    if enc["mode"] != "none":
        enc["password"] = st.get("disk_pw", "")
        if enc["mode"] == "tpm-pin":
            enc["pin"] = st.get("pin", "")
    return {"disk": st["disk"], "lang": st.get("lang", "en"),
            "account": {"name": st["user"], "full": st.get("full") or st["user"],
                        "password": st["password"]},
            "keyboard": keyboard_ids(st.get("kb", set()), st.get("kb_fa", "fa")),
            "enc": enc}


def engine_command() -> list:
    cmd = ["python3", ENGINE, "--answers-stdin"] + (["--dry-run"] if DRY else [])
    return cmd if (DRY or os.geteuid() == 0) else ["sudo", "-n"] + cmd


def probe() -> dict:
    try:
        out = subprocess.run(["python3", ENGINE, "--probe"], capture_output=True,
                             text=True, timeout=30).stdout
        return json.loads(out)
    except Exception:
        return {"disks": [], "in_use": [], "uefi": True, "tpm": False}


# ---------------------------------------------------------------------------
# the window
# ---------------------------------------------------------------------------
def run():
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    from gi.repository import Gdk, GLib, Gtk, Pango

    CSS = b"""
    window, .page { background-color: #0d1117; color: #e6edf3; }
    #side { background-color: #161b22; border-right: 1px solid #21262d; }
    #brand { font-size: 22px; font-weight: 700; color: #4c8dff; }
    .nav { color: #6e7681; font-size: 14px; padding: 6px 0; }
    .nav.done { color: #8b949e; }
    .nav.now { color: #e6edf3; font-weight: 700; }
    .title { font-size: 28px; font-weight: 700; }
    .sub { color: #8b949e; font-size: 15px; }
    .card { background-color: #161b22; border: 1px solid #30363d; border-radius: 10px; padding: 14px; }
    .card:checked, .card.on { border-color: #4c8dff; background-color: #1a2333; }
    .warn { color: #f0b429; } .bad { color: #ff7b72; } .ok { color: #3fb950; }
    .key { font-family: monospace; font-size: 22px; font-weight: 700; letter-spacing: 1px;
           background-color: #161b22; padding: 18px; border-radius: 10px; }
    button { padding: 8px 18px; background-image: none; background-color: #21262d;
             color: #e6edf3; border: 1px solid #30363d; box-shadow: none; text-shadow: none; }
    button:hover { background-color: #2a313c; }
    button.card { padding: 14px; font-size: 16px; }
    radiobutton, checkbutton { color: #e6edf3; }
    entry { background-color: #0d1117; color: #e6edf3; border: 1px solid #30363d; }
    progressbar trough { background-color: #21262d; border: none; }
    button.primary { background-image: none; background-color: #2d6cdf; color: white; border: none; }
    button.primary:disabled { background-color: #22324d; color: #6e7681; }
    entry { padding: 8px; min-height: 22px; }
    progressbar progress { background-color: #2d6cdf; min-height: 10px; }
    progressbar trough { min-height: 10px; }
    textview, textview text { background-color: #010409; color: #8b949e; font-family: monospace; }
    """

    class Installer(Gtk.Window):
        PAGES = ["lang", "check", "disk", "you", "kb", "enc", "sum", "inst", "key", "done"]
        NAV = [("lang", "nav_lang"), ("check", "nav_check"), ("disk", "nav_disk"),
               ("you", "nav_you"), ("kb", "nav_kb"), ("enc", "nav_enc"),
               ("sum", "nav_sum"), ("inst", "nav_inst")]

        def __init__(self):
            super().__init__(title="Install OSprime")
            prov = Gtk.CssProvider()
            prov.load_from_data(CSS)
            Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov,
                                                     Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
            self.st = {"lang": "en", "kb": set(), "kb_fa": "fa", "enc_mode": "",
                       "red_ok": False, "busy": False}
            self.machine = {"disks": [], "in_use": [], "uefi": True, "tpm": False}
            self.compat = None
            self.log = []
            self.page = "lang"
            self.engine = None
            self.connect("delete-event", lambda *_: self.st["busy"])   # no closing mid-install
            self.connect("destroy", Gtk.main_quit)
            scr = Gdk.Screen.get_default()
            self.set_default_size(scr.get_width(), scr.get_height())
            self.fullscreen()
            if not os.environ.get("OSPRIME_INSTALLER_SHOTS"):
                threading.Thread(target=self._probe, daemon=True).start()
            self.build()

        # ---- helpers -------------------------------------------------------
        def t(self, key, **kw):
            return S.t(self.st["lang"], key, **kw)

        def label(self, text, cls=None, wrap=True, xalign=0.0, markup=False):
            l = Gtk.Label(xalign=xalign, wrap=wrap)
            l.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
            if markup:
                l.set_markup(text)
            else:
                l.set_text(text)
            if cls:
                for c in cls.split():
                    l.get_style_context().add_class(c)
            if xalign == 0.0:
                # START, not an x position: it turns around by itself in
                # right-to-left languages (Persian, Arabic), where a fixed
                # x of 0 pushed the side panel's words over its edge.
                l.set_halign(Gtk.Align.START)
            return l

        def _probe(self):
            m = probe()
            try:
                import compat
                c = compat.assess(compat.gather())
            except Exception as e:
                c = {"verdict": "yellow", "assistant": "", "items": [
                    {"status": "warn", "title": "Check", "text": str(e)}]}
            GLib.idle_add(self._probed, m, c)

        def _probed(self, m, c):
            self.machine, self.compat = m, c
            if self.st["enc_mode"] == "":
                self.st["enc_mode"] = ("tpm" if m.get("tpm") else "password") if m.get("uefi") else "none"
            if self.page in ("check", "disk", "enc"):
                self.show(self.page)
            return False

        # ---- the frame: sidebar + page + buttons ----------------------------
        def build(self):
            rtl = dict((l[0], l[2]) for l in S.LANGUAGES).get(self.st["lang"], False)
            Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL if rtl else Gtk.TextDirection.LTR)
            for child in self.get_children():
                self.remove(child)
            root = Gtk.Box()
            self.add(root)
            # The panel's colour sits on an outer box; the space around the
            # words sits on an inner one. A border width on the coloured box
            # itself is drawn outside the colour, so the words touched its edge.
            panel = Gtk.Box()
            panel.set_name("side")
            panel.set_size_request(260, -1)
            side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            side.set_border_width(28)
            panel.pack_start(side, True, True, 0)
            brand = Gtk.Label(label="OSprime")
            brand.set_halign(Gtk.Align.START)
            brand.set_name("brand")
            side.pack_start(brand, False, False, 18)
            self.nav = {}
            for key, text in self.NAV:
                l = self.label(self.t(text), "nav", wrap=False)
                self.nav[key] = l
                side.pack_start(l, False, False, 0)
            if DRY:
                side.pack_end(self.label(self.t("dry"), "warn"), False, False, 0)
            root.pack_start(panel, False, False, 0)

            main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            root.pack_start(main, True, True, 0)
            self.body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
            self.body.set_border_width(48)
            scroll = Gtk.ScrolledWindow(hexpand=True, vexpand=True)
            scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            scroll.add(self.body)
            main.pack_start(scroll, True, True, 0)
            bar = Gtk.Box(spacing=10)
            bar.set_border_width(24)
            self.quit_btn = Gtk.Button(label=self.t("quit"))
            self.quit_btn.connect("clicked", lambda *_: self.destroy())
            bar.pack_start(self.quit_btn, False, False, 0)
            self.next_btn = Gtk.Button(label=self.t("next"))
            self.next_btn.get_style_context().add_class("primary")
            self.next_btn.connect("clicked", lambda *_: self.go(1))
            bar.pack_end(self.next_btn, False, False, 0)
            self.back_btn = Gtk.Button(label=self.t("back"))
            self.back_btn.connect("clicked", lambda *_: self.go(-1))
            bar.pack_end(self.back_btn, False, False, 0)
            main.pack_start(bar, False, False, 0)
            self.show_all()
            self.show(self.page)

        def show(self, page):
            self.page = page
            for c in self.body.get_children():
                self.body.remove(c)
            order = [n for n, _ in self.NAV]
            here = order.index(page) if page in order else len(order)
            for i, key in enumerate(order):
                ctx = self.nav[key].get_style_context()
                for c in ("now", "done"):
                    ctx.remove_class(c)
                ctx.add_class("now" if i == here else "done" if i < here else "x")
            getattr(self, "page_" + page)()
            self.back_btn.set_visible(page in ("check", "disk", "you", "kb", "enc", "sum"))
            self.quit_btn.set_visible(not self.st["busy"] and page != "done")
            self.next_btn.set_visible(page not in ("inst",))
            self.body.show_all()
            self.validate()

        def go(self, d):
            if self.page == "sum" and d > 0:
                return self.start_install()
            if self.page == "key" and d > 0:
                if "ok" in self.st:
                    return self.finish()
                self.st["want_done"] = True       # the engine says done in a moment
                return
            if self.page == "done":
                return self.restart()
            i = self.PAGES.index(self.page) + d
            self.show(self.PAGES[max(0, i)])

        def validate(self, *_):
            p, ok = self.page, True
            if p == "check":
                ok = self.compat is not None and (self.compat["verdict"] != "red" or self.st["red_ok"])
            elif p == "disk":
                ok = bool(self.st.get("disk"))
            elif p == "you":
                ok, why = check_account(self.st.get("user", ""), self.st.get("password", ""),
                                        self.st.get("password2", ""))
                if hasattr(self, "you_msg"):
                    # Only once there is something to judge: no red text on
                    # an empty page.
                    show = ((why == "user_bad" and self.st.get("user"))
                            or (why == "pw_mismatch" and self.st.get("password2")))
                    pw = self.st.get("password", "")
                    self.you_msg.set_text(self.t(why) if show else
                                          (self.t("pw_weak") if ok and len(pw) < 8 else ""))
            elif p == "enc":
                ok, why = check_protection(self.st["enc_mode"], self.st.get("disk_pw", ""),
                                           self.st.get("disk_pw2", ""), self.st.get("pin", ""),
                                           self.st.get("pin2", ""))
                if hasattr(self, "enc_msg"):
                    self.enc_msg.set_text(self.t(why) if why and self.st.get("disk_pw") else "")
            elif p == "sum":
                ok = getattr(self, "erase", None) is not None and self.erase.get_text().strip() == "ERASE"
            elif p == "key":
                ok = self.st.get("key_ok", False)
            self.next_btn.set_sensitive(ok)
            self.next_btn.set_label(self.t({"sum": "install", "done": "restart"}.get(p, "next")))

        # ---- pages ---------------------------------------------------------
        def head(self, title, sub=""):
            self.body.pack_start(self.label(self.t(title), "title"), False, False, 0)
            if sub:
                self.body.pack_start(self.label(self.t(sub), "sub"), False, False, 0)

        def page_lang(self):
            self.head("lang_title", "lang_sub")
            grid = Gtk.FlowBox(max_children_per_line=4, min_children_per_line=2,
                               selection_mode=Gtk.SelectionMode.NONE, row_spacing=12, column_spacing=12)
            for code, name, _rtl, _kb in S.LANGUAGES:
                b = Gtk.Button(label=name)
                b.get_style_context().add_class("card")
                if code == self.st["lang"]:
                    b.get_style_context().add_class("on")
                b.set_size_request(200, 70)
                b.connect("clicked", self.pick_lang, code)
                grid.add(b)
            self.body.pack_start(grid, False, False, 12)

        def pick_lang(self, _b, code):
            self.st["lang"] = code
            kb = dict((l[0], l[3]) for l in S.LANGUAGES)[code]
            if kb != "en":
                self.st["kb"].add(kb)                       # their language, ready to type
            self.build()

        def page_check(self):
            self.head("check_title", "check_sub")
            c = self.compat
            if c is None:
                sp = Gtk.Spinner(active=True)
                box = Gtk.Box(spacing=10)
                box.pack_start(sp, False, False, 0)
                box.pack_start(self.label(self.t("checking"), "sub"), False, False, 0)
                self.body.pack_start(box, False, False, 10)
                return
            colour = {"green": "ok", "yellow": "warn", "red": "bad"}[c["verdict"]]
            self.body.pack_start(self.label("● " + self.t("verdict_" + c["verdict"]),
                                            "title " + colour), False, False, 6)
            if c.get("assistant"):
                self.body.pack_start(self.label(self.t("assistant_here", name=c["assistant"]), "sub"),
                                     False, False, 0)
            for it in c.get("items", []):
                mark = {"ok": "✓", "warn": "!", "bad": "✗"}[it["status"]]
                cls = {"ok": "ok", "warn": "warn", "bad": "bad"}[it["status"]]
                row = Gtk.Box(spacing=10)
                row.pack_start(self.label(mark, cls, wrap=False), False, False, 0)
                row.pack_start(self.label(f"{it['title']}: {it['text']}"), True, True, 0)
                self.body.pack_start(row, False, False, 0)
            if c["verdict"] == "red":
                cb = Gtk.CheckButton(label=self.t("verdict_red_ok"))
                cb.set_active(self.st["red_ok"])
                cb.connect("toggled", lambda w: (self.st.__setitem__("red_ok", w.get_active()), self.validate()))
                self.body.pack_start(cb, False, False, 10)

        def page_disk(self):
            self.head("disk_title", "disk_sub")
            disks = self.machine.get("disks", [])
            if not disks:
                self.body.pack_start(self.label(self.t("disk_none"), "bad"), False, False, 0)
                return
            # A hidden first button, so that no disk is chosen until the
            # person chooses one (a radio group always has one switched on).
            group = Gtk.RadioButton()
            for d in disks:
                busy = os.path.basename(d["path"]) in self.machine.get("in_use", [])
                text = f"{d.get('model') or d['name']}   —   {d['size_gb']:g} GB   ({d['path']})"
                if d.get("removable"):
                    text += "   · " + self.t("disk_removable")
                rb = Gtk.RadioButton.new_with_label_from_widget(group, text)
                group = group or rb
                rb.get_style_context().add_class("card")
                rb.set_sensitive(not busy)
                if busy:
                    rb.set_label(text + "\n" + self.t("disk_in_use"))
                rb.set_active(self.st.get("disk") == d["path"])
                rb.connect("toggled", self.pick_disk, d["path"])
                self.body.pack_start(rb, False, False, 0)
            free = [d for d in disks if os.path.basename(d["path"]) not in self.machine.get("in_use", [])]
            if not self.st.get("disk") and len(free) == 1:
                self.st["disk"] = free[0]["path"]
            if self.st.get("disk"):
                self.body.pack_start(self.label("⚠ " + self.t("disk_warn", disk=self.st["disk"]), "warn"),
                                     False, False, 10)

        def pick_disk(self, rb, path):
            if rb.get_active():
                self.st["disk"] = path
                self.show("disk")

        def entry(self, key, label, secret=False, hint=None, on_change=None):
            self.body.pack_start(self.label(self.t(label)), False, False, 0)
            e = Gtk.Entry(visibility=not secret, text=self.st.get(key, ""))
            e.set_input_purpose(Gtk.InputPurpose.PASSWORD if secret else Gtk.InputPurpose.FREE_FORM)

            def changed(w):
                self.st[key] = w.get_text()
                if on_change:
                    on_change(w.get_text())
                self.validate()
            e.connect("changed", changed)
            self.body.pack_start(e, False, False, 0)
            if hint:
                self.body.pack_start(self.label(self.t(hint), "sub"), False, False, 0)
            return e

        def page_you(self):
            self.head("you_title", "you_sub")
            self.user_entry = None

            def full_changed(text):
                if self.user_entry is not None and not self.st.get("user_typed"):
                    self.user_entry.set_text(suggest_username(text))
            self.entry("full", "full_name", on_change=full_changed)
            self.user_entry = self.entry("user", "user_name", hint="user_hint")
            self.user_entry.connect("key-press-event", lambda *_: self.st.__setitem__("user_typed", True))
            self.entry("password", "password", secret=True)
            self.entry("password2", "password_again", secret=True)
            self.you_msg = self.label("", "bad")
            self.body.pack_start(self.you_msg, False, False, 0)

        def page_kb(self):
            self.head("kb_title", "kb_sub")
            for code, name, _r, kb in S.LANGUAGES:
                cb = Gtk.CheckButton(label=name)
                cb.set_active(kb == "en" or kb in self.st["kb"])
                cb.set_sensitive(kb != "en")
                cb.connect("toggled", self.pick_kb, kb)
                self.body.pack_start(cb, False, False, 0)
            if "fa" in self.st["kb"]:
                self.body.pack_start(self.label(self.t("kb_persian_style")), False, False, 8)
                g = None
                for val, key in (("fa", "kb_win"), ("fa-isiri", "kb_isiri")):
                    rb = Gtk.RadioButton.new_with_label_from_widget(g, self.t(key))
                    g = g or rb
                    rb.set_active(self.st["kb_fa"] == val)
                    rb.connect("toggled", lambda w, v=val: w.get_active() and self.st.__setitem__("kb_fa", v))
                    self.body.pack_start(rb, False, False, 0)

        def pick_kb(self, cb, kb):
            (self.st["kb"].add if cb.get_active() else self.st["kb"].discard)(kb)
            if kb == "fa":
                self.show("kb")

        def page_enc(self):
            self.head("enc_title", "enc_sub")
            m = self.machine
            if not m.get("uefi"):
                self.st["enc_mode"] = "none"
                self.body.pack_start(self.label(self.t("enc_bios"), "warn"), False, False, 0)
                return
            modes = (["tpm", "tpm-pin", "password", "none"] if m.get("tpm")
                     else ["password", "none"])
            if not m.get("tpm"):
                self.body.pack_start(self.label(self.t("enc_notpm"), "sub"), False, False, 0)
            if self.st["enc_mode"] not in modes:
                self.st["enc_mode"] = modes[0]
            names = {"tpm": "enc_tpm", "tpm-pin": "enc_tpmpin", "password": "enc_pw", "none": "enc_none"}
            g = None
            for mode in modes:
                rb = Gtk.RadioButton.new_from_widget(g)
                g = g or rb
                box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
                box.pack_start(self.label(self.t(names[mode])), False, False, 0)
                box.pack_start(self.label(self.t(names[mode] + "_d"), "sub"), False, False, 0)
                rb.add(box)
                rb.get_style_context().add_class("card")
                rb.set_active(self.st["enc_mode"] == mode)
                rb.connect("toggled", self.pick_enc, mode)
                self.body.pack_start(rb, False, False, 0)
            if self.st["enc_mode"] != "none":
                self.entry("disk_pw", "disk_pw", secret=True, hint="disk_pw_hint")
                self.entry("disk_pw2", "password_again", secret=True)
                if self.st["enc_mode"] == "tpm-pin":
                    self.entry("pin", "pin", secret=True, hint="pin_hint")
                    self.entry("pin2", "password_again", secret=True)
            self.enc_msg = self.label("", "bad")
            self.body.pack_start(self.enc_msg, False, False, 0)

        def pick_enc(self, rb, mode):
            if rb.get_active() and self.st["enc_mode"] != mode:
                self.st["enc_mode"] = mode
                self.show("enc")

        def page_sum(self):
            self.head("sum_title")
            enc_names = {"tpm": "enc_tpm", "tpm-pin": "enc_tpmpin", "password": "enc_pw", "none": "enc_none"}
            lang_name = dict((l[0], l[1]) for l in S.LANGUAGES)[self.st["lang"]]
            kb_names = dict((l[3], l[1]) for l in S.LANGUAGES)
            rows = [("sum_lang", lang_name), ("sum_disk", self.st.get("disk", "")),
                    ("sum_user", f"{self.st.get('full') or ''} ({self.st.get('user', '')})"),
                    ("sum_kb", ", ".join(kb_names[k] for k in ["en"] + sorted(self.st["kb"]))),
                    ("sum_enc", self.t(enc_names[self.st["enc_mode"]]))]
            grid = Gtk.Grid(row_spacing=8, column_spacing=24)
            for i, (k, v) in enumerate(rows):
                grid.attach(self.label(self.t(k), "sub", wrap=False), 0, i, 1, 1)
                grid.attach(self.label(v, wrap=True), 1, i, 1, 1)
            self.body.pack_start(grid, False, False, 8)
            self.body.pack_start(self.label("⚠ " + self.t("erase_hint", disk=self.st.get("disk", "")),
                                            "warn"), False, False, 12)
            self.erase = Gtk.Entry(placeholder_text="ERASE")
            self.erase.connect("changed", self.validate)
            self.body.pack_start(self.erase, False, False, 0)

        def page_inst(self):
            self.head("inst_title", "inst_sub")
            self.step_label = self.label("", "sub")
            self.body.pack_start(self.step_label, False, False, 8)
            self.bar = Gtk.ProgressBar()
            self.body.pack_start(self.bar, False, False, 0)
            self.details = Gtk.Expander(label=self.t("details"))
            tv = Gtk.TextView(editable=False, cursor_visible=False, wrap_mode=Gtk.WrapMode.CHAR)
            self.logbuf = tv.get_buffer()
            self.logbuf.set_text("\n".join(self.log))
            sw = Gtk.ScrolledWindow(min_content_height=260)
            sw.add(tv)
            self.details.add(sw)
            self.body.pack_start(self.details, True, True, 12)

        def page_key(self):
            self.head("key_title", "key_sub")
            self.body.pack_start(self.label(self.st.get("key", ""), "key", xalign=0.5), False, False, 12)
            self.body.pack_start(self.label(self.t("key_note"), "sub"), False, False, 0)
            self.body.pack_start(self.label(self.t("key_type")), False, False, 10)
            row = Gtk.Box(spacing=10)
            self.key_entry = Gtk.Entry(hexpand=True)
            row.pack_start(self.key_entry, True, True, 0)
            chk = Gtk.Button(label=self.t("key_check"))
            chk.connect("clicked", self.check_key)
            self.key_entry.connect("activate", self.check_key)
            row.pack_start(chk, False, False, 0)
            self.body.pack_start(row, False, False, 0)
            self.key_msg = self.label("", "sub")
            self.body.pack_start(self.key_msg, False, False, 0)

        def page_done(self):
            ok = self.st.get("ok")
            self.head("done_title" if ok else "fail_title", "done_sub" if ok else "fail_sub")
            if ok and self.st.get("secure_boot") in ("now", "later", "failed"):
                self.body.pack_start(self.label(self.t("sb_now" if self.st["secure_boot"] == "now"
                                                       else "sb_later"), "sub"), False, False, 8)
            if not ok:
                if self.st.get("error"):
                    self.body.pack_start(self.label(self.st["error"], "bad"), False, False, 6)
                exp = Gtk.Expander(label=self.t("details"), expanded=True)
                tv = Gtk.TextView(editable=False)
                tv.get_buffer().set_text("\n".join(self.log[-400:]))
                sw = Gtk.ScrolledWindow(min_content_height=320)
                sw.add(tv)
                exp.add(sw)
                self.body.pack_start(exp, True, True, 8)
                self.next_btn.set_label(self.t("close"))

        # ---- the engine ------------------------------------------------------
        def start_install(self):
            self.st["busy"] = True
            self.show("inst")
            try:
                if not DRY and os.geteuid() != 0 and subprocess.run(
                        ["sudo", "-n", "true"], capture_output=True).returncode != 0:
                    raise RuntimeError(self.t("no_root"))
                self.engine = subprocess.Popen(engine_command(), stdin=subprocess.PIPE,
                                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                               text=True, bufsize=1)
                self.engine.stdin.write(json.dumps(build_answers(self.st)) + "\n")
                self.engine.stdin.flush()
            except Exception as e:
                self.event({"event": "done", "ok": False, "error": str(e)})
                return
            # the passwords are not kept any longer than needed
            for k in ("password", "password2", "disk_pw", "disk_pw2", "pin", "pin2"):
                self.st.pop(k, None)
            threading.Thread(target=self.read_engine, daemon=True).start()

        def read_engine(self):
            for line in self.engine.stdout:
                try:
                    ev = json.loads(line)
                except ValueError:
                    ev = {"event": "log", "line": line.rstrip()}
                GLib.idle_add(self.event, ev)
            code = self.engine.wait()
            GLib.idle_add(self.event, {"event": "exit", "code": code})

        def event(self, ev):
            kind = ev.get("event")
            if kind == "log":
                self.log.append(ev.get("line", ""))
                if self.page == "inst":
                    self.logbuf.insert(self.logbuf.get_end_iter(), ev.get("line", "") + "\n")
            elif kind == "step" and self.page == "inst":
                self.step_n, self.step_of = ev["n"], ev["of"]
                self.step_label.set_text(f"{ev['n']} / {ev['of']} — " + self.t("st_" + ev["key"]))
                self.bar.set_fraction((ev["n"] - 1) / ev["of"])
            elif kind == "progress" and self.page == "inst":
                n, of = getattr(self, "step_n", 1), getattr(self, "step_of", 8)
                self.bar.set_fraction((n - 1 + ev["pct"] / 100) / of)
            elif kind == "recovery_key":
                self.st["key"] = ev.get("key", "")
                if ev.get("dry"):
                    self.st["key_ok"] = True
                    self.st["key"] = "abcdefgh-" * 7 + "abcdefgh"
                self.show("key")
            elif kind == "recovery_check":
                if ev.get("ok"):
                    self.st["key_ok"] = True
                    self.key_msg.set_text(self.t("key_ok"))
                    self.key_msg.get_style_context().add_class("ok")
                else:
                    g = ev.get("groups") or []
                    self.key_msg.set_text(self.t("key_bad", groups=", ".join(map(str, g))) if g
                                          else self.t("key_bad_len") if ev.get("length", 8) != 8
                                          else self.t("key_disk"))
                    self.key_msg.get_style_context().add_class("bad")
                self.validate()
            elif kind == "done":
                self.st.update(ok=bool(ev.get("ok")), secure_boot=ev.get("secure_boot"),
                               error=ev.get("error", ""))
                if self.page != "key" or self.st.get("want_done"):
                    self.finish()
            elif kind == "exit":
                if "ok" not in self.st:
                    self.st.update(ok=False, error=self.st.get("error") or f"exit {ev['code']}")
                    self.finish()
            return False

        def finish(self):
            self.st["busy"] = False
            self.show("done")

        def check_key(self, *_):
            if self.engine and self.engine.poll() is None:
                self.engine.stdin.write(json.dumps({"recovery": self.key_entry.get_text()}) + "\n")
                self.engine.stdin.flush()
            elif self.st.get("key_ok"):
                self.validate()

        def restart(self):
            if not self.st.get("ok"):
                return self.destroy()
            if DRY:
                return self.destroy()
            subprocess.Popen(["sudo", "-n", "systemctl", "reboot"])

    win = Installer()
    if os.environ.get("OSPRIME_INSTALLER_SHOTS"):
        _shots(win, GLib, Gdk)
    Gtk.main()
    return 0


def _shots(win, GLib, Gdk):
    """For the tests and the docs: every page with sample answers, saved as
    PNG into $OSPRIME_INSTALLER_SHOTS. Never writes to a disk."""
    out = pathlib.Path(os.environ["OSPRIME_INSTALLER_SHOTS"])
    out.mkdir(parents=True, exist_ok=True)
    lang = os.environ.get("OSPRIME_INSTALLER_SHOT_LANG", "en")
    win.machine = {"disks": [{"name": "nvme0n1", "path": "/dev/nvme0n1", "size_gb": 1024.2,
                              "model": "Samsung SSD 990 PRO", "removable": False},
                             {"name": "sda", "path": "/dev/sda", "size_gb": 32.0,
                              "model": "SanDisk Ultra", "removable": True}],
                   "in_use": ["sda"], "uefi": True, "tpm": True}
    win.compat = {"verdict": "green", "assistant": "Qwen3.5 9B",
                  "items": [{"status": "ok", "title": "Processor", "text": "Intel Core Ultra 9 185H (22 cores)"},
                            {"status": "ok", "title": "Memory", "text": "32 GB"},
                            {"status": "ok", "title": "Graphics", "text": "NVIDIA GeForce RTX 4070 (8 GB)"},
                            {"status": "warn", "title": "Camera", "text": "Not found"}]}
    win.st.update(lang=lang, enc_mode="tpm", disk="/dev/nvme0n1", full="Sara Ahmadi", user="sara",
                  password="secret12", password2="secret12", disk_pw="x", disk_pw2="x")
    kb = dict((l[0], l[3]) for l in S.LANGUAGES)[lang]
    if kb != "en":
        win.st["kb"].add(kb)
    win.build()
    pages = ["lang", "check", "disk", "you", "kb", "enc", "sum", "inst", "key", "done"]

    def snap(i=[0]):
        if i[0] > 0:
            w = win.get_window()
            pb = Gdk.pixbuf_get_from_window(w, 0, 0, w.get_width(), w.get_height())
            pb.savev(str(out / f"{lang}-{i[0]:02d}-{pages[i[0] - 1]}.png"), "png", [], [])
        if i[0] >= len(pages):
            win.destroy()
            return False
        page = pages[i[0]]
        if page == "inst":
            win.st["busy"] = True
        if page == "key":
            win.st["key"] = "fkrtjvnc-hbdlgiuv-ecnhrtkd-ijgvlbet-ndhkfuvr-tclgibek-vrhnjdfu-lteikbcg"
        if page == "done":
            win.st.update(ok=True, secure_boot="now", busy=False)
        win.show(page)
        if page == "inst":
            win.event({"event": "step", "key": "copy", "n": 3, "of": 8})
            win.event({"event": "progress", "pct": 42})
        i[0] += 1
        return True
    GLib.timeout_add(800, snap)


if __name__ == "__main__":
    try:
        sys.exit(run())
    except Exception as e:                 # no GTK: the caller falls back to text
        print(f"graphical installer could not start: {e}", file=sys.stderr)
        sys.exit(3)
